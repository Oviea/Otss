﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class dankongzhuangtai : Form
    {
        private static int allshebei_A,allshebei_B;
        private int n, k, m, p;
        private static string[] shebei_A,shebei_B;
        private static int clickcount_A, clickcount_B;
        private bool Ap, Bp;
        private void A_AreaR_Click(object sender, EventArgs e)
        {
            clickcount_A++;
            if (ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A == 0)
            {
                MessageBox.Show("没有更多A区设备！");
                // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                clickcount_A--;
            }
            else
            {
                delpanelall();
                if (ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A < 16)
                {

                    if (0 <= ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A && ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A <= 8)
                    {
                        for (int i = 0; i < ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A; i++)
                        {
                            
                            panelset(290, 150 + 50 * i, shebei_A[16 * clickcount_A + i],"A");
                        }
                    }
                    else if (ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A > 8 && ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A <= 16)
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            panelset(290, 150 + 50 * i, shebei_A[16 * clickcount_A + i], "A");
                        }
                        for (int i = 8; i < ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A; i++)
                        {
                            panelset(590, 150 + 50 * (i - 8), shebei_A[16 * clickcount_A + i], "A");
                        }
                    }
                                   
                    ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A = 0;
                }
                else
                {
                    for (int i = 0; i < 8; i++)
                    {
                        panelset(290, 150 + 50 * i, shebei_A[16 * clickcount_A + i], "A");
                    }
                    for (int i = 8; i < 16; i++)
                    {
                        panelset(590, 150 + 50 * (i - 8), shebei_A[16 * clickcount_A + i], "A");
                    }
                    ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A = ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A - 16;
                }
            }
        }

        private void B_AreaL_Click(object sender, EventArgs e)
        {
            clickcount_B--;
            if (ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B >= allshebei_B - 16)
            {
                MessageBox.Show("没有更多B区设备！");
                clickcount_B++;
                //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
            }
            else
            {
                delpanelall();
                for (int i = 0; i < 8; i++)
                {
                    panelset(1030, 150 + 50 * i, shebei_B[i], "B");
                }

                for (int i = 8; i < 16; i++)
                {
                    panelset(1330, 150 + 50 * (i - 8), shebei_B[i], "B");
                }
                if (ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B == 0)
                {
                    if (allshebei_B % 16 == 0)
                    {
                        ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B = 16;
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B = allshebei_B % 16;
                    }
                }
                else
                {
                    ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B = ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B + 16;
                }
            }
        }

        private void B_AreaR_Click(object sender, EventArgs e)
        {
            clickcount_B++;
            if (ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B == 0)
            {
                MessageBox.Show("没有更多B区设备！");
                // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                clickcount_B--;
            }
            else
            {
                delpanelall();
                if (ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B < 16)
                {

                    if (0 <= ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B && ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B <= 8)
                    {
                        for (int i = 0; i < ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B; i++)
                        {

                            panelset(1030, 150 + 50 * i, shebei_B[16 * clickcount_B + i], "B");
                        }
                    }
                    else if (ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B > 8 && ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B <= 16)
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            panelset(1030, 150 + 50 * i, shebei_B[16 * clickcount_B + i], "B");
                        }
                        for (int i = 8; i < ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B; i++)
                        {
                            panelset(1330, 150 + 50 * (i - 8), shebei_B[16 * clickcount_B + i], "B");
                        }
                    }

                    ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B = 0;
                }
                else
                {
                    for (int i = 0; i < 8; i++)
                    {
                        panelset(1030, 150 + 50 * i, shebei_B[16 * clickcount_B + i], "B");
                    }
                    for (int i = 8; i < 16; i++)
                    {
                        panelset(1330, 150 + 50 * (i - 8), shebei_B[16 * clickcount_B + i], "B");
                    }
                    ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B = ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B - 16;
                }
            }
        }

        private void Back_2_DKXZ_Click(object sender, EventArgs e)
        {
            var frm = new dankong();
            frm.Show();
            this.Close();
        }

        private void DkZT_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DKZT_2Main_Click(object sender, EventArgs e)
        {
            var frm = new main();
            frm.Show();
            this.Close();
        }


        private void A_AreaL_Click(object sender, EventArgs e)
        {
            clickcount_A--;
            if (ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A >= allshebei_A - 16)
            {
                MessageBox.Show("没有更多A区设备！");
                clickcount_A++;
                //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
            }
            else
            {
                delpanelall();
                for (int i = 0; i < 8; i++)
                {
                    panelset(290, 150 + 50 * i, shebei_A[i], "A");
                }

                for (int i = 8; i < 16; i++)
                {
                    panelset(590, 150 + 50 * (i - 8), shebei_A[i], "A");
                }
                if (ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A == 0)
                {
                    if (allshebei_A % 16 == 0)
                    {
                        ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A = 16;
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A = allshebei_A % 16;
                    }
                }
                else
                {
                    ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A = ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A + 16;
                }
            }
        }

        public dankongzhuangtai()
        {
            InitializeComponent();
        }

        private void dankongzhuangtai_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
            List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
            n = int.Parse(nkmp[0]);
            k = int.Parse(nkmp[1]);
            m = int.Parse(nkmp[2]);
            p = int.Parse(nkmp[3]);
            int totalshebei_A = 0;
                if (ChangCiSheZhiGlobalData.A_SheBei != null)
                {
                    for (int i = 0; i < ChangCiSheZhiGlobalData.A_SheBei.Length; i++)
                    {
                        if (ChangCiSheZhiGlobalData.A_SheBei[i] == true)
                        {
                            totalshebei_A++;
                        }
                    }
                    if (totalshebei_A != 0)
                    {
                        allshebei_A = totalshebei_A;
                        nkmp.Clear();
                        for (int i = 0; i < n; i++)
                        {
                            int j = i + 1;
                            if (ChangCiSheZhiGlobalData.A_SheBei[j] == true)
                            {
                                nkmp.Add("调速设备" + j);
                            }
                        }
                        for (int i = n; i < n + k; i++)
                        {
                            int j = i + 1 - n;
                            if (ChangCiSheZhiGlobalData.A_SheBei[j] == true)
                            {
                                nkmp.Add("调速互锁类设备" + j);
                            }
                        }
                        for (int i = n + k; i < n + k + m; i++)
                        {
                            int j = i + 1 - n - k;
                            if (ChangCiSheZhiGlobalData.A_SheBei[j] == true)
                            {
                                nkmp.Add("定速定位设备" + j);
                            }
                        }
                        for (int i = n + k + m; i < n + k + m + p; i++)
                        {
                            int j = i + 1 - n - k - m;
                            if (ChangCiSheZhiGlobalData.A_SheBei[j] == true)
                            {
                                nkmp.Add("定速设备" + j);
                            }
                        }
                        shebei_A = nkmp.ToArray();
                        //for(int i = 0; i < shebei.Length; i++)
                        //{
                        //    Console.WriteLine("++++++=+==" + shebei[i]);
                        //}
                        if (totalshebei_A <= 16)
                        {
                            if (0 <= totalshebei_A && totalshebei_A <= 8)
                            {
                                for (int i = 0; i < totalshebei_A; i++)
                                {
                                    panelset(290, 150 + 50 * i, shebei_A[i], "A");
                                }
                            }
                            else
                            {
                                for (int i = 0; i < 8; i++)
                                {
                                    panelset(290, 150 + 50 * i, shebei_A[i], "A");
                                }

                                for (int i = 8; i < totalshebei_A; i++)
                                {
                                    panelset(590, 150 + 50 * (i - 8), shebei_A[i], "A");
                                }
                            }
                            ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A = 0;
                        }
                        else
                        {
                            for (int i = 0; i < 8; i++)
                            {
                                panelset(290, 150 + 50 * i, shebei_A[i], "A");
                            }

                            for (int i = 8; i < 16; i++)
                            {
                                panelset(590, 150 + 50 * (i - 8), shebei_A[i], "A");
                            }
                            ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_A = totalshebei_A - 16;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("尚未有设备处于A区");
                }

                int totalshebei_B = 0;
                if (ChangCiSheZhiGlobalData.B_SheBei != null) { 
                for (int i = 0; i < ChangCiSheZhiGlobalData.B_SheBei.Length; i++)
                {
                    if (ChangCiSheZhiGlobalData.B_SheBei[i] == true)
                    {
                        totalshebei_B++;
                    }
                }
                    if (totalshebei_B != 0)
                    {
                        allshebei_B = totalshebei_B;
                        nkmp.Clear();
                        for (int i = 0; i < n; i++)
                        {
                            int j = i + 1;
                            if (ChangCiSheZhiGlobalData.B_SheBei[j] == true)
                            {
                                nkmp.Add("调速设备" + j);
                            }
                        }
                        for (int i = n; i < n + k; i++)
                        {
                            int j = i + 1;
                            if (ChangCiSheZhiGlobalData.B_SheBei[j] == true)
                            {
                                nkmp.Add("调速互锁类设备" + j);
                            }
                        }
                        for (int i = n + k; i < n + k + m; i++)
                        {
                            int j = i + 1;
                            if (ChangCiSheZhiGlobalData.B_SheBei[j] == true)
                            {
                                nkmp.Add("定速定位设备" + j);
                            }
                        }
                        for (int i = n + k + m; i < n + k + m + p; i++)
                        {
                            int j = i + 1;
                            if (ChangCiSheZhiGlobalData.B_SheBei[j] == true)
                            {
                                nkmp.Add("定速设备" + j);
                            }
                        }
                        shebei_B = nkmp.ToArray();

                        if (totalshebei_B <= 16)
                        {
                            if (0 <= totalshebei_B && totalshebei_B <= 8)
                            {
                                for (int i = 0; i < totalshebei_B; i++)
                                {
                                    panelset(1030, 150 + 50 * i, shebei_B[i], "B");
                                }
                            }
                            else
                            {
                                for (int i = 0; i < 8; i++)
                                {
                                    panelset(1030, 150 + 50 * i, shebei_B[i], "B");
                                }

                                for (int i = 8; i < totalshebei_B; i++)
                                {
                                    panelset(1330, 150 + 50 * (i - 8), shebei_B[i], "B");
                                }
                            }
                            ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B = 0;
                        }
                        else
                        {
                            for (int i = 0; i < 8; i++)
                            {
                                panelset(1030, 150 + 50 * i, shebei_B[i], "B");
                            }

                            for (int i = 8; i < 16; i++)
                            {
                                panelset(1330, 150 + 50 * (i - 8), shebei_B[i], "B");
                            }
                            ChangCiSheZhiGlobalData.DanKongZhuangTaiShengYuSheBei_B = totalshebei_B - 16;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("尚未有设备处于B区");
                }
            }
            panelsetA1("   ");
            panelsetA2("   ");
            panelsetB1("   ");
            panelsetB2("   ");
        }

        private void delpanelall()
        {
            if (Controls["SheBeiZhuangTai_Panel290150"] != null)
            {
                Controls["SheBeiZhuangTai_Panel290150"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel290200"] != null)
            {
                Controls["SheBeiZhuangTai_Panel290200"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel290250"] != null)
            {
                Controls["SheBeiZhuangTai_Panel290250"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel290300"] != null)
            {
                Controls["SheBeiZhuangTai_Panel290300"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel290350"] != null)
            {
                Controls["SheBeiZhuangTai_Panel290350"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel290400"] != null)
            {
                Controls["SheBeiZhuangTai_Panel290400"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel290450"] != null)
            {
                Controls["SheBeiZhuangTai_Panel290450"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel290500"] != null)
            {
                Controls["SheBeiZhuangTai_Panel290500"].Dispose();
            }



            if (Controls["SheBeiZhuangTai_Panel590150"] != null)
            {
                Controls["SheBeiZhuangTai_Panel590150"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel590200"] != null)
            {
                Controls["SheBeiZhuangTai_Panel590200"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel590250"] != null)
            {
                Controls["SheBeiZhuangTai_Panel590250"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel590300"] != null)
            {
                Controls["SheBeiZhuangTai_Panel590300"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel590350"] != null)
            {
                Controls["SheBeiZhuangTai_Panel590350"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel590400"] != null)
            {
                Controls["SheBeiZhuangTai_Panel590400"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel590450"] != null)
            {
                Controls["SheBeiZhuangTai_Panel590450"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel590500"] != null)
            {
                Controls["SheBeiZhuangTai_Panel590500"].Dispose();
            }


            if (Controls["SheBeiZhuangTai_Panel1030150"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1030150"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1030200"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1030200"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1030250"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1030250"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1030300"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1030300"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1030350"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1030350"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1030400"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1030400"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1030450"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1030450"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1030500"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1030500"].Dispose();
            }

            if (Controls["SheBeiZhuangTai_Panel1330150"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1330150"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1330200"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1330200"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1330250"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1330250"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1330300"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1330300"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1330350"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1330350"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1330400"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1330400"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1330450"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1330450"].Dispose();
            }
            if (Controls["SheBeiZhuangTai_Panel1330500"] != null)
            {
                Controls["SheBeiZhuangTai_Panel1330500"].Dispose();
            }
        }

        private void panelset(int x, int y, string shebeiname,string AorB)
        {

            // 
            // Shebei_DanKong
            // 
            Button Shebei_DanKongZhuangTai = new Button();
            Shebei_DanKongZhuangTai.Font = new System.Drawing.Font("宋体", 10F);
            // Shebei_DanKongXuanZe.Location = new System.Drawing.Point(1660, 550);
            Shebei_DanKongZhuangTai.Margin = new System.Windows.Forms.Padding(2);
            Shebei_DanKongZhuangTai.Name = shebeiname + x + y;
            Shebei_DanKongZhuangTai.Size = new System.Drawing.Size(90, 40);
            Shebei_DanKongZhuangTai.Text = shebeiname;
            Shebei_DanKongZhuangTai.UseVisualStyleBackColor = true;
            Shebei_DanKongZhuangTai.Click += (e, a) => this.Shebei_DanKongZhuangTai(shebeiname,AorB);
            // 


            Panel SheBeiZhuangTai_Panel = new Panel();
            SheBeiZhuangTai_Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SheBeiZhuangTai_Panel.Controls.Add(Shebei_DanKongZhuangTai);
            SheBeiZhuangTai_Panel.Location = new System.Drawing.Point(x, y);
            SheBeiZhuangTai_Panel.Margin = new System.Windows.Forms.Padding(2);
            SheBeiZhuangTai_Panel.Name = "SheBeiZhuangTai_Panel" + x + y;
            SheBeiZhuangTai_Panel.Size = new System.Drawing.Size(91, 41);
            this.Controls.Add(SheBeiZhuangTai_Panel);
        }

        private void Shebei_DanKongZhuangTai(string shebeiname,string AorB)
        { 
            if (AorB == "A") {
                if (Ap == false)
                {
                    delA1();
                    panelsetA1(shebeiname);
                    Ap = true;
                }
                else
                {
                    delA2();
                    panelsetA2(shebeiname);
                    Ap = false;
                }
            }
            else
            {
                if (Bp == false)
                {
                    delB1();
                    panelsetB1(shebeiname);
                    Bp = true;
                }
                else
                {
                    delB2();
                    panelsetB2(shebeiname);
                    Bp = false;
                }
            }
        }
        private void delA1()
        {
            if (Controls["SheBei_PanelA1"] != null)
            {
                Controls["SheBei_PanelA1"].Dispose();
            }
        }
        private void delA2()
        {
            if (Controls["SheBei_PanelA2"] != null)
            {
                Controls["SheBei_PanelA2"].Dispose();
            }
        }
        private void delB1()
        {
            if (Controls["SheBei_PanelB1"] != null)
            {
                Controls["SheBei_PanelB1"].Dispose();
            }
        }
        private void delB2()
        {
            if (Controls["SheBei_PanelB2"] != null)
            {
                Controls["SheBei_PanelB2"].Dispose();
            }
        }
        private void panelsetA1(string shebeiname)
        {

            // 
            // Shebei_DanKong
            // 
            Button Shebei_NameA1 = new Button();
            Shebei_NameA1.Font = new System.Drawing.Font("宋体", 12F);
            Shebei_NameA1.Margin = new System.Windows.Forms.Padding(2);
            Shebei_NameA1.Location= new System.Drawing.Point(9, 10);
            Shebei_NameA1.Name = shebeiname+"A1";
            Shebei_NameA1.Size = new System.Drawing.Size(158, 40);
            Shebei_NameA1.Text = shebeiname;
            Shebei_NameA1.TabIndex = 204;
            Shebei_NameA1.UseVisualStyleBackColor = true;
            // 
            Button A1YX4 = new Button();
            A1YX4.Font = new System.Drawing.Font("宋体", 14.2F);
            A1YX4.Location = new System.Drawing.Point(110, 182);
            A1YX4.Margin = new System.Windows.Forms.Padding(2);
            A1YX4.Name = "A1YX4";
            A1YX4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            A1YX4.Size = new System.Drawing.Size(56, 40);
            A1YX4.TabIndex = 217;
            A1YX4.Text = "有效";
            A1YX4.UseVisualStyleBackColor = true;
            // 
            // A1XDWZ
            // 
            Button A1XDWZ = new Button();
            A1XDWZ.Font = new System.Drawing.Font("宋体", 14.2F);
            A1XDWZ.Location = new System.Drawing.Point(9, 182);
            A1XDWZ.Margin = new System.Windows.Forms.Padding(2);
            A1XDWZ.Name = "A1XDWZ";
            A1XDWZ.Size = new System.Drawing.Size(90, 40);
            A1XDWZ.TabIndex = 216;
            A1XDWZ.Text = "相对";
            A1XDWZ.UseVisualStyleBackColor = true;
            // 
            // A1YX3
            // 
            Button A1YX3 = new Button();
            A1YX3.Font = new System.Drawing.Font("宋体", 14.2F);
            A1YX3.Location = new System.Drawing.Point(110, 139);
            A1YX3.Margin = new System.Windows.Forms.Padding(2);
            A1YX3.Name = "A1YX3";
            A1YX3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            A1YX3.Size = new System.Drawing.Size(56, 40);
            A1YX3.TabIndex = 215;
            A1YX3.Text = "有效";
            A1YX3.UseVisualStyleBackColor = true;
            // 
            // A1JDWZ
            // 
            Button A1JDWZ = new Button();
            A1JDWZ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            A1JDWZ.Location = new System.Drawing.Point(9, 140);
            A1JDWZ.Margin = new System.Windows.Forms.Padding(2);
            A1JDWZ.Name = "A1JDWZ";
            A1JDWZ.Size = new System.Drawing.Size(90, 40);
            A1JDWZ.TabIndex = 214;
            A1JDWZ.Text = "绝对位置";
            A1JDWZ.UseVisualStyleBackColor = true;
            // 
            // A1YX2
            // 
            Button A1YX2 = new Button();
            A1YX2.Font = new System.Drawing.Font("宋体", 14.2F);
            A1YX2.Location = new System.Drawing.Point(110, 97);
            A1YX2.Margin = new System.Windows.Forms.Padding(2);
            A1YX2.Name = "A1YX2";
            A1YX2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            A1YX2.Size = new System.Drawing.Size(56, 40);
            A1YX2.TabIndex = 213;
            A1YX2.Text = "有效";
            A1YX2.UseVisualStyleBackColor = true;
            // 
            // A1Wz2
            // 
            Button A1Wz2 = new Button();
            A1Wz2.Font = new System.Drawing.Font("宋体", 14.2F);
            A1Wz2.Location = new System.Drawing.Point(9, 97);
            A1Wz2.Margin = new System.Windows.Forms.Padding(2);
            A1Wz2.Name = "A1Wz2";
            A1Wz2.Size = new System.Drawing.Size(90, 40);
            A1Wz2.TabIndex = 212;
            A1Wz2.Text = "位置2";
            A1Wz2.UseVisualStyleBackColor = true;
            // 
            // A1YX1
            // 
            Button A1YX1 = new Button();
            A1YX1.Font = new System.Drawing.Font("宋体", 14.2F);
            A1YX1.Location = new System.Drawing.Point(110, 54);
            A1YX1.Margin = new System.Windows.Forms.Padding(2);
            A1YX1.Name = "A1YX1";
            A1YX1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            A1YX1.Size = new System.Drawing.Size(56, 40);
            A1YX1.TabIndex = 211;
            A1YX1.Text = "有效";
            A1YX1.UseVisualStyleBackColor = true;
            // 
            // A1Wz1
            // 
            Button A1Wz1 = new Button();
            A1Wz1.Font = new System.Drawing.Font("宋体", 14.2F);
            A1Wz1.Location = new System.Drawing.Point(9, 54);
            A1Wz1.Margin = new System.Windows.Forms.Padding(2);
            A1Wz1.Name = "A1Wz1";
            A1Wz1.Size = new System.Drawing.Size(90, 40);
            A1Wz1.TabIndex = 210;
            A1Wz1.Text = "位置1";
            A1Wz1.UseVisualStyleBackColor = true;
            // 
            // A1Wzr5
            //
            Button A1Wzr5 = new Button();
            A1Wzr5.Font = new System.Drawing.Font("宋体", 14.2F);
            A1Wzr5.Location = new System.Drawing.Point(178, 183);
            A1Wzr5.Margin = new System.Windows.Forms.Padding(2);
            A1Wzr5.Name = "A1Wzr5";
            A1Wzr5.Size = new System.Drawing.Size(75, 40);
            A1Wzr5.TabIndex = 209;
            A1Wzr5.Text = "位置";
            A1Wzr5.UseVisualStyleBackColor = true;
            // 
            // A1Wzr4
            // 
            Button A1Wzr4 = new Button();
            A1Wzr4.Font = new System.Drawing.Font("宋体", 14.2F);
            A1Wzr4.Location = new System.Drawing.Point(178, 139);
            A1Wzr4.Margin = new System.Windows.Forms.Padding(2);
            A1Wzr4.Name = "A1Wzr4";
            A1Wzr4.Size = new System.Drawing.Size(75, 40);
            A1Wzr4.TabIndex = 208;
            A1Wzr4.Text = "位置";
            A1Wzr4.UseVisualStyleBackColor = true;
            // 
            // A1Wzr3
            // 
            Button A1Wzr3 = new Button();
            A1Wzr3.Font = new System.Drawing.Font("宋体", 14.2F);
            A1Wzr3.Location = new System.Drawing.Point(178, 97);
            A1Wzr3.Margin = new System.Windows.Forms.Padding(2);
            A1Wzr3.Name = "A1Wzr3";
            A1Wzr3.Size = new System.Drawing.Size(75, 40);
            A1Wzr3.TabIndex = 207;
            A1Wzr3.Text = "位置";
            A1Wzr3.UseVisualStyleBackColor = true;
            // 
            // A1Wzr2
            // 
            Button A1Wzr2 = new Button();
            A1Wzr2.Font = new System.Drawing.Font("宋体", 14.2F);
            A1Wzr2.Location = new System.Drawing.Point(178, 54);
            A1Wzr2.Margin = new System.Windows.Forms.Padding(2);
            A1Wzr2.Name = "A1Wzr2";
            A1Wzr2.Size = new System.Drawing.Size(75, 40);
            A1Wzr2.TabIndex = 206;
            A1Wzr2.Text = "位置";
            A1Wzr2.UseVisualStyleBackColor = true;
            // 
            // A1Wzr1
            // 
            Button A1Wzr1 = new Button();
            A1Wzr1.Font = new System.Drawing.Font("宋体", 14.2F);
            A1Wzr1.Location = new System.Drawing.Point(178, 10);
            A1Wzr1.Margin = new System.Windows.Forms.Padding(2);
            A1Wzr1.Name = "A1Wzr1";
            A1Wzr1.Size = new System.Drawing.Size(75, 40);
            A1Wzr1.TabIndex = 205;
            A1Wzr1.Text = "位置";
            A1Wzr1.UseVisualStyleBackColor = true;

            Panel SheBei_PanelA1 = new Panel();
            SheBei_PanelA1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SheBei_PanelA1.Controls.Add(Shebei_NameA1);
            SheBei_PanelA1.Controls.Add(A1YX4);
            SheBei_PanelA1.Controls.Add(A1XDWZ);
            SheBei_PanelA1.Controls.Add(A1YX3);
            SheBei_PanelA1.Controls.Add(A1JDWZ);
            SheBei_PanelA1.Controls.Add(A1YX2);
            SheBei_PanelA1.Controls.Add(A1Wz2);
            SheBei_PanelA1.Controls.Add(A1YX1);
            SheBei_PanelA1.Controls.Add(A1Wz1);
            SheBei_PanelA1.Controls.Add(A1Wzr5);
            SheBei_PanelA1.Controls.Add(A1Wzr4);
            SheBei_PanelA1.Controls.Add(A1Wzr3);
            SheBei_PanelA1.Controls.Add(A1Wzr2);
            SheBei_PanelA1.Controls.Add(A1Wzr1);
            SheBei_PanelA1.Location = new System.Drawing.Point(285,585);
            SheBei_PanelA1.Margin = new System.Windows.Forms.Padding(2);
            SheBei_PanelA1.Name = "SheBei_PanelA1";
            SheBei_PanelA1.Size = new System.Drawing.Size(263, 232);
            this.Controls.Add(SheBei_PanelA1);
        }


        private void panelsetA2(string shebeiname)
        {

            // 
            // Shebei_DanKong
            // 
            Button Shebei_NameA2 = new Button();
            Shebei_NameA2.Font = new System.Drawing.Font("宋体", 12F);
            Shebei_NameA2.Margin = new System.Windows.Forms.Padding(2);
            Shebei_NameA2.Location = new System.Drawing.Point(9, 10);
            Shebei_NameA2.Name = shebeiname + "A2";
            Shebei_NameA2.Size = new System.Drawing.Size(158, 40);
            Shebei_NameA2.Text = shebeiname;
            Shebei_NameA2.TabIndex = 204;
            Shebei_NameA2.UseVisualStyleBackColor = true;
            // 
            Button A2YX4 = new Button();
            A2YX4.Font = new System.Drawing.Font("宋体", 14.2F);
            A2YX4.Location = new System.Drawing.Point(110, 182);
            A2YX4.Margin = new System.Windows.Forms.Padding(2);
            A2YX4.Name = "A2YX4";
            A2YX4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            A2YX4.Size = new System.Drawing.Size(56, 40);
            A2YX4.TabIndex = 217;
            A2YX4.Text = "有效";
            A2YX4.UseVisualStyleBackColor = true;
            // 
            // A2XDWZ
            // 
            Button A2XDWZ = new Button();
            A2XDWZ.Font = new System.Drawing.Font("宋体", 14.2F);
            A2XDWZ.Location = new System.Drawing.Point(9, 182);
            A2XDWZ.Margin = new System.Windows.Forms.Padding(2);
            A2XDWZ.Name = "A2XDWZ";
            A2XDWZ.Size = new System.Drawing.Size(90, 40);
            A2XDWZ.TabIndex = 216;
            A2XDWZ.Text = "相对";
            A2XDWZ.UseVisualStyleBackColor = true;
            // 
            // A2YX3
            // 
            Button A2YX3 = new Button();
            A2YX3.Font = new System.Drawing.Font("宋体", 14.2F);
            A2YX3.Location = new System.Drawing.Point(110, 139);
            A2YX3.Margin = new System.Windows.Forms.Padding(2);
            A2YX3.Name = "A2YX3";
            A2YX3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            A2YX3.Size = new System.Drawing.Size(56, 40);
            A2YX3.TabIndex = 215;
            A2YX3.Text = "有效";
            A2YX3.UseVisualStyleBackColor = true;
            // 
            // A2JDWZ
            // 
            Button A2JDWZ = new Button();
            A2JDWZ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            A2JDWZ.Location = new System.Drawing.Point(9, 140);
            A2JDWZ.Margin = new System.Windows.Forms.Padding(2);
            A2JDWZ.Name = "A2JDWZ";
            A2JDWZ.Size = new System.Drawing.Size(90, 40);
            A2JDWZ.TabIndex = 214;
            A2JDWZ.Text = "绝对位置";
            A2JDWZ.UseVisualStyleBackColor = true;
            // 
            // A2YX2
            // 
            Button A2YX2 = new Button();
            A2YX2.Font = new System.Drawing.Font("宋体", 14.2F);
            A2YX2.Location = new System.Drawing.Point(110, 97);
            A2YX2.Margin = new System.Windows.Forms.Padding(2);
            A2YX2.Name = "A2YX2";
            A2YX2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            A2YX2.Size = new System.Drawing.Size(56, 40);
            A2YX2.TabIndex = 213;
            A2YX2.Text = "有效";
            A2YX2.UseVisualStyleBackColor = true;
            // 
            // A2Wz2
            // 
            Button A2Wz2 = new Button();
            A2Wz2.Font = new System.Drawing.Font("宋体", 14.2F);
            A2Wz2.Location = new System.Drawing.Point(9, 97);
            A2Wz2.Margin = new System.Windows.Forms.Padding(2);
            A2Wz2.Name = "A2Wz2";
            A2Wz2.Size = new System.Drawing.Size(90, 40);
            A2Wz2.TabIndex = 212;
            A2Wz2.Text = "位置2";
            A2Wz2.UseVisualStyleBackColor = true;
            // 
            // A2YX1
            // 
            Button A2YX1 = new Button();
            A2YX1.Font = new System.Drawing.Font("宋体", 14.2F);
            A2YX1.Location = new System.Drawing.Point(110, 54);
            A2YX1.Margin = new System.Windows.Forms.Padding(2);
            A2YX1.Name = "A2YX1";
            A2YX1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            A2YX1.Size = new System.Drawing.Size(56, 40);
            A2YX1.TabIndex = 211;
            A2YX1.Text = "有效";
            A2YX1.UseVisualStyleBackColor = true;
            // 
            // A2Wz1
            // 
            Button A2Wz1 = new Button();
            A2Wz1.Font = new System.Drawing.Font("宋体", 14.2F);
            A2Wz1.Location = new System.Drawing.Point(9, 54);
            A2Wz1.Margin = new System.Windows.Forms.Padding(2);
            A2Wz1.Name = "A2Wz1";
            A2Wz1.Size = new System.Drawing.Size(90, 40);
            A2Wz1.TabIndex = 210;
            A2Wz1.Text = "位置1";
            A2Wz1.UseVisualStyleBackColor = true;
            // 
            // A2Wzr5
            //
            Button A2Wzr5 = new Button();
            A2Wzr5.Font = new System.Drawing.Font("宋体", 14.2F);
            A2Wzr5.Location = new System.Drawing.Point(178, 183);
            A2Wzr5.Margin = new System.Windows.Forms.Padding(2);
            A2Wzr5.Name = "A2Wzr5";
            A2Wzr5.Size = new System.Drawing.Size(75, 40);
            A2Wzr5.TabIndex = 209;
            A2Wzr5.Text = "位置";
            A2Wzr5.UseVisualStyleBackColor = true;
            // 
            // A2Wzr4
            // 
            Button A2Wzr4 = new Button();
            A2Wzr4.Font = new System.Drawing.Font("宋体", 14.2F);
            A2Wzr4.Location = new System.Drawing.Point(178, 139);
            A2Wzr4.Margin = new System.Windows.Forms.Padding(2);
            A2Wzr4.Name = "A2Wzr4";
            A2Wzr4.Size = new System.Drawing.Size(75, 40);
            A2Wzr4.TabIndex = 208;
            A2Wzr4.Text = "位置";
            A2Wzr4.UseVisualStyleBackColor = true;
            // 
            // A2Wzr3
            // 
            Button A2Wzr3 = new Button();
            A2Wzr3.Font = new System.Drawing.Font("宋体", 14.2F);
            A2Wzr3.Location = new System.Drawing.Point(178, 97);
            A2Wzr3.Margin = new System.Windows.Forms.Padding(2);
            A2Wzr3.Name = "A2Wzr3";
            A2Wzr3.Size = new System.Drawing.Size(75, 40);
            A2Wzr3.TabIndex = 207;
            A2Wzr3.Text = "位置";
            A2Wzr3.UseVisualStyleBackColor = true;
            // 
            // A2Wzr2
            // 
            Button A2Wzr2 = new Button();
            A2Wzr2.Font = new System.Drawing.Font("宋体", 14.2F);
            A2Wzr2.Location = new System.Drawing.Point(178, 54);
            A2Wzr2.Margin = new System.Windows.Forms.Padding(2);
            A2Wzr2.Name = "A2Wzr2";
            A2Wzr2.Size = new System.Drawing.Size(75, 40);
            A2Wzr2.TabIndex = 206;
            A2Wzr2.Text = "位置";
            A2Wzr2.UseVisualStyleBackColor = true;
            // 
            // A2Wzr1
            // 
            Button A2Wzr1 = new Button();
            A2Wzr1.Font = new System.Drawing.Font("宋体", 14.2F);
            A2Wzr1.Location = new System.Drawing.Point(178, 10);
            A2Wzr1.Margin = new System.Windows.Forms.Padding(2);
            A2Wzr1.Name = "A2Wzr1";
            A2Wzr1.Size = new System.Drawing.Size(75, 40);
            A2Wzr1.TabIndex = 205;
            A2Wzr1.Text = "位置";
            A2Wzr1.UseVisualStyleBackColor = true;

            Panel SheBei_PanelA2 = new Panel();
            SheBei_PanelA2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SheBei_PanelA2.Controls.Add(Shebei_NameA2);
            SheBei_PanelA2.Controls.Add(A2YX4);
            SheBei_PanelA2.Controls.Add(A2XDWZ);
            SheBei_PanelA2.Controls.Add(A2YX3);
            SheBei_PanelA2.Controls.Add(A2JDWZ);
            SheBei_PanelA2.Controls.Add(A2YX2);
            SheBei_PanelA2.Controls.Add(A2Wz2);
            SheBei_PanelA2.Controls.Add(A2YX1);
            SheBei_PanelA2.Controls.Add(A2Wz1);
            SheBei_PanelA2.Controls.Add(A2Wzr5);
            SheBei_PanelA2.Controls.Add(A2Wzr4);
            SheBei_PanelA2.Controls.Add(A2Wzr3);
            SheBei_PanelA2.Controls.Add(A2Wzr2);
            SheBei_PanelA2.Controls.Add(A2Wzr1);
            SheBei_PanelA2.Location = new System.Drawing.Point(585, 585);
            SheBei_PanelA2.Margin = new System.Windows.Forms.Padding(2);
            SheBei_PanelA2.Name = "SheBei_PanelA2";
            SheBei_PanelA2.Size = new System.Drawing.Size(263, 232);
            this.Controls.Add(SheBei_PanelA2);
        }

        private void panelsetB1(string shebeiname)
        {

            // 
            // Shebei_DanKong
            // 
            Button Shebei_NameB1 = new Button();
            Shebei_NameB1.Font = new System.Drawing.Font("宋体", 12F);
            Shebei_NameB1.Margin = new System.Windows.Forms.Padding(2);
            Shebei_NameB1.Location = new System.Drawing.Point(9, 10);
            Shebei_NameB1.Name = shebeiname + "B1";
            Shebei_NameB1.Size = new System.Drawing.Size(158, 40);
            Shebei_NameB1.Text = shebeiname;
            Shebei_NameB1.TabIndex = 204;
            Shebei_NameB1.UseVisualStyleBackColor = true;
            // 
            Button B1YX4 = new Button();
            B1YX4.Font = new System.Drawing.Font("宋体", 14.2F);
            B1YX4.Location = new System.Drawing.Point(110, 182);
            B1YX4.Margin = new System.Windows.Forms.Padding(2);
            B1YX4.Name = "B1YX4";
            B1YX4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            B1YX4.Size = new System.Drawing.Size(56, 40);
            B1YX4.TabIndex = 217;
            B1YX4.Text = "有效";
            B1YX4.UseVisualStyleBackColor = true;
            // 
            // B1XDWZ
            // 
            Button B1XDWZ = new Button();
            B1XDWZ.Font = new System.Drawing.Font("宋体", 14.2F);
            B1XDWZ.Location = new System.Drawing.Point(9, 182);
            B1XDWZ.Margin = new System.Windows.Forms.Padding(2);
            B1XDWZ.Name = "B1XDWZ";
            B1XDWZ.Size = new System.Drawing.Size(90, 40);
            B1XDWZ.TabIndex = 216;
            B1XDWZ.Text = "相对";
            B1XDWZ.UseVisualStyleBackColor = true;
            // 
            // B1YX3
            // 
            Button B1YX3 = new Button();
            B1YX3.Font = new System.Drawing.Font("宋体", 14.2F);
            B1YX3.Location = new System.Drawing.Point(110, 139);
            B1YX3.Margin = new System.Windows.Forms.Padding(2);
            B1YX3.Name = "B1YX3";
            B1YX3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            B1YX3.Size = new System.Drawing.Size(56, 40);
            B1YX3.TabIndex = 215;
            B1YX3.Text = "有效";
            B1YX3.UseVisualStyleBackColor = true;
            // 
            // B1JDWZ
            // 
            Button B1JDWZ = new Button();
            B1JDWZ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            B1JDWZ.Location = new System.Drawing.Point(9, 140);
            B1JDWZ.Margin = new System.Windows.Forms.Padding(2);
            B1JDWZ.Name = "B1JDWZ";
            B1JDWZ.Size = new System.Drawing.Size(90, 40);
            B1JDWZ.TabIndex = 214;
            B1JDWZ.Text = "绝对位置";
            B1JDWZ.UseVisualStyleBackColor = true;
            // 
            // B1YX2
            // 
            Button B1YX2 = new Button();
            B1YX2.Font = new System.Drawing.Font("宋体", 14.2F);
            B1YX2.Location = new System.Drawing.Point(110, 97);
            B1YX2.Margin = new System.Windows.Forms.Padding(2);
            B1YX2.Name = "B1YX2";
            B1YX2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            B1YX2.Size = new System.Drawing.Size(56, 40);
            B1YX2.TabIndex = 213;
            B1YX2.Text = "有效";
            B1YX2.UseVisualStyleBackColor = true;
            // 
            // B1Wz2
            // 
            Button B1Wz2 = new Button();
            B1Wz2.Font = new System.Drawing.Font("宋体", 14.2F);
            B1Wz2.Location = new System.Drawing.Point(9, 97);
            B1Wz2.Margin = new System.Windows.Forms.Padding(2);
            B1Wz2.Name = "B1Wz2";
            B1Wz2.Size = new System.Drawing.Size(90, 40);
            B1Wz2.TabIndex = 212;
            B1Wz2.Text = "位置2";
            B1Wz2.UseVisualStyleBackColor = true;
            // 
            // B1YX1
            // 
            Button B1YX1 = new Button();
            B1YX1.Font = new System.Drawing.Font("宋体", 14.2F);
            B1YX1.Location = new System.Drawing.Point(110, 54);
            B1YX1.Margin = new System.Windows.Forms.Padding(2);
            B1YX1.Name = "B1YX1";
            B1YX1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            B1YX1.Size = new System.Drawing.Size(56, 40);
            B1YX1.TabIndex = 211;
            B1YX1.Text = "有效";
            B1YX1.UseVisualStyleBackColor = true;
            // 
            // B1Wz1
            // 
            Button B1Wz1 = new Button();
            B1Wz1.Font = new System.Drawing.Font("宋体", 14.2F);
            B1Wz1.Location = new System.Drawing.Point(9, 54);
            B1Wz1.Margin = new System.Windows.Forms.Padding(2);
            B1Wz1.Name = "B1Wz1";
            B1Wz1.Size = new System.Drawing.Size(90, 40);
            B1Wz1.TabIndex = 210;
            B1Wz1.Text = "位置1";
            B1Wz1.UseVisualStyleBackColor = true;
            // 
            // B1Wzr5
            //
            Button B1Wzr5 = new Button();
            B1Wzr5.Font = new System.Drawing.Font("宋体", 14.2F);
            B1Wzr5.Location = new System.Drawing.Point(178, 183);
            B1Wzr5.Margin = new System.Windows.Forms.Padding(2);
            B1Wzr5.Name = "B1Wzr5";
            B1Wzr5.Size = new System.Drawing.Size(75, 40);
            B1Wzr5.TabIndex = 209;
            B1Wzr5.Text = "位置";
            B1Wzr5.UseVisualStyleBackColor = true;
            // 
            // B1Wzr4
            // 
            Button B1Wzr4 = new Button();
            B1Wzr4.Font = new System.Drawing.Font("宋体", 14.2F);
            B1Wzr4.Location = new System.Drawing.Point(178, 139);
            B1Wzr4.Margin = new System.Windows.Forms.Padding(2);
            B1Wzr4.Name = "B1Wzr4";
            B1Wzr4.Size = new System.Drawing.Size(75, 40);
            B1Wzr4.TabIndex = 208;
            B1Wzr4.Text = "位置";
            B1Wzr4.UseVisualStyleBackColor = true;
            // 
            // B1Wzr3
            // 
            Button B1Wzr3 = new Button();
            B1Wzr3.Font = new System.Drawing.Font("宋体", 14.2F);
            B1Wzr3.Location = new System.Drawing.Point(178, 97);
            B1Wzr3.Margin = new System.Windows.Forms.Padding(2);
            B1Wzr3.Name = "B1Wzr3";
            B1Wzr3.Size = new System.Drawing.Size(75, 40);
            B1Wzr3.TabIndex = 207;
            B1Wzr3.Text = "位置";
            B1Wzr3.UseVisualStyleBackColor = true;
            // 
            // B1Wzr2
            // 
            Button B1Wzr2 = new Button();
            B1Wzr2.Font = new System.Drawing.Font("宋体", 14.2F);
            B1Wzr2.Location = new System.Drawing.Point(178, 54);
            B1Wzr2.Margin = new System.Windows.Forms.Padding(2);
            B1Wzr2.Name = "B1Wzr2";
            B1Wzr2.Size = new System.Drawing.Size(75, 40);
            B1Wzr2.TabIndex = 206;
            B1Wzr2.Text = "位置";
            B1Wzr2.UseVisualStyleBackColor = true;
            // 
            // B1Wzr1
            // 
            Button B1Wzr1 = new Button();
            B1Wzr1.Font = new System.Drawing.Font("宋体", 14.2F);
            B1Wzr1.Location = new System.Drawing.Point(178, 10);
            B1Wzr1.Margin = new System.Windows.Forms.Padding(2);
            B1Wzr1.Name = "B1Wzr1";
            B1Wzr1.Size = new System.Drawing.Size(75, 40);
            B1Wzr1.TabIndex = 205;
            B1Wzr1.Text = "位置";
            B1Wzr1.UseVisualStyleBackColor = true;

            Panel SheBei_PanelB1 = new Panel();
            SheBei_PanelB1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SheBei_PanelB1.Controls.Add(Shebei_NameB1);
            SheBei_PanelB1.Controls.Add(B1YX4);
            SheBei_PanelB1.Controls.Add(B1XDWZ);
            SheBei_PanelB1.Controls.Add(B1YX3);
            SheBei_PanelB1.Controls.Add(B1JDWZ);
            SheBei_PanelB1.Controls.Add(B1YX2);
            SheBei_PanelB1.Controls.Add(B1Wz2);
            SheBei_PanelB1.Controls.Add(B1YX1);
            SheBei_PanelB1.Controls.Add(B1Wz1);
            SheBei_PanelB1.Controls.Add(B1Wzr5);
            SheBei_PanelB1.Controls.Add(B1Wzr4);
            SheBei_PanelB1.Controls.Add(B1Wzr3);
            SheBei_PanelB1.Controls.Add(B1Wzr2);
            SheBei_PanelB1.Controls.Add(B1Wzr1);
            SheBei_PanelB1.Location = new System.Drawing.Point(1030, 585);
            SheBei_PanelB1.Margin = new System.Windows.Forms.Padding(2);
            SheBei_PanelB1.Name = "SheBei_PanelB1";
            SheBei_PanelB1.Size = new System.Drawing.Size(263, 232);
            this.Controls.Add(SheBei_PanelB1);
        }

        private void panelsetB2(string shebeiname)
        {

            // 
            // Shebei_DanKong
            // 
            Button Shebei_NameB2 = new Button();
            Shebei_NameB2.Font = new System.Drawing.Font("宋体", 12F);
            Shebei_NameB2.Margin = new System.Windows.Forms.Padding(2);
            Shebei_NameB2.Location = new System.Drawing.Point(9, 10);
            Shebei_NameB2.Name = shebeiname + "B2";
            Shebei_NameB2.Size = new System.Drawing.Size(158, 40);
            Shebei_NameB2.Text = shebeiname;
            Shebei_NameB2.TabIndex = 204;
            Shebei_NameB2.UseVisualStyleBackColor = true;
            // 
            Button B2YX4 = new Button();
            B2YX4.Font = new System.Drawing.Font("宋体", 14.2F);
            B2YX4.Location = new System.Drawing.Point(110, 182);
            B2YX4.Margin = new System.Windows.Forms.Padding(2);
            B2YX4.Name = "B2YX4";
            B2YX4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            B2YX4.Size = new System.Drawing.Size(56, 40);
            B2YX4.TabIndex = 217;
            B2YX4.Text = "有效";
            B2YX4.UseVisualStyleBackColor = true;
            // 
            // B2XDWZ
            // 
            Button B2XDWZ = new Button();
            B2XDWZ.Font = new System.Drawing.Font("宋体", 14.2F);
            B2XDWZ.Location = new System.Drawing.Point(9, 182);
            B2XDWZ.Margin = new System.Windows.Forms.Padding(2);
            B2XDWZ.Name = "B2XDWZ";
            B2XDWZ.Size = new System.Drawing.Size(90, 40);
            B2XDWZ.TabIndex = 216;
            B2XDWZ.Text = "相对";
            B2XDWZ.UseVisualStyleBackColor = true;
            // 
            // B2YX3
            // 
            Button B2YX3 = new Button();
            B2YX3.Font = new System.Drawing.Font("宋体", 14.2F);
            B2YX3.Location = new System.Drawing.Point(110, 139);
            B2YX3.Margin = new System.Windows.Forms.Padding(2);
            B2YX3.Name = "B2YX3";
            B2YX3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            B2YX3.Size = new System.Drawing.Size(56, 40);
            B2YX3.TabIndex = 215;
            B2YX3.Text = "有效";
            B2YX3.UseVisualStyleBackColor = true;
            // 
            // B2JDWZ
            // 
            Button B2JDWZ = new Button();
            B2JDWZ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            B2JDWZ.Location = new System.Drawing.Point(9, 140);
            B2JDWZ.Margin = new System.Windows.Forms.Padding(2);
            B2JDWZ.Name = "B2JDWZ";
            B2JDWZ.Size = new System.Drawing.Size(90, 40);
            B2JDWZ.TabIndex = 214;
            B2JDWZ.Text = "绝对位置";
            B2JDWZ.UseVisualStyleBackColor = true;
            // 
            // B2YX2
            // 
            Button B2YX2 = new Button();
            B2YX2.Font = new System.Drawing.Font("宋体", 14.2F);
            B2YX2.Location = new System.Drawing.Point(110, 97);
            B2YX2.Margin = new System.Windows.Forms.Padding(2);
            B2YX2.Name = "B2YX2";
            B2YX2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            B2YX2.Size = new System.Drawing.Size(56, 40);
            B2YX2.TabIndex = 213;
            B2YX2.Text = "有效";
            B2YX2.UseVisualStyleBackColor = true;
            // 
            // B2Wz2
            // 
            Button B2Wz2 = new Button();
            B2Wz2.Font = new System.Drawing.Font("宋体", 14.2F);
            B2Wz2.Location = new System.Drawing.Point(9, 97);
            B2Wz2.Margin = new System.Windows.Forms.Padding(2);
            B2Wz2.Name = "B2Wz2";
            B2Wz2.Size = new System.Drawing.Size(90, 40);
            B2Wz2.TabIndex = 212;
            B2Wz2.Text = "位置2";
            B2Wz2.UseVisualStyleBackColor = true;
            // 
            // B2YX1
            // 
            Button B2YX1 = new Button();
            B2YX1.Font = new System.Drawing.Font("宋体", 14.2F);
            B2YX1.Location = new System.Drawing.Point(110, 54);
            B2YX1.Margin = new System.Windows.Forms.Padding(2);
            B2YX1.Name = "B2YX1";
            B2YX1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            B2YX1.Size = new System.Drawing.Size(56, 40);
            B2YX1.TabIndex = 211;
            B2YX1.Text = "有效";
            B2YX1.UseVisualStyleBackColor = true;
            // 
            // B2Wz1
            // 
            Button B2Wz1 = new Button();
            B2Wz1.Font = new System.Drawing.Font("宋体", 14.2F);
            B2Wz1.Location = new System.Drawing.Point(9, 54);
            B2Wz1.Margin = new System.Windows.Forms.Padding(2);
            B2Wz1.Name = "B2Wz1";
            B2Wz1.Size = new System.Drawing.Size(90, 40);
            B2Wz1.TabIndex = 210;
            B2Wz1.Text = "位置1";
            B2Wz1.UseVisualStyleBackColor = true;
            // 
            // B2Wzr5
            //
            Button B2Wzr5 = new Button();
            B2Wzr5.Font = new System.Drawing.Font("宋体", 14.2F);
            B2Wzr5.Location = new System.Drawing.Point(178, 183);
            B2Wzr5.Margin = new System.Windows.Forms.Padding(2);
            B2Wzr5.Name = "B2Wzr5";
            B2Wzr5.Size = new System.Drawing.Size(75, 40);
            B2Wzr5.TabIndex = 209;
            B2Wzr5.Text = "位置";
            B2Wzr5.UseVisualStyleBackColor = true;
            // 
            // B2Wzr4
            // 
            Button B2Wzr4 = new Button();
            B2Wzr4.Font = new System.Drawing.Font("宋体", 14.2F);
            B2Wzr4.Location = new System.Drawing.Point(178, 139);
            B2Wzr4.Margin = new System.Windows.Forms.Padding(2);
            B2Wzr4.Name = "B2Wzr4";
            B2Wzr4.Size = new System.Drawing.Size(75, 40);
            B2Wzr4.TabIndex = 208;
            B2Wzr4.Text = "位置";
            B2Wzr4.UseVisualStyleBackColor = true;
            // 
            // B2Wzr3
            // 
            Button B2Wzr3 = new Button();
            B2Wzr3.Font = new System.Drawing.Font("宋体", 14.2F);
            B2Wzr3.Location = new System.Drawing.Point(178, 97);
            B2Wzr3.Margin = new System.Windows.Forms.Padding(2);
            B2Wzr3.Name = "B2Wzr3";
            B2Wzr3.Size = new System.Drawing.Size(75, 40);
            B2Wzr3.TabIndex = 207;
            B2Wzr3.Text = "位置";
            B2Wzr3.UseVisualStyleBackColor = true;
            // 
            // B2Wzr2
            // 
            Button B2Wzr2 = new Button();
            B2Wzr2.Font = new System.Drawing.Font("宋体", 14.2F);
            B2Wzr2.Location = new System.Drawing.Point(178, 54);
            B2Wzr2.Margin = new System.Windows.Forms.Padding(2);
            B2Wzr2.Name = "B2Wzr2";
            B2Wzr2.Size = new System.Drawing.Size(75, 40);
            B2Wzr2.TabIndex = 206;
            B2Wzr2.Text = "位置";
            B2Wzr2.UseVisualStyleBackColor = true;
            // 
            // B2Wzr1
            // 
            Button B2Wzr1 = new Button();
            B2Wzr1.Font = new System.Drawing.Font("宋体", 14.2F);
            B2Wzr1.Location = new System.Drawing.Point(178, 10);
            B2Wzr1.Margin = new System.Windows.Forms.Padding(2);
            B2Wzr1.Name = "B2Wzr1";
            B2Wzr1.Size = new System.Drawing.Size(75, 40);
            B2Wzr1.TabIndex = 205;
            B2Wzr1.Text = "位置";
            B2Wzr1.UseVisualStyleBackColor = true;

            Panel SheBei_PanelB2 = new Panel();
            SheBei_PanelB2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SheBei_PanelB2.Controls.Add(Shebei_NameB2);
            SheBei_PanelB2.Controls.Add(B2YX4);
            SheBei_PanelB2.Controls.Add(B2XDWZ);
            SheBei_PanelB2.Controls.Add(B2YX3);
            SheBei_PanelB2.Controls.Add(B2JDWZ);
            SheBei_PanelB2.Controls.Add(B2YX2);
            SheBei_PanelB2.Controls.Add(B2Wz2);
            SheBei_PanelB2.Controls.Add(B2YX1);
            SheBei_PanelB2.Controls.Add(B2Wz1);
            SheBei_PanelB2.Controls.Add(B2Wzr5);
            SheBei_PanelB2.Controls.Add(B2Wzr4);
            SheBei_PanelB2.Controls.Add(B2Wzr3);
            SheBei_PanelB2.Controls.Add(B2Wzr2);
            SheBei_PanelB2.Controls.Add(B2Wzr1);
            SheBei_PanelB2.Location = new System.Drawing.Point(1330, 585);
            SheBei_PanelB2.Margin = new System.Windows.Forms.Padding(2);
            SheBei_PanelB2.Name = "SheBei_PanelB2";
            SheBei_PanelB2.Size = new System.Drawing.Size(263, 232);
            this.Controls.Add(SheBei_PanelB2);
        }
    }
}
