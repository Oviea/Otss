﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigPro
{
    class ChangCiSheZhiGlobalData
    {
        public static string NageJuMu;
        public static string JuTiChangCi;
        public static string JuTiSheBei;
        public static int ChangJingCount = 0;
        public static int  ShengYuSheBei;
        public static int DanKongShengYuSheBei;
        public static int DanKongXuanZeShengYuSheBei;
        public static int BangDingShengYuSheBei;
        public static int SheBeiYingSheShengYuSheBei;
        public static int PangLuShengYuSheBei;
        public static int JinYongShengYuSheBei;
        public static int DanKongZhuangTaiShengYuSheBei_A;
        public static int DanKongZhuangTaiShengYuSheBei_B;
        public static string YingSheQianChangCi;
        public static bool[] A_SheBei;
        public static bool[] B_SheBei;
        public static bool[] IF_PangLu;
        public static bool[] IF_JinYong;
        public static bool[] TSDanDuanflag;
        public static bool[] TSDuoDuanflag;
        public static bool[] TSFanFuflag;
        public static int[] TSDanDuanSDWZ;
        public static int[] TSDanDuanSDSD;
        public static int[] TSDanDuanYSSJ;
        public static int[] TSDuoDuanDS;
        public static int[] TSDuoDuanSDWZ;
        public static int[] TSDuoDuanYSSJ;
        public static int[] TSwz1;
        public static int[] TSwz2;
        public static int[] TSwz3;
        public static int[] TSwz4;
        public static int[] TSsd1;
        public static int[] TSsd2;
        public static int[] TSsd3;
        public static int[] TSsd4;
        public static int[] TSFanFuCS;
        public static int[] TSFanFSDSD;
        public static int[] TSFanFYSSJ;
        public static int[] TSFanFwz1;
        public static int[] TSFanFwz2;


        public static bool[] TSHSDanDuanflag;
        public static bool[] TSHSDuoDuanflag;
        public static bool[] TSHSFanFuflag;
        public static int[] TSHSDanDuanSDWZ;
        public static int[] TSHSDanDuanSDSD;
        public static int[] TSHSDanDuanYSSJ;
        public static int[] TSHSDuoDuanDS;
        public static int[] TSHSDuoDuanSDWZ;
        public static int[] TSHSDuoDuanYSSJ;
        public static int[] TSHSwz1;
        public static int[] TSHSwz2;
        public static int[] TSHSwz3;
        public static int[] TSHSwz4;
        public static int[] TSHSsd1;
        public static int[] TSHSsd2;
        public static int[] TSHSsd3;
        public static int[] TSHSsd4;
        public static int[] TSHSFanFuCS;
        public static int[] TSHSFanFSDSD;
        public static int[] TSHSFanFYSSJ;
        public static int[] TSHSFanFwz1;
        public static int[] TSHSFanFwz2;
        public static int N;
        public static int K;

        public static int TSSheBeiIndex;
        public static int TSHSSheBeiIndex;

        public static string XuanZhongSheBei_Name;

        public static bool[] DK_Ts;
        public static bool[] DK_TsHs;
        public static bool[] DK_DsDw;
        public static bool[] DK_Ds;

        public static int TaiShangBianPingQiShengYuSheBei;
        public static int TaiXiaBianPingQiShengYuSheBei;
        public static int WeiZhiZhuangTaiShengYuSheBeiTSTS;
        public static int WeiZhiZhuangTaiShengYuSheBeiTXTS;
        public static int WeiZhiZhuangTaiShengYuSheBeiDSDW;
        public static int WeiZhiZhuangTaiShengYuSheBeiDS;
        public static int BangTuShengYuSheBeiTSTS;
        public static int BangTuShengYuSheBeiTXTS;
        public static int BangTuShengYuSheBeiDSDW;

        public static int WangLuoYuSheBeiTSTS;
        public static int WangLuoYuSheBeiTXTS;

        public static string[] YingSheName;
    }
}
