﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class TiaoSuSheBeiHuSuoSheDing : Form
    {
        public TiaoSuSheBeiHuSuoSheDing()
        {
            InitializeComponent();
            this.comboBox1.Items.Add("升降台1");
      
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void TiaoSuSheBeiHuSuoSheDing_Load(object sender, EventArgs e)
        {

        }
    }
}
