﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class changjing : Form

    {
        private static string NaGeJuMu;
        private static string NaGeChangCi;
        private static string[] NaGeCue;
        private static int cueindex;
        private static int totalcue;
        private static int allshebei;
        private static int changcibianhao;
      //  private static int shebeicount;
        private static string[] SheBei_Name;
        private static int clickcount;
        public changjing()
        {

            InitializeComponent();
        }

        private void changjing_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            JumuAdd();

        }
        private void JumuAdd()
        {
            if (File.Exists("jumu.txt"))
            {
                List<string> lines = new List<string>(File.ReadAllLines("jumu.txt"));
                foreach (string s in lines)
                {
                    JuMuChoice.Items.Add(s);
                }

            }
        }
        private void panelset(int x, string SheBeiName)
        {
            Button B = new Button();
            B.BackColor = System.Drawing.SystemColors.ActiveBorder;
            B.Location = new System.Drawing.Point(0, -1);
            B.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            B.Name = "SheBeiName_1";
            B.Size = new System.Drawing.Size(170, 44);
            B.TabIndex = 0;
            B.Text = SheBeiName;
            B.UseVisualStyleBackColor = false;

            Button RSX = new Button();
            RSX.Location = new System.Drawing.Point(-1, 41);
            RSX.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            RSX.Size = new System.Drawing.Size(85, 35);
            RSX.TabIndex = 1;
            RSX.Text = "软上限";
            RSX.UseVisualStyleBackColor = true;

            Button SDWZ = new Button();
            SDWZ.Location = new System.Drawing.Point(-1, 76);
            SDWZ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            SDWZ.Size = new System.Drawing.Size(85, 35);
            SDWZ.TabIndex = 10;
            SDWZ.Text = "设定位置";
            SDWZ.UseVisualStyleBackColor = true;

            Button DQWZ = new Button();
            DQWZ.Location = new System.Drawing.Point(-1, 111);
            DQWZ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            DQWZ.Size = new System.Drawing.Size(85, 35);
            DQWZ.TabIndex = 3;
            DQWZ.Text = "当前位置";
            DQWZ.UseVisualStyleBackColor = true;

            Button RXX = new Button();
            RXX.Location = new System.Drawing.Point(-1, 146);
            RXX.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            RXX.Size = new System.Drawing.Size(85, 35);
            RXX.TabIndex = 3;
            RXX.Text = "软下限";
            RXX.UseVisualStyleBackColor = true;

            Button SDSD = new Button();
            SDSD.Location = new System.Drawing.Point(-1, 181);
            SDSD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            SDSD.Size = new System.Drawing.Size(85, 35);
            SDSD.TabIndex = 11;
            SDSD.Text = "设定速度";
            SDSD.UseVisualStyleBackColor = true;

            Button YSSJ = new Button();
            YSSJ.Location = new System.Drawing.Point(-1, 216);
            YSSJ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            YSSJ.Size = new System.Drawing.Size(85, 35);
            YSSJ.TabIndex = 12;
            YSSJ.Text = "延时时间";
            YSSJ.UseVisualStyleBackColor = true;

            Button DDSJ = new Button();
            DDSJ.Location = new System.Drawing.Point(-1, 251);
            DDSJ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            DDSJ.Size = new System.Drawing.Size(85, 35);
            DDSJ.TabIndex = 13;
            DDSJ.Text = "等待时间";
            DDSJ.UseVisualStyleBackColor = true;

            Button YSMS = new Button();
            YSMS.Location = new System.Drawing.Point(-1, 286);
            YSMS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            YSMS.Size = new System.Drawing.Size(85, 35);
            YSMS.TabIndex = 14;
            YSMS.Text = "运行模式";
            YSMS.UseVisualStyleBackColor = true;

            Label RSXL = new Label();
            RSXL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            RSXL.Location = new System.Drawing.Point(85, 42);
            RSX.Name = "";
            RSXL.Size = new System.Drawing.Size(85, 35);
            RSXL.TabIndex = 15;
            RSXL.Text = "***(默认值)";
            RSXL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            Label SDWZL = new Label();
            SDWZL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SDWZL.Location = new System.Drawing.Point(85, 77);
            SDWZL.Name = "SDWZL_1";
            SDWZL.Size = new System.Drawing.Size(85, 35);
            SDWZL.TabIndex = 16;
            SDWZL.Text = "***(默认值)";
            SDWZL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            Label DQWZL = new Label();
            DQWZL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            DQWZL.Location = new System.Drawing.Point(85, 112);
            DQWZL.Name = "DQWZL_1";
            DQWZL.Size = new System.Drawing.Size(85, 35);
            DQWZL.TabIndex = 17;
            DQWZL.Text = "***(默认值)";
            DQWZL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            Label RXXL = new Label();
            RXXL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            RXXL.Location = new System.Drawing.Point(85, 146);
            RXXL.Name = "RXXL_1";
            RXXL.Size = new System.Drawing.Size(85, 35);
            RXXL.TabIndex = 18;
            RXXL.Text = "***(默认值)";
            RXXL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            Label SDSDL = new Label();
            SDSDL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SDSDL.Location = new System.Drawing.Point(85, 181);
            SDSDL.Name = "SDSDL_1";
            SDSDL.Size = new System.Drawing.Size(85, 35);
            SDSDL.TabIndex = 19;
            SDSDL.Text = "***(默认值)";
            SDSDL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            Label YSSJL = new Label();
            YSSJL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            YSSJL.Location = new System.Drawing.Point(85, 216);
            YSSJL.Name = "YSSJL_1";
            YSSJL.Size = new System.Drawing.Size(85, 35);
            YSSJL.TabIndex = 20;
            YSSJL.Text = "***(默认值)";
            YSSJL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            Label DDSJL = new Label();
            DDSJL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            DDSJL.Location = new System.Drawing.Point(85, 251);
            DDSJL.Name = "DDSJL_1";
            DDSJL.Size = new System.Drawing.Size(85, 35);
            DDSJL.TabIndex = 21;
            DDSJL.Text = "***(默认值)";
            DDSJL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            Label YSMSL = new Label();
            YSMSL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            YSMSL.Location = new System.Drawing.Point(85, 286);
            YSMSL.Name = "YSMSL_1";
            YSMSL.Size = new System.Drawing.Size(85, 35);
            YSMSL.TabIndex = 22;
            YSMSL.Text = "***(默认值)";
            YSMSL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            Panel p = new Panel();
            p.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            p.Controls.Add(B);
            p.Controls.Add(RSX);
            p.Controls.Add(SDWZ);
            p.Controls.Add(DQWZ);
            p.Controls.Add(RXX);
            p.Controls.Add(SDSD);
            p.Controls.Add(YSSJ);
            p.Controls.Add(DDSJ);
            p.Controls.Add(YSMS);
            p.Controls.Add(RSXL);
            p.Controls.Add(SDWZL);
            p.Controls.Add(DQWZL);
            p.Controls.Add(RXXL);
            p.Controls.Add(SDSDL);
            p.Controls.Add(YSSJL);
            p.Controls.Add(DDSJL);
            p.Controls.Add(YSMSL);
            p.Location = new System.Drawing.Point(x, 60);
            p.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            p.Name = "XuanZhongSB" + x;
            p.Size = new System.Drawing.Size(172, 323);
            p.TabIndex = 2;
            this.Controls.Add(p);
        }
        private void delpanel(int x)
        {
            
            if (Controls["XuanZhongSB" + x] != null)
            {
                Controls["XuanZhongSB" + x].Dispose();
            }
        }
        private void deplanelX() {
            //if (Controls["XuanZhongSB240"].Created) {
            //    Controls["XuanZhongSB240"].Dispose();
            //}
            //if (Controls["XuanZhongSB540"].Created)
            //{
            //    Controls["XuanZhongSB540"].Dispose();
            //}
            //if (Controls["XuanZhongSB840"].Created)
            //{
            //    Controls["XuanZhongSB840"].Dispose();
            //}
            //if (Controls["XuanZhongSB1140"].Created)
            //{
            //    Controls["XuanZhongSB1140"].Dispose();
            //}
            //if (Controls["XuanZhongSB1440"].Created)
            //{
            //    Controls["XuanZhongSB1440"].Dispose();
            //}
            if (Controls["XuanZhongSB240"] != null) {
                Controls["XuanZhongSB240"].Dispose();
            }
            if (Controls["XuanZhongSB540"] != null)
            {
                Controls["XuanZhongSB540"].Dispose();
            }
            if (Controls["XuanZhongSB840"] != null)
            {
                Controls["XuanZhongSB840"].Dispose();
            }
            if (Controls["XuanZhongSB1140"] != null)
            {
                Controls["XuanZhongSB1140"].Dispose();
            }
            if (Controls["XuanZhongSB1440"] != null)
            {
                Controls["XuanZhongSB1440"].Dispose();
            }
        }
        private void button139_Click(object sender, EventArgs e)
        {
            new main().Show();
            this.Close();

        }

        private void button138_Click(object sender, EventArgs e)
        {
            new main().Show();
            this.Close();

        }



        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void JuMuChoice_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (JuMuChoice.SelectedIndex == -1)
            {
                return;
            }
            else
            {
                //   JuMuChoice.Text = JuMuChoice.Items[JuMuChoice.SelectedIndex].ToString();
                NaGeJuMu = JuMuChoice.SelectedItem.ToString();
                if (File.Exists("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt"))
                {

                    List<string> lines = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt"));
                    totalcue = lines.ToArray().Length;
                    cueindex = 0;
                    ChangCiChoice.Items.Clear();
                    foreach (string s in lines)
                    {
                        ChangCiChoice.Items.Add(s);
                    }

                }
             

            }

        }

        private void ChangCiChoice_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (JuMuChoice.SelectedIndex == -1)
            {
                return;
            }
            else
            {
                clickcount = 0;
                ChangCiSheZhiGlobalData.ChangJingCount++;
                if (ChangCiSheZhiGlobalData.ChangJingCount > 1) {
                    deplanelX();
                }
                
                //Console.WriteLine("GGGGGGG" + ChangCiSheZhiGlobalData.ShengYuSheBei);
                
                //   JuMuChoice.Text = JuMuChoice.Items[JuMuChoice.SelectedIndex].ToString();
                NaGeChangCi = ChangCiChoice.SelectedItem.ToString();
                changcibianhao = int.Parse(NaGeChangCi.Substring(3));
                //Console.WriteLine("*****"+changcibianhao);
                if (File.Exists("" + NaGeJuMu + "\\" + "CC" + changcibianhao + "\\" + "CC" + changcibianhao + ".txt"))
                {

                    List<string> shebeilines = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "CC" + changcibianhao + "\\" + "CC" + changcibianhao + ".txt"));
                    SheBei_Name = shebeilines.ToArray();
                    int totalshebei = SheBei_Name.Length;
                    allshebei = totalshebei;
                    if (totalshebei <= 5)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(240 + 300 * i, SheBei_Name[i]);
                        }
                        ChangCiSheZhiGlobalData.ShengYuSheBei = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            panelset(240 + 300 * i, SheBei_Name[i]);
                        }
                        ChangCiSheZhiGlobalData.ShengYuSheBei = totalshebei - 5;
                    }
                }

            }
        }

        private void Cue_Down_Click(object sender, EventArgs e)
        {
            if (JuMuChoice.SelectedIndex != -1 && ChangCiChoice.SelectedIndex != -1)
            {
                clickcount = 0;
                changcibianhao--;
                if (changcibianhao <= 0)
                {
                    MessageBox.Show("没有更多Cue!!!");
                    changcibianhao++;
                }
                else
                {
                    ChangCiChoice.SelectedIndex = changcibianhao - 1;
                    //if (ChangCiSheZhiGlobalData.ShengYuSheBei <= 5)
                    //{
                    //    for (int j = 0; j < ChangCiSheZhiGlobalData.ShengYuSheBei; j++)
                    //    {
                    //        delpanel(240 + 300 * j);
                    //    }
                    //}
                    //else
                    //{

                    //    for (int j = 0; j < 5; j++)
                    //    {
                    //        delpanel(240 + 300 * j);
                    //    }
                    //}
                    deplanelX();
                    if (File.Exists("" + NaGeJuMu + "\\" + "CC" + changcibianhao + "\\" + "CC" + changcibianhao + ".txt"))
                    {
                        List<string> shebeilines = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "CC" + changcibianhao + "\\" + "CC" + changcibianhao + ".txt"));
                        int totalshebei = shebeilines.ToArray().Length;
                        if (totalshebei <= 5)
                        {
                            for (int i = 0; i < totalshebei; i++)
                            {
                                panelset(240 + 300 * i, SheBei_Name[i]);
                            }
                            ChangCiSheZhiGlobalData.ShengYuSheBei = 0;
                        }
                        else
                        {
                            for (int i = 0; i < 5; i++)
                            {
                                panelset(240 + 300 * i, SheBei_Name[i]);
                            }
                            ChangCiSheZhiGlobalData.ShengYuSheBei = totalshebei - 5;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("剧目和场次不能为空!请选择剧目或者场次!");
            }
        }

        private void Cue_Up_Click(object sender, EventArgs e)
        {
            if (JuMuChoice.SelectedIndex != -1 && ChangCiChoice.SelectedIndex != -1)
            {
                clickcount = 0;
                changcibianhao++;
                if (changcibianhao >= totalcue + 1)
                {
                    MessageBox.Show("没有更多Cue!!!");
                    changcibianhao--;
                }
                else
                {
                    ChangCiChoice.SelectedIndex = changcibianhao - 1;
                    //if (ChangCiSheZhiGlobalData.ShengYuSheBei<=5) {
                    //    for (int j = 0; j < ChangCiSheZhiGlobalData.ShengYuSheBei; j++)
                    //    {
                    //        delpanel(240 + 300 * j);
                    //    }
                    //}
                    //else {

                    //    for (int j = 0; j < 5; j++)
                    //    {
                    //        delpanel(240 + 300 * j);
                    //    }
                    //}
                    deplanelX();
                    if (File.Exists("" + NaGeJuMu + "\\" + "CC" + changcibianhao + "\\" + "CC" + changcibianhao + ".txt"))
                    {
                        List<string> shebeilines = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "CC" + changcibianhao + "\\" + "CC" + changcibianhao + ".txt"));
                        int totalshebei = shebeilines.ToArray().Length;
                        if (totalshebei <= 5)
                        {
                            for (int i = 0; i < totalshebei; i++)
                            {
                                panelset(240 + 300 * i, SheBei_Name[i]);
                            }
                            ChangCiSheZhiGlobalData.ShengYuSheBei = 0;
                        }
                        else
                        {
                            for (int i = 0; i < 5; i++)
                            {
                                panelset(240 + 300 * i, SheBei_Name[i]);
                            }
                            ChangCiSheZhiGlobalData.ShengYuSheBei = totalshebei - 5;
                        }

                    }
                }
            }
            else
            {
                MessageBox.Show("剧目和场次不能为空!请选择剧目或者场次!");
            }
        }

        private void ToRight_Click(object sender, EventArgs e)
        {
            if (JuMuChoice.SelectedIndex != -1 && ChangCiChoice.SelectedIndex != -1)
            {
                clickcount++;
                if (ChangCiSheZhiGlobalData.ShengYuSheBei == 0)
                {
                    MessageBox.Show("没有更多已编组设备！");
                    // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;\
                    clickcount--;
                }
                else
                {
                    for (int j = 0; j < 5; j++)
                    {
                        delpanel(240 + 300 * j);
                    }

                    if (ChangCiSheZhiGlobalData.ShengYuSheBei <= 5)
                    {
                        for (int i = 0; i < ChangCiSheZhiGlobalData.ShengYuSheBei; i++)
                        {
                            panelset(240 + 300 * i, SheBei_Name[5 * clickcount + i]);
                        }
                        ChangCiSheZhiGlobalData.ShengYuSheBei = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            panelset(240 + 300 * i, SheBei_Name[5 * clickcount + i]);
                        }
                        ChangCiSheZhiGlobalData.ShengYuSheBei = ChangCiSheZhiGlobalData.ShengYuSheBei - 5;
                    }
                }
            }
            else
            {
                MessageBox.Show("剧目和场次不能为空!请选择剧目或者场次!");
            }
        }

        private void ToLeft_Click(object sender, EventArgs e)
        {
            if (JuMuChoice.SelectedIndex != -1 && ChangCiChoice.SelectedIndex != -1)
            {
                clickcount--;
                Console.WriteLine("ClickCount" + clickcount);
                Console.WriteLine("ShengYuSheBei" + ChangCiSheZhiGlobalData.ShengYuSheBei);
                if (ChangCiSheZhiGlobalData.ShengYuSheBei >= allshebei - 5)
                {
                    MessageBox.Show("没有更多已编组设备！");
                    //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
                    clickcount++;
                }
                else
                {
                    if (ChangCiSheZhiGlobalData.ShengYuSheBei == 0)
                    {
                        int j = 0;
                        if (allshebei % 5 == 0)
                        {
                            j = 5;
                        }
                        else
                        {
                            j = allshebei % 5;
                        }

                        for (int i = 0; i < j; i++)
                        {
                            delpanel(240 + 300 * i);
                        }

                    }
                    else
                    {
                        for (int j = 0; j < 5; j++)
                        {
                            delpanel(240 + 300 * j);
                        }

                    }
                    for (int i = 0; i < 5; i++)
                    {
                        panelset(240 + 300 * i, SheBei_Name[(allshebei / 5) * 5 - ((allshebei / 5) - clickcount) * 5 + i]);

                    }


                    if (ChangCiSheZhiGlobalData.ShengYuSheBei == 0)
                    {

                        if (allshebei % 5 == 0)
                        {
                            ChangCiSheZhiGlobalData.ShengYuSheBei = 5;
                        }
                        else
                        {
                            ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                        }
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.ShengYuSheBei = ChangCiSheZhiGlobalData.ShengYuSheBei + 5;

                    }
                }
            }
            else
            {
                MessageBox.Show("剧目和场次不能为空!请选择剧目或者场次!");
            }

        }
       
    }
}