﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class Bound : Form
    {
        private string zhujishebei="WXZ";
        private string congjishebei;
        private int n, k, m, p;
        private static int allshebei;
        private static string[] shebei;
        private static int clickcount;
        public Bound()
        {
            InitializeComponent();

        }
        static void WriteWS(string filePath, string writestr)
        {
            FileStream fs = new FileStream(filePath, FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            try
            {
                sw.WriteLine(writestr);
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine("Writing has been completed");
            }
            catch (IOException e)
            {
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine(e.ToString());
            }
        }
        private void Bound_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            if (File.Exists("SBSD.txt"))
            {
                List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
                // Console.WriteLine("%%%%"+sbsd[0].ToString());
                n = int.Parse(sbsd[0].ToString());
                k = int.Parse(sbsd[1].ToString());
                m = int.Parse(sbsd[2].ToString());
                p = int.Parse(sbsd[3].ToString());
                int j = 1;
                for (int i = 0; i < n; i++)
                {
                    ZJSB.Items.Add("调速设备" + j);
                    j++;
                }
                j = 1;
                for (int i = 0; i < k; i++)
                {
                    ZJSB.Items.Add("调速互锁类设备" + j);
                    j++;
                }
                j = 1;
                for (int i = 0; i < m; i++)
                {
                    ZJSB.Items.Add("定速定位设备" + j);
                    j++;
                }
                j = 1;
                for (int i = 0; i < p; i++)
                {
                    ZJSB.Items.Add("定速设备" + j);
                    j++;
                }
                CJSB.Items.Clear();
            }
            if (!Directory.Exists("" + "主机设备" + "\\")) {
                Directory.CreateDirectory("" + "主机设备" + "\\");
            }
            DirectoryInfo di = new DirectoryInfo("" + "主机设备" + "\\");
            DirectoryInfo[] dirs = di.GetDirectories();
            shebei = new string[dirs.Length];
            for (int i = 0; i < dirs.Length; i++)
            {
                shebei[i] = dirs[i].Name;
            }
            int totalshebei = dirs.Length;
            allshebei = totalshebei;
            if (totalshebei <= 7)
            {
                for (int i = 0; i < totalshebei; i++)
                {
                    panelset(450 + 200 * i, 160, shebei[i]);
                }
                ChangCiSheZhiGlobalData.BangDingShengYuSheBei = 0;
            }
            else
            {
                for (int i = 0; i < 7; i++)
                {
                    panelset(450 + 200 * i, 160, shebei[i]);
                }
                ChangCiSheZhiGlobalData.BangDingShengYuSheBei = totalshebei - 7;
            }
        }
        private void BD_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BD_2Main_Click(object sender, EventArgs e)
        {
            var frm = new main();
            frm.Show();
            this.Close();
        }

        private void BD_QR_Click(object sender, EventArgs e)
        {
            delpanelall();
            if (zhujishebei != "WXZ")
            {
                DirectoryInfo di = new DirectoryInfo("" + "主机设备" + "\\");
                DirectoryInfo[] dirs = di.GetDirectories();
               
                shebei = new string[dirs.Length];
                for (int i = 0; i < dirs.Length; i++)
                {
                    shebei[i] = dirs[i].Name;
                }
                int totalshebei = dirs.Length;
                Console.WriteLine("))))()()()" + totalshebei);
                allshebei = totalshebei;
                if (totalshebei <= 7)
                {
                    for (int i = 0; i < totalshebei; i++)
                    {
                        panelset(450+ 200 * i, 160, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.BangDingShengYuSheBei = 0;
                }
                else
                {
                    for (int i = 0; i < 7; i++)
                    {
                        panelset(450 + 200 * i, 160, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.BangDingShengYuSheBei = totalshebei - 7;
                }
                MessageBox.Show("确认完成");
            }
            else
            {
                MessageBox.Show("请先选择主机设备!");
            }
        }

        private void BD_TL_Click(object sender, EventArgs e)
        {
            clickcount--;
            if (ChangCiSheZhiGlobalData.BangDingShengYuSheBei >= allshebei - 7)
            {
                BD_QR.Enabled = true;
                BD_QR.BackColor = Color.White;
                MessageBox.Show("没有更多主从设备！");
                clickcount++;
                //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
            }
            else
            {
                delpanelall();

                for (int i = 0; i < 7; i++)
                {
                    panelset(450 + 200 * i, 160, shebei[(allshebei / 7) * 7 - ((allshebei / 7) - clickcount) * 7 + i]);
                }
                
                if (ChangCiSheZhiGlobalData.BangDingShengYuSheBei == 0)
                {
                    if (allshebei % 7 == 0)
                    {
                        ChangCiSheZhiGlobalData.BangDingShengYuSheBei = 7;
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.BangDingShengYuSheBei = allshebei % 7;
                    }
                }
                else
                {
                    ChangCiSheZhiGlobalData.BangDingShengYuSheBei = ChangCiSheZhiGlobalData.BangDingShengYuSheBei + 7;
                }
            }
        }

        private void delpanelall()
        {
            if (Controls["ZJ_CJ_P450160"] != null)
            {
                Controls["ZJ_CJ_P450160"].Dispose();
            }
            if (Controls["ZJ_CJ_P650160"] != null)
            {
                Controls["ZJ_CJ_P650160"].Dispose();
            }
            if (Controls["ZJ_CJ_P850160"] != null)
            {
                Controls["ZJ_CJ_P850160"].Dispose();
            }
            if (Controls["ZJ_CJ_P1050160"] != null)
            {
                Controls["ZJ_CJ_P1050160"].Dispose();
            }
            if (Controls["ZJ_CJ_P1250160"] != null)
            {
                Controls["ZJ_CJ_P1250160"].Dispose();
            }
            if (Controls["ZJ_CJ_P1450160"] != null)
            {
                Controls["ZJ_CJ_P1450160"].Dispose();
            }
            if (Controls["ZJ_CJ_P1650160"] != null)
            {
                Controls["ZJ_CJ_P1650160"].Dispose();
            }
        }

        private void ZJSB_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ZJSB.SelectedIndex == -1)
            {
                return;
            }
            else
            {
                DialogResult result = MessageBox.Show("主设备选择", "主设备", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    zhujishebei = ZJSB.SelectedItem.ToString();
                    if (!Directory.Exists("" +"主机设备"+"\\"+ zhujishebei + "\\"))
                    {
                        Directory.CreateDirectory("" + "主机设备" + "\\" + zhujishebei + "\\");
                    }
                    MessageBox.Show("主机设备为:" + zhujishebei + "请选择从机设备!");
                }
                
                ZJSB.Items.Clear();
                ZJSB.Items.Add(zhujishebei);
                ZJSB.Enabled = false;
                int j = 1;
                for (int i = 0; i < n; i++)
                {
                    CJSB.Items.Add("调速设备" + j);
                    j++;
                }
                j = 1;
                for (int i = 0; i < k; i++)
                {
                    CJSB.Items.Add("调速互锁类设备" + j);
                    j++;
                }
                j = 1;
                for (int i = 0; i < m; i++)
                {
                    CJSB.Items.Add("定速定位设备" + j);
                    j++;
                }
                j = 1;
                for (int i = 0; i < p; i++)
                {
                    CJSB.Items.Add("定速设备" + j);
                    j++;
                }
                if (!File.Exists("" + "主机设备" + "\\" + zhujishebei + "\\" + zhujishebei + ".txt"))
                {
                    File.Create("" + "主机设备" + "\\" + zhujishebei + "\\" + zhujishebei + ".txt").Close();   
                }
                List<string> lines = new List<string>(File.ReadAllLines("" + "主机设备" + "\\" + zhujishebei + "\\" + zhujishebei + ".txt"));
                foreach (string s in lines)
                {
                    if (CJSB.Items.IndexOf(s) != -1)
                    {
                        CJSB.Items.RemoveAt(CJSB.Items.IndexOf(s));
                    }
                }
            }
            ZJSB.SelectedIndex = -1;
        }

        private void BD_TR_Click(object sender, EventArgs e)
        {
            BD_QR.Enabled = false;
            BD_QR.BackColor = Color.AliceBlue;
            clickcount++;
            //   Console.WriteLine("XZXZXZX" + ChangCiSheZhiGlobalData.BangDingShengYuSheBei);
            if (ChangCiSheZhiGlobalData.BangDingShengYuSheBei == 0)
            {
                MessageBox.Show("没有更多主从设备！");
                // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                clickcount--;
            }
            else
            {
                delpanelall();
                if (ChangCiSheZhiGlobalData.BangDingShengYuSheBei < 7)
                {
                    for (int i = 0; i < ChangCiSheZhiGlobalData.BangDingShengYuSheBei; i++)
                    {
                        panelset(450 + 200 * i, 160, shebei[7 * clickcount + i]);
                    }

                    ChangCiSheZhiGlobalData.BangDingShengYuSheBei = 0;
                }
                else
                {
                    for (int i = 0; i < 7; i++)
                    {
                        panelset(450 + 200 * i, 160, shebei[7 * clickcount + i]);
                    }
                    
                    ChangCiSheZhiGlobalData.BangDingShengYuSheBei = ChangCiSheZhiGlobalData.BangDingShengYuSheBei - 7;
                }
            }
        }

        private void BDAll_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("是否取消", "取消", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Directory.Delete("" + "主机设备", true);
            }
            MessageBox.Show("主从设备已经全部删除!");
        }

        private void BD_BDCS_Click(object sender, EventArgs e)
        {
            var f = new Bound_parameter();
            f.Show();
            this.Close();
        }

        private void BD_CXXZ_Click(object sender, EventArgs e)
        {
            ZJSB.Enabled = true;
            ZJSB.Items.Clear();
            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            // Console.WriteLine("%%%%"+sbsd[0].ToString());
            n = int.Parse(sbsd[0].ToString());
            k = int.Parse(sbsd[1].ToString());
            m = int.Parse(sbsd[2].ToString());
            p = int.Parse(sbsd[3].ToString());
            int j = 1;
            for (int i = 0; i < n; i++)
            {
                ZJSB.Items.Add("调速设备" + j);
                j++;
            }
            j = 1;
            for (int i = 0; i < k; i++)
            {
                ZJSB.Items.Add("调速互锁类设备" + j);
                j++;
            }
            j = 1;
            for (int i = 0; i < m; i++)
            {
                ZJSB.Items.Add("定速定位设备" + j);
                j++;
            }
            j = 1;
            for (int i = 0; i < p; i++)
            {
                ZJSB.Items.Add("定速设备" + j);
                j++;
            }
            CJSB.Items.Clear();
            delpanelall();
            if (!Directory.Exists("" + "主机设备" + "\\")) {
                Directory.CreateDirectory("" + "主机设备" + "\\");
            }

            DirectoryInfo di = new DirectoryInfo("" + "主机设备" + "\\");
            DirectoryInfo[] dirs = di.GetDirectories();
            shebei = new string[dirs.Length];
            for (int i = 0; i < dirs.Length; i++)
            {
                shebei[i] = dirs[i].Name;
            }
            int totalshebei = dirs.Length;
            Console.WriteLine("))))()()()" + totalshebei);
            allshebei = totalshebei;
            if (totalshebei <= 7)
            {
                for (int i = 0; i < totalshebei; i++)
                {
                    panelset(450 + 200 * i, 160, shebei[i]);
                }
                ChangCiSheZhiGlobalData.BangDingShengYuSheBei = 0;
            }
            else
            {
                for (int i = 0; i < 7; i++)
                {
                    panelset(450 + 200 * i, 160, shebei[i]);
                }
                ChangCiSheZhiGlobalData.BangDingShengYuSheBei = totalshebei - 7;
            }
        }

        private void CJSB_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (zhujishebei == "WXZ")
            {
                MessageBox.Show("请先选择主设备!");
            }
            else
            {

                if (CJSB.SelectedIndex == -1)
                {
                    return;
                }
                else
                {
                    DialogResult result = MessageBox.Show("从设备选择", "从设备", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        congjishebei = CJSB.SelectedItem.ToString();
                        if (!File.Exists("" + "主机设备" + "\\" + zhujishebei + "\\" + zhujishebei + ".txt"))
                        {
                            File.Create("" + "主机设备" + "\\" + zhujishebei + "\\" + zhujishebei + ".txt");
                        }
                        WriteWS("" + "主机设备" + "\\" + zhujishebei + "\\" + zhujishebei + ".txt", congjishebei);
                        MessageBox.Show("主机设备为:" + zhujishebei + "从机设备为:"+congjishebei);
                        CJSB.Items.RemoveAt(CJSB.SelectedIndex);
                    }

                }
                CJSB.SelectedIndex = -1;
            }
        }

        private void panelset(int x, int y, string shebeiname)
        {
            Label L_ZJ = new Label();
            L_ZJ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            L_ZJ.Location = new System.Drawing.Point(-1, -1);
            L_ZJ.Name = "L_ZJ"+x+y;
            L_ZJ.Size = new System.Drawing.Size(150, 40);
            L_ZJ.TabIndex = 470;
            L_ZJ.Text =shebeiname;
            L_ZJ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DuiYing_CJ
            // 
            ListBox DuiYing_CJ = new ListBox();
            DuiYing_CJ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            DuiYing_CJ.FormattingEnabled = true;
            DuiYing_CJ.ItemHeight = 16;
            DuiYing_CJ.Location = new System.Drawing.Point(-1, 42);
            DuiYing_CJ.Name = "DuiYing_CJ" + x + y;
            DuiYing_CJ.ScrollAlwaysVisible = true;
            DuiYing_CJ.Size = new System.Drawing.Size(150, 436);
            DuiYing_CJ.TabIndex = 472;
            if (File.Exists("" + "主机设备" + "\\" + shebeiname + "\\" + shebeiname + ".txt"))
            {
                List<string> congshebei = new List<string>(File.ReadAllLines("" + "主机设备" + "\\" + shebeiname + "\\" + shebeiname + ".txt"));
                foreach(string s in congshebei)
                {
                    DuiYing_CJ.Items.Add(s);
                }
            }
           
            // 
            // ZJ_CJ_P
            // 
            Panel ZJ_CJ_P = new Panel();
            ZJ_CJ_P.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            ZJ_CJ_P.Controls.Add(L_ZJ);
            ZJ_CJ_P.Controls.Add(DuiYing_CJ);
            ZJ_CJ_P.Location = new System.Drawing.Point(x, y);
            ZJ_CJ_P.Name = "ZJ_CJ_P" + x + y;
            ZJ_CJ_P.Size = new System.Drawing.Size(150, 480);
            ZJ_CJ_P.TabIndex = 473;
            this.Controls.Add(ZJ_CJ_P);
        }

    }
    
}
