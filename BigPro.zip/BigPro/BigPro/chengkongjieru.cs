﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace BigPro
{
    public partial class chengkongjieru : Form
    {
        private static string NaGeJuMu;
        private static string NaGeChangCi;
        private static int allshebei;
        private static int changcibianhao;
        private static int shebeicount;
        private static string[] shebei;
        private static int clickcount;
        private static bool ifpause = false;
        private int n, k, m, p;
        public chengkongjieru()
        {
            InitializeComponent();
        }

        private void chengkongjieru_Load(object sender, EventArgs e)
        {
            if (File.Exists("SBSD.txt"))
            {
                List<string> lines = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(lines[0]);
                k = int.Parse(lines[1]);
                m = int.Parse(lines[2]);
                p = int.Parse(lines[3]);
                
                int n1 = n+1;
                int k1 = k+1;
                int m1 = m+1;
                int p1 = p+1;
                ChangCiSheZhiGlobalData.DK_Ds = new bool[n1];
                ChangCiSheZhiGlobalData.DK_DsDw = new bool[k1];
                ChangCiSheZhiGlobalData.DK_Ts = new bool[m1];
                ChangCiSheZhiGlobalData.DK_TsHs = new bool[p1];
            }
            this.WindowState = FormWindowState.Maximized;
            JumuAdd();
        }
        private void JumuAdd()
        {
            if (File.Exists("jumu.txt"))
            {
                List<string> lines = new List<string>(File.ReadAllLines("jumu.txt"));
                foreach (string s in lines)
                {
                    JMC.Items.Add(s);
                }

            }
        }
       

        private void button135_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button133_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void JuMuChoice_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (JMC.SelectedIndex == -1)
            {
                return;
            }
            else
            {
                //   JuMuChoice.Text = JuMuChoice.Items[JuMuChoice.SelectedIndex].ToString();
                NaGeJuMu = JMC.SelectedItem.ToString();
                if (File.Exists(NaGeJuMu + "\\" + NaGeJuMu + ".txt"))
                {

                    List<string> lines = new List<string>(File.ReadAllLines(NaGeJuMu + "\\" + NaGeJuMu + ".txt"));
                    foreach (string s in lines)
                    {
                        CCChoice.Items.Add(s);
                    }

                }

            }
        }



        private void CCChoice_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (CCChoice.SelectedIndex == -1)
            {
                return;
            }
            else
            {
                delpanelall();
                //   JuMuChoice.Text = JuMuChoice.Items[JuMuChoice.SelectedIndex].ToString();
                NaGeChangCi = CCChoice.SelectedItem.ToString();
                changcibianhao = int.Parse(NaGeChangCi.Substring(3));
                // Console.WriteLine("*****"+NaGeChangCi);
                if (File.Exists(NaGeJuMu + "\\" + "CC" + changcibianhao + "\\" + "CC" + changcibianhao + ".txt"))
                {

                    //List<string> lines = new List<string>(File.ReadAllLines(NaGeJuMu + "\\" + "CC" + changcibianhao + "\\" + "CC" + changcibianhao + ".txt"));
                    //foreach (string s in lines)
                    //{
                    //    ChangJing_Choice.Items.Add(s);
                    //}
                    List<string> shebeilines = new List<string>(File.ReadAllLines(NaGeJuMu + "\\" + "CC" + changcibianhao + "\\" + "CC" + changcibianhao + ".txt"));
                    int totalshebei = shebeilines.ToArray().Length;
                    allshebei = totalshebei;
                    shebei = shebeilines.ToArray();
                    if (totalshebei <= 27)
                    {
                        if (0 <= totalshebei && totalshebei <= 9)
                        {
                            for (int i = 0; i < totalshebei; i++)
                            {
                                panelset(50 + 200 * i, 120, shebei[i]);
                            }
                        }
                        else if (totalshebei > 9 && totalshebei <= 18)
                        {
                            for (int i = 0; i < 9; i++)
                            {
                                panelset(50 + 200 * i, 120, shebei[i]);
                            }
                            for (int i = 9; i < totalshebei; i++)
                            {
                                panelset(50 + 200 * (i - 9), 320, shebei[i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 9; i++)
                            {
                                panelset(50 + 200 * i, 120, shebei[i]);
                            }
                            for (int i = 9; i < 18; i++)
                            {
                                panelset(50 + 200 * (i - 9), 320, shebei[i]);
                            }
                            for (int i = 18; i < totalshebei; i++)
                            {
                                panelset(50 + 200 * (i - 18), 520, shebei[i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.DanKongShengYuSheBei = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 9; i++)
                        {
                            panelset(50 + 200 * i, 120, shebei[i]);
                        }
                        for (int i = 9; i < 18; i++)
                        {
                            panelset(50 + 200 * (i - 9), 320, shebei[i]);
                        }
                        for (int i = 18; i < 27; i++)
                        {
                            panelset(50 + 200 * (i - 18), 520, shebei[i]);
                        }
                        ChangCiSheZhiGlobalData.DanKongShengYuSheBei = totalshebei - 27;
                    }
                }

            }
        }
        

        private void panelset(int x, int y, string shebeiname)
        {

            // 
            // Shebei_DanKong
            // 
            Button Shebei_DanKong = new Button();
            Shebei_DanKong.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            Shebei_DanKong.Location = new System.Drawing.Point(96, 90);
            Shebei_DanKong.Margin = new System.Windows.Forms.Padding(2);
            Shebei_DanKong.Name = "Shebei_DanKong"+x+y;
            Shebei_DanKong.Size = new System.Drawing.Size(82, 36);
            Shebei_DanKong.TabIndex = 4;
            Shebei_DanKong.Text = "单控";
            Shebei_DanKong.UseVisualStyleBackColor = true;
            Shebei_DanKong.Click += (e, a) => this.ShebeiDanKong_Click(shebeiname,x,y);
            // 
            // SheBei_V
            // 
            Button SheBei_V = new Button();
            SheBei_V.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            SheBei_V.Location = new System.Drawing.Point(9, 90);
            SheBei_V.Margin = new System.Windows.Forms.Padding(2);
            SheBei_V.Name = "SheBei_V"+x+y;
            SheBei_V.Size = new System.Drawing.Size(82, 36);
            SheBei_V.TabIndex = 3;
            SheBei_V.Text = "速度";
            SheBei_V.UseVisualStyleBackColor = true;
            // 
            // Shebei_Pause
            // 
            Button Shebei_Pause = new Button();
            Shebei_Pause.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            Shebei_Pause.Location = new System.Drawing.Point(96, 50);
            Shebei_Pause.Margin = new System.Windows.Forms.Padding(2);
            Shebei_Pause.Name = "Shebei_Pause"+x+y;
            Shebei_Pause.Size = new System.Drawing.Size(82, 36);
            Shebei_Pause.TabIndex = 2;
            Shebei_Pause.Text = "暂停";
            Shebei_Pause.UseVisualStyleBackColor = true;
            //   Shebei_Pause.Click += new System.EventHandler(this.SheBeiPause_Click);
            Shebei_Pause.Click += (e, a) => this.SheBeiPause_Click(shebeiname,x,y);
            // 
            // SheBei_L
            // 
            Button SheBei_L = new Button();
            SheBei_L.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            SheBei_L.Location = new System.Drawing.Point(9, 50);
            SheBei_L.Margin = new System.Windows.Forms.Padding(2);
            SheBei_L.Name = "SheBei_L"+x+y;
            SheBei_L.Size = new System.Drawing.Size(82, 36);
            SheBei_L.TabIndex = 1;
            SheBei_L.Text = "位置";
            SheBei_L.UseVisualStyleBackColor = true;
            // 
            // SheBei_Name
            // 
            Button SheBei_Name = new Button();
            SheBei_Name.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            SheBei_Name.Location = new System.Drawing.Point(9, 10);
            SheBei_Name.Margin = new System.Windows.Forms.Padding(2);
            SheBei_Name.Name = "SheBei_Name" + x + y;
            SheBei_Name.Size = new System.Drawing.Size(170, 35);
            SheBei_Name.TabIndex = 0;
            SheBei_Name.Text = shebeiname;
            SheBei_Name.UseVisualStyleBackColor = true;

            Panel SheBei_Panel = new Panel();
            SheBei_Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SheBei_Panel.Controls.Add(Shebei_DanKong);
            SheBei_Panel.Controls.Add(SheBei_V);
            SheBei_Panel.Controls.Add(Shebei_Pause);
            SheBei_Panel.Controls.Add(SheBei_L);
            SheBei_Panel.Controls.Add(SheBei_Name);
            SheBei_Panel.Location = new System.Drawing.Point(x, y);
            SheBei_Panel.Margin = new System.Windows.Forms.Padding(2);
            SheBei_Panel.Name = "SheBei_Panel"+x+y;
            SheBei_Panel.Size = new System.Drawing.Size(188, 140);
            SheBei_Panel.TabIndex = 3;
            this.Controls.Add(SheBei_Panel);
        }

        private void ShebeiDanKong_Click(string shebeiname,int x,int y)
        {
            if (Controls["Shebei_DanKong" + x + y] != null)
            {
                Controls["Shebei_DanKong" + x + y].BackColor = Color.AliceBlue;
            }
            if (ifpause == true)
            {
               // MessageBox.Show(shebeiname + "处于单控状态!");
              if(shebeiname.Contains("调速设备"))
                {
                    int i = int.Parse(shebeiname.Substring(4));
                    ChangCiSheZhiGlobalData.DK_Ts[i] = true;
                    ChangCiSheZhiGlobalData.A_SheBei[GetIndex(shebeiname)] = true;
                    MessageBox.Show(shebeiname + "处于单控状态!Ts");
                }
                else if (shebeiname.Contains("调速互锁类设备")) {
                    int i = int.Parse(shebeiname.Substring(7));
                    ChangCiSheZhiGlobalData.DK_TsHs[i] = true;
                    MessageBox.Show(shebeiname + "处于单控状态!Tshs");
                }
                else if (shebeiname.Contains("定速定位设备"))
                {
                    int i = int.Parse(shebeiname.Substring(6));
                    ChangCiSheZhiGlobalData.DK_DsDw[i] = true;
                    MessageBox.Show(shebeiname + "处于单控状态!Dsdw");
                }
                else if (shebeiname.Contains("定速设备"))
                {
                    int i = int.Parse(shebeiname.Substring(4));
                    ChangCiSheZhiGlobalData.DK_Ds[i] = true;
                    MessageBox.Show(shebeiname + "处于单控状态!ds");
                }
            }
            else
            {
                MessageBox.Show("请先点击允许按钮!");
            }
        }

        private void SheBeiPause_Click(string shebeiname,int x,int y)
        {
            if (Controls["Shebei_Pause" + x + y] != null)
            {
                Controls["Shebei_Pause" + x + y].BackColor = Color.AliceBlue;
            }
            if (ifpause == true)
            {
                MessageBox.Show(shebeiname + "暂停!");
            }
            else
            {
                MessageBox.Show("请先点击允许按钮!");
            }
        }
        public int GetIndex(string shebeiname)
        {
            if (shebeiname.Contains("调速设备"))
            {
                int i = int.Parse(shebeiname.Substring(4));
                return i;
            }
            else if (shebeiname.Contains("调速互锁类设备"))
            {
                int i = int.Parse(shebeiname.Substring(7));
                return i + n;
            }
            else if (shebeiname.Contains("定速定位设备"))
            {
                int i = int.Parse(shebeiname.Substring(6));
                return i + n + k;
            }
            else if (shebeiname.Contains("定速设备"))
            {
                int i = int.Parse(shebeiname.Substring(4));
                return i + n + k + m;
            }
            return 0;
        }
        private void delpanel(int x, int y)
        {
            Controls["SheBei_Panel" + x + y].Dispose();
        }
        private void delpanelall()
        {
            if (Controls["SheBei_Panel50120"] != null)
            {
                Controls["SheBei_Panel50120"].Dispose();
            }
            if (Controls["SheBei_Panel250120"] != null)
            {
                Controls["SheBei_Panel250120"].Dispose();
            }
            if (Controls["SheBei_Panel450120"] != null)
            {
                Controls["SheBei_Panel450120"].Dispose();
            }
            if (Controls["SheBei_Panel650120"] != null)
            {
                Controls["SheBei_Panel650120"].Dispose();
            }
            if (Controls["SheBei_Panel850120"] != null)
            {
                Controls["SheBei_Panel850120"].Dispose();
            }
            if (Controls["SheBei_Panel1050120"] != null)
            {
                Controls["SheBei_Panel1050120"].Dispose();
            }
            if (Controls["SheBei_Panel1250120"] != null)
            {
                Controls["SheBei_Panel1250120"].Dispose();
            }
            if (Controls["SheBei_Panel1450120"] != null)
            {
                Controls["SheBei_Panel1450120"].Dispose();
            }
            if (Controls["SheBei_Panel1650120"] != null)
            {
                Controls["SheBei_Panel1650120"].Dispose();
            }

            if (Controls["SheBei_Panel50320"] != null)
            {
                Controls["SheBei_Panel50320"].Dispose();
            }
            if (Controls["SheBei_Panel250320"] != null)
            {
                Controls["SheBei_Panel250320"].Dispose();
            }
            if (Controls["SheBei_Panel450320"] != null)
            {
                Controls["SheBei_Panel450320"].Dispose();
            }
            if (Controls["SheBei_Panel650320"] != null)
            {
                Controls["SheBei_Panel650320"].Dispose();
            }
            if (Controls["SheBei_Panel850320"] != null)
            {
                Controls["SheBei_Panel850320"].Dispose();
            }
            if (Controls["SheBei_Panel1050320"] != null)
            {
                Controls["SheBei_Panel1050320"].Dispose();
            }
            if (Controls["SheBei_Panel1250320"] != null)
            {
                Controls["SheBei_Panel1250320"].Dispose();
            }
            if (Controls["SheBei_Panel1450320"] != null)
            {
                Controls["SheBei_Panel1450320"].Dispose();
            }
            if (Controls["SheBei_Panel1650320"] != null)
            {
                Controls["SheBei_Panel1650320"].Dispose();

            }
            if (Controls["SheBei_Panel50520"] != null)
            {
                Controls["SheBei_Panel50520"].Dispose();
            }
            if (Controls["SheBei_Panel250520"] != null)
            {
                Controls["SheBei_Panel250520"].Dispose();
            }
            if (Controls["SheBei_Panel450520"] != null)
            {
                Controls["SheBei_Panel450520"].Dispose();
            }
            if (Controls["SheBei_Panel650520"] != null)
            {
                Controls["SheBei_Panel650520"].Dispose();
            }
            if (Controls["SheBei_Panel850520"] != null)
            {
                Controls["SheBei_Panel850520"].Dispose();
            }
            if (Controls["SheBei_Panel1050520"] != null)
            {
                Controls["SheBei_Panel1050520"].Dispose();
            }
            if (Controls["SheBei_Panel1250520"] != null)
            {
                Controls["SheBei_Panel1250520"].Dispose();
            }
            if (Controls["SheBei_Panel1450520"] != null)
            {
                Controls["SheBei_Panel1450520"].Dispose();
            }
            if (Controls["SheBei_Panel1650520"] != null)
            {
                Controls["SheBei_Panel1650520"].Dispose();
            }
        }
        private void ToLeft_Click(object sender, EventArgs e)
        {
            clickcount--;
         
            if (ChangCiSheZhiGlobalData.DanKongShengYuSheBei >= allshebei - 27)
            {
                MessageBox.Show("没有更多已编组设备！");
                clickcount++;
                //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
            }
            else
            {
                if (ChangCiSheZhiGlobalData.DanKongShengYuSheBei == 0)
                {
                    if (0 <= allshebei % 27 && allshebei % 27 <= 9) {
                        for(int i = 0; i < allshebei % 27; i++)
                        {
                            delpanel(50 + 200 * i, 120);
                        }
                    }else if (allshebei % 27 > 9 && allshebei % 27 <= 18)
                    {
                        for (int j = 9; j < allshebei % 27; j++)
                        {
                            delpanel(50 + 200 * (j - 9), 320);
                        }
                    }
                    else
                    {
                        int k = 0;
                        if (allshebei % 27 == 0)
                        {
                            k = 27;
                        }
                        else
                        {
                            k= allshebei % 27;
                        }
                        for (int j = 18; j < k; j++)
                        {
                            delpanel(50 + 200 * (j - 18), 520);
                        }
                    }
                }
                else
                {
                    for (int j = 0; j < 9; j++)
                    {
                        delpanel(50 + 200 * j, 120);
                    }
                    for (int j = 9; j < 18; j++)
                    {
                        delpanel(50 + 200 * (j - 9), 320);
                    }
                    for (int j = 18; j < 27; j++)
                    {
                        delpanel(50 + 200 * (j - 18), 520);
                    }
                }
                for (int i = 0; i < 9; i++)
                {
                    panelset(50 + 200 * i, 120, shebei[(allshebei / 27) * 27 - ((allshebei / 27) - clickcount) * 27 + i]);
                }
                for (int i = 9; i < 18; i++)
                {
                    panelset(50 + 200 * (i - 9), 320, shebei[(allshebei / 27) * 27 - ((allshebei / 27) - clickcount) * 27 + i]);
                }
                for (int i = 18; i < 27; i++)
                {
                    panelset(50 + 200 * (i - 18), 520, shebei[(allshebei / 27) * 27 - ((allshebei / 27) - clickcount) * 27 + i]);
                }

                if (ChangCiSheZhiGlobalData.DanKongShengYuSheBei == 0)
                {
                    if (allshebei % 27 == 0)
                    {
                        ChangCiSheZhiGlobalData.ShengYuSheBei = 27;
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 27;
                    }
                }
                else
                {
                    ChangCiSheZhiGlobalData.DanKongShengYuSheBei = ChangCiSheZhiGlobalData.DanKongShengYuSheBei + 27;
                }


            }
        }

        private void ToRight_Click(object sender, EventArgs e)
        {
            clickcount++;
            if (ChangCiSheZhiGlobalData.DanKongShengYuSheBei == 0)
            {
                MessageBox.Show("没有更多已编组设备！");
                // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                clickcount--;
            }
            else
            {
                for (int j = 0; j < 9; j++)
                {
                    delpanel(50 + 200 * j, 120);
                }
                for (int j = 9; j < 18; j++)
                {
                    delpanel(50 + 200 * (j - 9), 320);
                }
                for (int j = 18; j < 27; j++)
                {
                    delpanel(50 + 200 * (j - 18), 520);
                }
                if (ChangCiSheZhiGlobalData.DanKongShengYuSheBei <27 )
                {

                    if (0 <= ChangCiSheZhiGlobalData.DanKongShengYuSheBei && ChangCiSheZhiGlobalData.DanKongShengYuSheBei <= 9)
                    {
                        for (int i = 0; i < ChangCiSheZhiGlobalData.DanKongShengYuSheBei; i++)
                        {
                            panelset(50 + 200 * i, 120, shebei[27 * clickcount + i]);
                        }
                    }
                    else if (ChangCiSheZhiGlobalData.DanKongShengYuSheBei > 9 && ChangCiSheZhiGlobalData.DanKongShengYuSheBei <= 18)
                    {
                        for (int i = 0; i < 9; i++)
                        {
                            panelset(50 + 200 * i, 120, shebei[27 * clickcount + i]);
                        }
                        for (int i = 9; i < ChangCiSheZhiGlobalData.DanKongShengYuSheBei; i++)
                        {
                            panelset(50 + 200 * (i - 9), 320, shebei[27 * clickcount + i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 9; i++)
                        {
                            panelset(50 + 200 * i, 120, shebei[27 * clickcount + i]);
                        }
                        for (int i = 9; i < 18; i++)
                        {
                            panelset(50 + 200 * (i - 9), 320, shebei[27 * clickcount + i]);
                        }
                        for (int i = 18; i < ChangCiSheZhiGlobalData.DanKongShengYuSheBei; i++)
                        {
                            panelset(50 + 200 * (i - 18), 520, shebei[27 * clickcount + i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.DanKongShengYuSheBei = 0;
                }
                else
                {
                    for (int i = 0; i < 9; i++)
                    {
                        panelset(50 + 200 * i, 120, shebei[27 * clickcount + i]);
                    }
                    for (int i = 9; i < 18; i++)
                    {
                        panelset(50 + 200 * (i - 9), 320, shebei[27 * clickcount + i]);
                    }
                    for (int i = 18; i <27; i++)
                    {
                        panelset(50 + 200 * (i - 18), 520, shebei[27 * clickcount + i]);
                    }
                    ChangCiSheZhiGlobalData.DanKongShengYuSheBei = ChangCiSheZhiGlobalData.DanKongShengYuSheBei - 27;
                }
            }
        }

        private void CK_Allow_Click(object sender, EventArgs e)
        {
            if (ifpause == true)
            {
                MessageBox.Show("已经处于允许设备暂停状态!");
            }
            else
            {
                ifpause =true;
                MessageBox.Show("可允许设备暂停与单控!!");
            }
        }

        private void CK_Forbid_Click(object sender, EventArgs e)
        {
            if (ifpause == false)
            {
                MessageBox.Show("已经处于禁止设备暂停状态!");
            }
            else
            {
                ifpause = false;
                MessageBox.Show("已禁止设备暂停!!");
            }
        }
    }
}
