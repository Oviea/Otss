﻿namespace BigPro
{
    partial class bangtu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Bt_DSDW = new System.Windows.Forms.Button();
            this.label1034 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.BT_B2Main = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.L251 = new System.Windows.Forms.Label();
            this.label202 = new System.Windows.Forms.Label();
            this.L151 = new System.Windows.Forms.Label();
            this.L101 = new System.Windows.Forms.Label();
            this.L51 = new System.Windows.Forms.Label();
            this.L01 = new System.Windows.Forms.Label();
            this.Bt_ToL = new System.Windows.Forms.Button();
            this.Bt_ToR = new System.Windows.Forms.Button();
            this.Bt_TS = new System.Windows.Forms.Button();
            this.Bt_TX = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.imageList3 = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.L252 = new System.Windows.Forms.Label();
            this.L202 = new System.Windows.Forms.Label();
            this.L152 = new System.Windows.Forms.Label();
            this.L102 = new System.Windows.Forms.Label();
            this.L52 = new System.Windows.Forms.Label();
            this.L02 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.BT_Back = new System.Windows.Forms.Button();
            this.BT_ML = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // Bt_DSDW
            // 
            this.Bt_DSDW.BackColor = System.Drawing.Color.White;
            this.Bt_DSDW.Font = new System.Drawing.Font("宋体", 14.2F);
            this.Bt_DSDW.Location = new System.Drawing.Point(1074, 834);
            this.Bt_DSDW.Margin = new System.Windows.Forms.Padding(2);
            this.Bt_DSDW.Name = "Bt_DSDW";
            this.Bt_DSDW.Size = new System.Drawing.Size(112, 40);
            this.Bt_DSDW.TabIndex = 3088;
            this.Bt_DSDW.Text = "定速定位";
            this.Bt_DSDW.UseVisualStyleBackColor = false;
            this.Bt_DSDW.Click += new System.EventHandler(this.Bt_DSDW_Click);
            // 
            // label1034
            // 
            this.label1034.AutoSize = true;
            this.label1034.Location = new System.Drawing.Point(348, 834);
            this.label1034.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1034.Name = "label1034";
            this.label1034.Size = new System.Drawing.Size(0, 12);
            this.label1034.TabIndex = 3084;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(-264, 38);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 50);
            this.button1.TabIndex = 3082;
            this.button1.Text = "<<";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button32.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button32.Location = new System.Drawing.Point(-230, 986);
            this.button32.Margin = new System.Windows.Forms.Padding(2);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(200, 70);
            this.button32.TabIndex = 3081;
            this.button32.Text = "返回";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // BT_B2Main
            // 
            this.BT_B2Main.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BT_B2Main.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BT_B2Main.Location = new System.Drawing.Point(1668, 899);
            this.BT_B2Main.Margin = new System.Windows.Forms.Padding(2);
            this.BT_B2Main.Name = "BT_B2Main";
            this.BT_B2Main.Size = new System.Drawing.Size(200, 70);
            this.BT_B2Main.TabIndex = 3080;
            this.BT_B2Main.Text = "回首页";
            this.BT_B2Main.UseVisualStyleBackColor = true;
            this.BT_B2Main.Click += new System.EventHandler(this.BT_B2Main_Click);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(99, 206);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(2, 200);
            this.label8.TabIndex = 2230;
            this.label8.Text = "label8";
            // 
            // L251
            // 
            this.L251.AutoSize = true;
            this.L251.Enabled = false;
            this.L251.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.L251.Location = new System.Drawing.Point(10, 218);
            this.L251.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.L251.Name = "L251";
            this.L251.Size = new System.Drawing.Size(35, 16);
            this.L251.TabIndex = 2602;
            this.L251.Text = "25M";
            // 
            // label202
            // 
            this.label202.AutoSize = true;
            this.label202.Enabled = false;
            this.label202.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label202.Location = new System.Drawing.Point(10, 258);
            this.label202.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label202.Name = "label202";
            this.label202.Size = new System.Drawing.Size(35, 16);
            this.label202.TabIndex = 2601;
            this.label202.Text = "20M";
            // 
            // L151
            // 
            this.L151.AutoSize = true;
            this.L151.Enabled = false;
            this.L151.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.L151.Location = new System.Drawing.Point(10, 295);
            this.L151.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.L151.Name = "L151";
            this.L151.Size = new System.Drawing.Size(35, 16);
            this.L151.TabIndex = 2600;
            this.L151.Text = "15M";
            // 
            // L101
            // 
            this.L101.AutoSize = true;
            this.L101.Enabled = false;
            this.L101.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.L101.Location = new System.Drawing.Point(10, 335);
            this.L101.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.L101.Name = "L101";
            this.L101.Size = new System.Drawing.Size(35, 16);
            this.L101.TabIndex = 2599;
            this.L101.Text = "10M";
            // 
            // L51
            // 
            this.L51.AutoSize = true;
            this.L51.Enabled = false;
            this.L51.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.L51.Location = new System.Drawing.Point(10, 375);
            this.L51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.L51.Name = "L51";
            this.L51.Size = new System.Drawing.Size(26, 16);
            this.L51.TabIndex = 2598;
            this.L51.Text = "5M";
            // 
            // L01
            // 
            this.L01.AutoSize = true;
            this.L01.Enabled = false;
            this.L01.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.L01.Location = new System.Drawing.Point(10, 415);
            this.L01.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.L01.Name = "L01";
            this.L01.Size = new System.Drawing.Size(26, 16);
            this.L01.TabIndex = 2597;
            this.L01.Text = "0M";
            // 
            // Bt_ToL
            // 
            this.Bt_ToL.ForeColor = System.Drawing.Color.Black;
            this.Bt_ToL.Image = global::BigPro.Properties.Resources.Toleft;
            this.Bt_ToL.Location = new System.Drawing.Point(20, 9);
            this.Bt_ToL.Margin = new System.Windows.Forms.Padding(2);
            this.Bt_ToL.Name = "Bt_ToL";
            this.Bt_ToL.Size = new System.Drawing.Size(50, 50);
            this.Bt_ToL.TabIndex = 3096;
            this.Bt_ToL.UseVisualStyleBackColor = true;
            this.Bt_ToL.Click += new System.EventHandler(this.Bt_ToL_Click);
            // 
            // Bt_ToR
            // 
            this.Bt_ToR.ForeColor = System.Drawing.Color.Black;
            this.Bt_ToR.Image = global::BigPro.Properties.Resources.ToRight;
            this.Bt_ToR.Location = new System.Drawing.Point(1829, 9);
            this.Bt_ToR.Margin = new System.Windows.Forms.Padding(2);
            this.Bt_ToR.Name = "Bt_ToR";
            this.Bt_ToR.Size = new System.Drawing.Size(50, 50);
            this.Bt_ToR.TabIndex = 3097;
            this.Bt_ToR.UseVisualStyleBackColor = true;
            this.Bt_ToR.Click += new System.EventHandler(this.Bt_ToR_Click);
            // 
            // Bt_TS
            // 
            this.Bt_TS.BackColor = System.Drawing.Color.White;
            this.Bt_TS.Font = new System.Drawing.Font("宋体", 14.2F);
            this.Bt_TS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Bt_TS.Location = new System.Drawing.Point(752, 834);
            this.Bt_TS.Margin = new System.Windows.Forms.Padding(2);
            this.Bt_TS.Name = "Bt_TS";
            this.Bt_TS.Size = new System.Drawing.Size(112, 40);
            this.Bt_TS.TabIndex = 3098;
            this.Bt_TS.Text = "台上调速";
            this.Bt_TS.UseVisualStyleBackColor = false;
            this.Bt_TS.Click += new System.EventHandler(this.Bt_TS_Click);
            // 
            // Bt_TX
            // 
            this.Bt_TX.BackColor = System.Drawing.Color.White;
            this.Bt_TX.Font = new System.Drawing.Font("宋体", 14.2F);
            this.Bt_TX.Location = new System.Drawing.Point(913, 834);
            this.Bt_TX.Margin = new System.Windows.Forms.Padding(2);
            this.Bt_TX.Name = "Bt_TX";
            this.Bt_TX.Size = new System.Drawing.Size(112, 40);
            this.Bt_TX.TabIndex = 3099;
            this.Bt_TX.Text = "台下调速";
            this.Bt_TX.UseVisualStyleBackColor = false;
            this.Bt_TX.Click += new System.EventHandler(this.Bt_TX_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // imageList2
            // 
            this.imageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList2.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // imageList3
            // 
            this.imageList3.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList3.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList3.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("宋体", 15F);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(81, 212);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 27);
            this.label1.TabIndex = 3108;
            this.label1.Text = "↑";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(81, 209);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(11, 2);
            this.label2.TabIndex = 3109;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Red;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(81, 406);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 2);
            this.label3.TabIndex = 3107;
            this.label3.Text = "label3";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("宋体", 15F);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(81, 382);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 27);
            this.label5.TabIndex = 3110;
            this.label5.Text = "↓";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox9.Enabled = false;
            this.pictureBox9.Image = global::BigPro.Properties.Resources.xuxian;
            this.pictureBox9.Location = new System.Drawing.Point(54, 295);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(1900, 12);
            this.pictureBox9.TabIndex = 3127;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox10.Enabled = false;
            this.pictureBox10.Image = global::BigPro.Properties.Resources.xuxian;
            this.pictureBox10.Location = new System.Drawing.Point(54, 335);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(1900, 12);
            this.pictureBox10.TabIndex = 3126;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox11.Enabled = false;
            this.pictureBox11.Image = global::BigPro.Properties.Resources.xuxian;
            this.pictureBox11.Location = new System.Drawing.Point(54, 375);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(1900, 12);
            this.pictureBox11.TabIndex = 3125;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox12.Enabled = false;
            this.pictureBox12.Image = global::BigPro.Properties.Resources.xuxian;
            this.pictureBox12.Location = new System.Drawing.Point(54, 415);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(1900, 12);
            this.pictureBox12.TabIndex = 3124;
            this.pictureBox12.TabStop = false;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Red;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(227, 210);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(11, 2);
            this.label4.TabIndex = 3132;
            this.label4.Text = "label4";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Red;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(226, 406);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(11, 2);
            this.label6.TabIndex = 3130;
            this.label6.Text = "label6";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("宋体", 15F);
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(226, 382);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 27);
            this.label7.TabIndex = 3133;
            this.label7.Text = "↓";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("宋体", 15F);
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(226, 208);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 27);
            this.label9.TabIndex = 3131;
            this.label9.Text = "↑";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(249, 205);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(2, 200);
            this.label10.TabIndex = 3129;
            this.label10.Text = "label10";
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Red;
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(372, 211);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(11, 2);
            this.label11.TabIndex = 3137;
            this.label11.Text = "label11";
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Red;
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(371, 408);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(11, 2);
            this.label12.TabIndex = 3135;
            this.label12.Text = "label12";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("宋体", 15F);
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(371, 383);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(14, 27);
            this.label13.TabIndex = 3138;
            this.label13.Text = "↓";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("宋体", 15F);
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(371, 210);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 27);
            this.label14.TabIndex = 3136;
            this.label14.Text = "↑";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.ControlText;
            this.label15.Location = new System.Drawing.Point(399, 207);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(2, 200);
            this.label15.TabIndex = 3134;
            this.label15.Text = "label15";
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Red;
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(800, 211);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(11, 2);
            this.label16.TabIndex = 3152;
            this.label16.Text = "label16";
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Red;
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(799, 408);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(11, 2);
            this.label17.TabIndex = 3150;
            this.label17.Text = "label17";
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("宋体", 15F);
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(799, 383);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(14, 27);
            this.label18.TabIndex = 3153;
            this.label18.Text = "↓";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("宋体", 15F);
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(799, 210);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(14, 27);
            this.label19.TabIndex = 3151;
            this.label19.Text = "↑";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.SystemColors.ControlText;
            this.label20.Location = new System.Drawing.Point(849, 207);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(2, 200);
            this.label20.TabIndex = 3149;
            this.label20.Text = "label20";
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.Red;
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(655, 210);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(11, 2);
            this.label21.TabIndex = 3147;
            this.label21.Text = "label21";
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.Red;
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(654, 406);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(11, 2);
            this.label22.TabIndex = 3145;
            this.label22.Text = "label22";
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("宋体", 15F);
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(654, 382);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(14, 27);
            this.label23.TabIndex = 3148;
            this.label23.Text = "↓";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("宋体", 15F);
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(654, 208);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(14, 27);
            this.label24.TabIndex = 3146;
            this.label24.Text = "↑";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.SystemColors.ControlText;
            this.label25.Location = new System.Drawing.Point(699, 206);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(2, 200);
            this.label25.TabIndex = 3144;
            this.label25.Text = "label25";
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.Red;
            this.label26.ForeColor = System.Drawing.Color.Red;
            this.label26.Location = new System.Drawing.Point(531, 210);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(11, 2);
            this.label26.TabIndex = 3142;
            this.label26.Text = "label26";
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.Red;
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(523, 407);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(11, 2);
            this.label27.TabIndex = 3140;
            this.label27.Text = "label27";
            // 
            // label28
            // 
            this.label28.Font = new System.Drawing.Font("宋体", 15F);
            this.label28.ForeColor = System.Drawing.Color.Red;
            this.label28.Location = new System.Drawing.Point(529, 381);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(14, 27);
            this.label28.TabIndex = 3143;
            this.label28.Text = "↓";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.Font = new System.Drawing.Font("宋体", 15F);
            this.label29.ForeColor = System.Drawing.Color.Red;
            this.label29.Location = new System.Drawing.Point(529, 209);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(14, 27);
            this.label29.TabIndex = 3141;
            this.label29.Text = "↑";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.SystemColors.ControlText;
            this.label30.Location = new System.Drawing.Point(549, 206);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(2, 200);
            this.label30.TabIndex = 3139;
            this.label30.Text = "label30";
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.Red;
            this.label31.ForeColor = System.Drawing.Color.Red;
            this.label31.Location = new System.Drawing.Point(1368, 209);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(11, 2);
            this.label31.TabIndex = 3172;
            this.label31.Text = "label31";
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.Red;
            this.label32.ForeColor = System.Drawing.Color.Red;
            this.label32.Location = new System.Drawing.Point(1367, 406);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(11, 2);
            this.label32.TabIndex = 3170;
            this.label32.Text = "label32";
            // 
            // label33
            // 
            this.label33.Font = new System.Drawing.Font("宋体", 15F);
            this.label33.ForeColor = System.Drawing.Color.Red;
            this.label33.Location = new System.Drawing.Point(1367, 381);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(14, 27);
            this.label33.TabIndex = 3173;
            this.label33.Text = "↓";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("宋体", 15F);
            this.label34.ForeColor = System.Drawing.Color.Red;
            this.label34.Location = new System.Drawing.Point(1367, 207);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(14, 27);
            this.label34.TabIndex = 3171;
            this.label34.Text = "↑";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.SystemColors.ControlText;
            this.label35.Location = new System.Drawing.Point(1449, 205);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(2, 200);
            this.label35.TabIndex = 3169;
            this.label35.Text = "label35";
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.Red;
            this.label36.ForeColor = System.Drawing.Color.Red;
            this.label36.Location = new System.Drawing.Point(1226, 210);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(11, 2);
            this.label36.TabIndex = 3167;
            this.label36.Text = "label36";
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.Red;
            this.label37.ForeColor = System.Drawing.Color.Red;
            this.label37.Location = new System.Drawing.Point(1225, 407);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(11, 2);
            this.label37.TabIndex = 3165;
            this.label37.Text = "label37";
            // 
            // label38
            // 
            this.label38.Font = new System.Drawing.Font("宋体", 15F);
            this.label38.ForeColor = System.Drawing.Color.Red;
            this.label38.Location = new System.Drawing.Point(1225, 382);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(14, 27);
            this.label38.TabIndex = 3168;
            this.label38.Text = "↓";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.Font = new System.Drawing.Font("宋体", 15F);
            this.label39.ForeColor = System.Drawing.Color.Red;
            this.label39.Location = new System.Drawing.Point(1225, 209);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(14, 27);
            this.label39.TabIndex = 3166;
            this.label39.Text = "↑";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.SystemColors.ControlText;
            this.label40.Location = new System.Drawing.Point(1299, 206);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(2, 200);
            this.label40.TabIndex = 3164;
            this.label40.Text = "label40";
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.Red;
            this.label41.ForeColor = System.Drawing.Color.Red;
            this.label41.Location = new System.Drawing.Point(1081, 209);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(11, 2);
            this.label41.TabIndex = 3162;
            this.label41.Text = "label41";
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.Red;
            this.label42.ForeColor = System.Drawing.Color.Red;
            this.label42.Location = new System.Drawing.Point(1080, 406);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(11, 2);
            this.label42.TabIndex = 3160;
            this.label42.Text = "label42";
            // 
            // label43
            // 
            this.label43.Font = new System.Drawing.Font("宋体", 15F);
            this.label43.ForeColor = System.Drawing.Color.Red;
            this.label43.Location = new System.Drawing.Point(1080, 381);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(14, 27);
            this.label43.TabIndex = 3163;
            this.label43.Text = "↓";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.Font = new System.Drawing.Font("宋体", 15F);
            this.label44.ForeColor = System.Drawing.Color.Red;
            this.label44.Location = new System.Drawing.Point(1080, 207);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(14, 27);
            this.label44.TabIndex = 3161;
            this.label44.Text = "↑";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label45
            // 
            this.label45.BackColor = System.Drawing.SystemColors.ControlText;
            this.label45.Location = new System.Drawing.Point(1149, 205);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(2, 200);
            this.label45.TabIndex = 3159;
            this.label45.Text = "label45";
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.Color.Red;
            this.label46.ForeColor = System.Drawing.Color.Red;
            this.label46.Location = new System.Drawing.Point(940, 209);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(11, 2);
            this.label46.TabIndex = 3157;
            this.label46.Text = "label46";
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.Red;
            this.label47.ForeColor = System.Drawing.Color.Red;
            this.label47.Location = new System.Drawing.Point(940, 406);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(11, 2);
            this.label47.TabIndex = 3155;
            this.label47.Text = "label47";
            // 
            // label48
            // 
            this.label48.Font = new System.Drawing.Font("宋体", 15F);
            this.label48.ForeColor = System.Drawing.Color.Red;
            this.label48.Location = new System.Drawing.Point(940, 381);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(14, 27);
            this.label48.TabIndex = 3158;
            this.label48.Text = "↓";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.Font = new System.Drawing.Font("宋体", 15F);
            this.label49.ForeColor = System.Drawing.Color.Red;
            this.label49.Location = new System.Drawing.Point(940, 207);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(14, 27);
            this.label49.TabIndex = 3156;
            this.label49.Text = "↑";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.BackColor = System.Drawing.SystemColors.ControlText;
            this.label50.Location = new System.Drawing.Point(999, 205);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(2, 200);
            this.label50.TabIndex = 3154;
            this.label50.Text = "label50";
            // 
            // label51
            // 
            this.label51.BackColor = System.Drawing.Color.Red;
            this.label51.ForeColor = System.Drawing.Color.Red;
            this.label51.Location = new System.Drawing.Point(1368, 558);
            this.label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(11, 2);
            this.label51.TabIndex = 3234;
            this.label51.Text = "label51";
            // 
            // label52
            // 
            this.label52.BackColor = System.Drawing.Color.Red;
            this.label52.ForeColor = System.Drawing.Color.Red;
            this.label52.Location = new System.Drawing.Point(1367, 755);
            this.label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(11, 2);
            this.label52.TabIndex = 3232;
            this.label52.Text = "label52";
            // 
            // label53
            // 
            this.label53.Font = new System.Drawing.Font("宋体", 15F);
            this.label53.ForeColor = System.Drawing.Color.Red;
            this.label53.Location = new System.Drawing.Point(1367, 730);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(14, 27);
            this.label53.TabIndex = 3235;
            this.label53.Text = "↓";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.Font = new System.Drawing.Font("宋体", 15F);
            this.label54.ForeColor = System.Drawing.Color.Red;
            this.label54.Location = new System.Drawing.Point(1368, 557);
            this.label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(14, 27);
            this.label54.TabIndex = 3233;
            this.label54.Text = "↑";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.SystemColors.ControlText;
            this.label55.Location = new System.Drawing.Point(1449, 558);
            this.label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(2, 200);
            this.label55.TabIndex = 3231;
            this.label55.Text = "label55";
            // 
            // label56
            // 
            this.label56.BackColor = System.Drawing.Color.Red;
            this.label56.ForeColor = System.Drawing.Color.Red;
            this.label56.Location = new System.Drawing.Point(1226, 560);
            this.label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(11, 2);
            this.label56.TabIndex = 3229;
            this.label56.Text = "label56";
            // 
            // label57
            // 
            this.label57.BackColor = System.Drawing.Color.Red;
            this.label57.ForeColor = System.Drawing.Color.Red;
            this.label57.Location = new System.Drawing.Point(1225, 757);
            this.label57.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(11, 2);
            this.label57.TabIndex = 3227;
            this.label57.Text = "label57";
            // 
            // label58
            // 
            this.label58.Font = new System.Drawing.Font("宋体", 15F);
            this.label58.ForeColor = System.Drawing.Color.Red;
            this.label58.Location = new System.Drawing.Point(1225, 732);
            this.label58.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(14, 27);
            this.label58.TabIndex = 3230;
            this.label58.Text = "↓";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.Font = new System.Drawing.Font("宋体", 15F);
            this.label59.ForeColor = System.Drawing.Color.Red;
            this.label59.Location = new System.Drawing.Point(1225, 558);
            this.label59.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(14, 27);
            this.label59.TabIndex = 3228;
            this.label59.Text = "↑";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.SystemColors.ControlText;
            this.label60.Location = new System.Drawing.Point(1299, 554);
            this.label60.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(2, 200);
            this.label60.TabIndex = 3226;
            this.label60.Text = "label60";
            // 
            // label61
            // 
            this.label61.BackColor = System.Drawing.Color.Red;
            this.label61.ForeColor = System.Drawing.Color.Red;
            this.label61.Location = new System.Drawing.Point(1081, 558);
            this.label61.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(11, 2);
            this.label61.TabIndex = 3224;
            this.label61.Text = "label61";
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.Color.Red;
            this.label62.ForeColor = System.Drawing.Color.Red;
            this.label62.Location = new System.Drawing.Point(1080, 755);
            this.label62.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(11, 2);
            this.label62.TabIndex = 3222;
            this.label62.Text = "label62";
            // 
            // label63
            // 
            this.label63.Font = new System.Drawing.Font("宋体", 15F);
            this.label63.ForeColor = System.Drawing.Color.Red;
            this.label63.Location = new System.Drawing.Point(1080, 730);
            this.label63.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(14, 27);
            this.label63.TabIndex = 3225;
            this.label63.Text = "↓";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.Font = new System.Drawing.Font("宋体", 15F);
            this.label64.ForeColor = System.Drawing.Color.Red;
            this.label64.Location = new System.Drawing.Point(1080, 557);
            this.label64.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(14, 27);
            this.label64.TabIndex = 3223;
            this.label64.Text = "↑";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.SystemColors.ControlText;
            this.label65.Location = new System.Drawing.Point(1149, 554);
            this.label65.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(2, 200);
            this.label65.TabIndex = 3221;
            this.label65.Text = "label65";
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.Color.Red;
            this.label66.ForeColor = System.Drawing.Color.Red;
            this.label66.Location = new System.Drawing.Point(940, 558);
            this.label66.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(11, 2);
            this.label66.TabIndex = 3219;
            this.label66.Text = "label66";
            // 
            // label67
            // 
            this.label67.BackColor = System.Drawing.Color.Red;
            this.label67.ForeColor = System.Drawing.Color.Red;
            this.label67.Location = new System.Drawing.Point(940, 755);
            this.label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(11, 2);
            this.label67.TabIndex = 3217;
            this.label67.Text = "label67";
            // 
            // label68
            // 
            this.label68.Font = new System.Drawing.Font("宋体", 15F);
            this.label68.ForeColor = System.Drawing.Color.Red;
            this.label68.Location = new System.Drawing.Point(940, 730);
            this.label68.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(14, 27);
            this.label68.TabIndex = 3220;
            this.label68.Text = "↓";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label69
            // 
            this.label69.Font = new System.Drawing.Font("宋体", 15F);
            this.label69.ForeColor = System.Drawing.Color.Red;
            this.label69.Location = new System.Drawing.Point(940, 557);
            this.label69.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(14, 27);
            this.label69.TabIndex = 3218;
            this.label69.Text = "↑";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label70
            // 
            this.label70.BackColor = System.Drawing.SystemColors.ControlText;
            this.label70.Location = new System.Drawing.Point(999, 557);
            this.label70.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(2, 200);
            this.label70.TabIndex = 3216;
            this.label70.Text = "label70";
            // 
            // label71
            // 
            this.label71.BackColor = System.Drawing.Color.Red;
            this.label71.ForeColor = System.Drawing.Color.Red;
            this.label71.Location = new System.Drawing.Point(800, 561);
            this.label71.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(11, 2);
            this.label71.TabIndex = 3214;
            this.label71.Text = "label71";
            // 
            // label72
            // 
            this.label72.BackColor = System.Drawing.Color.Red;
            this.label72.ForeColor = System.Drawing.Color.Red;
            this.label72.Location = new System.Drawing.Point(799, 758);
            this.label72.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(11, 2);
            this.label72.TabIndex = 3212;
            this.label72.Text = "label72";
            // 
            // label73
            // 
            this.label73.Font = new System.Drawing.Font("宋体", 15F);
            this.label73.ForeColor = System.Drawing.Color.Red;
            this.label73.Location = new System.Drawing.Point(799, 733);
            this.label73.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(14, 27);
            this.label73.TabIndex = 3215;
            this.label73.Text = "↓";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.Font = new System.Drawing.Font("宋体", 15F);
            this.label74.ForeColor = System.Drawing.Color.Red;
            this.label74.Location = new System.Drawing.Point(799, 559);
            this.label74.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(14, 27);
            this.label74.TabIndex = 3213;
            this.label74.Text = "↑";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label75
            // 
            this.label75.BackColor = System.Drawing.SystemColors.ControlText;
            this.label75.Location = new System.Drawing.Point(849, 554);
            this.label75.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(2, 200);
            this.label75.TabIndex = 3211;
            this.label75.Text = "label75";
            // 
            // label76
            // 
            this.label76.BackColor = System.Drawing.Color.Red;
            this.label76.ForeColor = System.Drawing.Color.Red;
            this.label76.Location = new System.Drawing.Point(655, 559);
            this.label76.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(11, 2);
            this.label76.TabIndex = 3209;
            this.label76.Text = "label76";
            // 
            // label77
            // 
            this.label77.BackColor = System.Drawing.Color.Red;
            this.label77.ForeColor = System.Drawing.Color.Red;
            this.label77.Location = new System.Drawing.Point(654, 756);
            this.label77.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(11, 2);
            this.label77.TabIndex = 3207;
            this.label77.Text = "label77";
            // 
            // label78
            // 
            this.label78.Font = new System.Drawing.Font("宋体", 15F);
            this.label78.ForeColor = System.Drawing.Color.Red;
            this.label78.Location = new System.Drawing.Point(654, 731);
            this.label78.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(14, 27);
            this.label78.TabIndex = 3210;
            this.label78.Text = "↓";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label79
            // 
            this.label79.Font = new System.Drawing.Font("宋体", 15F);
            this.label79.ForeColor = System.Drawing.Color.Red;
            this.label79.Location = new System.Drawing.Point(654, 558);
            this.label79.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(14, 27);
            this.label79.TabIndex = 3208;
            this.label79.Text = "↑";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label80
            // 
            this.label80.BackColor = System.Drawing.SystemColors.ControlText;
            this.label80.Location = new System.Drawing.Point(699, 555);
            this.label80.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(2, 200);
            this.label80.TabIndex = 3206;
            this.label80.Text = "label80";
            // 
            // label81
            // 
            this.label81.BackColor = System.Drawing.Color.Red;
            this.label81.ForeColor = System.Drawing.Color.Red;
            this.label81.Location = new System.Drawing.Point(514, 559);
            this.label81.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(11, 2);
            this.label81.TabIndex = 3204;
            this.label81.Text = "label81";
            // 
            // label82
            // 
            this.label82.BackColor = System.Drawing.Color.Red;
            this.label82.ForeColor = System.Drawing.Color.Red;
            this.label82.Location = new System.Drawing.Point(514, 756);
            this.label82.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(11, 2);
            this.label82.TabIndex = 3202;
            this.label82.Text = "label82";
            // 
            // label83
            // 
            this.label83.Font = new System.Drawing.Font("宋体", 15F);
            this.label83.ForeColor = System.Drawing.Color.Red;
            this.label83.Location = new System.Drawing.Point(514, 731);
            this.label83.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(14, 27);
            this.label83.TabIndex = 3205;
            this.label83.Text = "↓";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label84
            // 
            this.label84.Font = new System.Drawing.Font("宋体", 15F);
            this.label84.ForeColor = System.Drawing.Color.Red;
            this.label84.Location = new System.Drawing.Point(514, 558);
            this.label84.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(14, 27);
            this.label84.TabIndex = 3203;
            this.label84.Text = "↑";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label85
            // 
            this.label85.BackColor = System.Drawing.SystemColors.ControlText;
            this.label85.Location = new System.Drawing.Point(549, 554);
            this.label85.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(2, 200);
            this.label85.TabIndex = 3201;
            this.label85.Text = "label85";
            // 
            // label86
            // 
            this.label86.BackColor = System.Drawing.Color.Red;
            this.label86.ForeColor = System.Drawing.Color.Red;
            this.label86.Location = new System.Drawing.Point(372, 561);
            this.label86.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(11, 2);
            this.label86.TabIndex = 3199;
            this.label86.Text = "label86";
            // 
            // label87
            // 
            this.label87.BackColor = System.Drawing.Color.Red;
            this.label87.ForeColor = System.Drawing.Color.Red;
            this.label87.Location = new System.Drawing.Point(371, 758);
            this.label87.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(11, 2);
            this.label87.TabIndex = 3197;
            this.label87.Text = "label87";
            // 
            // label88
            // 
            this.label88.Font = new System.Drawing.Font("宋体", 15F);
            this.label88.ForeColor = System.Drawing.Color.Red;
            this.label88.Location = new System.Drawing.Point(371, 733);
            this.label88.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(14, 27);
            this.label88.TabIndex = 3200;
            this.label88.Text = "↓";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label89
            // 
            this.label89.Font = new System.Drawing.Font("宋体", 15F);
            this.label89.ForeColor = System.Drawing.Color.Red;
            this.label89.Location = new System.Drawing.Point(371, 559);
            this.label89.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(14, 27);
            this.label89.TabIndex = 3198;
            this.label89.Text = "↑";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label90
            // 
            this.label90.BackColor = System.Drawing.SystemColors.ControlText;
            this.label90.Location = new System.Drawing.Point(399, 554);
            this.label90.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(2, 200);
            this.label90.TabIndex = 3196;
            this.label90.Text = "label90";
            // 
            // label91
            // 
            this.label91.BackColor = System.Drawing.Color.Red;
            this.label91.ForeColor = System.Drawing.Color.Red;
            this.label91.Location = new System.Drawing.Point(227, 559);
            this.label91.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(11, 2);
            this.label91.TabIndex = 3194;
            this.label91.Text = "label91";
            // 
            // label92
            // 
            this.label92.BackColor = System.Drawing.Color.Red;
            this.label92.ForeColor = System.Drawing.Color.Red;
            this.label92.Location = new System.Drawing.Point(226, 756);
            this.label92.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(11, 2);
            this.label92.TabIndex = 3192;
            this.label92.Text = "label92";
            // 
            // label93
            // 
            this.label93.Font = new System.Drawing.Font("宋体", 15F);
            this.label93.ForeColor = System.Drawing.Color.Red;
            this.label93.Location = new System.Drawing.Point(226, 731);
            this.label93.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(14, 27);
            this.label93.TabIndex = 3195;
            this.label93.Text = "↓";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label94
            // 
            this.label94.Font = new System.Drawing.Font("宋体", 15F);
            this.label94.ForeColor = System.Drawing.Color.Red;
            this.label94.Location = new System.Drawing.Point(226, 558);
            this.label94.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(14, 27);
            this.label94.TabIndex = 3193;
            this.label94.Text = "↑";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label95
            // 
            this.label95.BackColor = System.Drawing.SystemColors.ControlText;
            this.label95.Location = new System.Drawing.Point(249, 555);
            this.label95.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(2, 200);
            this.label95.TabIndex = 3191;
            this.label95.Text = "label95";
            // 
            // label96
            // 
            this.label96.BackColor = System.Drawing.Color.Red;
            this.label96.ForeColor = System.Drawing.Color.Red;
            this.label96.Location = new System.Drawing.Point(80, 559);
            this.label96.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(11, 2);
            this.label96.TabIndex = 3183;
            this.label96.Text = "label96";
            // 
            // label97
            // 
            this.label97.BackColor = System.Drawing.Color.Red;
            this.label97.ForeColor = System.Drawing.Color.Red;
            this.label97.Location = new System.Drawing.Point(80, 755);
            this.label97.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(11, 2);
            this.label97.TabIndex = 3181;
            this.label97.Text = "label97";
            // 
            // label98
            // 
            this.label98.Font = new System.Drawing.Font("宋体", 15F);
            this.label98.ForeColor = System.Drawing.Color.Red;
            this.label98.Location = new System.Drawing.Point(78, 729);
            this.label98.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(14, 27);
            this.label98.TabIndex = 3184;
            this.label98.Text = "↓";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label99
            // 
            this.label99.Font = new System.Drawing.Font("宋体", 15F);
            this.label99.ForeColor = System.Drawing.Color.Red;
            this.label99.Location = new System.Drawing.Point(78, 561);
            this.label99.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(14, 27);
            this.label99.TabIndex = 3182;
            this.label99.Text = "↑";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label100
            // 
            this.label100.BackColor = System.Drawing.SystemColors.ControlText;
            this.label100.Location = new System.Drawing.Point(98, 556);
            this.label100.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(2, 200);
            this.label100.TabIndex = 3174;
            this.label100.Text = "label100";
            // 
            // L252
            // 
            this.L252.AutoSize = true;
            this.L252.Enabled = false;
            this.L252.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.L252.Location = new System.Drawing.Point(10, 567);
            this.L252.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.L252.Name = "L252";
            this.L252.Size = new System.Drawing.Size(35, 16);
            this.L252.TabIndex = 3180;
            this.L252.Text = "25M";
            // 
            // L202
            // 
            this.L202.AutoSize = true;
            this.L202.Enabled = false;
            this.L202.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.L202.Location = new System.Drawing.Point(10, 607);
            this.L202.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.L202.Name = "L202";
            this.L202.Size = new System.Drawing.Size(35, 16);
            this.L202.TabIndex = 3179;
            this.L202.Text = "20M";
            // 
            // L152
            // 
            this.L152.AutoSize = true;
            this.L152.Enabled = false;
            this.L152.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.L152.Location = new System.Drawing.Point(10, 645);
            this.L152.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.L152.Name = "L152";
            this.L152.Size = new System.Drawing.Size(35, 16);
            this.L152.TabIndex = 3178;
            this.L152.Text = "15M";
            // 
            // L102
            // 
            this.L102.AutoSize = true;
            this.L102.Enabled = false;
            this.L102.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.L102.Location = new System.Drawing.Point(10, 685);
            this.L102.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.L102.Name = "L102";
            this.L102.Size = new System.Drawing.Size(35, 16);
            this.L102.TabIndex = 3177;
            this.L102.Text = "10M";
            // 
            // L52
            // 
            this.L52.AutoSize = true;
            this.L52.Enabled = false;
            this.L52.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.L52.Location = new System.Drawing.Point(10, 725);
            this.L52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.L52.Name = "L52";
            this.L52.Size = new System.Drawing.Size(26, 16);
            this.L52.TabIndex = 3176;
            this.L52.Text = "5M";
            // 
            // L02
            // 
            this.L02.AutoSize = true;
            this.L02.Enabled = false;
            this.L02.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.L02.Location = new System.Drawing.Point(10, 765);
            this.L02.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.L02.Name = "L02";
            this.L02.Size = new System.Drawing.Size(26, 16);
            this.L02.TabIndex = 3175;
            this.L02.Text = "0M";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Image = global::BigPro.Properties.Resources.xuxian;
            this.pictureBox1.Location = new System.Drawing.Point(54, 567);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1900, 12);
            this.pictureBox1.TabIndex = 3185;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Enabled = false;
            this.pictureBox2.Image = global::BigPro.Properties.Resources.xuxian;
            this.pictureBox2.Location = new System.Drawing.Point(54, 607);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1900, 12);
            this.pictureBox2.TabIndex = 3190;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox3.Enabled = false;
            this.pictureBox3.Image = global::BigPro.Properties.Resources.xuxian;
            this.pictureBox3.Location = new System.Drawing.Point(54, 645);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(1900, 12);
            this.pictureBox3.TabIndex = 3189;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox4.Enabled = false;
            this.pictureBox4.Image = global::BigPro.Properties.Resources.xuxian;
            this.pictureBox4.Location = new System.Drawing.Point(54, 685);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(1900, 12);
            this.pictureBox4.TabIndex = 3188;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox5.Enabled = false;
            this.pictureBox5.Image = global::BigPro.Properties.Resources.xuxian;
            this.pictureBox5.Location = new System.Drawing.Point(54, 725);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(1900, 12);
            this.pictureBox5.TabIndex = 3187;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox6.Enabled = false;
            this.pictureBox6.Image = global::BigPro.Properties.Resources.xuxian;
            this.pictureBox6.Location = new System.Drawing.Point(54, 765);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(1900, 12);
            this.pictureBox6.TabIndex = 3186;
            this.pictureBox6.TabStop = false;
            // 
            // BT_Back
            // 
            this.BT_Back.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BT_Back.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BT_Back.Location = new System.Drawing.Point(47, 899);
            this.BT_Back.Margin = new System.Windows.Forms.Padding(2);
            this.BT_Back.Name = "BT_Back";
            this.BT_Back.Size = new System.Drawing.Size(200, 70);
            this.BT_Back.TabIndex = 3236;
            this.BT_Back.Text = "返回";
            this.BT_Back.UseVisualStyleBackColor = true;
            this.BT_Back.Click += new System.EventHandler(this.BT_Back_Click);
            // 
            // BT_ML
            // 
            this.BT_ML.AutoSize = true;
            this.BT_ML.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BT_ML.Location = new System.Drawing.Point(873, 17);
            this.BT_ML.Name = "BT_ML";
            this.BT_ML.Size = new System.Drawing.Size(106, 24);
            this.BT_ML.TabIndex = 3237;
            this.BT_ML.Text = "台上调速";
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox8.Enabled = false;
            this.pictureBox8.Image = global::BigPro.Properties.Resources.xuxian;
            this.pictureBox8.Location = new System.Drawing.Point(54, 258);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(1900, 12);
            this.pictureBox8.TabIndex = 3128;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox7.Enabled = false;
            this.pictureBox7.Image = global::BigPro.Properties.Resources.xuxian1;
            this.pictureBox7.Location = new System.Drawing.Point(54, 218);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(1900, 12);
            this.pictureBox7.TabIndex = 3123;
            this.pictureBox7.TabStop = false;
            // 
            // label115
            // 
            this.label115.BackColor = System.Drawing.SystemColors.ControlText;
            this.label115.Location = new System.Drawing.Point(1599, 205);
            this.label115.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(2, 200);
            this.label115.TabIndex = 3248;
            this.label115.Text = "label115";
            // 
            // label116
            // 
            this.label116.BackColor = System.Drawing.SystemColors.ControlText;
            this.label116.Location = new System.Drawing.Point(1749, 205);
            this.label116.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(2, 200);
            this.label116.TabIndex = 3249;
            this.label116.Text = "label116";
            // 
            // label117
            // 
            this.label117.BackColor = System.Drawing.SystemColors.ControlText;
            this.label117.Location = new System.Drawing.Point(1599, 556);
            this.label117.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(2, 200);
            this.label117.TabIndex = 3250;
            this.label117.Text = "label117";
            // 
            // label118
            // 
            this.label118.BackColor = System.Drawing.SystemColors.ControlText;
            this.label118.Location = new System.Drawing.Point(1749, 555);
            this.label118.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(2, 200);
            this.label118.TabIndex = 3251;
            this.label118.Text = "label118";
            // 
            // label119
            // 
            this.label119.Font = new System.Drawing.Font("宋体", 15F);
            this.label119.ForeColor = System.Drawing.Color.Red;
            this.label119.Location = new System.Drawing.Point(1510, 208);
            this.label119.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(14, 27);
            this.label119.TabIndex = 3252;
            this.label119.Text = "↑";
            this.label119.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label120
            // 
            this.label120.Font = new System.Drawing.Font("宋体", 15F);
            this.label120.ForeColor = System.Drawing.Color.Red;
            this.label120.Location = new System.Drawing.Point(1664, 209);
            this.label120.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(14, 27);
            this.label120.TabIndex = 3253;
            this.label120.Text = "↑";
            this.label120.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label121
            // 
            this.label121.Font = new System.Drawing.Font("宋体", 15F);
            this.label121.ForeColor = System.Drawing.Color.Red;
            this.label121.Location = new System.Drawing.Point(1510, 557);
            this.label121.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(14, 27);
            this.label121.TabIndex = 3254;
            this.label121.Text = "↑";
            this.label121.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label122
            // 
            this.label122.Font = new System.Drawing.Font("宋体", 15F);
            this.label122.ForeColor = System.Drawing.Color.Red;
            this.label122.Location = new System.Drawing.Point(1664, 557);
            this.label122.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(14, 27);
            this.label122.TabIndex = 3255;
            this.label122.Text = "↑";
            this.label122.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label123
            // 
            this.label123.Font = new System.Drawing.Font("宋体", 15F);
            this.label123.ForeColor = System.Drawing.Color.Red;
            this.label123.Location = new System.Drawing.Point(1510, 382);
            this.label123.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(14, 27);
            this.label123.TabIndex = 3256;
            this.label123.Text = "↓";
            this.label123.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label124
            // 
            this.label124.Font = new System.Drawing.Font("宋体", 15F);
            this.label124.ForeColor = System.Drawing.Color.Red;
            this.label124.Location = new System.Drawing.Point(1671, 380);
            this.label124.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(14, 27);
            this.label124.TabIndex = 3257;
            this.label124.Text = "↓";
            this.label124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label125
            // 
            this.label125.Font = new System.Drawing.Font("宋体", 15F);
            this.label125.ForeColor = System.Drawing.Color.Red;
            this.label125.Location = new System.Drawing.Point(1510, 733);
            this.label125.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(14, 27);
            this.label125.TabIndex = 3258;
            this.label125.Text = "↓";
            this.label125.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label126
            // 
            this.label126.Font = new System.Drawing.Font("宋体", 15F);
            this.label126.ForeColor = System.Drawing.Color.Red;
            this.label126.Location = new System.Drawing.Point(1664, 733);
            this.label126.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(14, 27);
            this.label126.TabIndex = 3259;
            this.label126.Text = "↓";
            this.label126.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label127
            // 
            this.label127.BackColor = System.Drawing.Color.Red;
            this.label127.ForeColor = System.Drawing.Color.Red;
            this.label127.Location = new System.Drawing.Point(1512, 208);
            this.label127.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(11, 2);
            this.label127.TabIndex = 3260;
            this.label127.Text = "label127";
            // 
            // label128
            // 
            this.label128.BackColor = System.Drawing.Color.Red;
            this.label128.ForeColor = System.Drawing.Color.Red;
            this.label128.Location = new System.Drawing.Point(1666, 207);
            this.label128.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(11, 2);
            this.label128.TabIndex = 3261;
            this.label128.Text = "label128";
            // 
            // label129
            // 
            this.label129.BackColor = System.Drawing.Color.Red;
            this.label129.ForeColor = System.Drawing.Color.Red;
            this.label129.Location = new System.Drawing.Point(1512, 404);
            this.label129.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(11, 2);
            this.label129.TabIndex = 3262;
            this.label129.Text = "label129";
            // 
            // label130
            // 
            this.label130.BackColor = System.Drawing.Color.Red;
            this.label130.ForeColor = System.Drawing.Color.Red;
            this.label130.Location = new System.Drawing.Point(1673, 405);
            this.label130.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(11, 2);
            this.label130.TabIndex = 3263;
            this.label130.Text = "label130";
            // 
            // label131
            // 
            this.label131.BackColor = System.Drawing.Color.Red;
            this.label131.ForeColor = System.Drawing.Color.Red;
            this.label131.Location = new System.Drawing.Point(1512, 755);
            this.label131.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(11, 2);
            this.label131.TabIndex = 3264;
            this.label131.Text = "label131";
            // 
            // label132
            // 
            this.label132.BackColor = System.Drawing.Color.Red;
            this.label132.ForeColor = System.Drawing.Color.Red;
            this.label132.Location = new System.Drawing.Point(1666, 755);
            this.label132.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(11, 2);
            this.label132.TabIndex = 3265;
            this.label132.Text = "label132";
            // 
            // L201
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.label132);
            this.Controls.Add(this.label131);
            this.Controls.Add(this.label130);
            this.Controls.Add(this.label129);
            this.Controls.Add(this.label128);
            this.Controls.Add(this.label127);
            this.Controls.Add(this.label126);
            this.Controls.Add(this.label125);
            this.Controls.Add(this.label124);
            this.Controls.Add(this.label123);
            this.Controls.Add(this.label122);
            this.Controls.Add(this.label121);
            this.Controls.Add(this.label120);
            this.Controls.Add(this.label119);
            this.Controls.Add(this.label118);
            this.Controls.Add(this.label117);
            this.Controls.Add(this.label116);
            this.Controls.Add(this.label115);
            this.Controls.Add(this.BT_ML);
            this.Controls.Add(this.BT_Back);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.label70);
            this.Controls.Add(this.label71);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.label73);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.label76);
            this.Controls.Add(this.label77);
            this.Controls.Add(this.label78);
            this.Controls.Add(this.label79);
            this.Controls.Add(this.label80);
            this.Controls.Add(this.label81);
            this.Controls.Add(this.label82);
            this.Controls.Add(this.label83);
            this.Controls.Add(this.label84);
            this.Controls.Add(this.label85);
            this.Controls.Add(this.label86);
            this.Controls.Add(this.label87);
            this.Controls.Add(this.label88);
            this.Controls.Add(this.label89);
            this.Controls.Add(this.label90);
            this.Controls.Add(this.label91);
            this.Controls.Add(this.label92);
            this.Controls.Add(this.label93);
            this.Controls.Add(this.label94);
            this.Controls.Add(this.label95);
            this.Controls.Add(this.label96);
            this.Controls.Add(this.label97);
            this.Controls.Add(this.label98);
            this.Controls.Add(this.label99);
            this.Controls.Add(this.label100);
            this.Controls.Add(this.L252);
            this.Controls.Add(this.L202);
            this.Controls.Add(this.L152);
            this.Controls.Add(this.L102);
            this.Controls.Add(this.L52);
            this.Controls.Add(this.L02);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Bt_TX);
            this.Controls.Add(this.Bt_TS);
            this.Controls.Add(this.Bt_ToR);
            this.Controls.Add(this.Bt_ToL);
            this.Controls.Add(this.Bt_DSDW);
            this.Controls.Add(this.label1034);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.BT_B2Main);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.L251);
            this.Controls.Add(this.label202);
            this.Controls.Add(this.L151);
            this.Controls.Add(this.L101);
            this.Controls.Add(this.L51);
            this.Controls.Add(this.L01);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox12);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "L201";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "bangtu";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.bangtu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Bt_DSDW;
        private System.Windows.Forms.Label label1034;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button BT_B2Main;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label L251;
        private System.Windows.Forms.Label label202;
        private System.Windows.Forms.Label L151;
        private System.Windows.Forms.Label L101;
        private System.Windows.Forms.Label L51;
        private System.Windows.Forms.Label L01;
        private System.Windows.Forms.Button Bt_ToL;
        private System.Windows.Forms.Button Bt_ToR;
        private System.Windows.Forms.Button Bt_TS;
        private System.Windows.Forms.Button Bt_TX;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.ImageList imageList3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label L252;
        private System.Windows.Forms.Label L202;
        private System.Windows.Forms.Label L152;
        private System.Windows.Forms.Label L102;
        private System.Windows.Forms.Label L52;
        private System.Windows.Forms.Label L02;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button BT_Back;
        private System.Windows.Forms.Label BT_ML;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
    }
}