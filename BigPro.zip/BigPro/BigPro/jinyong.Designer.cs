﻿namespace BigPro
{
    partial class jinyong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.JY_ToLeft = new System.Windows.Forms.Button();
            this.JY_ToRight = new System.Windows.Forms.Button();
            this.JY_MainPage = new System.Windows.Forms.Button();
            this.JY_Back = new System.Windows.Forms.Button();
            this.JY_QX = new System.Windows.Forms.Button();
            this.JY_QBQX = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.JY_ML = new System.Windows.Forms.Label();
            this.JY_QR = new System.Windows.Forms.Button();
            this.JY_TJ = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // JY_ToLeft
            // 
            this.JY_ToLeft.ForeColor = System.Drawing.Color.Black;
            this.JY_ToLeft.Image = global::BigPro.Properties.Resources.Toleft;
            this.JY_ToLeft.Location = new System.Drawing.Point(11, 11);
            this.JY_ToLeft.Margin = new System.Windows.Forms.Padding(2);
            this.JY_ToLeft.Name = "JY_ToLeft";
            this.JY_ToLeft.Size = new System.Drawing.Size(50, 50);
            this.JY_ToLeft.TabIndex = 473;
            this.JY_ToLeft.UseVisualStyleBackColor = true;
            this.JY_ToLeft.Click += new System.EventHandler(this.JY_ToLeft_Click);
            // 
            // JY_ToRight
            // 
            this.JY_ToRight.ForeColor = System.Drawing.Color.Black;
            this.JY_ToRight.Image = global::BigPro.Properties.Resources.ToRight;
            this.JY_ToRight.Location = new System.Drawing.Point(1856, 15);
            this.JY_ToRight.Margin = new System.Windows.Forms.Padding(2);
            this.JY_ToRight.Name = "JY_ToRight";
            this.JY_ToRight.Size = new System.Drawing.Size(50, 50);
            this.JY_ToRight.TabIndex = 472;
            this.JY_ToRight.UseVisualStyleBackColor = true;
            this.JY_ToRight.Click += new System.EventHandler(this.JY_ToRight_Click);
            // 
            // JY_MainPage
            // 
            this.JY_MainPage.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.JY_MainPage.Location = new System.Drawing.Point(1773, 932);
            this.JY_MainPage.Margin = new System.Windows.Forms.Padding(2);
            this.JY_MainPage.Name = "JY_MainPage";
            this.JY_MainPage.Size = new System.Drawing.Size(112, 40);
            this.JY_MainPage.TabIndex = 471;
            this.JY_MainPage.Text = "回首页";
            this.JY_MainPage.UseVisualStyleBackColor = true;
            // 
            // JY_Back
            // 
            this.JY_Back.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.JY_Back.Location = new System.Drawing.Point(49, 932);
            this.JY_Back.Margin = new System.Windows.Forms.Padding(2);
            this.JY_Back.Name = "JY_Back";
            this.JY_Back.Size = new System.Drawing.Size(112, 40);
            this.JY_Back.TabIndex = 470;
            this.JY_Back.Text = "返回";
            this.JY_Back.UseVisualStyleBackColor = true;
            // 
            // JY_QX
            // 
            this.JY_QX.BackColor = System.Drawing.Color.White;
            this.JY_QX.Font = new System.Drawing.Font("宋体", 14.2F);
            this.JY_QX.Location = new System.Drawing.Point(790, 851);
            this.JY_QX.Margin = new System.Windows.Forms.Padding(2);
            this.JY_QX.Name = "JY_QX";
            this.JY_QX.Size = new System.Drawing.Size(112, 40);
            this.JY_QX.TabIndex = 469;
            this.JY_QX.Text = "已禁用";
            this.JY_QX.UseVisualStyleBackColor = false;
            this.JY_QX.Click += new System.EventHandler(this.JY_QX_Click);
            // 
            // JY_QBQX
            // 
            this.JY_QBQX.BackColor = System.Drawing.Color.White;
            this.JY_QBQX.Font = new System.Drawing.Font("宋体", 14.2F);
            this.JY_QBQX.Location = new System.Drawing.Point(999, 851);
            this.JY_QBQX.Margin = new System.Windows.Forms.Padding(2);
            this.JY_QBQX.Name = "JY_QBQX";
            this.JY_QBQX.Size = new System.Drawing.Size(112, 40);
            this.JY_QBQX.TabIndex = 467;
            this.JY_QBQX.Text = "全部取消";
            this.JY_QBQX.UseVisualStyleBackColor = false;
            this.JY_QBQX.Click += new System.EventHandler(this.JY_QBQX_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Enabled = false;
            this.label2.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label2.Location = new System.Drawing.Point(-5, 133);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1940, 3);
            this.label2.TabIndex = 466;
            // 
            // JY_ML
            // 
            this.JY_ML.Font = new System.Drawing.Font("宋体", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.JY_ML.Location = new System.Drawing.Point(883, 25);
            this.JY_ML.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.JY_ML.Name = "JY_ML";
            this.JY_ML.Size = new System.Drawing.Size(120, 27);
            this.JY_ML.TabIndex = 465;
            this.JY_ML.Text = "设备禁用";
            // 
            // JY_QR
            // 
            this.JY_QR.BackColor = System.Drawing.Color.White;
            this.JY_QR.Font = new System.Drawing.Font("宋体", 14.2F);
            this.JY_QR.Location = new System.Drawing.Point(1081, 21);
            this.JY_QR.Margin = new System.Windows.Forms.Padding(2);
            this.JY_QR.Name = "JY_QR";
            this.JY_QR.Size = new System.Drawing.Size(75, 40);
            this.JY_QR.TabIndex = 464;
            this.JY_QR.Text = "确认";
            this.JY_QR.UseVisualStyleBackColor = false;
            // 
            // JY_TJ
            // 
            this.JY_TJ.BackColor = System.Drawing.Color.White;
            this.JY_TJ.Font = new System.Drawing.Font("宋体", 14.2F);
            this.JY_TJ.Location = new System.Drawing.Point(730, 21);
            this.JY_TJ.Margin = new System.Windows.Forms.Padding(2);
            this.JY_TJ.Name = "JY_TJ";
            this.JY_TJ.Size = new System.Drawing.Size(75, 40);
            this.JY_TJ.TabIndex = 463;
            this.JY_TJ.Text = "添加";
            this.JY_TJ.UseVisualStyleBackColor = false;
            this.JY_TJ.Click += new System.EventHandler(this.JY_TJ_Click);
            // 
            // jinyong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.JY_ToLeft);
            this.Controls.Add(this.JY_ToRight);
            this.Controls.Add(this.JY_MainPage);
            this.Controls.Add(this.JY_Back);
            this.Controls.Add(this.JY_QX);
            this.Controls.Add(this.JY_QBQX);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.JY_ML);
            this.Controls.Add(this.JY_QR);
            this.Controls.Add(this.JY_TJ);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "jinyong";
            this.Text = "jinyong";
            this.Load += new System.EventHandler(this.jinyong_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button JY_ToLeft;
        private System.Windows.Forms.Button JY_ToRight;
        private System.Windows.Forms.Button JY_MainPage;
        private System.Windows.Forms.Button JY_Back;
        private System.Windows.Forms.Button JY_QX;
        private System.Windows.Forms.Button JY_QBQX;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label JY_ML;
        private System.Windows.Forms.Button JY_QR;
        private System.Windows.Forms.Button JY_TJ;
    }
}