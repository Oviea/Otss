﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class bangtu : Form
    {
        private static int allshebei;
        private static string[] shebei;
        private int n, k, m, p;
        private static int clickcountTsTs;
        private static int clickcountTxTs;
        private static int clickcountDsDw;
        private static int ButtonFlag;//0:台上调速 1:台下调速 2：定速定位
        DBB1 dbb1;
        public bangtu()
        {
            InitializeComponent();
        }

     
        private void bangtu_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            Bt_TS.BackColor = Color.AliceBlue;
            Bt_TS.Enabled = false;
            ButtonFlag = 0;
            delpanelall();
            BT_ML.Text = "台上调速";
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                if (totalshebei <= 24)
                {
                    if (0 <= totalshebei && totalshebei <= 12)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(50 + 150 * i, 105, shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(50 + 150 * i, 105, shebei[i]);
                        }
                        for (int i = 12; i < totalshebei; i++)
                        {
                            panelset(50 + 150 * (i - 12), 450, shebei[i]);
                        }
                  
                    }
                    ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS = 0;
                }
                else
                {
                    for (int i = 0; i < 12; i++)
                    {
                        panelset(50 + 150 * i, 105, shebei[i]);
                    }
                    for (int i = 12; i < 24; i++)
                    {
                        panelset(50 + 150 * (i - 12), 450, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS = totalshebei - 24;
                }
            }
        }

        private void panelset(int x, int y, string shebeiname)
        {

            // 
            // BT_SBM
            // 
            Label BT_SBM = new Label();
            BT_SBM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            BT_SBM.Location = new System.Drawing.Point(-1, 0);
            BT_SBM.Font = new System.Drawing.Font("宋体", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            BT_SBM.Name = "BT_SBM"+x+y;
            BT_SBM.Size = new System.Drawing.Size(100, 25);
            BT_SBM.TabIndex = 3238;
            BT_SBM.Text = shebeiname;
            BT_SBM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BT_RXXZ
            // 
            Label BT_RXXZ = new Label();
            BT_RXXZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            BT_RXXZ.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            BT_RXXZ.Location = new System.Drawing.Point(49, 72);
            BT_RXXZ.Name = "BT_RXXZ" + x + y;
            BT_RXXZ.Size = new System.Drawing.Size(50, 25);
            BT_RXXZ.TabIndex = 3244;
            BT_RXXZ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BT_RSXL
            //
            Label BT_RSXL = new Label();
            BT_RSXL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            BT_RSXL.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            BT_RSXL.Location = new System.Drawing.Point(-1, 24);
            BT_RSXL.Name = "BT_RSXL" + x + y;
            BT_RSXL.Size = new System.Drawing.Size(50, 25);
            BT_RSXL.TabIndex = 3239;
            BT_RSXL.Text = "软上限";
            BT_RSXL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BT_DQWZZ
            // 
            Label BT_DQWZZ = new Label();
            BT_DQWZZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            BT_DQWZZ.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            BT_DQWZZ.Location = new System.Drawing.Point(49, 48);
            BT_DQWZZ.Name = "BT_DQWZZ" + x + y;
            BT_DQWZZ.Size = new System.Drawing.Size(50, 25);
            BT_DQWZZ.TabIndex = 3243;
            BT_DQWZZ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BT_DQWZL
            // 
            Label BT_DQWZL = new Label();
            BT_DQWZL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            BT_DQWZL.Font = new System.Drawing.Font("宋体", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            BT_DQWZL.Location = new System.Drawing.Point(-1, 48);
            BT_DQWZL.Name = "BT_DQWZL" + x + y;
            BT_DQWZL.Size = new System.Drawing.Size(50, 25);
            BT_DQWZL.TabIndex = 3240;
            BT_DQWZL.Text = "当前位置";
            BT_DQWZL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BT_RSXZ
            // 
            Label BT_RSXZ = new Label();
            BT_RSXZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            BT_RSXZ.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            BT_RSXZ.Location = new System.Drawing.Point(49, 24);
            BT_RSXZ.Name = "BT_RSXZ" + x + y;
            BT_RSXZ.Size = new System.Drawing.Size(50, 25);
            BT_RSXZ.TabIndex = 3242;
            BT_RSXZ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BT_RXXL
            // 
            Label BT_RXXL = new Label();
            BT_RXXL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            BT_RXXL.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            BT_RXXL.Location = new System.Drawing.Point(-1, 72);
            BT_RXXL.Name = "BT_RXXL" + x + y;
            BT_RXXL.Size = new System.Drawing.Size(50, 25);
            BT_RXXL.TabIndex = 3241;
            BT_RXXL.Text = "软下限";
            BT_RXXL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // 
            // BT_P
            // 
            Panel BT_P = new Panel();
            BT_P.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            BT_P.Controls.Add(BT_SBM);
            BT_P.Controls.Add(BT_RXXZ);
            BT_P.Controls.Add(BT_RSXL);
            BT_P.Controls.Add(BT_DQWZZ);
            BT_P.Controls.Add(BT_DQWZL);
            BT_P.Controls.Add(BT_RSXZ);
            BT_P.Controls.Add(BT_RXXL);
            BT_P.Location = new System.Drawing.Point(x, y);
            BT_P.Name = "BT_P" + x + y;
            BT_P.Size = new System.Drawing.Size(100, 98);
            BT_P.TabIndex = 3245;
            this.Controls.Add(BT_P);
        }

        private void Bt_ToL_Click(object sender, EventArgs e)
        {
            if (ButtonFlag == 0)
            {
                clickcountTsTs--;
                if (ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS >= allshebei - 24)
                {
                    MessageBox.Show("没有更多设备！");
                    clickcountTsTs++;
                    //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
                }
                else
                {
                    delpanelall();

                    for (int i = 0; i < 12; i++)
                    {
                        panelset(50 + 150 * i, 105, shebei[(allshebei / 24) * 24 - ((allshebei / 24) - clickcountTsTs) * 24 + i]);
                    }
                    for (int i = 12; i < 24; i++)
                    {
                        panelset(50 + 150 * (i - 12), 450, shebei[(allshebei / 24) * 24 - ((allshebei / 24) - clickcountTsTs) * 24 + i]);
                    }


                    if (ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS == 0)
                    {
                        if (allshebei % 24 == 0)
                        {
                            ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS = 24;
                        }
                        else
                        {
                            ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS = allshebei % 24;
                        }
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS = ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS + 24;
                    }
                }
            }
            else if (ButtonFlag == 1)
            {
                clickcountTxTs--;
                if (ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS >= allshebei - 24)
                {
                    MessageBox.Show("没有更多设备！");
                    clickcountTxTs++;
                    //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
                }
                else
                {
                    delpanelall();

                    for (int i = 0; i < 12; i++)
                    {
                        panelset(50 + 150 * i, 105, shebei[(allshebei / 24) * 24 - ((allshebei / 24) - clickcountTxTs) * 24 + i]);
                    }
                    for (int i = 12; i < 24; i++)
                    {
                        panelset(50 + 150 * (i - 12), 450, shebei[(allshebei / 24) * 24 - ((allshebei / 24) - clickcountTxTs) * 24 + i]);
                    }


                    if (ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS == 0)
                    {
                        if (allshebei % 24 == 0)
                        {
                            ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS = 24;
                        }
                        else
                        {
                            ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS = allshebei % 24;
                        }
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS = ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS + 24;
                    }
                }
            }
            else if (ButtonFlag == 2)
            {
                clickcountDsDw--;
                if (ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW >= allshebei - 24)
                {
                    MessageBox.Show("没有更多设备！");
                    clickcountDsDw++;
                    //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
                }
                else
                {
                    delpanelall();

                    for (int i = 0; i < 12; i++)
                    {
                        panelset(50 + 150 * i, 105, shebei[(allshebei / 24) * 24 - ((allshebei / 24) - clickcountDsDw) * 24 + i]);
                    }
                    for (int i = 12; i < 24; i++)
                    {
                        panelset(50 + 150 * (i - 12), 450, shebei[(allshebei / 24) * 24 - ((allshebei / 24) - clickcountDsDw) * 24 + i]);
                    }


                    if (ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW == 0)
                    {
                        if (allshebei % 24 == 0)
                        {
                            ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW = 24;
                        }
                        else
                        {
                            ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW = allshebei % 24;
                        }
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW = ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW + 24;
                    }
                }
            }
        }

        private void BT_B2Main_Click(object sender, EventArgs e)
        {
            var frm = new main();
            frm.Show();
            this.Close();
        }

        private void Bt_TS_Click(object sender, EventArgs e)
        {
            Bt_TS.Enabled = false;
            Bt_TS.BackColor = Color.AliceBlue;
            Bt_TX.Enabled = true;
            Bt_TX.BackColor = Color.White;
            Bt_DSDW.Enabled = true;
            Bt_DSDW.BackColor = Color.White;
            BT_ML.Text = "台上调速";
            ButtonFlag = 0;
            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                if (totalshebei <= 24)
                {
                    if (0 <= totalshebei && totalshebei <= 12)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(50 + 150 * i, 105, shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(50 + 150 * i, 105, shebei[i]);
                        }
                        for (int i = 12; i < totalshebei; i++)
                        {
                            panelset(50 + 150 * (i - 12), 450, shebei[i]);
                        }

                    }
                    ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS = 0;
                }
                else
                {
                    for (int i = 0; i < 12; i++)
                    {
                        panelset(50 + 150 * i, 105, shebei[i]);
                    }
                    for (int i = 12; i < 24; i++)
                    {
                        panelset(50 + 150 * (i - 12), 450, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS = totalshebei - 24;
                }
            }
        }

        private void Bt_TX_Click(object sender, EventArgs e)
        {
            Bt_TX.Enabled = false;
            Bt_TX.BackColor = Color.AliceBlue;
            Bt_TS.Enabled = true;
            Bt_TS.BackColor = Color.White;
            Bt_DSDW.Enabled = true;
            Bt_DSDW.BackColor = Color.White;
            BT_ML.Text = "台下调速";
            ButtonFlag = 1;
            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                if (totalshebei <= 24)
                {
                    if (0 <= totalshebei && totalshebei <= 12)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(50 + 150 * i, 105, shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(50 + 150 * i, 105, shebei[i]);
                        }
                        for (int i = 12; i < totalshebei; i++)
                        {
                            panelset(50 + 150 * (i - 12), 450, shebei[i]);
                        }

                    }
                    ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS = 0;
                }
                else
                {
                    for (int i = 0; i < 12; i++)
                    {
                        panelset(50 + 150 * i, 105, shebei[i]);
                    }
                    for (int i = 12; i < 24; i++)
                    {
                        panelset(50 + 150 * (i - 12), 450, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS = totalshebei - 24;
                }
            }
        }

        private void Bt_DSDW_Click(object sender, EventArgs e)
        {
            Bt_DSDW.Enabled = false;
            Bt_DSDW.BackColor = Color.AliceBlue;
            Bt_TX.Enabled = true;
            Bt_TX.BackColor = Color.White;
            Bt_TS.Enabled = true;
            Bt_TS.BackColor = Color.White;
            BT_ML.Text = "定速定位";
            ButtonFlag = 2;
            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                if (totalshebei <= 24)
                {
                    if (0 <= totalshebei && totalshebei <= 12)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(50 + 150 * i, 105, shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(50 + 150 * i, 105, shebei[i]);
                        }
                        for (int i = 12; i < totalshebei; i++)
                        {
                            panelset(50 + 150 * (i - 12), 450, shebei[i]);
                        }

                    }
                    ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW = 0;
                }
                else
                {
                    for (int i = 0; i < 12; i++)
                    {
                        panelset(50 + 150 * i, 105, shebei[i]);
                    }
                    for (int i = 12; i < 24; i++)
                    {
                        panelset(50 + 150 * (i - 12), 450, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW = totalshebei - 24;
                }
            }
        }

        private void Bt_ToR_Click(object sender, EventArgs e)
        {
            if (ButtonFlag == 0)
            {
                clickcountTsTs++;
                if (ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS == 0)
                {
                    MessageBox.Show("没有更多设备！");
                    // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                    clickcountTsTs--;
                }
                else
                {
                    delpanelall();
                    if (ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS < 24)
                    {

                        if (0 <= ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS && ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS <= 12)
                        {
                            for (int i = 0; i < ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS; i++)
                            {
                                panelset(50 + 150 * i, 105, shebei[24 * clickcountTsTs + i]);
                            }
                        }
                        else 
                        {
                            for (int i = 0; i < 12; i++)
                            {
                                panelset(50 + 150 * i, 105, shebei[24 * clickcountTsTs + i]);
                            }
                            for (int i = 12; i < ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS; i++)
                            {
                                panelset(50 + 150 * (i - 12), 450, shebei[24 * clickcountTsTs + i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(50 + 150 * i, 105, shebei[24 * clickcountTsTs + i]);
                        }
                        for (int i = 12; i < 24; i++)
                        {
                            panelset(50 + 150 * (i - 12), 450, shebei[24 * clickcountTsTs + i]);
                        }

                        ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS = ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTSTS - 24;
                    }
                }
            }
            else if(ButtonFlag == 1)
            {
                clickcountTxTs++;
                if (ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS == 0)
                {
                    MessageBox.Show("没有更多设备！");
                    // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                    clickcountTxTs--;
                }
                else
                {
                    delpanelall();
                    if (ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS < 24)
                    {

                        if (0 <= ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS && ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS <= 12)
                        {
                            for (int i = 0; i < ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS; i++)
                            {
                                panelset(50 + 150 * i, 105, shebei[24 * clickcountTxTs + i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 12; i++)
                            {
                                panelset(50 + 150 * i, 105, shebei[24 * clickcountTxTs + i]);
                            }
                            for (int i = 12; i < ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS; i++)
                            {
                                panelset(50 + 150 * (i - 12), 450, shebei[24 * clickcountTxTs + i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(50 + 150 * i, 105, shebei[24 * clickcountTxTs + i]);
                        }
                        for (int i = 12; i < 24; i++)
                        {
                            panelset(50 + 150 * (i - 12), 450, shebei[24 * clickcountTxTs + i]);
                        }

                        ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS = ChangCiSheZhiGlobalData.BangTuShengYuSheBeiTXTS - 24;
                    }
                }
            }
            else if (ButtonFlag == 2)
            {
                clickcountDsDw++;
                if (ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW == 0)
                {
                    MessageBox.Show("没有更多设备！");
                    // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                    clickcountDsDw--;
                }
                else
                {
                    delpanelall();
                    if (ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW < 24)
                    {

                        if (0 <= ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW && ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW <= 12)
                        {
                            for (int i = 0; i < ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW; i++)
                            {
                                panelset(50 + 150 * i, 105, shebei[24 * clickcountDsDw + i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 12; i++)
                            {
                                panelset(50 + 150 * i, 105, shebei[24 * clickcountDsDw + i]);
                            }
                            for (int i = 12; i < ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW; i++)
                            {
                                panelset(50 + 150 * (i - 12), 450, shebei[24 * clickcountDsDw + i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(50 + 150 * i, 105, shebei[24 * clickcountDsDw + i]);
                        }
                        for (int i = 12; i < 24; i++)
                        {
                            panelset(50 + 150 * (i - 12), 450, shebei[24 * clickcountDsDw + i]);
                        }

                        ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW = ChangCiSheZhiGlobalData.BangTuShengYuSheBeiDSDW - 24;
                    }
                }
            }
        }

        private void delpanelall()
        {
            if (Controls["BT_P50105"] != null)
            {
                Controls["BT_P50105"].Dispose();
            }
            if (Controls["BT_P200105"] != null)
            {
                Controls["BT_P200105"].Dispose();
            }
            if (Controls["BT_P350105"] != null)
            {
                Controls["BT_P350105"].Dispose();
            }
            if (Controls["BT_P500105"] != null)
            {
                Controls["BT_P500105"].Dispose();
            }
            if (Controls["BT_P650105"] != null)
            {
                Controls["BT_P650105"].Dispose();
            }
            if (Controls["BT_P800105"] != null)
            {
                Controls["BT_P800105"].Dispose();
            }
            if (Controls["BT_P950105"] != null)
            {
                Controls["BT_P950105"].Dispose();
            }
            if (Controls["BT_P1100105"] != null)
            {
                Controls["BT_P1100105"].Dispose();
            }
            if (Controls["BT_P1250105"] != null)
            {
                Controls["BT_P1250105"].Dispose();
            }
            if (Controls["BT_P1400105"] != null)
            {
                Controls["BT_P1400105"].Dispose();
            }
            if (Controls["BT_P1550105"] != null)
            {
                Controls["BT_P1550105"].Dispose();
            }
            if (Controls["BT_P1700105"] != null)
            {
                Controls["BT_P1700105"].Dispose();
            }

            if (Controls["BT_P50450"] != null)
            {
                Controls["BT_P50450"].Dispose();
            }
            if (Controls["BT_P200450"] != null)
            {
                Controls["BT_P200450"].Dispose();
            }
            if (Controls["BT_P350450"] != null)
            {
                Controls["BT_P350450"].Dispose();
            }
            if (Controls["BT_P500450"] != null)
            {
                Controls["BT_P500450"].Dispose();
            }
            if (Controls["BT_P650450"] != null)
            {
                Controls["BT_P650450"].Dispose();
            }
            if (Controls["BT_P800450"] != null)
            {
                Controls["BT_P800450"].Dispose();
            }
            if (Controls["BT_P950450"] != null)
            {
                Controls["BT_P950450"].Dispose();
            }
            if (Controls["BT_P1100450"] != null)
            {
                Controls["BT_P1100450"].Dispose();
            }
            if (Controls["BT_P1250450"] != null)
            {
                Controls["BT_P1250450"].Dispose();
            }
            if (Controls["BT_P1400450"] != null)
            {
                Controls["BT_P1400450"].Dispose();
            }
            if (Controls["BT_P1550450"] != null)
            {
                Controls["BT_P1550450"].Dispose();
            }
            if (Controls["BT_P1700450"] != null)
            {
                Controls["BT_P1700450"].Dispose();
            }
        }

        private void BT_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
