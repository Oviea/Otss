﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using S7.Net;
namespace BigPro
{
    public class DBB1
    {
        int N;
        int K;
        int M;
        int P;
        int Length;
        bool dankong;
        bool chengkong;
        public DBB1(int N, int K, int M, int P)
        {
            this.N = N;
            this.K = K;
            this.M = M;
            this.P = P;
            data1 = new byte[56];
            data2 = new byte[N * 57]; //表2的数据
            data5 = new byte[P * 22];
            data3_1 = new byte[93 * K]; //表3_1的数据
            data4 = new byte[34 * M];
            this.Length = 56 + N * 57 + P * 22 + 93 * K + 34 * M;
            edata = new byte[20000 -Length];
    }
        private byte[] data1; //表1的数据
        private byte[] data2;
        private byte[] data3_1;
        private byte[] data4;
        private byte[] data5;
        private byte[] edata;
        //index从0开始 
        //获取取第index位 
        public static int GetBit(byte b, int index)
        {
            return ((b & (1 << index)) > 0) ? 1 : 0;
        }
        //将第index位设为1 
        public static byte SetBit(byte b, int index)
        {
            return (byte)(b | (1 << index));
        }
        //将第index位设为0 
        public static byte ClearBit(byte b, int index)
        {
            return (byte)(b & (byte.MaxValue - (1 << index)));
        }
        //将第index位取反 
        public static byte ReverseBit(byte b, int index)
        {
            return (byte)(b ^ (byte)(1 << index));
        }
        //调速设备
        public void Tsdanduan(bool[] flag,  int[] sdwz,  int[] sdsd,  int[] yssj)// 是否单段 位置 速度 延时时间 单段
        {
            for (int n = 0; n < N; n++)
            {
                if(flag[n]) data2[n * 57 + 2] = SetBit(data2[n * 57 + 2], 0);
                data2[n * 57 + 12] = (byte)(BitConverter.GetBytes(sdsd[n])[0]);
                data2[n * 57 + 13] = (byte)(BitConverter.GetBytes(sdsd[n])[1]);
                data2[n * 57 + 20] = (byte)(BitConverter.GetBytes(sdwz[n])[0]);
                data2[n * 57 + 21] = (byte)(BitConverter.GetBytes(sdwz[n])[1]);
                data2[n * 57 + 14] = (byte)(BitConverter.GetBytes(yssj[n])[0]);
                data2[n * 57 + 15] = (byte)(BitConverter.GetBytes(yssj[n])[1]);
            }
         }

        public void Tsduoduan(bool[] flag, int[] duanshu, int[] sdwz, int[] yssj, int[] wz1, int[] wz2, int[] wz3, int[] wz4, int[] sd1, int[] sd2, int[] sd3, int[] sd4)// 是否多段 段数 位置 延时  位置1-4 速度1-4
       {
            for (int n = 0; n < N; n++)
            {
                if (flag[n]) data2[n * 57 + 2] = SetBit(data2[n * 57 + 2], 2);
                data2[n * 57 + 7] = (byte)(BitConverter.GetBytes(duanshu[n])[0]);
                data2[n * 57 + 20] = (byte)(BitConverter.GetBytes(sdwz[n])[0]);
                data2[n * 57 + 21] = (byte)(BitConverter.GetBytes(sdwz[n])[1]);
                data2[n * 57 + 14] = (byte)(BitConverter.GetBytes(yssj[n])[0]);
                data2[n * 57 + 15] = (byte)(BitConverter.GetBytes(yssj[n])[1]);
                data2[n * 57 + 8] = (byte)(BitConverter.GetBytes(sd1[n])[0]);
                data2[n * 57 + 9] = (byte)(BitConverter.GetBytes(sd2[n])[0]);
                data2[n * 57 + 10] = (byte)(BitConverter.GetBytes(sd3[n])[0]);
                data2[n * 57 + 11] = (byte)(BitConverter.GetBytes(sd4[n])[0]);
                data2[n * 57 + 30] = (byte)(BitConverter.GetBytes(wz1[n])[0]);
                data2[n * 57 + 31] = (byte)(BitConverter.GetBytes(wz1[n])[1]);
                data2[n * 57 + 32] = (byte)(BitConverter.GetBytes(wz2[n])[0]);
                data2[n * 57 + 33] = (byte)(BitConverter.GetBytes(wz2[n])[1]);
                data2[n * 57 + 34] = (byte)(BitConverter.GetBytes(wz3[n])[0]);
                data2[n * 57 + 35] = (byte)(BitConverter.GetBytes(wz3[n])[1]);
                data2[n * 57 + 36] = (byte)(BitConverter.GetBytes(wz4[n])[0]);
                data2[n * 57 + 37] = (byte)(BitConverter.GetBytes(wz4[n])[1]);
            }

         }
         public void Tsfanfu(bool[]flag, int[] cishu, int[] sdsd, int[] yssj, int[] wz1, int[] wz2)//是否反复 次数 设定速度 延时时间 位置1 位置2
        {
            for (int n = 0; n < N; n++)
            {
                if (flag[n]) data2[n * 57 + 2] = SetBit(data2[n * 57 + 2], 1);
                data2[n * 57 + 6] = (byte)(BitConverter.GetBytes(cishu[n])[0]);
                data2[n * 57 + 12] = (byte)(BitConverter.GetBytes(sdsd[n])[0]);
                data2[n * 57 + 13] = (byte)(BitConverter.GetBytes(sdsd[n])[1]);
                data2[n * 57 + 14] = (byte)(BitConverter.GetBytes(yssj[n])[0]);
                data2[n * 57 + 15] = (byte)(BitConverter.GetBytes(yssj[n])[1]);
                data2[n * 57 + 16] = (byte)(BitConverter.GetBytes(wz1[n])[0]);
                data2[n * 57 + 17] = (byte)(BitConverter.GetBytes(wz1[n])[1]);
                data2[n * 57 + 18] = (byte)(BitConverter.GetBytes(wz2[n])[0]);
                data2[n * 57 + 19] = (byte)(BitConverter.GetBytes(wz2[n])[1]);
                Console.WriteLine("%%%%%(((((%"+data2[n * 57 + 16]);
            }

            }

        public void Table1(int bianhao=1, bool zanting=true, bool bianzukongzhi=false, bool fenqu = false, int jishuqi = 0, bool ds = false,
            bool ts = false, bool hs = false, bool dsdw = false)
        {
            data1[0] = (byte)(BitConverter.GetBytes(bianhao)[0]);
            if (zanting)
            {
                data1[0] = SetBit(data1[0], 5);
            }
            if (bianzukongzhi)
            {
                data1[0] = SetBit(data1[0], 6);
            }
            if (fenqu)
            {
                data1[0] = SetBit(data1[0], 7);
            }
            data1[1] = (byte)(BitConverter.GetBytes(jishuqi)[0]);
            data1[2] = (byte)(BitConverter.GetBytes(jishuqi)[1]);
            if (ds)
            {
                data1[3] = SetBit(data1[0], 0);
            }
            if (ts)
            {
                data1[3] = SetBit(data1[0], 1);
            }
            if (hs)
            {
                data1[3] = SetBit(data1[0], 2);
            }
            if (dsdw)
            {
                data1[3] = SetBit(data1[0], 3);
            }
            data1[5] = (byte)(BitConverter.GetBytes(this.N)[0]);
            data1[6] = (byte)(BitConverter.GetBytes(this.K)[0]);
            data1[7] = (byte)(BitConverter.GetBytes(this.M)[0]);
            data1[8] = (byte)(BitConverter.GetBytes(this.P)[0]);

        }
        public void tsshuzhi(int[] rsx, int[] rxx, int[] djrxx)
        {
            for (int n = 0; n < N; n++)
            {
                data2[n * 57 + 38] = (byte)(BitConverter.GetBytes(rsx[n])[0]);
                data2[n * 57 + 39] = (byte)(BitConverter.GetBytes(rsx[n])[1]);
                data2[n * 57 + 40] = (byte)(BitConverter.GetBytes(rxx[n])[0]);
                data2[n * 57 + 41] = (byte)(BitConverter.GetBytes(rxx[n])[1]);
                data2[n * 57 + 49] = (byte)(BitConverter.GetBytes(djrxx[n])[0]);
                data2[n * 57 + 49] = (byte)(BitConverter.GetBytes(djrxx[n])[1]);
            }
        }
        public void Table2(bool[] qidong, bool[] shangsheng, bool[] xiajiang, bool[] bianzu, bool[] fenqu,
            int[] bianhao, bool[] qu1, bool[] qu2, bool[] zanting, bool[] bianzukz, bool[] fenqukz,
            bool[] danduan, bool[] wangfu, bool[] fenduan, bool[] youxiao1, bool[] youxiao2, bool[] xdyouxiao, bool[] jdyouxiao,
            bool[] queren, bool[] yunxu, bool[] jiesuo, bool[] pangbang, bool[] fuwei, bool[] shoudong, bool[] bzzanting,
            int[] csxgms, int[] pcfqsdsu, int[] sbwfsdcs, int[] fdyxsdds, int[] ddwz1sd, int[] ddwz2sd, int[] ddwz3sd, int[] ddwz4sd, int[] bzsdsd,
            int[] qdsdyssj, int[] wfwz1, int[] wfwz2, int[] bjsbsdwz, int[] sdjywz1, int[] sdjywz2, int[] sdxdwz, int[] sdjdwz, int[] ddwz1,
            int[] ddwz2, int[] ddwz3, int[] ddwz4, int[] rsx, int[] rxx, int[] mcxsm, int[] kpm, int[] kim, int[] djrxx, int[] tbbdccbhz, int[] mcxsn,
            int[] kpn, int[] kin, int[] tbzjsbbh, bool[] bdtbbz, bool[] pl, bool[] jy
            )
        {
            for (int n = 0; n < N; n++)
            {
                if (qidong[n]) data2[n * 57] = SetBit(data2[n * 57], 0);
                if (shangsheng[n]) data2[n * 57] = SetBit(data2[n * 57], 1);
                if (xiajiang[n]) data2[n * 57] = SetBit(data2[n * 57], 2);
                if (bianzu[n]) data2[n * 57] = SetBit(data2[n * 57], 3);
                if (fenqu[n]) data2[n * 57] = SetBit(data2[n * 57], 4);

                data1[n * 57 + 1] = (byte)(BitConverter.GetBytes(bianhao[n])[0]);
                if (qu1[n]) data2[n * 57 + 1] = SetBit(data2[n * 57 + 1], 3);
                if (qu2[n]) data2[n * 57 + 1] = SetBit(data2[n * 57 + 1], 4);
                if (zanting[n]) data2[n * 57 + 1] = SetBit(data2[n * 57 + 1], 5);
                if (bianzukz[n]) data2[n * 57 + 1] = SetBit(data2[n * 57 + 1], 6);
                if (fenqukz[n]) data2[n * 57 + 1] = SetBit(data2[n * 57 + 1], 7);

                if (danduan[n]) data2[n * 57 + 2] = SetBit(data2[n * 57 + 2], 0);
                if (wangfu[n]) data2[n * 57 + 2] = SetBit(data2[n * 57 + 2], 1);
                if (fenduan[n]) data2[n * 57 + 2] = SetBit(data2[n * 57 + 2], 2);
                if (youxiao1[n]) data2[n * 57 + 2] = SetBit(data2[n * 57 + 2], 3);
                if (youxiao2[n]) data2[n * 57 + 2] = SetBit(data2[n * 57 + 2], 4);
                if (xdyouxiao[n]) data2[n * 57 + 2] = SetBit(data2[n * 57 + 2], 5);
                if (jdyouxiao[n]) data2[n * 57 + 2] = SetBit(data2[n * 57 + 2], 6);

                if (queren[n]) data2[n * 57 + 3] = SetBit(data2[n * 57 + 3], 0);
                if (yunxu[n]) data2[n * 57 + 3] = SetBit(data2[n * 57 + 3], 1);
                if (jiesuo[n]) data2[n * 57 + 3] = SetBit(data2[n * 57 + 3], 2);
                if (pangbang[n]) data2[n * 57 + 3] = SetBit(data2[n * 57 + 3], 3);
                if (fuwei[n]) data2[n * 57 + 3] = SetBit(data2[n * 57 + 3], 4);
                if (shoudong[n]) data2[n * 57 + 3] = SetBit(data2[n * 57 + 3], 6);
                if (bzzanting[n]) data2[n * 57 + 3] = SetBit(data2[n * 57 + 3], 7);

                data2[n * 57 + 4] = (byte)(BitConverter.GetBytes(csxgms[n])[0]);
                data2[n * 57 + 5] = (byte)(BitConverter.GetBytes(pcfqsdsu[n])[0]);
                data2[n * 57 + 6] = (byte)(BitConverter.GetBytes(sbwfsdcs[n])[0]);
                data2[n * 57 + 7] = (byte)(BitConverter.GetBytes(fdyxsdds[n])[0]);
                data2[n * 57 + 8] = (byte)(BitConverter.GetBytes(ddwz1sd[n])[0]);
                data2[n * 57 + 9] = (byte)(BitConverter.GetBytes(ddwz2sd[n])[0]);
                data2[n * 57 + 10] = (byte)(BitConverter.GetBytes(ddwz3sd[n])[0]);
                data2[n * 57 + 11] = (byte)(BitConverter.GetBytes(ddwz4sd[n])[0]);
                data2[n * 57 + 12] = (byte)(BitConverter.GetBytes(bzsdsd[n])[0]);
                data2[n * 57 + 13] = (byte)(BitConverter.GetBytes(bzsdsd[n])[1]);
                data2[n * 57 + 14] = (byte)(BitConverter.GetBytes(qdsdyssj[n])[0]);
                data2[n * 57 + 15] = (byte)(BitConverter.GetBytes(qdsdyssj[n])[1]);
                data2[n * 57 + 16] = (byte)(BitConverter.GetBytes(wfwz1[n])[0]);
                data2[n * 57 + 17] = (byte)(BitConverter.GetBytes(wfwz1[n])[1]);
                data2[n * 57 + 18] = (byte)(BitConverter.GetBytes(wfwz2[n])[0]);
                data2[n * 57 + 19] = (byte)(BitConverter.GetBytes(wfwz2[n])[1]);
                data2[n * 57 + 20] = (byte)(BitConverter.GetBytes(bjsbsdwz[n])[0]);
                data2[n * 57 + 21] = (byte)(BitConverter.GetBytes(bjsbsdwz[n])[1]);
                data2[n * 57 + 22] = (byte)(BitConverter.GetBytes(sdjywz1[n])[0]);
                data2[n * 57 + 23] = (byte)(BitConverter.GetBytes(sdjywz1[n])[1]);
                data2[n * 57 + 24] = (byte)(BitConverter.GetBytes(sdjywz2[n])[0]);
                data2[n * 57 + 25] = (byte)(BitConverter.GetBytes(sdjywz2[n])[1]);
                data2[n * 57 + 26] = (byte)(BitConverter.GetBytes(sdxdwz[n])[0]);
                data2[n * 57 + 27] = (byte)(BitConverter.GetBytes(sdxdwz[n])[1]);
                data2[n * 57 + 28] = (byte)(BitConverter.GetBytes(sdjdwz[n])[0]);
                data2[n * 57 + 29] = (byte)(BitConverter.GetBytes(sdjdwz[n])[1]);
                data2[n * 57 + 30] = (byte)(BitConverter.GetBytes(ddwz1[n])[0]);
                data2[n * 57 + 31] = (byte)(BitConverter.GetBytes(ddwz1[n])[1]);
                data2[n * 57 + 32] = (byte)(BitConverter.GetBytes(ddwz2[n])[0]);
                data2[n * 57 + 33] = (byte)(BitConverter.GetBytes(ddwz2[n])[1]);
                data2[n * 57 + 34] = (byte)(BitConverter.GetBytes(ddwz3[n])[0]);
                data2[n * 57 + 35] = (byte)(BitConverter.GetBytes(ddwz3[n])[1]);
                data2[n * 57 + 36] = (byte)(BitConverter.GetBytes(ddwz4[n])[0]);
                data2[n * 57 + 37] = (byte)(BitConverter.GetBytes(ddwz4[n])[1]);
                data2[n * 57 + 38] = (byte)(BitConverter.GetBytes(rsx[n])[0]);
                data2[n * 57 + 39] = (byte)(BitConverter.GetBytes(rsx[n])[1]);
                data2[n * 57 + 40] = (byte)(BitConverter.GetBytes(rxx[n])[0]);
                data2[n * 57 + 41] = (byte)(BitConverter.GetBytes(rxx[n])[1]);
                data2[n * 57 + 42] = (byte)(BitConverter.GetBytes(mcxsm[n])[0]);
                data2[n * 57 + 43] = (byte)(BitConverter.GetBytes(mcxsm[n])[1]);
                data2[n * 57 + 44] = (byte)(BitConverter.GetBytes(kpm[n])[0]);
                data2[n * 57 + 45] = (byte)(BitConverter.GetBytes(kpm[n])[1]);
                data2[n * 57 + 46] = (byte)(BitConverter.GetBytes(kim[n])[0]);
                data2[n * 57 + 47] = (byte)(BitConverter.GetBytes(kim[n])[1]);
                data2[n * 57 + 49] = (byte)(BitConverter.GetBytes(djrxx[n])[0]);
                data2[n * 57 + 49] = (byte)(BitConverter.GetBytes(djrxx[n])[1]);
                data2[n * 57 + 50] = (byte)(BitConverter.GetBytes(tbbdccbhz[n])[0]);
                data2[n * 57 + 51] = (byte)(BitConverter.GetBytes(tbbdccbhz[n])[1]);
                data2[n * 57 + 52] = (byte)(BitConverter.GetBytes(mcxsn[n])[0]);
                data2[n * 57 + 53] = (byte)(BitConverter.GetBytes(kpn[n])[0]);
                data2[n * 57 + 54] = (byte)(BitConverter.GetBytes(kin[n])[0]);
                data2[n * 57 + 55] = (byte)(BitConverter.GetBytes(tbzjsbbh[n])[0]);
                if (bdtbbz[n]) data2[n * 57 + 56] = SetBit(data2[n * 57 + 56], 0);
                if (pl[n]) data2[n * 57 + 56] = SetBit(data2[n * 57 + 56], 0);
                if (jy[n]) data2[n * 57 + 56] = SetBit(data2[n * 57 + 56], 0);



            }
        }
        public void tsdhssz(int[] rsx, int[] rxx, int[] djrxx)
        {
            for (int k = 0; k < K; k++)
            {
                int wz = k * 93;
                data3_1[wz + 38] = (byte)(BitConverter.GetBytes(rsx[k])[0]);
                data3_1[wz + 39] = (byte)(BitConverter.GetBytes(rsx[k])[1]);
                data3_1[wz + 40] = (byte)(BitConverter.GetBytes(rxx[k])[0]);
                data3_1[wz + 41] = (byte)(BitConverter.GetBytes(rxx[k])[1]);
                data3_1[wz + 48] = (byte)(BitConverter.GetBytes(djrxx[k])[0]);
                data3_1[wz + 49] = (byte)(BitConverter.GetBytes(djrxx[k])[1]);
            }
        }
        //调速互锁设备
        public void Tshsdanduan(bool[] flag, int[] sdwz, int[] sdsd, int[] yssj)// 是否单段 位置 速度 延时时间 单段
        {
            for (int k = 0; k < K; k++)
            {
                int wz = k * 93;
                if (flag[k]) data3_1[wz + 2] = SetBit(data3_1[wz + 2], 0);
                data3_1[wz + 12] = (byte)(BitConverter.GetBytes(sdsd[k])[0]);
                data3_1[wz + 13] = (byte)(BitConverter.GetBytes(sdsd[k])[1]);
                data3_1[wz + 20] = (byte)(BitConverter.GetBytes(sdwz[k])[0]);
                data3_1[wz + 21] = (byte)(BitConverter.GetBytes(sdwz[k])[1]);
                data3_1[wz + 14] = (byte)(BitConverter.GetBytes(yssj[k])[0]);
                data3_1[wz + 15] = (byte)(BitConverter.GetBytes(yssj[k])[1]);
            }
        }

        public void Tshsduoduan(bool[] flag, int[] duanshu, int[] sdwz, int[] yssj, int[] wz1, int[] wz2, int[] wz3, int[] wz4, int[] sd1, int[] sd2, int[] sd3, int[] sd4)// 是否多段 段数 位置 延时  位置1-4 速度1-4
        {
            for (int k = 0; k < K; k++)
            {
                int wz = k * 93;
                if (flag[k]) data3_1[wz + 2] = SetBit(data3_1[wz+ 2], 2);
                data3_1[wz+ 7] = (byte)(BitConverter.GetBytes(duanshu[k])[0]);
                data3_1[wz + 20] = (byte)(BitConverter.GetBytes(sdwz[k])[0]);
                data3_1[wz + 21] = (byte)(BitConverter.GetBytes(sdwz[k])[1]);
                data3_1[wz + 14] = (byte)(BitConverter.GetBytes(yssj[k])[0]);
                data3_1[wz + 15] = (byte)(BitConverter.GetBytes(yssj[k])[1]);
                data3_1[wz + 8] = (byte)(BitConverter.GetBytes(sd1[k])[0]);
                data3_1[wz + 9] = (byte)(BitConverter.GetBytes(sd2[k])[0]);
                data3_1[wz + 10] = (byte)(BitConverter.GetBytes(sd3[k])[0]);
                data3_1[wz + 11] = (byte)(BitConverter.GetBytes(sd4[k])[0]);
                data3_1[wz + 30] = (byte)(BitConverter.GetBytes(wz1[k])[0]);
                data3_1[wz + 31] = (byte)(BitConverter.GetBytes(wz1[k])[1]);
                data3_1[wz + 32] = (byte)(BitConverter.GetBytes(wz2[k])[0]);
                data3_1[wz + 33] = (byte)(BitConverter.GetBytes(wz2[k])[1]);
                data3_1[wz + 34] = (byte)(BitConverter.GetBytes(wz3[k])[0]);
                data3_1[wz + 35] = (byte)(BitConverter.GetBytes(wz3[k])[1]);
                data3_1[wz + 36] = (byte)(BitConverter.GetBytes(wz4[k])[0]);
                data3_1[wz + 37] = (byte)(BitConverter.GetBytes(wz4[k])[1]);
            }

        }
        public void Tshsfanfu(bool[] flag, int[] cishu, int[] sdsd, int[] yssj, int[] wz1, int[] wz2)//是否反复 次数 设定速度 延时时间 位置1 位置2
        {
            for (int k = 0; k < K; k++)
            {
                int wz = k * 93;
                if (flag[k]) data3_1[wz + 2] = SetBit(data3_1[wz + 2], 1);
                data3_1[wz + 6] = (byte)(BitConverter.GetBytes(cishu[k])[0]);
                data3_1[wz + 12] = (byte)(BitConverter.GetBytes(sdsd[k])[0]);
                data3_1[wz + 13] = (byte)(BitConverter.GetBytes(sdsd[k])[1]);
                data3_1[wz + 14] = (byte)(BitConverter.GetBytes(yssj[k])[0]);
                data3_1[wz + 15] = (byte)(BitConverter.GetBytes(yssj[k])[1]);
                data3_1[wz + 16] = (byte)(BitConverter.GetBytes(wz1[k])[0]);
                data3_1[wz + 17] = (byte)(BitConverter.GetBytes(wz1[k])[1]);
                data3_1[wz + 18] = (byte)(BitConverter.GetBytes(wz2[k])[0]);
                data3_1[wz + 19] = (byte)(BitConverter.GetBytes(wz2[k])[1]);
            }

        }
        public void Table3_1(bool[] bzqdkz, bool[] fqssqdkz, bool[] fqxjqdkz, bool[] bztzkz, bool[] fqtzkz, int[] kztbh,
            bool[] yqkz, bool[] eqkz, bool[] bzkz, bool[] fqkz, bool[] ddyx, bool[] wfyx, bool[] fdyx, bool[] fqjywzyyx, bool[] fqjywzeyx, bool[] fqxdwzyx,
            bool[] fqjdwzyx, bool[] csxgqr, bool[] csxgyx, bool[] js, bool[] plbd, bool[] bpqfw, bool[] bzsd, bool[] bzzt,
            int[] csxgms,
            //bool [] xgdqwz, bool [] xgrsx, bool [] xgrxx, bool [] xgmcxs, bool [] xgkpxs, bool [] xgkixs, bool [] xgdjrxx, bool [] bdsz, bool [] bdcssz,
            //bool [] jysd, bool [] xgpl, bool [] xgsblb, bool [] xghs,

            int[] pcfqsdsu, int[] sbwfsdcs, int[] fdyxsdds, int[] ddwz1sd, int[] ddwz2sd, int[] ddwz3sd, int[] ddwz4sd, int[] bzsdsd,
            int[] qdsdyssj, int[] wfwz1, int[] wfwz2, int[] bjsbsdwz, int[] sdjywz1, int[] sdjywz2, int[] sdxdwz, int[] sdjdwz, int[] ddwz1,
            int[] ddwz2, int[] ddwz3, int[] ddwz4, int[] rsx, int[] rxx, int[] mcxsm, int[] kpm, int[] kim, int[] djrxx, int[] tbbdccbhz, int[] mcxsn,
            int[] kpn, int[] kin, int[] tbzjsbbh, bool[] bdtbbz, bool[] pl, bool[] jy)
        {
            for (int k = 0; k < K; k++)
            {
                int wz = k * 93;

                if (bzqdkz[k])
                {
                    data3_1[wz + 0] = SetBit(data3_1[wz + 0], 0);
                }
                if (fqssqdkz[k])
                {
                    data3_1[wz + 0] = SetBit(data3_1[wz + 0], 1);
                }
                if (fqxjqdkz[k])
                {
                    data3_1[wz + 0] = SetBit(data3_1[wz + 0], 2);
                }
                if (bztzkz[k])
                {
                    data3_1[wz + 0] = SetBit(data3_1[wz + 0], 3);
                }
                if (fqtzkz[k])
                {
                    data3_1[wz + 0] = SetBit(data3_1[wz + 0], 4);
                }

                data3_1[wz + 1] = (byte)(BitConverter.GetBytes(kztbh[k])[0]);
                if (yqkz[k])
                {
                    data3_1[wz + 1] = SetBit(data3_1[wz + 1], 3);
                }
                if (eqkz[k])
                {
                    data3_1[wz + 1] = SetBit(data3_1[wz + 1], 4);
                }

                if (bzkz[k])
                {
                    data3_1[wz + 1] = SetBit(data3_1[wz + 1], 6);
                }
                if (fqkz[k])
                {
                    data3_1[wz + 1] = SetBit(data3_1[wz + 1], 7);
                    //----------------------------------------------------------------
                }
                if (ddyx[k])
                {
                    data3_1[wz + 2] = SetBit(data3_1[wz + 2], 0);
                }
                if (wfyx[k])
                {
                    data3_1[wz + 2] = SetBit(data3_1[wz + 2], 1);
                }
                if (fdyx[k])
                {
                    data3_1[wz + 2] = SetBit(data3_1[wz + 2], 2);
                }
                if (fqjywzyyx[k])
                {
                    data3_1[wz + 2] = SetBit(data3_1[wz + 2], 3);
                }
                if (fqjywzeyx[k])
                {
                    data3_1[wz + 2] = SetBit(data3_1[wz + 2], 4);
                }
                if (fqxdwzyx[k])
                {
                    data3_1[wz + 2] = SetBit(data3_1[wz + 2], 5);
                }
                if (fqjdwzyx[k])
                {
                    data3_1[wz + 2] = SetBit(data3_1[wz + 2], 6);
                }

                //--------------------------------------------------------
                if (csxgqr[k])
                {
                    data3_1[wz + 3] = SetBit(data3_1[wz + 3], 0);
                }
                if (csxgyx[k])
                {
                    data3_1[wz + 3] = SetBit(data3_1[wz + 3], 1);
                }
                if (js[k])
                {
                    data3_1[wz + 3] = SetBit(data3_1[wz + 3], 2);
                }
                if (plbd[k])
                {
                    data3_1[wz + 3] = SetBit(data3_1[wz + 3], 3);
                }
                if (bpqfw[k])
                {
                    data3_1[wz + 3] = SetBit(data3_1[wz + 3], 4);
                }
                if (bzsd[k])
                {
                    data3_1[wz + 3] = SetBit(data3_1[wz + 3], 5);
                }
                if (bzzt[k])
                {
                    data3_1[wz + 3] = SetBit(data3_1[wz + 3], 6);
                }

                data3_1[wz + 4] = (byte)(BitConverter.GetBytes(csxgms[k])[0]);
                data3_1[wz + 5] = (byte)(BitConverter.GetBytes(pcfqsdsu[k])[0]);
                data3_1[wz + 6] = (byte)(BitConverter.GetBytes(sbwfsdcs[k])[0]);
                data3_1[wz + 7] = (byte)(BitConverter.GetBytes(fdyxsdds[k])[0]);
                data3_1[wz + 8] = (byte)(BitConverter.GetBytes(ddwz1sd[k])[0]);
                data3_1[wz + 9] = (byte)(BitConverter.GetBytes(ddwz2sd[k])[0]);
                data3_1[wz + 10] = (byte)(BitConverter.GetBytes(ddwz3sd[k])[0]);
                data3_1[wz + 11] = (byte)(BitConverter.GetBytes(ddwz4sd[k])[0]);
                data3_1[wz + 12] = (byte)(BitConverter.GetBytes(bzsdsd[k])[0]);
                data3_1[wz + 13] = (byte)(BitConverter.GetBytes(bzsdsd[k])[1]);
                data3_1[wz + 14] = (byte)(BitConverter.GetBytes(qdsdyssj[k])[0]);
                data3_1[wz + 15] = (byte)(BitConverter.GetBytes(qdsdyssj[k])[1]);
                data3_1[wz + 16] = (byte)(BitConverter.GetBytes(wfwz1[k])[0]);
                data3_1[wz + 17] = (byte)(BitConverter.GetBytes(wfwz1[k])[1]);
                data3_1[wz + 18] = (byte)(BitConverter.GetBytes(wfwz2[k])[0]);
                data3_1[wz + 19] = (byte)(BitConverter.GetBytes(wfwz2[k])[1]);
                data3_1[wz + 20] = (byte)(BitConverter.GetBytes(bjsbsdwz[k])[0]);
                data3_1[wz + 21] = (byte)(BitConverter.GetBytes(bjsbsdwz[k])[1]);
                data3_1[wz + 22] = (byte)(BitConverter.GetBytes(sdjywz1[k])[0]);
                data3_1[wz + 23] = (byte)(BitConverter.GetBytes(sdjywz1[k])[1]);
                data3_1[wz + 24] = (byte)(BitConverter.GetBytes(sdjywz2[k])[0]);
                data3_1[wz + 25] = (byte)(BitConverter.GetBytes(sdjywz2[k])[1]);
                data3_1[wz + 26] = (byte)(BitConverter.GetBytes(sdxdwz[k])[0]);
                data3_1[wz + 27] = (byte)(BitConverter.GetBytes(sdxdwz[k])[1]);
                data3_1[wz + 28] = (byte)(BitConverter.GetBytes(sdjdwz[k])[0]);
                data3_1[wz + 29] = (byte)(BitConverter.GetBytes(sdjdwz[k])[1]);
                data3_1[wz + 30] = (byte)(BitConverter.GetBytes(ddwz1[k])[0]);
                data3_1[wz + 31] = (byte)(BitConverter.GetBytes(ddwz1[k])[1]);
                data3_1[wz + 32] = (byte)(BitConverter.GetBytes(ddwz2[k])[0]);
                data3_1[wz + 33] = (byte)(BitConverter.GetBytes(ddwz2[k])[1]);
                data3_1[wz + 34] = (byte)(BitConverter.GetBytes(ddwz3[k])[0]);
                data3_1[wz + 35] = (byte)(BitConverter.GetBytes(ddwz3[k])[1]);
                data3_1[wz + 36] = (byte)(BitConverter.GetBytes(ddwz4[k])[0]);
                data3_1[wz + 37] = (byte)(BitConverter.GetBytes(ddwz4[k])[1]);
                data3_1[wz + 38] = (byte)(BitConverter.GetBytes(rsx[k])[0]);
                data3_1[wz + 39] = (byte)(BitConverter.GetBytes(rsx[k])[1]);
                data3_1[wz + 40] = (byte)(BitConverter.GetBytes(rxx[k])[0]);
                data3_1[wz + 41] = (byte)(BitConverter.GetBytes(rxx[k])[1]);
                data3_1[wz + 42] = (byte)(BitConverter.GetBytes(mcxsm[k])[0]);
                data3_1[wz + 43] = (byte)(BitConverter.GetBytes(mcxsm[k])[1]);

                data3_1[wz + 44] = (byte)(BitConverter.GetBytes(kpm[k])[0]);
                data3_1[wz + 45] = (byte)(BitConverter.GetBytes(kpm[k])[1]);
                data3_1[wz + 46] = (byte)(BitConverter.GetBytes(kim[k])[0]);
                data3_1[wz + 47] = (byte)(BitConverter.GetBytes(kim[k])[1]);
                data3_1[wz + 48] = (byte)(BitConverter.GetBytes(djrxx[k])[0]);
                data3_1[wz + 49] = (byte)(BitConverter.GetBytes(djrxx[k])[1]);
                data3_1[wz + 50] = (byte)(BitConverter.GetBytes(tbbdccbhz[k])[0]);
                data3_1[wz + 51] = (byte)(BitConverter.GetBytes(tbbdccbhz[k])[1]);

                data3_1[wz + 52] = (byte)(BitConverter.GetBytes(mcxsn[k])[0]);
                data3_1[wz + 53] = (byte)(BitConverter.GetBytes(kpn[k])[0]);
                data3_1[wz + 54] = (byte)(BitConverter.GetBytes(kin[k])[0]);
                data3_1[wz + 55] = (byte)(BitConverter.GetBytes(tbzjsbbh[k])[0]);
                if (bdtbbz[k])
                {
                    data3_1[wz + 56] = SetBit(data3_1[wz + 56], 0);
                }
                if (pl[k])
                {
                    data3_1[wz + 56] = SetBit(data3_1[wz + 56], 1);
                }
                if (jy[k])
                {
                    data3_1[wz + 56] = SetBit(data3_1[wz + 56], 1);
                }
            }
        }
        public void dsdwsz(int[] rsx, int[] rxx )
        {
            for (int m = 0; m < M; m++)
            {
                int wz = m * 34;
                data4[wz + 18] = (byte)(BitConverter.GetBytes(rsx[m])[0]);
                data4[wz + 19] = (byte)(BitConverter.GetBytes(rsx[m])[1]);
                data4[wz + 20] = (byte)(BitConverter.GetBytes(rxx[m])[0]);
                data4[wz + 21] = (byte)(BitConverter.GetBytes(rxx[m])[1]);
            }
        }
        public void Table4(bool[] bzqdkz, bool[] fqssqdkz, bool[] fqxjqdkz, bool[] bztzkz, bool[] fqtzkz, bool[] pl_0, int[] kztbh,
               bool[] yqkz, bool[] eqkz, bool[] bzkz, bool[] fqkz, bool[] bzyx, bool[] fqjywzyyx, bool[] fqjywzeyx, bool[] fqxdwzyx,
               bool[] fqjdwzyx, bool[] csxgqr, bool[] csxgyx, bool[] js, bool[] pl_1, bool[] bzsd, bool[] bzzt,
               int[] csxgms,
               //bool [] xgdqwz, bool [] xgrsx, bool [] xgrxx, bool [] xgmcxs, bool [] xgkpxs, bool [] xgkixs, bool [] xgdjrxx, bool [] bdsz, bool [] bdcssz,
               //bool [] jysd, bool [] xgpl, bool [] xgsblb, bool [] xghs,

               //int [] pcfqsdsu, int [] sbwfsdcs, int [] fdyxsdds,int [] ddwz1sd, int [] ddwz2sd, int [] ddwz3sd, int [] ddwz4sd, int [] bzsdsd, 
               int[] qdsdyssj, int[] sdwz, int[] sdjywz1, int[] sdjywz2, int[] sdxdwz, int[] sdjdwz, int[] rsx, int[] rxx, int[] mcxsm, int[] mcxsn,
               bool[] pl_2, bool[] jy, int[] ssgxtztql, int[] xjgxtztql, int[] djzcyxlxyxsj, int[] djzdzdlcsjsj
               )
        {
            for (int m = 0; m < M; m++)
            {
                int wz =  m  * 34;

                if (bzqdkz[m])
                {
                    data4[wz + 0] = SetBit(data4[wz + 0], 0);
                }
                if (fqssqdkz[m])
                {
                    data4[wz + 0] = SetBit(data4[wz + 0], 1);
                }
                if (fqxjqdkz[m])
                {
                    data4[wz + 0] = SetBit(data4[wz + 0], 2);
                }
                if (bztzkz[m])
                {
                    data4[wz + 0] = SetBit(data4[wz + 0], 3);
                }
                if (fqtzkz[m])
                {
                    data4[wz + 0] = SetBit(data4[wz + 0], 4);
                }
                if (pl_0[m])
                {
                    data4[wz + 0] = SetBit(data4[wz + 0], 7);
                }
                data4[wz + 1] = (byte)(BitConverter.GetBytes(kztbh[m])[0]);
                if (yqkz[m])
                {
                    data4[wz + 1] = SetBit(data4[wz + 1], 3);
                }
                if (eqkz[m])
                {
                    data4[wz + 1] = SetBit(data4[wz + 1], 4);
                }

                if (bzkz[m])
                {
                    data4[wz + 1] = SetBit(data4[wz + 1], 6);
                }
                if (fqkz[m])
                {
                    data4[wz + 1] = SetBit(data4[wz + 1], 7);
                    //----------------------------------------------------------------
                }
                if (bzyx[m])
                {
                    data4[wz + 2] = SetBit(data4[wz + 2], 0);
                }

                if (fqjywzyyx[m])
                {
                    data4[wz + 2] = SetBit(data4[wz + 2], 3);
                }
                if (fqjywzeyx[m])
                {
                    data4[wz + 2] = SetBit(data4[wz + 2], 4);
                }
                if (fqxdwzyx[m])
                {
                    data4[wz + 2] = SetBit(data4[wz + 2], 5);
                }
                if (fqjdwzyx[m])
                {
                    data4[wz + 2] = SetBit(data4[wz + 2], 6);
                }

                //--------------------------------------------------------
                if (csxgqr[m])
                {
                    data4[wz + 3] = SetBit(data4[wz + 3], 0);
                }
                if (csxgyx[m])
                {
                    data4[wz + 3] = SetBit(data4[wz + 3], 1);
                }
                if (js[m])
                {
                    data4[wz + 3] = SetBit(data4[wz + 3], 2);
                }
                if (pl_1[m])
                {
                    data4[wz + 3] = SetBit(data4[wz + 3], 3);
                }

                if (bzsd[m])
                {
                    data4[wz + 3] = SetBit(data4[wz + 3], 6);
                }
                if (bzzt[m])
                {
                    data4[wz + 3] = SetBit(data4[wz + 3], 7);
                }

                data4[wz + 4] = (byte)(BitConverter.GetBytes(csxgms[m])[0]);

                data4[wz + 6] = (byte)(BitConverter.GetBytes(qdsdyssj[m])[0]);
                data4[wz + 7] = (byte)(BitConverter.GetBytes(qdsdyssj[m])[1]);
                data4[wz + 8] = (byte)(BitConverter.GetBytes(sdwz[m])[0]);
                data4[wz + 9] = (byte)(BitConverter.GetBytes(sdwz[m])[1]);

                data4[wz + 10] = (byte)(BitConverter.GetBytes(sdjywz1[m])[0]);
                data4[wz + 11] = (byte)(BitConverter.GetBytes(sdjywz1[m])[1]);
                data4[wz + 12] = (byte)(BitConverter.GetBytes(sdjywz2[m])[0]);
                data4[wz + 13] = (byte)(BitConverter.GetBytes(sdjywz2[m])[1]);
                data4[wz + 14] = (byte)(BitConverter.GetBytes(sdxdwz[m])[0]);
                data4[wz + 15] = (byte)(BitConverter.GetBytes(sdxdwz[m])[1]);
                data4[wz + 16] = (byte)(BitConverter.GetBytes(sdjdwz[m])[0]);
                data4[wz + 17] = (byte)(BitConverter.GetBytes(sdjdwz[m])[1]);

                data4[wz + 18] = (byte)(BitConverter.GetBytes(rsx[m])[0]);
                data4[wz + 19] = (byte)(BitConverter.GetBytes(rsx[m])[1]);
                data4[wz + 20] = (byte)(BitConverter.GetBytes(rxx[m])[0]);
                data4[wz + 21] = (byte)(BitConverter.GetBytes(rxx[m])[1]);
                data4[wz + 22] = (byte)(BitConverter.GetBytes(mcxsm[m])[0]);
                data4[wz + 23] = (byte)(BitConverter.GetBytes(mcxsm[m])[1]);


                data4[wz + 24] = (byte)(BitConverter.GetBytes(mcxsn[m])[0]);

                if (pl_2[m])
                {
                    data4[wz + 25] = SetBit(data4[wz + 25], 1);
                }
                if (jy[m])
                {
                    data4[wz + 25] = SetBit(data4[wz + 25], 2);
                }
                data4[wz + 26] = (byte)(BitConverter.GetBytes(ssgxtztql[m])[0]);
                data4[wz + 27] = (byte)(BitConverter.GetBytes(ssgxtztql[m])[1]);
                data4[wz + 28] = (byte)(BitConverter.GetBytes(xjgxtztql[m])[0]);
                data4[wz + 29] = (byte)(BitConverter.GetBytes(xjgxtztql[m])[1]);
                data4[wz + 30] = (byte)(BitConverter.GetBytes(djzcyxlxyxsj[m])[0]);
                data4[wz + 31] = (byte)(BitConverter.GetBytes(djzcyxlxyxsj[m])[1]);
                data4[wz + 32] = (byte)(BitConverter.GetBytes(djzdzdlcsjsj[m])[0]);
                data4[wz + 33] = (byte)(BitConverter.GetBytes(djzdzdlcsjsj[m])[1]);
            }
        }
    
    public void Table5(bool[] bzqdkz, bool[] fqssqdkz, bool[] fqxjqdkz, bool[] bztzkz, bool[] fqtzkz,
            int[] kztbh, bool[] yqkz, bool[] eqkz, bool[] bzkz, bool[] fqkz,
             bool[] csxgqr, bool[] csxgyx, bool[] js, bool[] pl, bool[] bzsd, bool[] bzzt,
             int[] csxgms, int[] qdsdyssj, int[] djzcyxlxyxsj,
             bool[] cx, bool[] hw, bool[] fzt, bool[] bct, bool[] hbct, bool[] hfzt, bool[] qfzt, bool[] pll, bool[] jy,
             int[] hssbh, int[] hssbwz, int[] hsyxfw)
        {
            for (int p = 1; p < P; p++)
            {
                int wz = p * 22;
                if (bzqdkz[p])
                {
                    data5[wz + 0] = SetBit(data5[wz + 0], 0);
                }
                if (fqssqdkz[p])
                {
                    data5[wz + 0] = SetBit(data5[wz + 0], 1);
                }
                if (fqxjqdkz[p])
                {
                    data5[wz + 0] = SetBit(data5[wz + 0], 2);
                }
                if (bztzkz[p])
                {
                    data5[wz + 0] = SetBit(data5[wz + 0], 3);
                }
                if (fqtzkz[p])
                {
                    data5[wz + 0] = SetBit(data5[wz + 0], 4);
                }


                data5[wz + 1] = (byte)(BitConverter.GetBytes(kztbh[p])[0]);
                if (yqkz[p])
                {
                    data5[wz + 1] = SetBit(data5[wz + 1], 3);
                }
                if (eqkz[p])
                {
                    data5[wz + 1] = SetBit(data5[wz + 1], 4);
                }

                if (bzkz[p])
                {
                    data5[wz + 1] = SetBit(data5[wz + 1], 6);
                }
                if (fqkz[p])
                {
                    data5[wz + 1] = SetBit(data5[wz + 1], 7);
                }
                if (csxgqr[p])
                {
                    data5[wz + 3] = SetBit(data5[wz + 3], 0);
                }
                if (csxgyx[p])
                {
                    data5[wz + 3] = SetBit(data5[wz + 3], 1);
                }
                if (js[p])
                {
                    data5[wz + 3] = SetBit(data5[wz + 3], 2);
                }
                if (pl[p])
                {
                    data5[wz + 3] = SetBit(data5[wz + 3], 4);
                }
                if (bzsd[p])
                {
                    data5[wz + 3] = SetBit(data5[wz + 3], 6);
                }
                if (bzzt[p])
                {
                    data5[wz + 3] = SetBit(data5[wz + 3], 7);
                }
                data5[wz + 4] = (byte)(BitConverter.GetBytes(csxgms[p])[0]);
                data5[wz + 6] = (byte)(BitConverter.GetBytes(qdsdyssj[p])[0]);
                data5[wz + 7] = (byte)(BitConverter.GetBytes(qdsdyssj[p])[1]);
                data5[wz + 8] = (byte)(BitConverter.GetBytes(djzcyxlxyxsj[p])[0]);
                data5[wz + 9] = (byte)(BitConverter.GetBytes(djzcyxlxyxsj[p])[1]);
                if (cx[p]) data5[wz + 10] = SetBit(data5[wz + 10], 0);
                if (hw[p]) data5[wz + 10] = SetBit(data5[wz + 10], 1);
                if (fzt[p]) data5[wz + 10] = SetBit(data5[wz + 10], 2);
                if (bct[p]) data5[wz + 10] = SetBit(data5[wz + 10], 3);
                if (hbct[p]) data5[wz + 10] = SetBit(data5[wz + 10], 4);
                if (hfzt[p]) data5[wz + 10] = SetBit(data5[wz + 10], 5);
                if (qfzt[p]) data5[wz + 10] = SetBit(data5[wz + 10], 6);
                if (pll[p]) data5[wz + 11] = SetBit(data5[wz + 11], 1);
                if (jy[p]) data5[wz + 11] = SetBit(data5[wz + 11], 2);
                data5[wz + 12] = (byte)(BitConverter.GetBytes(hssbh[p])[0]);
                data5[wz + 14] = (byte)(BitConverter.GetBytes(hssbwz[p])[0]);
                data5[wz + 15] = (byte)(BitConverter.GetBytes(hssbwz[p])[1]);
                data5[wz + 16] = (byte)(BitConverter.GetBytes(hsyxfw[p])[0]);
                data5[wz + 17] = (byte)(BitConverter.GetBytes(hsyxfw[p])[1]);
            }

        }
        public void writer()
        {
            /*  string path = filename+".dat";
              //创建一个文件流
              FileStream fs = new FileStream(path, FileMode.Create);

              //将byte数组写入文件中
              fs.Write(data1, 0, data1.Length);
              fs.Write(data2, 0, data2.Length);
              fs.Write(data3_1, 0, data3_1.Length);
              fs.Write(data4, 0, data4.Length);
              fs.Write(data5, 0, data5.Length);
              fs.Write(edata, 0, edata.Length);
              //所有流类型都要关闭流，否则会出现内存泄露问题
              fs.Close();
              Console.WriteLine("保存文件成功");
              Console.ReadKey();*/
            Plc plc = new Plc(CpuType.S71500, "192.168.0.1", 0, 1);
            try
            {
                plc.Open();
                //Console.WriteLine(plc.IsConnected);
                //Byte[] b = new byte[5];
                //for (int i = 0; i < 5; i++)
                //{
                //    b[i] = 6;
                //}
                // S7.Net.Types.DInt.ToByteArray(num).CopyTo(b, 0);
                Console.WriteLine("*******" + data2[16]);
             //   plc.WriteBytes(DataType.DataBlock, 2, 0, data1);
                plc.WriteBytes(DataType.DataBlock, 3, 0, data2);
            }
            catch (PlcException e)
            {
                Console.WriteLine("Error:" + e.ErrorCode);
                // Console.WriteLine("Code:"+e.ErrorCode.ToString());
            }
        }

    }
}
