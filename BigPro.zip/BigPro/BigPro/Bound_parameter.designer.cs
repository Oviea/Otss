﻿namespace BigPro
{
    partial class Bound_parameter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.BP_TL = new System.Windows.Forms.Button();
            this.BP_TR = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.BP_Back = new System.Windows.Forms.Button();
            this.BP_2Main = new System.Windows.Forms.Button();
            this.SHQR = new System.Windows.Forms.Button();
            this.AllowEdit_Button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ZJSB_Select = new System.Windows.Forms.ComboBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.BP2BD = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView1.Location = new System.Drawing.Point(292, 132);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView1.Size = new System.Drawing.Size(1352, 205);
            this.dataGridView1.TabIndex = 455;
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView2.Location = new System.Drawing.Point(292, 371);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView2.Size = new System.Drawing.Size(1352, 205);
            this.dataGridView2.TabIndex = 456;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1427, 850);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 12);
            this.label3.TabIndex = 454;
            // 
            // BP_TL
            // 
            this.BP_TL.ForeColor = System.Drawing.Color.Black;
            this.BP_TL.Image = global::BigPro.Properties.Resources.Toleft;
            this.BP_TL.Location = new System.Drawing.Point(11, 11);
            this.BP_TL.Margin = new System.Windows.Forms.Padding(2);
            this.BP_TL.Name = "BP_TL";
            this.BP_TL.Size = new System.Drawing.Size(50, 50);
            this.BP_TL.TabIndex = 453;
            this.BP_TL.UseVisualStyleBackColor = true;
            this.BP_TL.Click += new System.EventHandler(this.BP_TL_Click);
            // 
            // BP_TR
            // 
            this.BP_TR.ForeColor = System.Drawing.Color.Black;
            this.BP_TR.Image = global::BigPro.Properties.Resources.ToRight;
            this.BP_TR.Location = new System.Drawing.Point(1827, 11);
            this.BP_TR.Margin = new System.Windows.Forms.Padding(2);
            this.BP_TR.Name = "BP_TR";
            this.BP_TR.Size = new System.Drawing.Size(50, 50);
            this.BP_TR.TabIndex = 452;
            this.BP_TR.UseVisualStyleBackColor = true;
            this.BP_TR.Click += new System.EventHandler(this.BP_TR_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1660, 334);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 12);
            this.label2.TabIndex = 451;
            // 
            // BP_Back
            // 
            this.BP_Back.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BP_Back.Location = new System.Drawing.Point(27, 907);
            this.BP_Back.Margin = new System.Windows.Forms.Padding(2);
            this.BP_Back.Name = "BP_Back";
            this.BP_Back.Size = new System.Drawing.Size(200, 70);
            this.BP_Back.TabIndex = 450;
            this.BP_Back.Text = "返回";
            this.BP_Back.UseVisualStyleBackColor = true;
            this.BP_Back.Click += new System.EventHandler(this.BP_Back_Click);
            // 
            // BP_2Main
            // 
            this.BP_2Main.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BP_2Main.Location = new System.Drawing.Point(1702, 907);
            this.BP_2Main.Margin = new System.Windows.Forms.Padding(2);
            this.BP_2Main.Name = "BP_2Main";
            this.BP_2Main.Size = new System.Drawing.Size(200, 70);
            this.BP_2Main.TabIndex = 449;
            this.BP_2Main.Text = "回首页";
            this.BP_2Main.UseVisualStyleBackColor = true;
            this.BP_2Main.Click += new System.EventHandler(this.BP_2Main_Click);
            // 
            // SHQR
            // 
            this.SHQR.BackColor = System.Drawing.Color.White;
            this.SHQR.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SHQR.Location = new System.Drawing.Point(1049, 24);
            this.SHQR.Margin = new System.Windows.Forms.Padding(2);
            this.SHQR.Name = "SHQR";
            this.SHQR.Size = new System.Drawing.Size(100, 40);
            this.SHQR.TabIndex = 443;
            this.SHQR.Text = "确认";
            this.SHQR.UseVisualStyleBackColor = false;
            // 
            // AllowEdit_Button
            // 
            this.AllowEdit_Button.BackColor = System.Drawing.Color.White;
            this.AllowEdit_Button.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AllowEdit_Button.Location = new System.Drawing.Point(823, 24);
            this.AllowEdit_Button.Margin = new System.Windows.Forms.Padding(2);
            this.AllowEdit_Button.Name = "AllowEdit_Button";
            this.AllowEdit_Button.Size = new System.Drawing.Size(100, 40);
            this.AllowEdit_Button.TabIndex = 442;
            this.AllowEdit_Button.Text = "允许";
            this.AllowEdit_Button.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 20F);
            this.label1.Location = new System.Drawing.Point(925, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 27);
            this.label1.TabIndex = 444;
            this.label1.Text = "数值设置";
            // 
            // ZJSB_Select
            // 
            this.ZJSB_Select.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ZJSB_Select.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ZJSB_Select.FormattingEnabled = true;
            this.ZJSB_Select.Location = new System.Drawing.Point(644, 28);
            this.ZJSB_Select.Margin = new System.Windows.Forms.Padding(2);
            this.ZJSB_Select.Name = "ZJSB_Select";
            this.ZJSB_Select.Size = new System.Drawing.Size(150, 34);
            this.ZJSB_Select.TabIndex = 458;
            this.ZJSB_Select.SelectedIndexChanged += new System.EventHandler(this.ZJSB_Select_SelectedIndexChanged);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AllowUserToResizeColumns = false;
            this.dataGridView3.AllowUserToResizeRows = false;
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView3.Location = new System.Drawing.Point(292, 610);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView3.Size = new System.Drawing.Size(1352, 205);
            this.dataGridView3.TabIndex = 459;
            // 
            // BP2BD
            // 
            this.BP2BD.BackColor = System.Drawing.Color.White;
            this.BP2BD.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BP2BD.Location = new System.Drawing.Point(930, 907);
            this.BP2BD.Margin = new System.Windows.Forms.Padding(2);
            this.BP2BD.Name = "BP2BD";
            this.BP2BD.Size = new System.Drawing.Size(150, 50);
            this.BP2BD.TabIndex = 460;
            this.BP2BD.Text = "绑定设置";
            this.BP2BD.UseVisualStyleBackColor = false;
            this.BP2BD.Click += new System.EventHandler(this.BP2BD_Click);
            // 
            // Bound_parameter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.BP2BD);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.ZJSB_Select);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.BP_TL);
            this.Controls.Add(this.BP_TR);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BP_Back);
            this.Controls.Add(this.BP_2Main);
            this.Controls.Add(this.SHQR);
            this.Controls.Add(this.AllowEdit_Button);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Bound_parameter";
            this.Text = "绑定设置";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Bound_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridViewRow bound_id;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BP_TL;
        private System.Windows.Forms.Button BP_TR;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BP_Back;
        private System.Windows.Forms.Button BP_2Main;
        private System.Windows.Forms.Button SHQR;
        private System.Windows.Forms.Button AllowEdit_Button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox ZJSB_Select;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Button BP2BD;
    }
}