﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class Bound_parameter : Form
    {
        private bool[,] validate1;
        private int[,] input1;
        private bool[,] validate2;
        private int[,] input2;
        private bool[,] validate3;
        private int[,] input3;
        private int[,] totalinput;
        private int thirtyzheng = 0;
        private int thirtyyu = 0;
        private int tenzheng = 0;
        private int tenyu = 0;
        private string[] congshebeiinfo;
        private int ThirtyZ;
        private int beginindex1, beginindex2;
        public Bound_parameter()
        {
            InitializeComponent();
        }

        private void Bound_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            zhushebeiadd();
            if (dataGridView1.Rows.Count == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns.Add(new DataGridViewTextBoxColumn());
                }
                for (int i = 0; i < 7; i++)
                {
                    dataGridView1.Rows.Add(new DataGridViewRow());
                }
            }
            this.dataGridView1.Rows[0].HeaderCell.Value = "KPm";
            this.dataGridView1.Rows[1].HeaderCell.Value = "KPn";
            this.dataGridView1.Rows[2].HeaderCell.Value = "KIm";
            this.dataGridView1.Rows[3].HeaderCell.Value = "KIn";
            this.dataGridView1.Rows[4].HeaderCell.Value = "最大允许偏差mm";
            this.dataGridView1.Rows[5].HeaderCell.Value = "运行偏差mm";
            this.dataGridView1.Rows[6].HeaderCell.Value = "初始偏差mm";
            this.dataGridView1.Rows[7].HeaderCell.Value = "运行偏差p";
            this.dataGridView1.TopLeftHeaderCell.Value = "参数|从机设备";

            if (dataGridView2.Rows.Count == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView2.Columns.Add(new DataGridViewTextBoxColumn());
                }
                for (int i = 0; i < 7; i++)
                {
                    dataGridView2.Rows.Add(new DataGridViewRow());
                }
            }
            this.dataGridView2.Rows[0].HeaderCell.Value = "KPm";
            this.dataGridView2.Rows[1].HeaderCell.Value = "KPn";
            this.dataGridView2.Rows[2].HeaderCell.Value = "KIm";
            this.dataGridView2.Rows[3].HeaderCell.Value = "KIn";
            this.dataGridView2.Rows[4].HeaderCell.Value = "最大允许偏差mm";
            this.dataGridView2.Rows[5].HeaderCell.Value = "运行偏差mm";
            this.dataGridView2.Rows[6].HeaderCell.Value = "初始偏差mm";
            this.dataGridView2.Rows[7].HeaderCell.Value = "运行偏差p";
            this.dataGridView2.TopLeftHeaderCell.Value = "参数|从机设备";

            if (dataGridView3.Rows.Count == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView3.Columns.Add(new DataGridViewTextBoxColumn());
                }
                for (int i = 0; i < 7; i++)
                {
                    dataGridView3.Rows.Add(new DataGridViewRow());
                }
            }
            this.dataGridView3.Rows[0].HeaderCell.Value = "KPm";
            this.dataGridView3.Rows[1].HeaderCell.Value = "KPn";
            this.dataGridView3.Rows[2].HeaderCell.Value = "KIm";
            this.dataGridView3.Rows[3].HeaderCell.Value = "KIn";
            this.dataGridView3.Rows[4].HeaderCell.Value = "最大允许偏差mm";
            this.dataGridView3.Rows[5].HeaderCell.Value = "运行偏差mm";
            this.dataGridView3.Rows[6].HeaderCell.Value = "初始偏差mm";
            this.dataGridView3.Rows[7].HeaderCell.Value = "运行偏差p";
            this.dataGridView3.TopLeftHeaderCell.Value = "参数|从机设备";
        }

        private void BP_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BP_2Main_Click(object sender, EventArgs e)
        {
            new main().Show();
            this.Close();
        }
        private void zhushebeiadd()
        {
            if (Directory.Exists("" + "主机设备" + "\\"))
            {
                DirectoryInfo di = new DirectoryInfo("" + "主机设备" + "\\");
                DirectoryInfo[] dirs = di.GetDirectories();
                for (int i = 0; i < dirs.Length; i++)
                {
                    ZJSB_Select.Items.Add(dirs[i].Name);
                }
            }
           
        }

        private void BP_TL_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                dataGridView1.Columns[i].HeaderCell.Value = " ";
                dataGridView2.Columns[i].HeaderCell.Value = " ";
                dataGridView3.Columns[i].HeaderCell.Value = " ";
            }
            thirtyzheng = thirtyzheng + 1;
            beginindex1 = beginindex1 - 30;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = "";
                    dataGridView2.Rows[i].Cells[j].Value = "";
                    dataGridView3.Rows[i].Cells[j].Value = "";
                  
                }
            }
            if (thirtyzheng > 0 && thirtyzheng <= ThirtyZ)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = congshebeiinfo[beginindex1 + i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = congshebeiinfo[beginindex1 + i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = congshebeiinfo[beginindex1 + i];
                }
                validate1 = new bool[8, 10];
                input1 = new int[8, 10];
                validate2 = new bool[8, 10];
                input2 = new int[8, 10];
                validate3 = new bool[8, 10];
                input3 = new int[8, 10];
            }
            else if (thirtyzheng > ThirtyZ)
            {
                MessageBox.Show("没有更多从设备!");
                //   ToLeft_SZ.Enabled = false;
                thirtyzheng = thirtyzheng - 1;
                beginindex1 = beginindex1 + 30;
            }


        }

        private void BP_TR_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                dataGridView1.Columns[i].HeaderCell.Value = " ";
                dataGridView2.Columns[i].HeaderCell.Value = " ";
                dataGridView3.Columns[i].HeaderCell.Value = " ";
            }
            thirtyzheng = thirtyzheng - 1;
            beginindex1 = beginindex1 + 30;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = "";
                    dataGridView2.Rows[i].Cells[j].Value = "";
                    dataGridView3.Rows[i].Cells[j].Value = "";
                }
            }
            if (thirtyzheng > 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = congshebeiinfo[beginindex1 + i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = congshebeiinfo[beginindex1 + i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = congshebeiinfo[beginindex1 + i];
                }
                validate1 = new bool[8, 10];
                input1 = new int[8, 10];
                validate2 = new bool[8, 10];
                input2 = new int[8, 10];
                validate3 = new bool[8, 10];
                input3 = new int[8, 10];
            }
            else if (thirtyzheng == 0)
            {
                int tenzheng = thirtyyu / 10;
                int thenyu = thirtyyu % 10;
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = "";

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = "";
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = "";
                }
                switch (tenzheng)
                {
                    case 0:
                        validate1 = new bool[8, tenyu];
                        input1 = new int[8, tenyu];
                        validate2 = new bool[8, 0];
                        input2 = new int[8, 0];
                        validate3 = new bool[8, 0];
                        input3 = new int[8, 0];
                        for (int i = 0; i < tenyu; i++)
                        {

                            dataGridView1.Columns[i].HeaderCell.Value = congshebeiinfo[beginindex1 + i];
                        }
                        break;
                    case 1:
                        validate1 = new bool[8, 10];
                        input1 = new int[8, 10];
                        validate2 = new bool[8, tenyu];
                        input2 = new int[8, tenyu];
                        validate3 = new bool[8, 0];
                        input3 = new int[8, 0];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = congshebeiinfo[beginindex1 + i];

                        }
                        for (int i = 10; i < 10 + tenyu; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = congshebeiinfo[beginindex1 + i];
                        }
                        break;
                    case 2:
                        validate1 = new bool[8, 10];
                        input1 = new int[8, 10];
                        validate2 = new bool[8, 10];
                        input2 = new int[8, 10];
                        validate3 = new bool[8, tenyu];
                        input3 = new int[8, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = congshebeiinfo[beginindex1 + i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = congshebeiinfo[beginindex1 + i];
                        }
                        for (int i = 20; i < 20 + tenyu; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = congshebeiinfo[beginindex1 + i];
                        }
                        break;
                }
            }
            else
            {
                MessageBox.Show("没有从设备!");
                //  ToRight_SZ.Enabled = false;
                thirtyzheng = thirtyzheng + 1;
                beginindex1 = beginindex1 - 30;
            }
        }

        private void BP2BD_Click(object sender, EventArgs e)
        {
            var f = new Bound();
            f.Show();
            this.Close();
        }

        private void ZJSB_Select_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ZJSB_Select.SelectedIndex == -1)
            {
                return;
            }
            else
            {
                string zhushebei = ZJSB_Select.SelectedItem.ToString();
                if(File.Exists("" + "主机设备" + "\\"+zhushebei+"\\"+zhushebei+".txt"))
                {
                    for (int i = 0; i < 10; i++)
                    {
                        dataGridView1.Columns[i].HeaderCell.Value = " ";
                        dataGridView2.Columns[i].HeaderCell.Value = " ";
                        dataGridView3.Columns[i].HeaderCell.Value = " ";
                    }
                    List<string> congshebei = new List<string>(File.ReadAllLines("" + "主机设备" + "\\" + zhushebei + "\\" + zhushebei + ".txt"));
                    int total = 0;
                    //    total = int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString())+ int.Parse(sbsd[2].ToString())+ int.Parse(sbsd[3].ToString());
                    total = congshebei.Count;
                    congshebeiinfo = congshebei.ToArray();
                    totalinput = new int[8, total];

                    tenzheng = total / 10;
                    tenyu = total % 10;
                    thirtyzheng = total / 30;
                    thirtyyu = total % 30;
                    ThirtyZ = thirtyzheng;
                    beginindex2 = total;
                    if (thirtyzheng == 0)
                    {
                        switch (tenzheng)
                        {
                            case 0:
                                validate1 = new bool[8, tenyu];
                                input1 = new int[8, tenyu];
                                for (int i = 0; i < tenyu; i++)
                                {

                                    dataGridView1.Columns[i].HeaderCell.Value = congshebeiinfo[i];
                                }
                                for (int i = tenyu; i < 10; i++)
                                {
                                    dataGridView1.Columns[i].ReadOnly = true;
                                }
                                dataGridView2.ReadOnly = true;
                                dataGridView3.ReadOnly = true;

                                break;
                            case 1:
                                validate1 = new bool[8, 10];
                                input1 = new int[8, 10];
                                validate2 = new bool[8, tenyu];
                                input2 = new int[8, tenyu];
                                for (int i = 0; i < 10; i++)
                                {
                                    dataGridView1.Columns[i].HeaderCell.Value = congshebeiinfo[i];

                                }
                                for (int i = 10; i < 10 + tenyu; i++)
                                {
                                    dataGridView2.Columns[i - 10].HeaderCell.Value = congshebeiinfo[i];
                                }
                                for (int i = 10 + tenyu; i < 20; i++)
                                {
                                    dataGridView2.Columns[i - 10].ReadOnly = true;
                                }
                                dataGridView3.ReadOnly = true;
                                break;
                            case 2:
                                validate1 = new bool[8, 10];
                                input1 = new int[8, 10];
                                validate2 = new bool[8, 10];
                                input2 = new int[8, 10];
                                validate3 = new bool[8, tenyu];
                                input3 = new int[8, tenyu];
                                for (int i = 0; i < 10; i++)
                                {
                                    dataGridView1.Columns[i].HeaderCell.Value = congshebeiinfo[i];

                                }
                                for (int i = 10; i < 20; i++)
                                {
                                    dataGridView2.Columns[i - 10].HeaderCell.Value = congshebeiinfo[i];
                                }
                                for (int i = 20; i < 20 + tenyu; i++)
                                {
                                    dataGridView3.Columns[i - 20].HeaderCell.Value = congshebeiinfo[i];
                                }
                                for (int i = 20 + tenyu; i < 30; i++)
                                {
                                    dataGridView3.Columns[i].ReadOnly = true;
                                }
                                break;
                        }
                    }
                    else
                    {
                        validate1 = new bool[8, 10];
                        input1 = new int[8, 10];
                        validate2 = new bool[8, 10];
                        input2 = new int[8, 10];
                        validate3 = new bool[8, 10];
                        input3 = new int[8, 10];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = congshebeiinfo[i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = congshebeiinfo[i];
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = congshebeiinfo[i];
                        }
                    }

                }
            }
        }
    }
}
