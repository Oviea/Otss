﻿namespace BigPro
{
    partial class Bound
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button25 = new System.Windows.Forms.Button();
            this.BD_TL = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.BD_TR = new System.Windows.Forms.Button();
            this.BD_2Main = new System.Windows.Forms.Button();
            this.BD_Back = new System.Windows.Forms.Button();
            this.BD_BDCS = new System.Windows.Forms.Button();
            this.BDAll_Cancel = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.BD_ML = new System.Windows.Forms.Label();
            this.BD_QR = new System.Windows.Forms.Button();
            this.BD_QX = new System.Windows.Forms.Button();
            this.BD_Add = new System.Windows.Forms.Button();
            this.ZJSB = new System.Windows.Forms.ListBox();
            this.L_ZJSB = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CJSB = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BD_CXXZ = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button25
            // 
            this.button25.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button25.Location = new System.Drawing.Point(1714, 22);
            this.button25.Margin = new System.Windows.Forms.Padding(2);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(55, 44);
            this.button25.TabIndex = 464;
            this.button25.Text = "程控";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // BD_TL
            // 
            this.BD_TL.ForeColor = System.Drawing.Color.Black;
            this.BD_TL.Image = global::BigPro.Properties.Resources.Toleft;
            this.BD_TL.Location = new System.Drawing.Point(11, 11);
            this.BD_TL.Margin = new System.Windows.Forms.Padding(2);
            this.BD_TL.Name = "BD_TL";
            this.BD_TL.Size = new System.Drawing.Size(50, 50);
            this.BD_TL.TabIndex = 462;
            this.BD_TL.UseVisualStyleBackColor = true;
            this.BD_TL.Click += new System.EventHandler(this.BD_TL_Click);
            // 
            // button58
            // 
            this.button58.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button58.Location = new System.Drawing.Point(1773, 22);
            this.button58.Margin = new System.Windows.Forms.Padding(2);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(55, 44);
            this.button58.TabIndex = 461;
            this.button58.Text = "单控";
            this.button58.UseVisualStyleBackColor = true;
            // 
            // button56
            // 
            this.button56.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button56.Location = new System.Drawing.Point(1585, 26);
            this.button56.Margin = new System.Windows.Forms.Padding(2);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(112, 40);
            this.button56.TabIndex = 460;
            this.button56.Text = "复位报警";
            this.button56.UseVisualStyleBackColor = true;
            // 
            // BD_TR
            // 
            this.BD_TR.ForeColor = System.Drawing.Color.Black;
            this.BD_TR.Image = global::BigPro.Properties.Resources.ToRight;
            this.BD_TR.Location = new System.Drawing.Point(1856, 15);
            this.BD_TR.Margin = new System.Windows.Forms.Padding(2);
            this.BD_TR.Name = "BD_TR";
            this.BD_TR.Size = new System.Drawing.Size(50, 50);
            this.BD_TR.TabIndex = 459;
            this.BD_TR.UseVisualStyleBackColor = true;
            this.BD_TR.Click += new System.EventHandler(this.BD_TR_Click);
            // 
            // BD_2Main
            // 
            this.BD_2Main.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BD_2Main.Location = new System.Drawing.Point(1773, 932);
            this.BD_2Main.Margin = new System.Windows.Forms.Padding(2);
            this.BD_2Main.Name = "BD_2Main";
            this.BD_2Main.Size = new System.Drawing.Size(112, 40);
            this.BD_2Main.TabIndex = 458;
            this.BD_2Main.Text = "回首页";
            this.BD_2Main.UseVisualStyleBackColor = true;
            this.BD_2Main.Click += new System.EventHandler(this.BD_2Main_Click);
            // 
            // BD_Back
            // 
            this.BD_Back.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BD_Back.Location = new System.Drawing.Point(49, 932);
            this.BD_Back.Margin = new System.Windows.Forms.Padding(2);
            this.BD_Back.Name = "BD_Back";
            this.BD_Back.Size = new System.Drawing.Size(112, 40);
            this.BD_Back.TabIndex = 457;
            this.BD_Back.Text = "返回";
            this.BD_Back.UseVisualStyleBackColor = true;
            this.BD_Back.Click += new System.EventHandler(this.BD_Back_Click);
            // 
            // BD_BDCS
            // 
            this.BD_BDCS.Font = new System.Drawing.Font("宋体", 14.2F);
            this.BD_BDCS.Location = new System.Drawing.Point(974, 838);
            this.BD_BDCS.Margin = new System.Windows.Forms.Padding(2);
            this.BD_BDCS.Name = "BD_BDCS";
            this.BD_BDCS.Size = new System.Drawing.Size(112, 40);
            this.BD_BDCS.TabIndex = 454;
            this.BD_BDCS.Text = "绑定参数";
            this.BD_BDCS.UseVisualStyleBackColor = true;
            this.BD_BDCS.Click += new System.EventHandler(this.BD_BDCS_Click);
            // 
            // BDAll_Cancel
            // 
            this.BDAll_Cancel.Font = new System.Drawing.Font("宋体", 14.2F);
            this.BDAll_Cancel.Location = new System.Drawing.Point(794, 838);
            this.BDAll_Cancel.Margin = new System.Windows.Forms.Padding(2);
            this.BDAll_Cancel.Name = "BDAll_Cancel";
            this.BDAll_Cancel.Size = new System.Drawing.Size(112, 40);
            this.BDAll_Cancel.TabIndex = 453;
            this.BDAll_Cancel.Text = "全部取消";
            this.BDAll_Cancel.UseVisualStyleBackColor = true;
            this.BDAll_Cancel.Click += new System.EventHandler(this.BDAll_Cancel_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label2.Location = new System.Drawing.Point(-5, 133);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1940, 3);
            this.label2.TabIndex = 451;
            // 
            // BD_ML
            // 
            this.BD_ML.AutoSize = true;
            this.BD_ML.Font = new System.Drawing.Font("宋体", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BD_ML.Location = new System.Drawing.Point(883, 25);
            this.BD_ML.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BD_ML.Name = "BD_ML";
            this.BD_ML.Size = new System.Drawing.Size(120, 27);
            this.BD_ML.TabIndex = 450;
            this.BD_ML.Text = "绑定设置";
            // 
            // BD_QR
            // 
            this.BD_QR.Font = new System.Drawing.Font("宋体", 14.2F);
            this.BD_QR.Location = new System.Drawing.Point(1081, 21);
            this.BD_QR.Margin = new System.Windows.Forms.Padding(2);
            this.BD_QR.Name = "BD_QR";
            this.BD_QR.Size = new System.Drawing.Size(75, 40);
            this.BD_QR.TabIndex = 449;
            this.BD_QR.Text = "确认";
            this.BD_QR.UseVisualStyleBackColor = true;
            this.BD_QR.Click += new System.EventHandler(this.BD_QR_Click);
            // 
            // BD_QX
            // 
            this.BD_QX.Font = new System.Drawing.Font("宋体", 14.2F);
            this.BD_QX.Location = new System.Drawing.Point(648, 21);
            this.BD_QX.Margin = new System.Windows.Forms.Padding(2);
            this.BD_QX.Name = "BD_QX";
            this.BD_QX.Size = new System.Drawing.Size(75, 40);
            this.BD_QX.TabIndex = 448;
            this.BD_QX.Text = "取消";
            this.BD_QX.UseVisualStyleBackColor = true;
            // 
            // BD_Add
            // 
            this.BD_Add.Font = new System.Drawing.Font("宋体", 14.2F);
            this.BD_Add.Location = new System.Drawing.Point(745, 21);
            this.BD_Add.Margin = new System.Windows.Forms.Padding(2);
            this.BD_Add.Name = "BD_Add";
            this.BD_Add.Size = new System.Drawing.Size(75, 40);
            this.BD_Add.TabIndex = 465;
            this.BD_Add.Text = "添加";
            this.BD_Add.UseVisualStyleBackColor = true;
            // 
            // ZJSB
            // 
            this.ZJSB.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ZJSB.FormattingEnabled = true;
            this.ZJSB.ItemHeight = 16;
            this.ZJSB.Location = new System.Drawing.Point(49, 203);
            this.ZJSB.Name = "ZJSB";
            this.ZJSB.ScrollAlwaysVisible = true;
            this.ZJSB.Size = new System.Drawing.Size(150, 436);
            this.ZJSB.TabIndex = 466;
            this.ZJSB.SelectedIndexChanged += new System.EventHandler(this.ZJSB_SelectedIndexChanged);
            // 
            // L_ZJSB
            // 
            this.L_ZJSB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.L_ZJSB.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.L_ZJSB.Location = new System.Drawing.Point(49, 160);
            this.L_ZJSB.Name = "L_ZJSB";
            this.L_ZJSB.Size = new System.Drawing.Size(150, 40);
            this.L_ZJSB.TabIndex = 467;
            this.L_ZJSB.Text = "主机设备";
            this.L_ZJSB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(215, 160);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 40);
            this.label1.TabIndex = 469;
            this.label1.Text = "从机设备";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CJSB
            // 
            this.CJSB.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CJSB.FormattingEnabled = true;
            this.CJSB.ItemHeight = 16;
            this.CJSB.Location = new System.Drawing.Point(215, 203);
            this.CJSB.Name = "CJSB";
            this.CJSB.ScrollAlwaysVisible = true;
            this.CJSB.Size = new System.Drawing.Size(150, 436);
            this.CJSB.TabIndex = 468;
            this.CJSB.SelectedIndexChanged += new System.EventHandler(this.CJSB_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Red;
            this.label3.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label3.Location = new System.Drawing.Point(402, 136);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(3, 650);
            this.label3.TabIndex = 471;
            // 
            // BD_CXXZ
            // 
            this.BD_CXXZ.Font = new System.Drawing.Font("宋体", 14.2F);
            this.BD_CXXZ.Location = new System.Drawing.Point(1172, 21);
            this.BD_CXXZ.Margin = new System.Windows.Forms.Padding(2);
            this.BD_CXXZ.Name = "BD_CXXZ";
            this.BD_CXXZ.Size = new System.Drawing.Size(100, 40);
            this.BD_CXXZ.TabIndex = 472;
            this.BD_CXXZ.Text = "重新选择";
            this.BD_CXXZ.UseVisualStyleBackColor = true;
            this.BD_CXXZ.Click += new System.EventHandler(this.BD_CXXZ_Click);
            // 
            // Bound
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.BD_CXXZ);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CJSB);
            this.Controls.Add(this.L_ZJSB);
            this.Controls.Add(this.ZJSB);
            this.Controls.Add(this.BD_Add);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.BD_TL);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.BD_TR);
            this.Controls.Add(this.BD_2Main);
            this.Controls.Add(this.BD_Back);
            this.Controls.Add(this.BD_BDCS);
            this.Controls.Add(this.BDAll_Cancel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BD_ML);
            this.Controls.Add(this.BD_QR);
            this.Controls.Add(this.BD_QX);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Bound";
            this.Text = "绑定设置";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Bound_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridViewRow bound_id;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button BD_TL;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button BD_TR;
        private System.Windows.Forms.Button BD_2Main;
        private System.Windows.Forms.Button BD_Back;
        private System.Windows.Forms.Button BD_BDCS;
        private System.Windows.Forms.Button BDAll_Cancel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label BD_ML;
        private System.Windows.Forms.Button BD_QR;
        private System.Windows.Forms.Button BD_QX;
        private System.Windows.Forms.Button BD_Add;
        private System.Windows.Forms.ListBox ZJSB;
        private System.Windows.Forms.Label L_ZJSB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox CJSB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BD_CXXZ;
    }
}