﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class _2changcifanfu : Form
    {
        private static string JuTiChangCi;
        private static string JuTiJuMu;
        private static string JuTiSheBei;
        public DBB1 dBB1;
        static void WriteC(string filePath, string writestr)
        {
            FileStream fs = new FileStream(filePath, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            try
            {
                sw.WriteLine(writestr);
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine("Writing has been completed");
            }
            catch (IOException e)
            {
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine(e.ToString());
            }
        }
        static void WriteWS(string filePath, string writestr)
        {
            FileStream fs = new FileStream(filePath, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            try
            {
                sw.WriteLine(writestr);
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine("Writing has been completed");
            }
            catch (IOException e)
            {
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine(e.ToString());
            }
        }
        public _2changcifanfu(DBB1 dBB1)
        {
            this.dBB1 = dBB1;
            InitializeComponent();
        }

        private void _2changcifanfu_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            JuTiJuMu = ChangCiSheZhiGlobalData.NageJuMu;
            JuTiChangCi = ChangCiSheZhiGlobalData.JuTiChangCi;
            JuTiSheBei = ChangCiSheZhiGlobalData.JuTiSheBei;
            if (!Directory.Exists( JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei))
            {
                Directory.CreateDirectory( JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei);
            }
            if (File.Exists("" + JuTiJuMu + "\\" + JuTiJuMu + ".txt"))
            {
                //List<string> lines = new List<string>(File.ReadAllLines("" + JuTiJuMu + "\\" + JuTiJuMu + ".txt"));
                //foreach (string s in lines)
                //{
                //    FFCue_List.Items.Add(s);
                //}
                FFCue_List.Items.Add("场次:" + JuTiChangCi.Substring(2));
                FFXZSB.Items.Add(JuTiSheBei);
                FFLabel.Text = JuTiChangCi +  "/" + JuTiSheBei;
            }
            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            // Console.WriteLine("%%%%"+sbsd[0].ToString());
            int j = 1;
            //for (int i = 0; i < int.Parse(sbsd[0].ToString()); i++)
            //{
            //    FanF_Dx.Items.Add("调速设备" + j);
            //    j++;
            //}
            //j = 1;
            //for (int i = 0; i < int.Parse(sbsd[1].ToString()); i++)
            //{
            //    FanF_Dx.Items.Add("调速互锁类设备" + j);
            //    j++;
            //}
            //j = 1;
            //for (int i = 0; i < int.Parse(sbsd[2].ToString()); i++)
            //{
            //    FanF_Dx.Items.Add("定速定位设备" + j);
            //    j++;
            //}
            //j = 1;
            //for (int i = 0; i < int.Parse(sbsd[3].ToString()); i++)
            //{
            //    FanF_Dx.Items.Add("定速设备" + j);
            //    j++;
            //}
        }

        private void button13_Click(object sender, EventArgs e)
        {
       
            new _2changci(dBB1).Show();
            this.Close();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            new main().Show();
            this.Close();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            new changjing().Show();
        }

        private void FanF_Cs_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入反复次数", "设置反复次数", "反复次数", -1, -1);
            if (str != "")
            {
                if (str != "反复次数")
                {
                    if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
                    {
                        ChangCiSheZhiGlobalData.TSFanFuCS[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(str);
                        La_FCS.Text = str;
                    }
                    else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
                    {
                        ChangCiSheZhiGlobalData.TSHSFanFuCS[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(str);
                        La_FCS.Text = str;
                    }
                    else
                    {
                        MessageBox.Show("请选择设备！");
                    }
                    WriteC( JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "FanFCS" + ".txt", str);
                    MessageBox.Show("设置成功！");
                }
                else
                {
                    MessageBox.Show("请输入反复次数！");
                }
            }
        }

        private void FanF_Wz1_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入位置1", "设置位置1", "位置1", -1, -1);
            if (str != "")
            {
                if (str != "位置1")
                {
                    if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
                    {
                        ChangCiSheZhiGlobalData.TSFanFwz1[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(str);
                        La_FWZ1.Text = str;
                    }
                    else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
                    {
                        ChangCiSheZhiGlobalData.TSHSFanFwz1[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(str);
                        La_FWZ1.Text = str;
                    }
                    else
                    {
                        MessageBox.Show("请选择设备！");
                    }
                    WriteC(JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "FanWZ1" + ".txt", str);
                    MessageBox.Show("设置成功！");
                }
                else
                {
                    MessageBox.Show("请输入位置1");
                }
            }
        }

        private void FanF_Wz2_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入位置2", "设置位置2", "位置2", -1, -1);
            if (str != "")
            {
                if (str != "位置2")
                {
                    if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
                    {
                        ChangCiSheZhiGlobalData.TSFanFwz2[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(str);
                        La_FWZ2.Text = str;
                    }
                    else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
                    {
                        ChangCiSheZhiGlobalData.TSHSFanFwz2[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(str);
                        La_FWZ2.Text = str;
                    }
                    else
                    {
                        MessageBox.Show("请选择设备！");
                    }
                    WriteC( JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "FanWZ2" + ".txt", str);
                    MessageBox.Show("设置成功！");
                }
                else
                {
                    MessageBox.Show("请输入位置2");
                }
            }
        }

        private void FanF_Sd_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入速度", "设置速度", "速度", -1, -1);
            if (str != "")
            {
                if (str != "速度")
                {
                    if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
                    {
                        ChangCiSheZhiGlobalData.TSHSFanFSDSD[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(str);
                        La_FV.Text = str;
                    }
                    else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
                    {
                        ChangCiSheZhiGlobalData.TSHSFanFSDSD[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(str);
                        La_FV.Text = str;
                    }
                    else
                    {
                        MessageBox.Show("请选择设备！");
                    }
                    WriteC( JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "FanSD" + ".txt", str);
                    MessageBox.Show("设置成功！");
                }
                else
                {
                    MessageBox.Show("请输入速度");
                }
            }
        }

        private void FanF_Sj_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入延时时间", "设置延时时间", "延时时间", -1, -1);
            if (str != "")
            {
                if (str != "延时时间")
                {
                    if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
                    {
                        ChangCiSheZhiGlobalData.TSFanFYSSJ[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(str);
                        La_FT.Text = str;
                    }
                    else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
                    {
                        ChangCiSheZhiGlobalData.TSHSFanFYSSJ[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(str);
                        La_FT.Text = str;
                    }
                    else
                    {
                        MessageBox.Show("请选择设备！");
                    }
                    WriteC( JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "FanYS" + ".txt", str);
                    MessageBox.Show("设置成功！");
                }
                else
                {
                    MessageBox.Show("请输入延时时间");
                }
            }
        }

        private void FanF_DelData_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                DialogResult result = MessageBox.Show("确定删除吗？", "单段设定删除", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    File.Delete( JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "FanFCS" + ".txt");
                    File.Delete(JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "FanWZ1" + ".txt");
                    File.Delete(JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "FanWZ2" + ".txt");
                    File.Delete(JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "FanSD" + ".txt");
                    File.Delete( JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "FanYS" + ".txt");
                }
            }
        }

        

        private void CCFF_DanD_Click(object sender, EventArgs e)
        {
            if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
            {
                ChangCiSheZhiGlobalData.TSDanDuanflag[ChangCiSheZhiGlobalData.TSSheBeiIndex] = true;

            }
            else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
            {
                ChangCiSheZhiGlobalData.TSHSDanDuanflag[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = true;
            }
            else
            {
                MessageBox.Show("请选择设备！");
            }
            var frm = new _2changcidanduan(dBB1);
            frm.Show();
            this.Close();
        }

        private void CCFF_DuoD_Click(object sender, EventArgs e)
        {
            if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
            {
                ChangCiSheZhiGlobalData.TSDuoDuanflag[ChangCiSheZhiGlobalData.TSSheBeiIndex] = true;

            }
            else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
            {
                ChangCiSheZhiGlobalData.TSHSDuoDuanflag[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = true;
            }
            else
            {
                MessageBox.Show("请选择设备！");
            }
            var frm = new _2changciduoduan(dBB1);
            frm.Show();
            this.Close();
        }

        private void CCFF_Qx_Click(object sender, EventArgs e)
        {
            var frm = new _2changciquxian(dBB1);
            frm.Show();
            this.Close();
        }

        private void FanF_QR_Click(object sender, EventArgs e)
        {
            Console.WriteLine("#######"+ ChangCiSheZhiGlobalData.TSFanFwz1.Length);
        
            if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
            {
              dBB1.Tsfanfu(ChangCiSheZhiGlobalData.TSFanFuflag, ChangCiSheZhiGlobalData.TSFanFuCS, ChangCiSheZhiGlobalData.TSFanFSDSD, ChangCiSheZhiGlobalData.TSFanFYSSJ, ChangCiSheZhiGlobalData.TSFanFwz1, ChangCiSheZhiGlobalData.TSFanFwz2);

            }
            else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
            {
                dBB1.Tshsfanfu(ChangCiSheZhiGlobalData.TSHSFanFuflag, ChangCiSheZhiGlobalData.TSHSFanFuCS, ChangCiSheZhiGlobalData.TSHSFanFSDSD, ChangCiSheZhiGlobalData.TSHSFanFYSSJ, ChangCiSheZhiGlobalData.TSHSFanFwz1, ChangCiSheZhiGlobalData.TSHSFanFwz2);

            }
            else
            {
                MessageBox.Show("请选择设备！");
            }
            dBB1.writer();
        }
    }
}
