﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace BigPro
{
    public partial class dankong : Form
    {
        private static int allshebei;
        private static string[] shebei;
        private static int clickcount;
        private static bool A_Flag = false;
        private static bool B_Flag = false;
        private static bool Qx_Flag = false;
        private int n, k, m, p;
        public dankong()
        {
            InitializeComponent();
        }

        private void dankong_Load(object sender, EventArgs e)
        {
            //this.TopMost = true;
                this.WindowState = FormWindowState.Maximized;
                delpanelall();
                if (File.Exists("SBSD.txt"))
                {
                    List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                    n = int.Parse(nkmp[0]);
                    k = int.Parse(nkmp[1]);
                    m = int.Parse(nkmp[2]);
                    p = int.Parse(nkmp[3]);
                    int totalshebei = n + m + k + p;
                    int t = totalshebei + 1;
                    allshebei = totalshebei;
                    nkmp.Clear();
                    for(int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n+k; i++)
                {
                    int j = i + 1-n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n+k; i < n+k+m; i++)
                {
                    int j = i + 1-n-k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m+p; i++)
                {
                    int j = i + 1-n-k-m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                //for(int i = 0; i < shebei.Length; i++)
                //{
                //    Console.WriteLine("++++++=+==" + shebei[i]);
                //}
                    if (totalshebei <= 40)
                    {
                        if (0 <= totalshebei && totalshebei <= 10)
                        {
                            for (int i = 0; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                        }
                        else if (totalshebei > 10 && totalshebei <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                        }
                    else if (totalshebei > 20 && totalshebei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i <20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                    }
                    else
                        {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                        for (int i = 30; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[i]);
                        }
                    }
                        ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = 0;
                    }
                    else
                    {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(130 + 170 * (i - 30), 550, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = totalshebei - 40;
                    }
                }
        }

        private void DK_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DK_MainPage_Click(object sender, EventArgs e)
        {
            var frm = new main();
            frm.Show();
            this.Close();
        }

        private void panelset(int x, int y, string shebeiname)
        {

            // 
            // Shebei_DanKong
            // 
            Button Shebei_DanKongXuanZe = new Button();
            Shebei_DanKongXuanZe.Font = new System.Drawing.Font("宋体", 10F);
           // Shebei_DanKongXuanZe.Location = new System.Drawing.Point(1660, 550);
            Shebei_DanKongXuanZe.Margin = new System.Windows.Forms.Padding(2);
            Shebei_DanKongXuanZe.Name = shebeiname+x+y;
            Shebei_DanKongXuanZe.Size = new System.Drawing.Size(90, 40);
            Shebei_DanKongXuanZe.Text =shebeiname;
            Shebei_DanKongXuanZe.UseVisualStyleBackColor = true;
            Shebei_DanKongXuanZe.Click += (e, a) => this.Shebei_DanKongXuanZe(shebeiname);
            // 


            Panel SheBeiXuanZe_Panel = new Panel();
            SheBeiXuanZe_Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SheBeiXuanZe_Panel.Controls.Add(Shebei_DanKongXuanZe);
            SheBeiXuanZe_Panel.Location = new System.Drawing.Point(x, y);
            SheBeiXuanZe_Panel.Margin = new System.Windows.Forms.Padding(2);
            SheBeiXuanZe_Panel.Name = "SheBeiXuanZe_Panel" + x + y;
            SheBeiXuanZe_Panel.Size = new System.Drawing.Size(91, 41);
            this.Controls.Add(SheBeiXuanZe_Panel);
        }

        private void Shebei_DanKongXuanZe(string shebeiname)
        {
            if (A_Flag == true || B_Flag == true)
            {
                if (A_Flag == true)
                {
                    ChangCiSheZhiGlobalData.A_SheBei[GetIndex(shebeiname)] = true;
                    ChangCiSheZhiGlobalData.B_SheBei[GetIndex(shebeiname)] = false;
                    MessageBox.Show(shebeiname + "已经加入A区!");
                }
                else
                {
                    ChangCiSheZhiGlobalData.B_SheBei[GetIndex(shebeiname)] = true;
                    ChangCiSheZhiGlobalData.A_SheBei[GetIndex(shebeiname)] = false;
                    MessageBox.Show(shebeiname + "已经加入B区!");
                }
            }else if (Qx_Flag == true)
            {
                ChangCiSheZhiGlobalData.A_SheBei[GetIndex(shebeiname)] = false;
                ChangCiSheZhiGlobalData.B_SheBei[GetIndex(shebeiname)] = false;
                MessageBox.Show(shebeiname + "已经取消A区或B区选择!");
            }
            else
            {
                MessageBox.Show("请选择A区或者B区或者取消按钮!");
            }

        }

        private void delpanelall()
        {
            if (Controls["SheBeiXuanZe_Panel130250"] != null)
            {
                Controls["SheBeiXuanZe_Panel130250"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel300250"] != null)
            {
                Controls["SheBeiXuanZe_Panel300250"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel470250"] != null)
            {
                Controls["SheBeiXuanZe_Panel470250"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel640250"] != null)
            {
                Controls["SheBeiXuanZe_Panel640250"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel810250"] != null)
            {
                Controls["SheBeiXuanZe_Panel810250"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel980250"] != null)
            {
                Controls["SheBeiXuanZe_Panel980250"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1150250"] != null)
            {
                Controls["SheBeiXuanZe_Panel1150250"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1320250"] != null)
            {
                Controls["SheBeiXuanZe_Panel1320250"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1490250"] != null)
            {
                Controls["SheBeiXuanZe_Panel1490250"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1660250"] != null)
            {
                Controls["SheBeiXuanZe_Panel1660250"].Dispose();
            }


            if (Controls["SheBeiXuanZe_Panel130350"] != null)
            {
                Controls["SheBeiXuanZe_Panel130350"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel300350"] != null)
            {
                Controls["SheBeiXuanZe_Panel300350"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel470350"] != null)
            {
                Controls["SheBeiXuanZe_Panel470350"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel640350"] != null)
            {
                Controls["SheBeiXuanZe_Panel640350"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel810350"] != null)
            {
                Controls["SheBeiXuanZe_Panel810350"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel980350"] != null)
            {
                Controls["SheBeiXuanZe_Panel980350"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1150350"] != null)
            {
                Controls["SheBeiXuanZe_Panel1150350"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1320350"] != null)
            {
                Controls["SheBeiXuanZe_Panel1320350"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1490350"] != null)
            {
                Controls["SheBeiXuanZe_Panel1490350"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1660350"] != null)
            {
                Controls["SheBeiXuanZe_Panel1660350"].Dispose();
            }


            if (Controls["SheBeiXuanZe_Panel130450"] != null)
            {
                Controls["SheBeiXuanZe_Panel130450"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel300450"] != null)
            {
                Controls["SheBeiXuanZe_Panel300450"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel470450"] != null)
            {
                Controls["SheBeiXuanZe_Panel470450"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel640450"] != null)
            {
                Controls["SheBeiXuanZe_Panel640450"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel810450"] != null)
            {
                Controls["SheBeiXuanZe_Panel810450"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel980450"] != null)
            {
                Controls["SheBeiXuanZe_Panel980450"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1150450"] != null)
            {
                Controls["SheBeiXuanZe_Panel1150450"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1320450"] != null)
            {
                Controls["SheBeiXuanZe_Panel1320450"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1490450"] != null)
            {
                Controls["SheBeiXuanZe_Panel1490450"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1660450"] != null)
            {
                Controls["SheBeiXuanZe_Panel1660450"].Dispose();
            }

            if (Controls["SheBeiXuanZe_Panel130550"] != null)
            {
                Controls["SheBeiXuanZe_Panel130550"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel300550"] != null)
            {
                Controls["SheBeiXuanZe_Panel300550"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel470550"] != null)
            {
                Controls["SheBeiXuanZe_Panel470550"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel640550"] != null)
            {
                Controls["SheBeiXuanZe_Panel640550"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel810550"] != null)
            {
                Controls["SheBeiXuanZe_Panel810550"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel980550"] != null)
            {
                Controls["SheBeiXuanZe_Panel980550"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1150550"] != null)
            {
                Controls["SheBeiXuanZe_Panel1150550"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1320550"] != null)
            {
                Controls["SheBeiXuanZe_Panel1320550"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1490550"] != null)
            {
                Controls["SheBeiXuanZe_Panel1490550"].Dispose();
            }
            if (Controls["SheBeiXuanZe_Panel1660550"] != null)
            {
                Controls["SheBeiXuanZe_Panel1660550"].Dispose();
            }
        }

        private void DKXZ_ToLeft_Click(object sender, EventArgs e)
        {
            clickcount--;
            if (ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei >= allshebei - 40)
            {
                MessageBox.Show("没有更多已编组设备！");
                clickcount++;
                //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
            }
            else
            {
                    delpanelall();
            
                for (int i = 0; i < 10; i++)
                {
                    panelset(130 + 170 * i, 250, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                for (int i = 10; i < 20; i++)
                {
                    panelset(130 + 170 * (i - 10), 350, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                for (int i = 20; i < 30; i++)
                {
                    panelset(130 + 170 * (i - 20), 450, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                for (int i = 30; i < 40; i++)
                {
                    panelset(130 + 170 * (i - 30), 550, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                if (ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei == 0)
                {
                    if (allshebei % 40 == 0)
                    {
                        ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = 40;
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = allshebei % 40;
                    }
                }
                else
                {
                    ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei + 40;
                }
            }
        }

        private void DKXZ_ToRight_Click(object sender, EventArgs e)
        {
            clickcount++;
         //   Console.WriteLine("XZXZXZX" + ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei);
            if (ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei == 0)
            {
                MessageBox.Show("没有更多已编组设备！");
                // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                clickcount--;
            }
            else
            {
                delpanelall();
                if (ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei <40)
                {

                    if (0 <= ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei && ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei <= 10)
                    {
                        for (int i = 0; i < ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                    }
                    else if (ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei > 10 && ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                        for (int i = 10; i < ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                        }
                    }
                    else if (ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei > 20 && ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                        }
                        for (int i = 20; i < ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[40 * clickcount + i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[40 * clickcount + i]);
                        }
                        for (int i = 30; i < ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[40 * clickcount + i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[40 * clickcount + i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(130 + 170 * (i - 30), 550, shebei[40 * clickcount + i]);
                    }
                    ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei - 40;
                }
            }
        }

        private void Qx_Bt_Click(object sender, EventArgs e)
        {
            if (Qx_Flag == false)
            {
                A_Flag = false;
                B_Flag = false;
                Qx_Flag = true;
                MessageBox.Show("可以取消设备选择!");

            }
            else
            {
                Qx_Flag = false;
                MessageBox.Show("取消设备选择解除!");
            }
        }

        private void DkAll_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("确定全部删除设备分区吗？", "设备分区删除", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                ChangCiSheZhiGlobalData.A_SheBei.Initialize();
                ChangCiSheZhiGlobalData.B_SheBei.Initialize();
                MessageBox.Show("分区选择已全部删除!");
            }
        }

        private void To_DkZt_Click(object sender, EventArgs e)
        {
            var frm = new dankongzhuangtai();
            frm.Show();
            this.Close();
        }

        private void DkXz_Ts_Click(object sender, EventArgs e)
        {
            delpanelall();
            int totalshebei = n;
                allshebei = totalshebei;
                if (totalshebei <= 40)
                {
                    if (0 <= totalshebei && totalshebei <= 10)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                    }
                    else if (totalshebei > 10 && totalshebei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                    }
                    else if (totalshebei > 20 && totalshebei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                        for (int i = 30; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(130 + 170 * (i - 30), 550, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = totalshebei - 40;
                
            }
        }

        private void DkXz_TsHs_Click(object sender, EventArgs e)
        {
            delpanelall();
            int totalshebei = k;
            allshebei = totalshebei;
            if (totalshebei <= 40)
            {
                if (0 <= totalshebei && totalshebei <= 10)
                {
                    for (int i = 0; i < totalshebei; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                }
                else if (totalshebei > 10 && totalshebei <= 20)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < totalshebei; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                }
                else if (totalshebei > 20 && totalshebei <= 30)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                    for (int i = 20; i < totalshebei; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[i]);
                    }
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[i]);
                    }
                    for (int i = 30; i < totalshebei; i++)
                    {
                        panelset(130 + 170 * (i - 30), 550, shebei[i]);
                    }
                }
                ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = 0;
            }
            else
            {
                for (int i = 0; i < 10; i++)
                {
                    panelset(130 + 170 * i, 250, shebei[i]);
                }
                for (int i = 10; i < 20; i++)
                {
                    panelset(130 + 170 * (i - 10), 350, shebei[i]);
                }
                for (int i = 20; i < 30; i++)
                {
                    panelset(130 + 170 * (i - 20), 450, shebei[i]);
                }
                for (int i = 30; i < 40; i++)
                {
                    panelset(130 + 170 * (i - 30), 550, shebei[i]);
                }
                ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = totalshebei - 40;

            }
        }

        private void DkXz_DsDw_Click(object sender, EventArgs e)
        {
            delpanelall();
            int totalshebei = m;
            allshebei = totalshebei;
            if (totalshebei <= 40)
            {
                if (0 <= totalshebei && totalshebei <= 10)
                {
                    for (int i = 0; i < totalshebei; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                }
                else if (totalshebei > 10 && totalshebei <= 20)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < totalshebei; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                }
                else if (totalshebei > 20 && totalshebei <= 30)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                    for (int i = 20; i < totalshebei; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[i]);
                    }
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[i]);
                    }
                    for (int i = 30; i < totalshebei; i++)
                    {
                        panelset(130 + 170 * (i - 30), 550, shebei[i]);
                    }
                }
                ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = 0;
            }
            else
            {
                for (int i = 0; i < 10; i++)
                {
                    panelset(130 + 170 * i, 250, shebei[i]);
                }
                for (int i = 10; i < 20; i++)
                {
                    panelset(130 + 170 * (i - 10), 350, shebei[i]);
                }
                for (int i = 20; i < 30; i++)
                {
                    panelset(130 + 170 * (i - 20), 450, shebei[i]);
                }
                for (int i = 30; i < 40; i++)
                {
                    panelset(130 + 170 * (i - 30), 550, shebei[i]);
                }
                ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = totalshebei - 40;

            }
        }

        private void DkXz_Ds_Click(object sender, EventArgs e)
        {
            delpanelall();
            int totalshebei = p;
            allshebei = totalshebei;
            if (totalshebei <= 40)
            {
                if (0 <= totalshebei && totalshebei <= 10)
                {
                    for (int i = 0; i < totalshebei; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                }
                else if (totalshebei > 10 && totalshebei <= 20)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < totalshebei; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                }
                else if (totalshebei > 20 && totalshebei <= 30)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                    for (int i = 20; i < totalshebei; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[i]);
                    }
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[i]);
                    }
                    for (int i = 30; i < totalshebei; i++)
                    {
                        panelset(130 + 170 * (i - 30), 550, shebei[i]);
                    }
                }
                ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = 0;
            }
            else
            {
                for (int i = 0; i < 10; i++)
                {
                    panelset(130 + 170 * i, 250, shebei[i]);
                }
                for (int i = 10; i < 20; i++)
                {
                    panelset(130 + 170 * (i - 10), 350, shebei[i]);
                }
                for (int i = 20; i < 30; i++)
                {
                    panelset(130 + 170 * (i - 20), 450, shebei[i]);
                }
                for (int i = 30; i < 40; i++)
                {
                    panelset(130 + 170 * (i - 30), 550, shebei[i]);
                }
                ChangCiSheZhiGlobalData.DanKongXuanZeShengYuSheBei = totalshebei - 40;

            }
        }

        private void A_Area_Click(object sender, EventArgs e)
        {

            if (A_Flag == false)
            {
                A_Flag = true;
                B_Flag = false;
                Qx_Flag = false;
                MessageBox.Show("可以选择A区设备!");
               
            }
            else
            {
                A_Flag = false;
                MessageBox.Show("取消A区选择状态!");
            }
        }

        private void B_Area_Click(object sender, EventArgs e)
        {
            if (B_Flag == false)
            {
                B_Flag = true;
                A_Flag = false;
                Qx_Flag = false;
                MessageBox.Show("可以选择B区设备!");
            }
            else
            {
                B_Flag = false;
                MessageBox.Show("取消B区选择状态!");
            }
        }


        public int GetIndex(string shebeiname)
        {
            if (shebeiname.Contains("调速设备"))
            {
                int i = int.Parse(shebeiname.Substring(4));
                return i;
            }
            else if (shebeiname.Contains("调速互锁类设备"))
            {
                int i = int.Parse(shebeiname.Substring(7));
                return i+n;
            }
            else if (shebeiname.Contains("定速定位设备"))
            {
                int i = int.Parse(shebeiname.Substring(6));
                return i+n+k;
            }
            else if (shebeiname.Contains("定速设备"))
            {
                int i = int.Parse(shebeiname.Substring(4));
                return i+n+k+m;
            }
            return 0;
        }
    }
    
}
