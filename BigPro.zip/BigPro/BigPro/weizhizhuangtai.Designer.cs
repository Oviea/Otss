﻿namespace BigPro
{
    partial class weizhizhuangtai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WZZT_Back = new System.Windows.Forms.Button();
            this.WZZT_2Main = new System.Windows.Forms.Button();
            this.WZZT_ML = new System.Windows.Forms.Label();
            this.WZZT_DS = new System.Windows.Forms.Button();
            this.WZZT_DSDW = new System.Windows.Forms.Button();
            this.WZZT_TXTS = new System.Windows.Forms.Button();
            this.WZZT_TSTS = new System.Windows.Forms.Button();
            this.WZZT_TR = new System.Windows.Forms.Button();
            this.WZZT_TL = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // WZZT_Back
            // 
            this.WZZT_Back.Font = new System.Drawing.Font("宋体", 14.2F);
            this.WZZT_Back.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.WZZT_Back.Location = new System.Drawing.Point(59, 898);
            this.WZZT_Back.Margin = new System.Windows.Forms.Padding(2);
            this.WZZT_Back.Name = "WZZT_Back";
            this.WZZT_Back.Size = new System.Drawing.Size(200, 70);
            this.WZZT_Back.TabIndex = 606;
            this.WZZT_Back.Text = "返回";
            this.WZZT_Back.UseVisualStyleBackColor = true;
            this.WZZT_Back.Click += new System.EventHandler(this.WZZT_Back_Click);
            // 
            // WZZT_2Main
            // 
            this.WZZT_2Main.Font = new System.Drawing.Font("宋体", 14.2F);
            this.WZZT_2Main.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.WZZT_2Main.Location = new System.Drawing.Point(1667, 898);
            this.WZZT_2Main.Margin = new System.Windows.Forms.Padding(2);
            this.WZZT_2Main.Name = "WZZT_2Main";
            this.WZZT_2Main.Size = new System.Drawing.Size(200, 70);
            this.WZZT_2Main.TabIndex = 605;
            this.WZZT_2Main.Text = "回首页";
            this.WZZT_2Main.UseVisualStyleBackColor = true;
            this.WZZT_2Main.Click += new System.EventHandler(this.WZZT_2Main_Click);
            // 
            // WZZT_ML
            // 
            this.WZZT_ML.AutoSize = true;
            this.WZZT_ML.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.WZZT_ML.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.WZZT_ML.Location = new System.Drawing.Point(905, 22);
            this.WZZT_ML.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.WZZT_ML.Name = "WZZT_ML";
            this.WZZT_ML.Size = new System.Drawing.Size(106, 24);
            this.WZZT_ML.TabIndex = 422;
            this.WZZT_ML.Text = "台上调速";
            // 
            // WZZT_DS
            // 
            this.WZZT_DS.BackColor = System.Drawing.Color.White;
            this.WZZT_DS.Font = new System.Drawing.Font("宋体", 14.2F);
            this.WZZT_DS.Location = new System.Drawing.Point(1198, 823);
            this.WZZT_DS.Margin = new System.Windows.Forms.Padding(2);
            this.WZZT_DS.Name = "WZZT_DS";
            this.WZZT_DS.Size = new System.Drawing.Size(150, 56);
            this.WZZT_DS.TabIndex = 854;
            this.WZZT_DS.Text = "定速";
            this.WZZT_DS.UseVisualStyleBackColor = false;
            this.WZZT_DS.Click += new System.EventHandler(this.WZZT_DS_Click);
            // 
            // WZZT_DSDW
            // 
            this.WZZT_DSDW.BackColor = System.Drawing.Color.White;
            this.WZZT_DSDW.Font = new System.Drawing.Font("宋体", 14.2F);
            this.WZZT_DSDW.Location = new System.Drawing.Point(1012, 823);
            this.WZZT_DSDW.Margin = new System.Windows.Forms.Padding(2);
            this.WZZT_DSDW.Name = "WZZT_DSDW";
            this.WZZT_DSDW.Size = new System.Drawing.Size(150, 56);
            this.WZZT_DSDW.TabIndex = 853;
            this.WZZT_DSDW.Text = "定速定位";
            this.WZZT_DSDW.UseVisualStyleBackColor = false;
            this.WZZT_DSDW.Click += new System.EventHandler(this.WZZT_DSDW_Click);
            // 
            // WZZT_TXTS
            // 
            this.WZZT_TXTS.BackColor = System.Drawing.Color.White;
            this.WZZT_TXTS.Font = new System.Drawing.Font("宋体", 14.2F);
            this.WZZT_TXTS.Location = new System.Drawing.Point(825, 823);
            this.WZZT_TXTS.Margin = new System.Windows.Forms.Padding(2);
            this.WZZT_TXTS.Name = "WZZT_TXTS";
            this.WZZT_TXTS.Size = new System.Drawing.Size(150, 56);
            this.WZZT_TXTS.TabIndex = 852;
            this.WZZT_TXTS.Text = "台下调速";
            this.WZZT_TXTS.UseVisualStyleBackColor = false;
            this.WZZT_TXTS.Click += new System.EventHandler(this.WZZT_TXTS_Click);
            // 
            // WZZT_TSTS
            // 
            this.WZZT_TSTS.BackColor = System.Drawing.Color.White;
            this.WZZT_TSTS.Font = new System.Drawing.Font("宋体", 14.2F);
            this.WZZT_TSTS.Location = new System.Drawing.Point(631, 823);
            this.WZZT_TSTS.Margin = new System.Windows.Forms.Padding(2);
            this.WZZT_TSTS.Name = "WZZT_TSTS";
            this.WZZT_TSTS.Size = new System.Drawing.Size(150, 56);
            this.WZZT_TSTS.TabIndex = 851;
            this.WZZT_TSTS.Text = "台上调速";
            this.WZZT_TSTS.UseVisualStyleBackColor = false;
            this.WZZT_TSTS.Click += new System.EventHandler(this.WZZT_TSTS_Click);
            // 
            // WZZT_TR
            // 
            this.WZZT_TR.ForeColor = System.Drawing.Color.Black;
            this.WZZT_TR.Image = global::BigPro.Properties.Resources.ToRight;
            this.WZZT_TR.Location = new System.Drawing.Point(1828, 14);
            this.WZZT_TR.Margin = new System.Windows.Forms.Padding(2);
            this.WZZT_TR.Name = "WZZT_TR";
            this.WZZT_TR.Size = new System.Drawing.Size(50, 50);
            this.WZZT_TR.TabIndex = 858;
            this.WZZT_TR.UseVisualStyleBackColor = true;
            this.WZZT_TR.Click += new System.EventHandler(this.WZZT_TR_Click);
            // 
            // WZZT_TL
            // 
            this.WZZT_TL.ForeColor = System.Drawing.Color.Black;
            this.WZZT_TL.Image = global::BigPro.Properties.Resources.Toleft;
            this.WZZT_TL.Location = new System.Drawing.Point(33, 14);
            this.WZZT_TL.Margin = new System.Windows.Forms.Padding(2);
            this.WZZT_TL.Name = "WZZT_TL";
            this.WZZT_TL.Size = new System.Drawing.Size(50, 50);
            this.WZZT_TL.TabIndex = 857;
            this.WZZT_TL.UseVisualStyleBackColor = true;
            this.WZZT_TL.Click += new System.EventHandler(this.WZZT_TL_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Location = new System.Drawing.Point(1450, 100);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(365, 35);
            this.panel3.TabIndex = 862;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.Control;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label15.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label15.Location = new System.Drawing.Point(-1, -1);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(90, 35);
            this.label15.TabIndex = 423;
            this.label15.Text = "设备名";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.Control;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label16.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label16.Location = new System.Drawing.Point(88, -1);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(70, 35);
            this.label16.TabIndex = 424;
            this.label16.Text = "位置";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.SystemColors.Control;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label17.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label17.Location = new System.Drawing.Point(157, -1);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 35);
            this.label17.TabIndex = 425;
            this.label17.Text = "状态";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.SystemColors.Control;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label18.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label18.Location = new System.Drawing.Point(226, -1);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(70, 35);
            this.label18.TabIndex = 614;
            this.label18.Text = "限位";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.SystemColors.Control;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label19.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label19.Location = new System.Drawing.Point(295, -1);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 35);
            this.label19.TabIndex = 615;
            this.label19.Text = "偏差";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Location = new System.Drawing.Point(100, 100);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(365, 35);
            this.panel4.TabIndex = 863;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label3.Location = new System.Drawing.Point(-1, -1);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 35);
            this.label3.TabIndex = 423;
            this.label3.Text = "设备名";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label4.Location = new System.Drawing.Point(88, -1);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 35);
            this.label4.TabIndex = 424;
            this.label4.Text = "位置";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.Control;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label6.Location = new System.Drawing.Point(157, -1);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 35);
            this.label6.TabIndex = 425;
            this.label6.Text = "状态";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.Control;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label7.Location = new System.Drawing.Point(226, -1);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 35);
            this.label7.TabIndex = 614;
            this.label7.Text = "限位";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.SystemColors.Control;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label20.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label20.Location = new System.Drawing.Point(295, -1);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(70, 35);
            this.label20.TabIndex = 615;
            this.label20.Text = "偏差";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Location = new System.Drawing.Point(550, 100);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(365, 35);
            this.panel1.TabIndex = 864;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label1.Location = new System.Drawing.Point(-1, -1);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 35);
            this.label1.TabIndex = 423;
            this.label1.Text = "设备名";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label2.Location = new System.Drawing.Point(88, -1);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 35);
            this.label2.TabIndex = 424;
            this.label2.Text = "位置";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label5.Location = new System.Drawing.Point(157, -1);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 35);
            this.label5.TabIndex = 425;
            this.label5.Text = "状态";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.Control;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label13.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label13.Location = new System.Drawing.Point(226, -1);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 35);
            this.label13.TabIndex = 614;
            this.label13.Text = "限位";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.Control;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label14.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label14.Location = new System.Drawing.Point(295, -1);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 35);
            this.label14.TabIndex = 615;
            this.label14.Text = "偏差";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Location = new System.Drawing.Point(1000, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(365, 35);
            this.panel2.TabIndex = 865;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label8.Location = new System.Drawing.Point(-1, -1);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 35);
            this.label8.TabIndex = 423;
            this.label8.Text = "设备名";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.Control;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label9.Location = new System.Drawing.Point(88, -1);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 35);
            this.label9.TabIndex = 424;
            this.label9.Text = "位置";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.Control;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label10.Location = new System.Drawing.Point(157, -1);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 35);
            this.label10.TabIndex = 425;
            this.label10.Text = "状态";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.Control;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label11.Location = new System.Drawing.Point(226, -1);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 35);
            this.label11.TabIndex = 614;
            this.label11.Text = "限位";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.Control;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("黑体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label12.Location = new System.Drawing.Point(295, -1);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 35);
            this.label12.TabIndex = 615;
            this.label12.Text = "偏差";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // weizhizhuangtai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.WZZT_TR);
            this.Controls.Add(this.WZZT_TL);
            this.Controls.Add(this.WZZT_DS);
            this.Controls.Add(this.WZZT_DSDW);
            this.Controls.Add(this.WZZT_TXTS);
            this.Controls.Add(this.WZZT_TSTS);
            this.Controls.Add(this.WZZT_Back);
            this.Controls.Add(this.WZZT_2Main);
            this.Controls.Add(this.WZZT_ML);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "weizhizhuangtai";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "weizhizhuangtai";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.weizhizhuangtai_Load);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button WZZT_Back;
        private System.Windows.Forms.Button WZZT_2Main;
        private System.Windows.Forms.Label WZZT_ML;
        private System.Windows.Forms.Button WZZT_DS;
        private System.Windows.Forms.Button WZZT_DSDW;
        private System.Windows.Forms.Button WZZT_TXTS;
        private System.Windows.Forms.Button WZZT_TSTS;
        private System.Windows.Forms.Button WZZT_TR;
        private System.Windows.Forms.Button WZZT_TL;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}