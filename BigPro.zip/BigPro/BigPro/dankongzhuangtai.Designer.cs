﻿namespace BigPro
{
    partial class dankongzhuangtai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Back_2_DKXZ = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.DkZT_Back = new System.Windows.Forms.Button();
            this.DKZT_2Main = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.A_AreaL = new System.Windows.Forms.Button();
            this.A_AreaR = new System.Windows.Forms.Button();
            this.B_AreaL = new System.Windows.Forms.Button();
            this.B_AreaR = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Back_2_DKXZ
            // 
            this.Back_2_DKXZ.Font = new System.Drawing.Font("宋体", 14.2F);
            this.Back_2_DKXZ.Location = new System.Drawing.Point(910, 923);
            this.Back_2_DKXZ.Margin = new System.Windows.Forms.Padding(2);
            this.Back_2_DKXZ.Name = "Back_2_DKXZ";
            this.Back_2_DKXZ.Size = new System.Drawing.Size(112, 40);
            this.Back_2_DKXZ.TabIndex = 291;
            this.Back_2_DKXZ.Text = "单控选择";
            this.Back_2_DKXZ.UseVisualStyleBackColor = true;
            this.Back_2_DKXZ.Click += new System.EventHandler(this.Back_2_DKXZ_Click);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(286, 863);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(559, 29);
            this.label8.TabIndex = 285;
            this.label8.Text = "操作提示:请先在单控选择界面选择设备分区！";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label2.Location = new System.Drawing.Point(284, 126);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(568, 2);
            this.label2.TabIndex = 175;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button3.Location = new System.Drawing.Point(844, 234);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(59, 40);
            this.button3.TabIndex = 171;
            this.button3.Text = "速度";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Enabled = false;
            this.button2.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button2.Location = new System.Drawing.Point(1228, 54);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 56);
            this.button2.TabIndex = 170;
            this.button2.Text = "B区";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Enabled = false;
            this.button1.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button1.Location = new System.Drawing.Point(492, 54);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 56);
            this.button1.TabIndex = 169;
            this.button1.Text = "A区";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(880, 54);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 24);
            this.label1.TabIndex = 168;
            this.label1.Text = "手动状态";
            // 
            // DkZT_Back
            // 
            this.DkZT_Back.Font = new System.Drawing.Font("宋体", 14.2F);
            this.DkZT_Back.Location = new System.Drawing.Point(286, 923);
            this.DkZT_Back.Margin = new System.Windows.Forms.Padding(2);
            this.DkZT_Back.Name = "DkZT_Back";
            this.DkZT_Back.Size = new System.Drawing.Size(112, 40);
            this.DkZT_Back.TabIndex = 293;
            this.DkZT_Back.Text = "返回";
            this.DkZT_Back.UseVisualStyleBackColor = true;
            this.DkZT_Back.Click += new System.EventHandler(this.DkZT_Back_Click);
            // 
            // DKZT_2Main
            // 
            this.DKZT_2Main.Font = new System.Drawing.Font("宋体", 14.2F);
            this.DKZT_2Main.Location = new System.Drawing.Point(1557, 923);
            this.DKZT_2Main.Margin = new System.Windows.Forms.Padding(2);
            this.DKZT_2Main.Name = "DKZT_2Main";
            this.DKZT_2Main.Size = new System.Drawing.Size(112, 40);
            this.DKZT_2Main.TabIndex = 294;
            this.DKZT_2Main.Text = "回首页";
            this.DKZT_2Main.UseVisualStyleBackColor = true;
            this.DKZT_2Main.Click += new System.EventHandler(this.DKZT_2Main_Click);
            // 
            // button49
            // 
            this.button49.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button49.Location = new System.Drawing.Point(289, 54);
            this.button49.Margin = new System.Windows.Forms.Padding(2);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(76, 42);
            this.button49.TabIndex = 295;
            this.button49.Text = "解锁";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button5.Location = new System.Drawing.Point(1618, 54);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(76, 42);
            this.button5.TabIndex = 296;
            this.button5.Text = "单动";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button6.Location = new System.Drawing.Point(1446, 54);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(124, 42);
            this.button6.TabIndex = 297;
            this.button6.Text = "复位报警";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.ControlText;
            this.label13.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label13.Location = new System.Drawing.Point(902, 316);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(2, 200);
            this.label13.TabIndex = 1162;
            this.label13.Text = "label13";
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button4.Location = new System.Drawing.Point(884, 396);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(38, 24);
            this.button4.TabIndex = 1163;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button105
            // 
            this.button105.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button105.Location = new System.Drawing.Point(906, 234);
            this.button105.Margin = new System.Windows.Forms.Padding(2);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(64, 40);
            this.button105.TabIndex = 1194;
            this.button105.Text = "50";
            this.button105.UseVisualStyleBackColor = true;
            // 
            // button63
            // 
            this.button63.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button63.Location = new System.Drawing.Point(1652, 234);
            this.button63.Margin = new System.Windows.Forms.Padding(2);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(64, 40);
            this.button63.TabIndex = 1257;
            this.button63.Text = "50";
            this.button63.UseVisualStyleBackColor = true;
            // 
            // button92
            // 
            this.button92.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button92.Location = new System.Drawing.Point(1617, 678);
            this.button92.Margin = new System.Windows.Forms.Padding(2);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(60, 40);
            this.button92.TabIndex = 1229;
            this.button92.Text = "下降";
            this.button92.UseVisualStyleBackColor = true;
            // 
            // button93
            // 
            this.button93.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button93.Location = new System.Drawing.Point(1617, 611);
            this.button93.Margin = new System.Windows.Forms.Padding(2);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(60, 40);
            this.button93.TabIndex = 1228;
            this.button93.Text = "停止";
            this.button93.UseVisualStyleBackColor = true;
            // 
            // button94
            // 
            this.button94.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button94.Location = new System.Drawing.Point(1617, 538);
            this.button94.Margin = new System.Windows.Forms.Padding(2);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(60, 40);
            this.button94.TabIndex = 1227;
            this.button94.Text = "上升";
            this.button94.UseVisualStyleBackColor = true;
            // 
            // button95
            // 
            this.button95.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button95.Location = new System.Drawing.Point(1628, 396);
            this.button95.Margin = new System.Windows.Forms.Padding(2);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(38, 24);
            this.button95.TabIndex = 1226;
            this.button95.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ControlText;
            this.label5.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label5.Location = new System.Drawing.Point(1646, 316);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(2, 200);
            this.label5.TabIndex = 1225;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(1030, 863);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(559, 29);
            this.label6.TabIndex = 1224;
            this.label6.Text = "操作提示:请先在单控选择界面选择设备分区！";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Red;
            this.label10.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label10.Location = new System.Drawing.Point(1028, 126);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(568, 2);
            this.label10.TabIndex = 1196;
            // 
            // A_AreaL
            // 
            this.A_AreaL.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.A_AreaL.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.A_AreaL.Location = new System.Drawing.Point(236, 150);
            this.A_AreaL.Name = "A_AreaL";
            this.A_AreaL.Size = new System.Drawing.Size(30, 30);
            this.A_AreaL.TabIndex = 1302;
            this.A_AreaL.Text = "<";
            this.A_AreaL.UseVisualStyleBackColor = false;
            this.A_AreaL.Click += new System.EventHandler(this.A_AreaL_Click);
            // 
            // A_AreaR
            // 
            this.A_AreaR.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.A_AreaR.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.A_AreaR.Location = new System.Drawing.Point(861, 150);
            this.A_AreaR.Name = "A_AreaR";
            this.A_AreaR.Size = new System.Drawing.Size(30, 30);
            this.A_AreaR.TabIndex = 1303;
            this.A_AreaR.Text = ">";
            this.A_AreaR.UseVisualStyleBackColor = false;
            this.A_AreaR.Click += new System.EventHandler(this.A_AreaR_Click);
            // 
            // B_AreaL
            // 
            this.B_AreaL.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.B_AreaL.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.B_AreaL.Location = new System.Drawing.Point(976, 150);
            this.B_AreaL.Name = "B_AreaL";
            this.B_AreaL.Size = new System.Drawing.Size(30, 30);
            this.B_AreaL.TabIndex = 1304;
            this.B_AreaL.Text = "<";
            this.B_AreaL.UseVisualStyleBackColor = false;
            this.B_AreaL.Click += new System.EventHandler(this.B_AreaL_Click);
            // 
            // B_AreaR
            // 
            this.B_AreaR.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.B_AreaR.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.B_AreaR.Location = new System.Drawing.Point(1599, 150);
            this.B_AreaR.Name = "B_AreaR";
            this.B_AreaR.Size = new System.Drawing.Size(30, 30);
            this.B_AreaR.TabIndex = 1305;
            this.B_AreaR.Text = ">";
            this.B_AreaR.UseVisualStyleBackColor = false;
            this.B_AreaR.Click += new System.EventHandler(this.B_AreaR_Click);
            // 
            // button50
            // 
            this.button50.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button50.Location = new System.Drawing.Point(872, 538);
            this.button50.Margin = new System.Windows.Forms.Padding(2);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(60, 40);
            this.button50.TabIndex = 1164;
            this.button50.Text = "上升";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button77
            // 
            this.button77.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button77.Location = new System.Drawing.Point(872, 611);
            this.button77.Margin = new System.Windows.Forms.Padding(2);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(60, 40);
            this.button77.TabIndex = 1165;
            this.button77.Text = "停止";
            this.button77.UseVisualStyleBackColor = true;
            // 
            // button78
            // 
            this.button78.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button78.Location = new System.Drawing.Point(872, 678);
            this.button78.Margin = new System.Windows.Forms.Padding(2);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(60, 40);
            this.button78.TabIndex = 1166;
            this.button78.Text = "下降";
            this.button78.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button7.Location = new System.Drawing.Point(1589, 234);
            this.button7.Margin = new System.Windows.Forms.Padding(2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(59, 40);
            this.button7.TabIndex = 1306;
            this.button7.Text = "速度";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // dankongzhuangtai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.B_AreaR);
            this.Controls.Add(this.B_AreaL);
            this.Controls.Add(this.A_AreaR);
            this.Controls.Add(this.A_AreaL);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button92);
            this.Controls.Add(this.button93);
            this.Controls.Add(this.button94);
            this.Controls.Add(this.button95);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button105);
            this.Controls.Add(this.button78);
            this.Controls.Add(this.button77);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.DKZT_2Main);
            this.Controls.Add(this.DkZT_Back);
            this.Controls.Add(this.Back_2_DKXZ);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "dankongzhuangtai";
            this.Text = "dankongzhuangtai";
            this.Load += new System.EventHandler(this.dankongzhuangtai_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Back_2_DKXZ;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button DkZT_Back;
        private System.Windows.Forms.Button DKZT_2Main;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button A_AreaL;
        private System.Windows.Forms.Button A_AreaR;
        private System.Windows.Forms.Button B_AreaL;
        private System.Windows.Forms.Button B_AreaR;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button7;
    }
}