﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class wangluo : Form
    {
        private static bool ButtonFlag;// true:台上 false:台下
        private static int allshebei;
        private static string[] shebei;
        private int n, k, m, p;
        private static int clickcountTSTX;
        private static int clickcountTXTS;
        public wangluo()
        {
            InitializeComponent();
        }

        private void wangluo_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            WL_TSTX.BackColor = Color.AliceBlue;
            WL_TSTX.Enabled = false;
            ButtonFlag = true;
            delpanelall();
            WL_ML.Text = "台上调速";
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                if (totalshebei <= 36)
                {
                    if (0 <= totalshebei && totalshebei <= 12)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(350 + 100 * i, 150, shebei[i]);
                        }
                    }
                    else if (12 < totalshebei && totalshebei <= 24)
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(350 + 100 * i, 150, shebei[i]);
                        }
                        for (int i = 12; i < totalshebei; i++)
                        {
                            panelset(350 + 100 * (i - 12), 315, shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(350 + 100 * i, 150, shebei[i]);
                        }
                        for (int i = 12; i < 24; i++)
                        {
                            panelset(350 + 100 * (i - 12), 315, shebei[i]);
                        }
                        for (int i = 24; i < totalshebei; i++)
                        {
                            panelset(350 + 100 * (i - 24), 480, shebei[i]);
                        }

                    }
                    ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS = 0;
                }
                else
                {
                    for (int i = 0; i < 12; i++)
                    {
                        panelset(350 + 100 * i, 150, shebei[i]);
                    }
                    for (int i = 12; i < 24; i++)
                    {
                        panelset(350 + 100 * (i - 12), 315, shebei[i]);
                    }
                    for (int i = 24; i < 36; i++)
                    {
                        panelset(350 + 100 * (i - 24), 480, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS = totalshebei - 36;
                }
            }
        }

        private void delpanelall()
        {
            if (Controls["WL_P350150"] != null)
            {
                Controls["WL_P350150"].Dispose();
            }
            if (Controls["WL_P450150"] != null)
            {
                Controls["WL_P450150"].Dispose();
            }
            if (Controls["WL_P550150"] != null)
            {
                Controls["WL_P550150"].Dispose();
            }
            if (Controls["WL_P650150"] != null)
            {
                Controls["WL_P650150"].Dispose();
            }
            if (Controls["WL_P750150"] != null)
            {
                Controls["WL_P750150"].Dispose();
            }
            if (Controls["WL_P850150"] != null)
            {
                Controls["WL_P850150"].Dispose();
            }
            if (Controls["WL_P950150"] != null)
            {
                Controls["WL_P950150"].Dispose();
            }
            if (Controls["WL_P1050150"] != null)
            {
                Controls["WL_P1050150"].Dispose();
            }
            if (Controls["WL_P1150150"] != null)
            {
                Controls["WL_P1150150"].Dispose();
            }
            if (Controls["WL_P1250150"] != null)
            {
                Controls["WL_P1250150"].Dispose();
            }
            if (Controls["WL_P1350150"] != null)
            {
                Controls["WL_P1350150"].Dispose();
            }
            if (Controls["WL_P1450150"] != null)
            {
                Controls["WL_P1450150"].Dispose();
            }

            if (Controls["WL_P350315"] != null)
            {
                Controls["WL_P350315"].Dispose();
            }
            if (Controls["WL_P450315"] != null)
            {
                Controls["WL_P450315"].Dispose();
            }
            if (Controls["WL_P550315"] != null)
            {
                Controls["WL_P550315"].Dispose();
            }
            if (Controls["WL_P650315"] != null)
            {
                Controls["WL_P650315"].Dispose();
            }
            if (Controls["WL_P750315"] != null)
            {
                Controls["WL_P750315"].Dispose();
            }
            if (Controls["WL_P850315"] != null)
            {
                Controls["WL_P850315"].Dispose();
            }
            if (Controls["WL_P950315"] != null)
            {
                Controls["WL_P950315"].Dispose();
            }
            if (Controls["WL_P1050315"] != null)
            {
                Controls["WL_P1050315"].Dispose();
            }
            if (Controls["WL_P1150315"] != null)
            {
                Controls["WL_P1150315"].Dispose();
            }
            if (Controls["WL_P1250315"] != null)
            {
                Controls["WL_P1250315"].Dispose();
            }
            if (Controls["WL_P1350315"] != null)
            {
                Controls["WL_P1350315"].Dispose();
            }
            if (Controls["WL_P1450315"] != null)
            {
                Controls["WL_P1450315"].Dispose();
            }


            if (Controls["WL_P350480"] != null)
            {
                Controls["WL_P350480"].Dispose();
            }
            if (Controls["WL_P450480"] != null)
            {
                Controls["WL_P450480"].Dispose();
            }
            if (Controls["WL_P550480"] != null)
            {
                Controls["WL_P550480"].Dispose();
            }
            if (Controls["WL_P650480"] != null)
            {
                Controls["WL_P650480"].Dispose();
            }
            if (Controls["WL_P750480"] != null)
            {
                Controls["WL_P750480"].Dispose();
            }
            if (Controls["WL_P850480"] != null)
            {
                Controls["WL_P850480"].Dispose();
            }
            if (Controls["WL_P950480"] != null)
            {
                Controls["WL_P950480"].Dispose();
            }
            if (Controls["WL_P1050480"] != null)
            {
                Controls["WL_P1050480"].Dispose();
            }
            if (Controls["WL_P1150480"] != null)
            {
                Controls["WL_P1150480"].Dispose();
            }
            if (Controls["WL_P1250480"] != null)
            {
                Controls["WL_P1250480"].Dispose();
            }
            if (Controls["WL_P1350480"] != null)
            {
                Controls["WL_P1350480"].Dispose();
            }
            if (Controls["WL_P1450480"] != null)
            {
                Controls["WL_P1450480"].Dispose();
            }
        }

        private void WL_TL_Click(object sender, EventArgs e)
        {
            if (ButtonFlag == true)
            {
                clickcountTSTX--;
                if (ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS >= allshebei - 36)
                {
                    MessageBox.Show("没有更多台上调速设备！");
                    clickcountTSTX++;
                    //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
                }
                else
                {
                    delpanelall();

                    for (int i = 0; i < 12; i++)
                    {
                        panelset(350 + 100 * i, 150, shebei[i]);
                    }
                    for (int i = 12; i < 24; i++)
                    {
                        panelset(350 + 100 * (i - 12), 315, shebei[i]);
                    }
                    for (int i = 24; i < 36; i++)
                    {
                        panelset(350 + 100 * (i - 24), 480, shebei[i]);
                    }

                    if (ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS == 0)
                    {
                        if (allshebei % 36 == 0)
                        {
                            ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS = 36;
                        }
                        else
                        {
                            ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS = allshebei % 36;
                        }
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS = ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS + 36;
                    }
                }
            }
            else
            {
                clickcountTXTS--;
                if (ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS >= allshebei - 36)
                {
                    MessageBox.Show("没有更多台下调速设备！");
                    clickcountTXTS++;
                    //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
                }
                else
                {
                    delpanelall();

                    for (int i = 0; i < 12; i++)
                    {
                        panelset(350 + 100 * i, 150, shebei[i]);
                    }
                    for (int i = 12; i < 24; i++)
                    {
                        panelset(350 + 100 * (i - 12), 315, shebei[i]);
                    }
                    for (int i = 24; i < 36; i++)
                    {
                        panelset(350 + 100 * (i - 24), 480, shebei[i]);
                    }

                    if (ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS == 0)
                    {
                        if (allshebei % 36 == 0)
                        {
                            ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS = 36;
                        }
                        else
                        {
                            ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS = allshebei % 36;
                        }
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS = ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS + 36;
                    }
                }
            }
        }

        private void WL_TR_Click(object sender, EventArgs e)
        {
            if (ButtonFlag == true)
            {
                clickcountTSTX++;
                if (ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS == 0)
                {
                    MessageBox.Show("没有更多台上调速设备！");
                    // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                    clickcountTSTX--;
                }
                else
                {
                    delpanelall();
                    if (ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS < 36)
                    {

                        if (0 <= ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS && ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS <= 12)
                        {
                            for (int i = 0; i < ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS; i++)
                            {
                                panelset(350 + 100 * i, 150, shebei[36 * clickcountTSTX + i]);
                            }
                        }
                        else if (ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS > 12 && ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS <= 24)
                        {
                            for (int i = 0; i < 12; i++)
                            {
                                panelset(350 + 100 * i, 150, shebei[36 * clickcountTSTX + i]);
                            }
                            for (int i = 12; i < ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS; i++)
                            {
                                panelset(35 + 100 * (i - 12), 315, shebei[36 * clickcountTSTX + i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 12; i++)
                            {
                                panelset(350 + 100 * i, 150, shebei[36 * clickcountTSTX + i]);
                            }
                            for (int i = 12; i < 24; i++)
                            {
                                panelset(35 + 100 * (i - 12), 315, shebei[36 * clickcountTSTX + i]);
                            }
                            for (int i = 24; i < ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS; i++)
                            {
                                panelset(35 + 100 * (i - 24), 480, shebei[36 * clickcountTSTX + i]);
                            }

                        }
                        ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(350 + 100 * i, 150, shebei[36 * clickcountTSTX + i]);
                        }
                        for (int i = 12; i < 24; i++)
                        {
                            panelset(35 + 100 * (i - 12), 315, shebei[36 * clickcountTSTX + i]);
                        }
                        for (int i = 24; i < 36; i++)
                        {
                            panelset(35 + 100 * (i - 24), 480, shebei[36 * clickcountTSTX + i]);
                        }

                        ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS = ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS - 40;
                    }
                }
            }
            else
            {
                clickcountTXTS++;
                if (ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS == 0)
                {
                    MessageBox.Show("没有更多台上调速设备！");
                    // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                    clickcountTXTS--;
                }
                else
                {
                    delpanelall();
                    if (ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS < 36)
                    {

                        if (0 <= ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS && ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS <= 12)
                        {
                            for (int i = 0; i < ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS; i++)
                            {
                                panelset(350 + 100 * i, 150, shebei[36 * clickcountTXTS + i]);
                            }
                        }
                        else if (ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS > 12 && ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS <= 24)
                        {
                            for (int i = 0; i < 12; i++)
                            {
                                panelset(350 + 100 * i, 150, shebei[36 * clickcountTXTS + i]);
                            }
                            for (int i = 12; i < ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS; i++)
                            {
                                panelset(35 + 100 * (i - 12), 315, shebei[36 * clickcountTXTS + i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 12; i++)
                            {
                                panelset(350 + 100 * i, 150, shebei[36 * clickcountTXTS + i]);
                            }
                            for (int i = 12; i < 24; i++)
                            {
                                panelset(35 + 100 * (i - 12), 315, shebei[36 * clickcountTXTS + i]);
                            }
                            for (int i = 24; i < ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS; i++)
                            {
                                panelset(35 + 100 * (i - 24), 480, shebei[36 * clickcountTXTS + i]);
                            }

                        }
                        ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(350 + 100 * i, 150, shebei[36 * clickcountTXTS + i]);
                        }
                        for (int i = 12; i < 24; i++)
                        {
                            panelset(35 + 100 * (i - 12), 315, shebei[36 * clickcountTXTS + i]);
                        }
                        for (int i = 24; i < 36; i++)
                        {
                            panelset(35 + 100 * (i - 24), 480, shebei[36 * clickcountTXTS + i]);
                        }

                        ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS = ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS - 40;
                    }
                }
            }
        }

        private void WL_TSTX_Click(object sender, EventArgs e)
        {
            WL_TXTS.Enabled = true;
            WL_TXTS.BackColor = Color.White;
            WL_TSTX.Enabled = false;
            WL_TSTX.BackColor = Color.AliceBlue;
            WL_ML.Text = "台上调速";
            ButtonFlag = true;

            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                if (totalshebei <= 36)
                {
                    if (0 <= totalshebei && totalshebei <= 12)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(350 + 100 * i, 150, shebei[i]);
                        }
                    }
                    else if (12 < totalshebei && totalshebei <= 24)
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(350 + 100 * i, 150, shebei[i]);
                        }
                        for (int i = 12; i < totalshebei; i++)
                        {
                            panelset(350 + 100 * (i - 12), 315, shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(350 + 100 * i, 150, shebei[i]);
                        }
                        for (int i = 12; i < 24; i++)
                        {
                            panelset(350 + 100 * (i - 12), 315, shebei[i]);
                        }
                        for (int i = 24; i < totalshebei; i++)
                        {
                            panelset(350 + 100 * (i - 24), 480, shebei[i]);
                        }

                    }
                    ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS = 0;
                }
                else
                {
                    for (int i = 0; i < 12; i++)
                    {
                        panelset(350 + 100 * i, 150, shebei[i]);
                    }
                    for (int i = 12; i < 24; i++)
                    {
                        panelset(350 + 100 * (i - 12), 315, shebei[i]);
                    }
                    for (int i = 24; i < 36; i++)
                    {
                        panelset(350 + 100 * (i - 24), 480, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.WangLuoYuSheBeiTSTS = totalshebei - 36;
                }
            }
        }

        private void WL_TXTS_Click(object sender, EventArgs e)
        {
            WL_TSTX.Enabled = true;
            WL_TSTX.BackColor = Color.White;
            WL_TXTS.Enabled = false;
            WL_TXTS.BackColor = Color.AliceBlue;
            WL_ML.Text = "台下调速";
            ButtonFlag = false;

            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                if (totalshebei <= 36)
                {
                    if (0 <= totalshebei && totalshebei <= 12)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(350 + 100 * i, 150, shebei[i]);
                        }
                    }
                    else if (12 < totalshebei && totalshebei <= 24)
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(350 + 100 * i, 150, shebei[i]);
                        }
                        for (int i = 12; i < totalshebei; i++)
                        {
                            panelset(350 + 100 * (i - 12), 315, shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 12; i++)
                        {
                            panelset(350 + 100 * i, 150, shebei[i]);
                        }
                        for (int i = 12; i < 24; i++)
                        {
                            panelset(350 + 100 * (i - 12), 315, shebei[i]);
                        }
                        for (int i = 24; i < totalshebei; i++)
                        {
                            panelset(350 + 100 * (i - 24), 480, shebei[i]);
                        }

                    }
                    ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS = 0;
                }
                else
                {
                    for (int i = 0; i < 12; i++)
                    {
                        panelset(350 + 100 * i, 150, shebei[i]);
                    }
                    for (int i = 12; i < 24; i++)
                    {
                        panelset(350 + 100 * (i - 12), 315, shebei[i]);
                    }
                    for (int i = 24; i < 36; i++)
                    {
                        panelset(350 + 100 * (i - 24), 480, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.WangLuoYuSheBeiTXTS = totalshebei - 36;
                }
            }
        }

        private void panelset(int x, int y, string shebeiname)
        { // 
            // WL_DZ
            // 
            Label WL_DZ = new Label();
            WL_DZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            WL_DZ.Location = new System.Drawing.Point(0, 95);
            WL_DZ.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            WL_DZ.Name = "WL_DZ"+x+y;
            WL_DZ.Size = new System.Drawing.Size(50, 20);
            WL_DZ.TabIndex = 614;
            WL_DZ.Text = "地址";
            WL_DZ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // WL_SBM
            //
            Label WL_SBM = new Label();
            WL_SBM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            WL_SBM.Font = new System.Drawing.Font("宋体", 9F);
            WL_SBM.Location = new System.Drawing.Point(-1, 0);
            WL_SBM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            WL_SBM.Name = "WL_SBM" + x + y;
            WL_SBM.Size = new System.Drawing.Size(50, 20);
            WL_SBM.TabIndex = 613;
            WL_SBM.Text = shebeiname;
            WL_SBM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // WL_PIC
            // 
            PictureBox WL_PIC = new PictureBox();
            WL_PIC.Image = ((System.Drawing.Image)(global::BigPro.Properties.Resources.变频器));
            WL_PIC.Location = new System.Drawing.Point(-1, 20);
            WL_PIC.Margin = new System.Windows.Forms.Padding(2);
            WL_PIC.Name = "WL_PIC" + x + y;
            WL_PIC.Size = new System.Drawing.Size(50, 75);
            WL_PIC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            WL_PIC.TabIndex = 612;
            WL_PIC.TabStop = false;
            // 
            // WL_P
            //
            Panel WL_P = new Panel();
            WL_P.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            WL_P.Controls.Add(WL_SBM);
            WL_P.Controls.Add(WL_PIC);
            WL_P.Controls.Add(WL_DZ);
            WL_P.Location = new System.Drawing.Point(x,y);
            WL_P.Name = "WL_P"+x+y;
            WL_P.Size = new System.Drawing.Size(51, 117);
            WL_P.TabIndex = 3699;
            this.Controls.Add(WL_P);
        }

        private void WL_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void WL_Back2Main_Click(object sender, EventArgs e)
        {
            var frm = new main();
            frm.Show();
            this.Close();
        }
    }
}
