﻿namespace BigPro
{
    partial class dankong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.To_DkZt = new System.Windows.Forms.Button();
            this.DkAll_Cancel = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.B_Area = new System.Windows.Forms.Button();
            this.A_Area = new System.Windows.Forms.Button();
            this.Qx_Bt = new System.Windows.Forms.Button();
            this.DK_Back = new System.Windows.Forms.Button();
            this.DK_MainPage = new System.Windows.Forms.Button();
            this.DKXZ_ToRight = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.DKXZ_ToLeft = new System.Windows.Forms.Button();
            this.FenLei_Panel = new System.Windows.Forms.Panel();
            this.DkXz_Ds = new System.Windows.Forms.Button();
            this.DkXz_DsDw = new System.Windows.Forms.Button();
            this.DkXz_TsHs = new System.Windows.Forms.Button();
            this.DkXz_Ts = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.FenLei_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label4.Location = new System.Drawing.Point(1363, 665);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 19);
            this.label4.TabIndex = 164;
            // 
            // To_DkZt
            // 
            this.To_DkZt.Font = new System.Drawing.Font("宋体", 14.2F);
            this.To_DkZt.Location = new System.Drawing.Point(1168, 838);
            this.To_DkZt.Margin = new System.Windows.Forms.Padding(2);
            this.To_DkZt.Name = "To_DkZt";
            this.To_DkZt.Size = new System.Drawing.Size(112, 40);
            this.To_DkZt.TabIndex = 149;
            this.To_DkZt.Text = "单控状态";
            this.To_DkZt.UseVisualStyleBackColor = true;
            this.To_DkZt.Click += new System.EventHandler(this.To_DkZt_Click);
            // 
            // DkAll_Cancel
            // 
            this.DkAll_Cancel.Font = new System.Drawing.Font("宋体", 14.2F);
            this.DkAll_Cancel.Location = new System.Drawing.Point(990, 838);
            this.DkAll_Cancel.Margin = new System.Windows.Forms.Padding(2);
            this.DkAll_Cancel.Name = "DkAll_Cancel";
            this.DkAll_Cancel.Size = new System.Drawing.Size(112, 40);
            this.DkAll_Cancel.TabIndex = 147;
            this.DkAll_Cancel.Text = "全部取消";
            this.DkAll_Cancel.UseVisualStyleBackColor = true;
            this.DkAll_Cancel.Click += new System.EventHandler(this.DkAll_Cancel_Click);
            // 
            // button31
            // 
            this.button31.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button31.Location = new System.Drawing.Point(634, 838);
            this.button31.Margin = new System.Windows.Forms.Padding(2);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(112, 40);
            this.button31.TabIndex = 146;
            this.button31.Text = "确定";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label2.Location = new System.Drawing.Point(-5, 133);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1940, 3);
            this.label2.TabIndex = 113;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(883, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 27);
            this.label1.TabIndex = 112;
            this.label1.Text = "手动状态";
            // 
            // B_Area
            // 
            this.B_Area.Font = new System.Drawing.Font("宋体", 14.2F);
            this.B_Area.Location = new System.Drawing.Point(1081, 21);
            this.B_Area.Margin = new System.Windows.Forms.Padding(2);
            this.B_Area.Name = "B_Area";
            this.B_Area.Size = new System.Drawing.Size(75, 40);
            this.B_Area.TabIndex = 111;
            this.B_Area.Text = "B区";
            this.B_Area.UseVisualStyleBackColor = true;
            this.B_Area.Click += new System.EventHandler(this.B_Area_Click);
            // 
            // A_Area
            // 
            this.A_Area.Font = new System.Drawing.Font("宋体", 14.2F);
            this.A_Area.Location = new System.Drawing.Point(730, 21);
            this.A_Area.Margin = new System.Windows.Forms.Padding(2);
            this.A_Area.Name = "A_Area";
            this.A_Area.Size = new System.Drawing.Size(75, 40);
            this.A_Area.TabIndex = 110;
            this.A_Area.Text = "A区";
            this.A_Area.UseVisualStyleBackColor = true;
            this.A_Area.Click += new System.EventHandler(this.A_Area_Click);
            // 
            // Qx_Bt
            // 
            this.Qx_Bt.Font = new System.Drawing.Font("宋体", 14.2F);
            this.Qx_Bt.Location = new System.Drawing.Point(812, 838);
            this.Qx_Bt.Margin = new System.Windows.Forms.Padding(2);
            this.Qx_Bt.Name = "Qx_Bt";
            this.Qx_Bt.Size = new System.Drawing.Size(112, 40);
            this.Qx_Bt.TabIndex = 166;
            this.Qx_Bt.Text = "取消";
            this.Qx_Bt.UseVisualStyleBackColor = true;
            this.Qx_Bt.Click += new System.EventHandler(this.Qx_Bt_Click);
            // 
            // DK_Back
            // 
            this.DK_Back.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DK_Back.Location = new System.Drawing.Point(49, 932);
            this.DK_Back.Margin = new System.Windows.Forms.Padding(2);
            this.DK_Back.Name = "DK_Back";
            this.DK_Back.Size = new System.Drawing.Size(112, 40);
            this.DK_Back.TabIndex = 167;
            this.DK_Back.Text = "返回";
            this.DK_Back.UseVisualStyleBackColor = true;
            this.DK_Back.Click += new System.EventHandler(this.DK_Back_Click);
            // 
            // DK_MainPage
            // 
            this.DK_MainPage.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DK_MainPage.Location = new System.Drawing.Point(1773, 932);
            this.DK_MainPage.Margin = new System.Windows.Forms.Padding(2);
            this.DK_MainPage.Name = "DK_MainPage";
            this.DK_MainPage.Size = new System.Drawing.Size(112, 40);
            this.DK_MainPage.TabIndex = 168;
            this.DK_MainPage.Text = "回首页";
            this.DK_MainPage.UseVisualStyleBackColor = true;
            this.DK_MainPage.Click += new System.EventHandler(this.DK_MainPage_Click);
            // 
            // DKXZ_ToRight
            // 
            this.DKXZ_ToRight.ForeColor = System.Drawing.Color.Black;
            this.DKXZ_ToRight.Image = global::BigPro.Properties.Resources.ToRight;
            this.DKXZ_ToRight.Location = new System.Drawing.Point(1856, 15);
            this.DKXZ_ToRight.Margin = new System.Windows.Forms.Padding(2);
            this.DKXZ_ToRight.Name = "DKXZ_ToRight";
            this.DKXZ_ToRight.Size = new System.Drawing.Size(50, 50);
            this.DKXZ_ToRight.TabIndex = 441;
            this.DKXZ_ToRight.UseVisualStyleBackColor = true;
            this.DKXZ_ToRight.Click += new System.EventHandler(this.DKXZ_ToRight_Click);
            // 
            // button56
            // 
            this.button56.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button56.Location = new System.Drawing.Point(1585, 26);
            this.button56.Margin = new System.Windows.Forms.Padding(2);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(112, 40);
            this.button56.TabIndex = 442;
            this.button56.Text = "复位报警";
            this.button56.UseVisualStyleBackColor = true;
            // 
            // button58
            // 
            this.button58.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button58.Location = new System.Drawing.Point(1773, 22);
            this.button58.Margin = new System.Windows.Forms.Padding(2);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(55, 44);
            this.button58.TabIndex = 444;
            this.button58.Text = "单控";
            this.button58.UseVisualStyleBackColor = true;
            // 
            // DKXZ_ToLeft
            // 
            this.DKXZ_ToLeft.ForeColor = System.Drawing.Color.Black;
            this.DKXZ_ToLeft.Image = global::BigPro.Properties.Resources.Toleft;
            this.DKXZ_ToLeft.Location = new System.Drawing.Point(11, 11);
            this.DKXZ_ToLeft.Margin = new System.Windows.Forms.Padding(2);
            this.DKXZ_ToLeft.Name = "DKXZ_ToLeft";
            this.DKXZ_ToLeft.Size = new System.Drawing.Size(50, 50);
            this.DKXZ_ToLeft.TabIndex = 445;
            this.DKXZ_ToLeft.UseVisualStyleBackColor = true;
            this.DKXZ_ToLeft.Click += new System.EventHandler(this.DKXZ_ToLeft_Click);
            // 
            // FenLei_Panel
            // 
            this.FenLei_Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FenLei_Panel.Controls.Add(this.DkXz_Ds);
            this.FenLei_Panel.Controls.Add(this.DkXz_DsDw);
            this.FenLei_Panel.Controls.Add(this.DkXz_TsHs);
            this.FenLei_Panel.Controls.Add(this.DkXz_Ts);
            this.FenLei_Panel.Location = new System.Drawing.Point(547, 665);
            this.FenLei_Panel.Name = "FenLei_Panel";
            this.FenLei_Panel.Size = new System.Drawing.Size(816, 66);
            this.FenLei_Panel.TabIndex = 446;
            // 
            // DkXz_Ds
            // 
            this.DkXz_Ds.Font = new System.Drawing.Font("宋体", 14.2F);
            this.DkXz_Ds.Location = new System.Drawing.Point(654, 12);
            this.DkXz_Ds.Margin = new System.Windows.Forms.Padding(2);
            this.DkXz_Ds.Name = "DkXz_Ds";
            this.DkXz_Ds.Size = new System.Drawing.Size(112, 40);
            this.DkXz_Ds.TabIndex = 173;
            this.DkXz_Ds.Text = "定速设备";
            this.DkXz_Ds.UseVisualStyleBackColor = true;
            this.DkXz_Ds.Click += new System.EventHandler(this.DkXz_Ds_Click);
            // 
            // DkXz_DsDw
            // 
            this.DkXz_DsDw.Font = new System.Drawing.Font("宋体", 14.2F);
            this.DkXz_DsDw.Location = new System.Drawing.Point(440, 12);
            this.DkXz_DsDw.Margin = new System.Windows.Forms.Padding(2);
            this.DkXz_DsDw.Name = "DkXz_DsDw";
            this.DkXz_DsDw.Size = new System.Drawing.Size(142, 40);
            this.DkXz_DsDw.TabIndex = 172;
            this.DkXz_DsDw.Text = "定速定位设备";
            this.DkXz_DsDw.UseVisualStyleBackColor = true;
            this.DkXz_DsDw.Click += new System.EventHandler(this.DkXz_DsDw_Click);
            // 
            // DkXz_TsHs
            // 
            this.DkXz_TsHs.Font = new System.Drawing.Font("宋体", 14.2F);
            this.DkXz_TsHs.Location = new System.Drawing.Point(232, 12);
            this.DkXz_TsHs.Margin = new System.Windows.Forms.Padding(2);
            this.DkXz_TsHs.Name = "DkXz_TsHs";
            this.DkXz_TsHs.Size = new System.Drawing.Size(136, 40);
            this.DkXz_TsHs.TabIndex = 171;
            this.DkXz_TsHs.Text = "调速互锁设备";
            this.DkXz_TsHs.UseVisualStyleBackColor = true;
            this.DkXz_TsHs.Click += new System.EventHandler(this.DkXz_TsHs_Click);
            // 
            // DkXz_Ts
            // 
            this.DkXz_Ts.Font = new System.Drawing.Font("宋体", 14.2F);
            this.DkXz_Ts.Location = new System.Drawing.Point(48, 12);
            this.DkXz_Ts.Margin = new System.Windows.Forms.Padding(2);
            this.DkXz_Ts.Name = "DkXz_Ts";
            this.DkXz_Ts.Size = new System.Drawing.Size(112, 40);
            this.DkXz_Ts.TabIndex = 170;
            this.DkXz_Ts.Text = "调速设备";
            this.DkXz_Ts.UseVisualStyleBackColor = true;
            this.DkXz_Ts.Click += new System.EventHandler(this.DkXz_Ts_Click);
            // 
            // button25
            // 
            this.button25.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button25.Location = new System.Drawing.Point(1714, 22);
            this.button25.Margin = new System.Windows.Forms.Padding(2);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(55, 44);
            this.button25.TabIndex = 447;
            this.button25.Text = "程控";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // dankong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.FenLei_Panel);
            this.Controls.Add(this.DKXZ_ToLeft);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.DKXZ_ToRight);
            this.Controls.Add(this.DK_MainPage);
            this.Controls.Add(this.DK_Back);
            this.Controls.Add(this.Qx_Bt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.To_DkZt);
            this.Controls.Add(this.DkAll_Cancel);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.B_Area);
            this.Controls.Add(this.A_Area);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "dankong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "dankong";
            this.Load += new System.EventHandler(this.dankong_Load);
            this.FenLei_Panel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button To_DkZt;
        private System.Windows.Forms.Button DkAll_Cancel;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button B_Area;
        private System.Windows.Forms.Button A_Area;
        private System.Windows.Forms.Button Qx_Bt;
        private System.Windows.Forms.Button DK_Back;
        private System.Windows.Forms.Button DK_MainPage;
        private System.Windows.Forms.Button DKXZ_ToRight;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button DKXZ_ToLeft;
        private System.Windows.Forms.Panel FenLei_Panel;
        private System.Windows.Forms.Button DkXz_Ds;
        private System.Windows.Forms.Button DkXz_DsDw;
        private System.Windows.Forms.Button DkXz_TsHs;
        private System.Windows.Forms.Button DkXz_Ts;
        private System.Windows.Forms.Button button25;
    }
}