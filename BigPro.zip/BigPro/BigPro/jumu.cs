﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Text.RegularExpressions;
using System.Linq;

namespace BigPro
{
    public partial class jumu : Form
    {
        private static int ChangCiCount = 0;
        private static string NaGeJuMu;
        private static int[] ChangCiJiLu = new int[41];
        private static string[] ChangCiYingShe;
        private static bool flag = false;
        private static int multidelcount = 0;
        private static int[] delfalg=new int[42];
        public DBB1 dBB1;
        public jumu(DBB1 dbb1)
        {
            dBB1 = dbb1;
            InitializeComponent();
        }
        //Write file with steamwrite
        static void WriteWS(string filePath,string writestr)
        {
            FileStream fs = new FileStream(filePath, FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            try
            {
                sw.WriteLine(writestr);
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine("Writing has been completed");
            }
            catch (IOException e)
            {
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine(e.ToString());
            }
        }
        

        private void jumu_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            if (File.Exists("jumu.txt"))
            {
                List<string> lines = new List<string>(File.ReadAllLines("jumu.txt"));
                foreach (string s in lines)
                {
                    JuMuList.Items.Add(s);
                }

                if (JuMuList.Items.Count!=0)
                {
                    JuMuMc.Text = JuMuList.Items[0].ToString();
                }
            }
            
        }

        private void button67_Click(object sender, EventArgs e)
        {

        }

        private void button71_Click(object sender, EventArgs e)
        {

            this.Close();

        }

        private void button10_Click(object sender, EventArgs e)
        {

            this.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void button55_Click(object sender, EventArgs e)
        {
            new changjing().Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            new main().Show();
            this.Close();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            new main().Show();
            this.Close();
        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }


        private void button71_Click_1(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入新添加的剧目", "剧目添加", "剧目名称", -1, -1);
            if (str != "剧目名称" && str != "") 
            {
                if (JuMuList.Items.IndexOf(str) == -1)
                {
                    // int count = JuMuList.Items.Count + 1;
                    //  JuMuList.Items.Add(count.ToString() + '.' + str);
                    JuMuList.Items.Add(str);
                    WriteWS("jumu.txt", str);
                }
                else
                {
                    MessageBox.Show("该称剧目已经存在!!!");
                }

            }
            else if(str== "剧目名称")
            {
                MessageBox.Show("请输入剧目名称！");
            }
            else
            {
                MessageBox.Show("剧目名称不能为空!");
            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {   
            if (JuMuList.SelectedIndex == -1)
            {
                return;
            }
            else
            {
                ChangCiCount = 0;
                InvisibleCC();
                JuMuMc.Text = JuMuList.Items[JuMuList.SelectedIndex].ToString();
                NaGeJuMu= JuMuList.Items[JuMuList.SelectedIndex].ToString();
                if (File.Exists("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt"))
                {
                    ChangCiCount = readFileLines("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt");
                    Console.WriteLine(NaGeJuMu + "###" + ChangCiCount);
                    LaZCC.Text = ChangCiCount.ToString();
                    List<string> lines = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt"));

                    string name = "" + NaGeJuMu + "\\" + NaGeJuMu + ".txt";
                    var newl = File.ReadAllLines(name).Where(arg => !string.IsNullOrWhiteSpace(arg));
                    File.WriteAllLines("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt", newl);

                    string name2 = "" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt";
                    var newl2= File.ReadAllLines(name2).Where(arg => !string.IsNullOrWhiteSpace(arg));
                    File.WriteAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt", newl2);
                    int i = 0;
                    foreach (string s in lines)
                    {
                        if (s != "")
                        {
                                ChangCiJiLu[i] = int.Parse(s.Substring(3));
                            
                            i++;
                        }
                    }
                    //  Console.WriteLine(ChangCiJiLu[2]);
                    for (int j = 0; j < ChangCiCount; j++)
                    {
                        showChangCi(ChangCiJiLu[j]);
                    }
                    List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
                    ChangCiYingShe = ys.ToArray();
                    for (int k = 0; k < ChangCiYingShe.Length; k++)
                    {
                        Console.WriteLine(ChangCiYingShe[k] + " ");
                    }

                }

               
            }
            JuMuList.SelectedIndex = -1;

        }

        private void button6_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入要删除的剧目名称", "剧目删除", "剧目名称",-1, -1);
            if (str != "")
            {
                if (str != "剧目名称")
                {
                    if (JuMuList.Items.IndexOf(str) != -1)
                    {
                        Console.WriteLine("FFFF" + JuMuList.Items.IndexOf(str));
                        int index = JuMuList.Items.IndexOf(str);
                        string jumudel = JuMuList.Items[index].ToString();
                        JuMuList.Items.RemoveAt(index);
                        List<string> lines = new List<string>(File.ReadAllLines("jumu.txt"));
                        lines.RemoveAt(index);
                        File.WriteAllLines("jumu.txt", lines.ToArray());
                        if (Directory.Exists("" + jumudel))
                        { Directory.Delete("" + jumudel, true); }
                        if (JuMuList.Items.Count != 0)
                        {
                            JuMuMc.Text = JuMuList.Items[0].ToString();
                            JuMuList.SetSelected(0, true);
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("输入剧目不存在!!!");
                    }


                }
                else
                {
                    
                    MessageBox.Show("请输入剧目名称!!!");  
                }
            }
                else {
                    MessageBox.Show("剧目名称不能为空!!!");
                }
            

        }

        private void CC24_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次24";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[23];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void button56_Click(object sender, EventArgs e)
        {
            //   Console.WriteLine("CCCCCCCCCCCount" + ChangCiCount);
            //flag = false;
            //ChangCiCount++;
            //Console.WriteLine("CCCCCCCCCCCount" + ChangCiCount);

            //if (ChangCiCount <= 41)
            //{   for(int i = 0; i <delfalg.Length; i++)
            //    {
            //        if (delfalg[i]==1)
            //        {
            //            showChangCi(i+1);
            //            delfalg[i] = 0;
            //           // Console.WriteLine("FAFAFAFAFAFAFA" +i+":" + delfalg[i]);
            //            flag = true;
            //            int m = ChangCiCount;
            //           // Console.WriteLine("RERERERERE" + "CC" + m);
            //            if (!Directory.Exists("" +NaGeJuMu + "\\" + "CC"+m))
            //            {
            //                Directory.CreateDirectory("" + NaGeJuMu + "\\" + "CC" + m);
            //            }
            //            List<string> lines = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            //            lines[i] = m.ToString();
            //            File.WriteAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt", lines.ToArray());
            //            MessageBox.Show("添加成功Flag");
            //            break;
            //        }
            //    }
            //    if (flag == false)
            //    {
            //        showChangCi(ChangCiCount);
            //        if (!Directory.Exists("" + NaGeJuMu))
            //        {
            //            Directory.CreateDirectory("" + NaGeJuMu);
            //        }

            //        WriteWS("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt", "场次:" + ChangCiCount);
            //        WriteWS("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt", ChangCiCount.ToString());

            //        MessageBox.Show("添加成功！");
            //    }
            //    List<string> line = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt"));
            //    for (int i = 0; i < ChangCiCount; i++)
            //    { int j = i + 1;
            //        line[i] = "场次:" +j ;
            //    }
            //    File.WriteAllLines("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt", line.ToArray());
            //}
            //else
            //{
            //    ChangCiCount--;
            //    MessageBox.Show("超出场次添加限制！");
            //}
            //if (!Directory.Exists("" + NaGeJuMu + "\\" + "CC" + ChangCiCount + "\\"))
            //{
            //    Directory.CreateDirectory("" + NaGeJuMu + "\\" + "CC" + ChangCiCount + "\\");
            //}
            ChangCiCount++;
            if (ChangCiCount <= 41)
            {
                showChangCi(ChangCiCount);
                if (!Directory.Exists("" + NaGeJuMu + "\\" + "CC" + ChangCiCount + "\\"))
                {
                    Directory.CreateDirectory("" + NaGeJuMu + "\\" + "CC" + ChangCiCount + "\\");
                }
                WriteWS("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt", "场次:" + ChangCiCount);
                WriteWS("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt", ChangCiCount.ToString());
                MessageBox.Show("添加成功！");

            }
            else
            {
                MessageBox.Show("超出场次添加限制！");
            }

        }

        private void CC5_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次5";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[4];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC6_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次6";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[5];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入要删除的场次编号", "场次删除", "场次编号", -1, -1);
            int t = ChangCiCount;
            if (str != "")
            {
                if (str != "场次编号")
                {
                    if (IsNumber(str))
                    {
                        int bianhao = int.Parse(str);
                        if (bianhao < 0 || bianhao > ChangCiCount)
                        {
                            MessageBox.Show("场次编号不合法！请重新输入");
                        }
                        else
                        {
                            if (CheckChangCi(bianhao))
                            {
                                DelChangCi(ChangCiCount);
                                ChangCiCount--;
                               // DelChangCi(bianhao);
                                List<string> lines = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt"));
                                bianhao--;
                                //lines[bianhao] = " ";
                                for (int i = bianhao + 1; i < lines.Count; i++)
                                {
                                    //  Console.WriteLine("UUUUUUu"+lines[i].Substring(1));
                                    int m = int.Parse(lines[i].Substring(3)) - 1;
                                    lines[i] = "场次:" + m.ToString();
                                }
                                lines.RemoveAt(bianhao);
                                File.WriteAllLines("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt", lines.ToArray());
                                List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
                                //ys[bianhao] = " ";
                                for (int i = bianhao + 1; i < ys.Count; i++)
                                {
                                    int m = int.Parse(ys[i]) - 1;
                                    ys[i] = m.ToString();
                                }
                                ys.RemoveAt(bianhao);
                                //delfalg[bianhao] = 1;
                                File.WriteAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt", ys.ToArray());
                                int k = bianhao + 1 - multidelcount;
                                string del = "CC" + k;
                                Console.WriteLine("@@@@@@@@" + t);
                                if (Directory.Exists("" + NaGeJuMu + "\\" + del))
                                {
                                    Directory.Delete("" + NaGeJuMu + "\\" + del, true);
                                }
                                for (int i = k + 1; i < t + 1; i++)
                                {
                                    int j = i - 1;
                                    if (Directory.Exists("" + NaGeJuMu + "\\" + "CC" + i))
                                    {
                                        Directory.Move("" + NaGeJuMu + "\\" + "CC" + i, "" + NaGeJuMu + "\\" + "CC" + j);
                                        if (File.Exists("" + NaGeJuMu + "\\" + "CC" + j + "\\" + "CC" + i + ".txt"))
                                        {
                                            File.Move("" + NaGeJuMu + "\\" + "CC" + j + "\\" + "CC" + i + ".txt", "" + NaGeJuMu + "\\" + "CC" + j + "\\" + "CC" + j + ".txt");
                                        }
                                    }
                                }
                                MessageBox.Show("删除成功！");
                                multidelcount++;
                            }
                            else
                            {
                                MessageBox.Show("该场次已删除！");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("输入的不是数字!!!");
                    }
                }
                else
                {
                    MessageBox.Show("请输入场次编号!!");
                }
            }
            else
            {
                MessageBox.Show("场次编号不能为空!!!");
            }

        }

        private void CC3_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次3";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[2];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC4_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次4";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[3];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC7_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次7";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[6];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC8_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次8";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[7];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC9_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次9";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[8];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC10_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次10";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[9];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC11_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次11";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[10];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC12_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次12";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[11];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC13_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次13";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[12];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC14_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次14";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[13];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC15_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次15";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[14];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC16_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次16";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[15];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC17_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次17";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[16];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC18_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次18";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[17];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC19_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次19";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[18];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC20_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次20";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[19];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC21_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次21";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[20];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC22_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次22";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[21];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC23_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次23";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[22];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC25_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次25";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[24];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC26_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次26";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[25];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC27_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次27";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[26];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC28_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次28";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[27];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC29_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次29";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[28];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC30_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次30";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[29];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC31_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次31";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[30];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC32_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次32";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[31];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC33_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次33";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[32];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC34_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次34";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[33];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC35_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次35";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[34];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC36_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次36";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[35];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC37_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次37";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[36];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC38_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次38";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[37];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC39_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次39";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[38];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC40_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次40";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[39];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC41_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次41";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[40];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }

        private void CC1_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次1";
        }

        private void CC2_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次2";
        }

        private void CC3_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次3";
        }

        private void CC4_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次4";
        }

        private void CC5_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次5";
        }

        private void CC6_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次6";
        }

        private void CC7_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次7";
        }

        private void CC8_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次8";
        }

        private void CC9_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次9";
        }

        private void CC10_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次10";
        }

        private void CC11_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次11";
        }

        private void CC12_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次12";
        }

        private void CC13_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次13";
        }

        private void CC14_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次14";
        }

        private void CC15_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次15";
        }

        private void CC16_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次16";
        }

        private void CC17_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次17";
        }

        private void CC18_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次18";
        }

        private void CC19_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次19";
        }

        private void CC20_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次20";
        }

        private void CC21_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次21";
        }

        private void CC22_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次22";
        }

        private void CC23_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次23";
        }

        private void CC24_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次24";
        }

        private void CC25_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次25";
        }

        private void CC26_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次26";
        }

        private void CC27_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次27";
        }

        private void CC28_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次28";
        }

        private void CC29_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次29";
        }

        private void CC30_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次30";
        }

        private void CC31_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次31";
        }

        private void CC32_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次32";
        }

        private void CC33_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次33";
        }

        private void CC34_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次34";
        }

        private void CC35_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次35";
        }

        private void CC36_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次36";
        }

        private void CC37_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次37";
        }

        private void CC38_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次38";
        }

        private void CC39_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次39";
        }

        private void CC40_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次40";
        }

        private void CC41_MouseHover(object sender, EventArgs e)
        {
            LaDQCC.Text = "场次41";
        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入在哪个场次之后插入", "场次插入", "在哪个场次之后插入", -1, -1);
            int bianhao = int.Parse(str);
            if (bianhao >= 0 && bianhao <= ChangCiCount)
            {
                ChangCiCount++;
                if (ChangCiCount <= 41)
                {
                    showChangCi(ChangCiCount);
                    WriteWS("" + NaGeJuMu + "\\" + NaGeJuMu + ".txt", "场次:" + ChangCiCount);
                    List<string> lines = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
                    lines.Insert(bianhao, ChangCiCount.ToString());
                    File.WriteAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt", lines.ToArray());
                    MessageBox.Show("插入成功！");
                    if (!Directory.Exists("" + NaGeJuMu + "\\" + "CC" + ChangCiCount + "\\"))
                    {
                        Directory.CreateDirectory("" + NaGeJuMu + "\\" + "CC" + ChangCiCount + "\\");
                    }
                }
                else
                {
                    ChangCiCount--;
                    MessageBox.Show("超过最大场次限制！");
                }
                
            }
            else if (bianhao < 0)
            {
                MessageBox.Show("编号不合法！");
            }
            else if (bianhao > ChangCiCount)
            {
                MessageBox.Show("超过当前最大场次限制！");
            }
           
        }

        private void JuMuMc_Click(object sender, EventArgs e)
        {

        }

        public static int readFileLines(string path)  //这里的参数是txt所在路径
        {
            int lines = 0;  //用来统计txt行数
            FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamReader sr = new StreamReader(fs);
            while (sr.ReadLine() != null)
            {
           
                    lines++;
            }

            fs.Close();
            sr.Close();

            return lines;

        }

        private void showChangCi(int ChangCiNum)
        {
            switch (ChangCiNum)
            {
                case 0:
                    break;
                case 1:
                    CC1.Text = "场次1";
                    CC1.Visible = true;
                    break;
                case 2:
                    CC2.Text = "场次2";
                    CC2.Visible = true;
                    break;
                case 3:
                    CC3.Text = "场次3";
                    CC3.Visible = true;
                    break;
                case 4:
                    CC4.Text = "场次4";
                    CC4.Visible = true;
                    break;
                case 5:
                    CC5.Text = "场次5";
                    CC5.Visible = true;
                    break;
                case 6:
                    CC6.Text = "场次6";
                    CC6.Visible = true;
                    break;
                case 7:
                    CC7.Text = "场次7";
                    CC7.Visible = true;
                    break;
                case 8:
                    CC8.Text = "场次8";
                    CC8.Visible = true;
                    break;
                case 9:
                    CC9.Text = "场次9";
                    CC9.Visible = true;
                    break;
                case 10:
                    CC10.Text = "场次10";
                    CC10.Visible = true;
                    break;
                case 11:
                    CC11.Text = "场次11";
                    CC11.Visible = true;
                    break;
                case 12:
                    CC12.Text = "场次12";
                    CC12.Visible = true;
                    break;
                case 13:
                    CC13.Text = "场次13";
                    CC13.Visible = true;
                    break;
                case 14:
                    CC14.Text = "场次14";
                    CC14.Visible = true;
                    break;
                case 15:
                    CC15.Text = "场次15";
                    CC15.Visible = true;
                    break;
                case 16:
                    CC16.Text = "场次16";
                    CC16.Visible = true;
                    break;
                case 17:
                    CC17.Text = "场次17";
                    CC17.Visible = true;
                    break;
                case 18:
                    CC18.Text = "场次18";
                    CC18.Visible = true;
                    break;
                case 19:
                    CC19.Text = "场次19";
                    CC19.Visible = true;
                    break;
                case 20:
                    CC20.Text = "场次20";
                    CC20.Visible = true;
                    break;
                case 21:
                    CC21.Text = "场次21";
                    CC21.Visible = true;
                    break;
                case 22:
                    CC22.Text = "场次22";
                    CC22.Visible = true;
                    break;
                case 23:
                    CC23.Text = "场次23";
                    CC23.Visible = true;
                    break;
                case 24:
                    CC24.Text = "场次24";
                    CC24.Visible = true;
                    break;
                case 25:
                    CC25.Text = "场次25";
                    CC25.Visible = true;
                    break;
                case 26:
                    CC26.Text = "场次26";
                    CC26.Visible = true;
                    break;
                case 27:
                    CC27.Text = "场次27";
                    CC27.Visible = true;
                    break;
                case 28:
                    CC28.Text = "场次28";
                    CC28.Visible = true;
                    break;
                case 29:
                    CC29.Text = "场次29";
                    CC29.Visible = true;
                    break;
                case 30:
                    CC30.Text = "场次30";
                    CC30.Visible = true;
                    break;
                case 31:
                    CC31.Text = "场次31";
                    CC31.Visible = true;
                    break;
                case 32:
                    CC32.Text = "场次32";
                    CC32.Visible = true;
                    break;
                case 33:
                    CC33.Text = "场次33";
                    CC33.Visible = true;
                    break;
                case 34:
                    CC34.Text = "场次34";
                    CC34.Visible = true;
                    break;
                case 35:
                    CC35.Text = "场次35";
                    CC35.Visible = true;
                    break;
                case 36:
                    CC36.Text = "场次36";
                    CC36.Visible = true;
                    break;
                case 37:
                    CC37.Text = "场次37";
                    CC37.Visible = true;
                    break;
                case 38:
                    CC38.Text = "场次38";
                    CC38.Visible = true;
                    break;
                case 39:
                    CC39.Text = "场次39";
                    CC39.Visible = true;
                    break;
                case 40:
                    CC40.Text = "场次40";
                    CC40.Visible = true;
                    break;
                case 41:
                    CC41.Text = "场次41";
                    CC41.Visible = true;
                    break;
            }
        }
        private void InvisibleCC()
        {
            CC1.Visible = false;      
            CC2.Visible = false;         
            CC3.Visible = false;          
            CC4.Visible = false;          
            CC5.Visible = false;            
            CC6.Visible = false;         
            CC7.Visible = false;           
            CC8.Visible = false;        
            CC9.Visible = false;          
            CC10.Visible = false;          
            CC11.Visible = false;        
            CC12.Visible = false;       
            CC13.Visible = false;     
            CC14.Visible = false;         
            CC15.Visible = false;          
            CC16.Visible = false;          
            CC17.Visible = false;         
            CC18.Visible = false;          
            CC19.Visible = false;          
            CC20.Visible = false;     
            CC21.Visible = false;       
            CC22.Visible = false;      
            CC23.Visible = false;           
            CC24.Visible = false;         
            CC25.Visible = false;        
            CC26.Visible = false;            
            CC27.Visible = false;            
            CC28.Visible = false;        
            CC29.Visible = false;          
            CC30.Visible = false;           
            CC31.Visible = false;           
            CC32.Visible = false;            
            CC33.Visible = false;           
            CC34.Visible = false;        
            CC35.Visible = false;    
            CC36.Visible = false;
            CC37.Visible = false;
            CC38.Visible = false;
            CC39.Visible = false;
            CC40.Visible = false;
            CC41.Visible = false;
           
        }
        private void DelChangCi(int delnum)
        {
            switch (delnum)
            {
                case 1:
                    //CC1.Dispose();
                    CC1.Visible = false;
                    break;
                case 2:
                    // CC2.Dispose();
                    CC2.Visible = false;
                    break;
                case 3:
                    //  CC3.Dispose();
                    CC3.Visible = false;
                    break;
                case 4:
                    //  CC4.Dispose();
                    CC4.Visible = false;
                    break;
                case 5:
                    //  CC5.Dispose();
                    CC5.Visible = false;
                    break;
                case 6:
                    //  CC6.Dispose();
                    CC6.Visible = false;
                    break;
                case 7:
                    //  CC7.Dispose();
                    CC7.Visible = false;
                    break;
                case 8:
                    //  CC8.Dispose();
                    CC8.Visible = false;
                    break;
                case 9:
                    //  CC9.Dispose();
                    CC9.Visible = false;
                    break;
                case 10:
                    //  CC10.Dispose();
                    CC10.Visible = false;
                    break;
                case 11:
                    // CC11.Dispose();
                    CC11.Visible = false;
                    break;
                case 12:
                  //  CC12.Dispose();
                    CC12.Visible = false;
                    break;
                case 13:
                    //   CC13.Dispose();
                    CC13.Visible = false;
                    break;
                case 14:
                    //  CC14.Dispose();
                    CC14.Visible = false;
                    break;
                case 15:
                    //  CC15.Dispose();
                    CC15.Visible = false;
                    break;
                case 16:
                    //  CC16.Dispose();
                    CC16.Visible = false;
                    break;
                case 17:
                    // CC17.Dispose();
                    CC17.Visible = false;
                    break;
                case 18:
                    //  CC18.Dispose();
                    CC18.Visible = false;
                    break;
                case 19:
                    //  CC19.Dispose();
                    CC19.Visible = false;
                    break;
                case 20:
                    //   CC20.Dispose();
                    CC20.Visible = false;
                    break;
                case 21:
                    //  CC21.Dispose();
                    CC21.Visible = false;
                    break;
                case 22:
                    //  CC22.Dispose();
                    CC22.Visible = false;
                    break;
                case 23:
                    //   CC23.Dispose();
                    CC23.Visible = false;
                    break;
                case 24:
                    //   CC24.Dispose();
                    CC24.Visible = false;
                    break;
                case 25:
                    //  CC25.Dispose();
                    CC25.Visible = false;
                    break;
                case 26:
                    //   CC26.Dispose();
                    CC26.Visible = false;
                    break;
                case 27:
                    //  CC27.Dispose();
                    CC27.Visible = false;
                    break;
                case 28:
                    //  CC28.Dispose();
                    CC28.Visible = false;
                    break;
                case 29:
                    //   CC29.Dispose();
                    CC29.Visible = false;
                    break;
                case 30:
                    //   CC30.Dispose();
                    CC30.Visible = false;
                    break;
                case 31:
                    //   CC31.Dispose();
                    CC31.Visible = false;
                    break;
                case 32:
                    //   CC32.Dispose();
                    CC32.Visible = false;
                    break;
                case 33:
                    //   CC33.Dispose();
                    CC33.Visible = false;
                    break;
                case 34:
                    //   CC34.Dispose();
                    CC34.Visible = false;
                    break;
                case 35:
                    //   CC35.Dispose();
                    CC35.Visible = false;
                    break;
                case 36:
                    //   CC36.Dispose();
                    CC36.Visible = false;
                    break;
                case 37:
                    //   CC37.Dispose();
                    CC37.Visible = false;
                    break;
                case 38:
                    //   CC38.Dispose();
                    CC38.Visible = false;
                    break;
                case 39:
                    //   CC39.Dispose();
                    CC39.Visible = false;
                    break;
                case 40:
                    //   CC40.Dispose();
                    CC40.Visible = false;
                    break;
                case 41:
                    //   CC41.Dispose();
                    CC41.Visible = false;
                    break;
            }
        }

        private bool CheckChangCi(int checknum)
        {
            switch (checknum)
            {
                case 1:
                    if (CC1.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 2:
                    if (CC2.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 3:
                    if (CC3.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 4:
                    if (CC4.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 5:
                    if (CC5.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 6:
                    if (CC6.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 7:
                    if (CC7.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 8:
                    if (CC8.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 9:
                    if (CC9.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 10:
                    if (CC10.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 11:
                    if (CC11.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 12:
                    if (CC12.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 13:
                    if (CC13.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 14:
                    if (CC14.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 15:
                    if (CC15.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 16:
                    if (CC16.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 17:
                    if (CC17.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 18:
                    if (CC18.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 19:
                    if (CC19.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 20:
                    if (CC20.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 21:
                    if (CC21.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 22:
                    if (CC22.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 23:
                    if (CC23.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 24:
                    if (CC24.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 25:
                    if (CC25.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 26:
                    if (CC26.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 27:
                    if (CC27.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 28:
                    if (CC28.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 29:
                    if (CC29.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 30:
                    if (CC30.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 31:
                    if (CC31.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 32:
                    if (CC32.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 33:
                    if (CC33.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 34:
                    if (CC34.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 35:
                    if (CC35.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 36:
                    if (CC36.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 37:
                    if (CC37.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 38:
                    if (CC38.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 39:
                    if (CC39.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 40:
                    if (CC40.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case 41:
                    if (CC41.Visible == true)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
            }
            return false;
        }
        private void CC1_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次1";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC"+ChangCiYingShe[0];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }


        private void CC2_Click(object sender, EventArgs e)
        {
            List<string> ys = new List<string>(File.ReadAllLines("" + NaGeJuMu + "\\" + "YingShe" + NaGeJuMu + ".txt"));
            ChangCiYingShe = ys.ToArray();
            ChangCiSheZhiGlobalData.NageJuMu = NaGeJuMu;
            ChangCiSheZhiGlobalData.YingSheQianChangCi = "场次2";
            ChangCiSheZhiGlobalData.JuTiChangCi = "CC" + ChangCiYingShe[1];
            var frm = new _2changci(dBB1);
            frm.Show();
            this.Close();
        }
        public bool IsNumber(String strNumber)
        {
            Regex objNotNumberPattern = new Regex("[^0-9.-]");
            Regex objTwoDotPattern = new Regex("[0-9]*[.][0-9]*[.][0-9]*");
            Regex objTwoMinusPattern = new Regex("[0-9]*[-][0-9]*[-][0-9]*");
            String strValidRealPattern = "^([-]|[.]|[-.]|[0-9])[0-9]*[.]*[0-9]+$";
            String strValidIntegerPattern = "^([-]|[0-9])[0-9]*$";
            Regex objNumberPattern = new Regex("(" + strValidRealPattern + ")|(" + strValidIntegerPattern + ")");

            return !objNotNumberPattern.IsMatch(strNumber) &&
                !objTwoDotPattern.IsMatch(strNumber) &&
                !objTwoMinusPattern.IsMatch(strNumber) &&
                objNumberPattern.IsMatch(strNumber);
        }


    }





}
