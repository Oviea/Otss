﻿namespace BigPro
{
    partial class chengkongjieru
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.CK_Allow = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button133 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.JMC = new System.Windows.Forms.ComboBox();
            this.CCChoice = new System.Windows.Forms.ComboBox();
            this.ToLeft = new System.Windows.Forms.Button();
            this.ToRight = new System.Windows.Forms.Button();
            this.CK_Forbid = new System.Windows.Forms.Button();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 20F);
            this.label1.Location = new System.Drawing.Point(871, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "程控(场景介入)";
            // 
            // CK_Allow
            // 
            this.CK_Allow.Font = new System.Drawing.Font("宋体", 20F);
            this.CK_Allow.Location = new System.Drawing.Point(703, 9);
            this.CK_Allow.Margin = new System.Windows.Forms.Padding(2);
            this.CK_Allow.Name = "CK_Allow";
            this.CK_Allow.Size = new System.Drawing.Size(150, 50);
            this.CK_Allow.TabIndex = 1;
            this.CK_Allow.Text = "允许";
            this.CK_Allow.UseVisualStyleBackColor = true;
            this.CK_Allow.Click += new System.EventHandler(this.CK_Allow_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("宋体", 20F);
            this.button2.Location = new System.Drawing.Point(1626, 9);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 50);
            this.button2.TabIndex = 1;
            this.button2.Text = "复位报警";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.button83);
            this.panel17.Controls.Add(this.button84);
            this.panel17.Controls.Add(this.button85);
            this.panel17.Controls.Add(this.button86);
            this.panel17.Controls.Add(this.button87);
            this.panel17.Location = new System.Drawing.Point(-198, 432);
            this.panel17.Margin = new System.Windows.Forms.Padding(2);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(188, 140);
            this.panel17.TabIndex = 11;
            // 
            // button83
            // 
            this.button83.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button83.Location = new System.Drawing.Point(96, 90);
            this.button83.Margin = new System.Windows.Forms.Padding(2);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(82, 36);
            this.button83.TabIndex = 4;
            this.button83.Text = "单控";
            this.button83.UseVisualStyleBackColor = true;
            // 
            // button84
            // 
            this.button84.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button84.Location = new System.Drawing.Point(9, 90);
            this.button84.Margin = new System.Windows.Forms.Padding(2);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(82, 36);
            this.button84.TabIndex = 3;
            this.button84.Text = "速度";
            this.button84.UseVisualStyleBackColor = true;
            // 
            // button85
            // 
            this.button85.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button85.Location = new System.Drawing.Point(96, 50);
            this.button85.Margin = new System.Windows.Forms.Padding(2);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(82, 36);
            this.button85.TabIndex = 2;
            this.button85.Text = "暂停";
            this.button85.UseVisualStyleBackColor = true;
            // 
            // button86
            // 
            this.button86.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button86.Location = new System.Drawing.Point(9, 50);
            this.button86.Margin = new System.Windows.Forms.Padding(2);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(82, 36);
            this.button86.TabIndex = 1;
            this.button86.Text = "位置";
            this.button86.UseVisualStyleBackColor = true;
            // 
            // button87
            // 
            this.button87.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button87.Location = new System.Drawing.Point(9, 10);
            this.button87.Margin = new System.Windows.Forms.Padding(2);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(170, 35);
            this.button87.TabIndex = 0;
            this.button87.Text = "设备名";
            this.button87.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.button88);
            this.panel18.Controls.Add(this.button89);
            this.panel18.Controls.Add(this.button90);
            this.panel18.Controls.Add(this.button91);
            this.panel18.Controls.Add(this.button92);
            this.panel18.Location = new System.Drawing.Point(-434, 432);
            this.panel18.Margin = new System.Windows.Forms.Padding(2);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(188, 140);
            this.panel18.TabIndex = 6;
            // 
            // button88
            // 
            this.button88.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button88.Location = new System.Drawing.Point(96, 90);
            this.button88.Margin = new System.Windows.Forms.Padding(2);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(82, 36);
            this.button88.TabIndex = 4;
            this.button88.Text = "单控";
            this.button88.UseVisualStyleBackColor = true;
            // 
            // button89
            // 
            this.button89.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button89.Location = new System.Drawing.Point(9, 90);
            this.button89.Margin = new System.Windows.Forms.Padding(2);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(82, 36);
            this.button89.TabIndex = 3;
            this.button89.Text = "速度";
            this.button89.UseVisualStyleBackColor = true;
            // 
            // button90
            // 
            this.button90.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button90.Location = new System.Drawing.Point(96, 50);
            this.button90.Margin = new System.Windows.Forms.Padding(2);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(82, 36);
            this.button90.TabIndex = 2;
            this.button90.Text = "暂停";
            this.button90.UseVisualStyleBackColor = true;
            // 
            // button91
            // 
            this.button91.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button91.Location = new System.Drawing.Point(9, 50);
            this.button91.Margin = new System.Windows.Forms.Padding(2);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(82, 36);
            this.button91.TabIndex = 1;
            this.button91.Text = "位置";
            this.button91.UseVisualStyleBackColor = true;
            // 
            // button92
            // 
            this.button92.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button92.Location = new System.Drawing.Point(9, 10);
            this.button92.Margin = new System.Windows.Forms.Padding(2);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(170, 35);
            this.button92.TabIndex = 0;
            this.button92.Text = "设备名";
            this.button92.UseVisualStyleBackColor = true;
            // 
            // button133
            // 
            this.button133.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button133.Location = new System.Drawing.Point(45, 909);
            this.button133.Margin = new System.Windows.Forms.Padding(2);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(200, 70);
            this.button133.TabIndex = 15;
            this.button133.Text = "返回";
            this.button133.UseVisualStyleBackColor = true;
            this.button133.Click += new System.EventHandler(this.button133_Click);
            // 
            // button135
            // 
            this.button135.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button135.Location = new System.Drawing.Point(1672, 873);
            this.button135.Margin = new System.Windows.Forms.Padding(2);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(200, 70);
            this.button135.TabIndex = 17;
            this.button135.Text = "回首页";
            this.button135.UseVisualStyleBackColor = true;
            this.button135.Click += new System.EventHandler(this.button135_Click);
            // 
            // JMC
            // 
            this.JMC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.JMC.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.JMC.FormattingEnabled = true;
            this.JMC.Location = new System.Drawing.Point(713, 873);
            this.JMC.Margin = new System.Windows.Forms.Padding(2);
            this.JMC.Name = "JMC";
            this.JMC.Size = new System.Drawing.Size(151, 34);
            this.JMC.TabIndex = 59;
            this.JMC.SelectedIndexChanged += new System.EventHandler(this.JuMuChoice_SelectedIndexChanged);
            // 
            // CCChoice
            // 
            this.CCChoice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CCChoice.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCChoice.FormattingEnabled = true;
            this.CCChoice.Location = new System.Drawing.Point(892, 873);
            this.CCChoice.Margin = new System.Windows.Forms.Padding(2);
            this.CCChoice.Name = "CCChoice";
            this.CCChoice.Size = new System.Drawing.Size(151, 34);
            this.CCChoice.TabIndex = 60;
            this.CCChoice.SelectedIndexChanged += new System.EventHandler(this.CCChoice_SelectedIndexChanged_1);
            // 
            // ToLeft
            // 
            this.ToLeft.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ToLeft.Image = global::BigPro.Properties.Resources.Toleft;
            this.ToLeft.Location = new System.Drawing.Point(13, 9);
            this.ToLeft.Name = "ToLeft";
            this.ToLeft.Size = new System.Drawing.Size(50, 50);
            this.ToLeft.TabIndex = 62;
            this.ToLeft.UseVisualStyleBackColor = false;
            this.ToLeft.Click += new System.EventHandler(this.ToLeft_Click);
            // 
            // ToRight
            // 
            this.ToRight.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ToRight.Image = global::BigPro.Properties.Resources.ToRight;
            this.ToRight.Location = new System.Drawing.Point(1813, 9);
            this.ToRight.Name = "ToRight";
            this.ToRight.Size = new System.Drawing.Size(50, 50);
            this.ToRight.TabIndex = 63;
            this.ToRight.UseVisualStyleBackColor = false;
            this.ToRight.Click += new System.EventHandler(this.ToRight_Click);
            // 
            // CK_Forbid
            // 
            this.CK_Forbid.Font = new System.Drawing.Font("宋体", 20F);
            this.CK_Forbid.Location = new System.Drawing.Point(1077, 9);
            this.CK_Forbid.Margin = new System.Windows.Forms.Padding(2);
            this.CK_Forbid.Name = "CK_Forbid";
            this.CK_Forbid.Size = new System.Drawing.Size(150, 50);
            this.CK_Forbid.TabIndex = 64;
            this.CK_Forbid.Text = "禁止";
            this.CK_Forbid.UseVisualStyleBackColor = true;
            this.CK_Forbid.Click += new System.EventHandler(this.CK_Forbid_Click);
            // 
            // chengkongjieru
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1778, 1027);
            this.Controls.Add(this.CK_Forbid);
            this.Controls.Add(this.ToRight);
            this.Controls.Add(this.ToLeft);
            this.Controls.Add(this.CCChoice);
            this.Controls.Add(this.JMC);
            this.Controls.Add(this.button135);
            this.Controls.Add(this.button133);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel18);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.CK_Allow);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "chengkongjieru";
            this.Text = "chengkongjieru";
            this.Load += new System.EventHandler(this.chengkongjieru_Load);
            this.panel17.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button CK_Allow;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.ComboBox JMC;
        private System.Windows.Forms.ComboBox CCChoice;
        private System.Windows.Forms.Button ToLeft;
        private System.Windows.Forms.Button ToRight;
        private System.Windows.Forms.Button CK_Forbid;
    }
}