﻿namespace BigPro
{
    partial class bianpinqi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BPQ_Back2Main = new System.Windows.Forms.Button();
            this.BPQ_Back = new System.Windows.Forms.Button();
            this.BPQ_MiddleL = new System.Windows.Forms.Label();
            this.BPQ_TSTS = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label159 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label286 = new System.Windows.Forms.Label();
            this.BPQ_TXTS = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.BPQ_TR = new System.Windows.Forms.Button();
            this.BPQ_ToL = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button2.Location = new System.Drawing.Point(1697, 28);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 40);
            this.button2.TabIndex = 1034;
            this.button2.Text = "复位";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label34.Location = new System.Drawing.Point(156, 268);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(1700, 2);
            this.label34.TabIndex = 824;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(519, 242);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 0);
            this.label4.TabIndex = 819;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(235, 238);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(2, 30);
            this.label3.TabIndex = 815;
            // 
            // BPQ_Back2Main
            // 
            this.BPQ_Back2Main.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BPQ_Back2Main.Location = new System.Drawing.Point(1669, 893);
            this.BPQ_Back2Main.Margin = new System.Windows.Forms.Padding(2);
            this.BPQ_Back2Main.Name = "BPQ_Back2Main";
            this.BPQ_Back2Main.Size = new System.Drawing.Size(200, 70);
            this.BPQ_Back2Main.TabIndex = 811;
            this.BPQ_Back2Main.Text = "回首页";
            this.BPQ_Back2Main.UseVisualStyleBackColor = true;
            this.BPQ_Back2Main.Click += new System.EventHandler(this.BPQ_Back2Main_Click);
            // 
            // BPQ_Back
            // 
            this.BPQ_Back.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BPQ_Back.Location = new System.Drawing.Point(70, 893);
            this.BPQ_Back.Margin = new System.Windows.Forms.Padding(2);
            this.BPQ_Back.Name = "BPQ_Back";
            this.BPQ_Back.Size = new System.Drawing.Size(200, 70);
            this.BPQ_Back.TabIndex = 810;
            this.BPQ_Back.Text = "返回";
            this.BPQ_Back.UseVisualStyleBackColor = true;
            this.BPQ_Back.Click += new System.EventHandler(this.BPQ_Back_Click);
            // 
            // BPQ_MiddleL
            // 
            this.BPQ_MiddleL.AutoSize = true;
            this.BPQ_MiddleL.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BPQ_MiddleL.Location = new System.Drawing.Point(869, 18);
            this.BPQ_MiddleL.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BPQ_MiddleL.Name = "BPQ_MiddleL";
            this.BPQ_MiddleL.Size = new System.Drawing.Size(178, 24);
            this.BPQ_MiddleL.TabIndex = 809;
            this.BPQ_MiddleL.Text = "台下变频器状态";
            // 
            // BPQ_TSTS
            // 
            this.BPQ_TSTS.BackColor = System.Drawing.Color.White;
            this.BPQ_TSTS.Font = new System.Drawing.Font("宋体", 14.2F);
            this.BPQ_TSTS.Location = new System.Drawing.Point(839, 820);
            this.BPQ_TSTS.Margin = new System.Windows.Forms.Padding(2);
            this.BPQ_TSTS.Name = "BPQ_TSTS";
            this.BPQ_TSTS.Size = new System.Drawing.Size(112, 40);
            this.BPQ_TSTS.TabIndex = 1043;
            this.BPQ_TSTS.Text = "台上调速";
            this.BPQ_TSTS.UseVisualStyleBackColor = false;
            this.BPQ_TSTS.Click += new System.EventHandler(this.BPQ_TSTS_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button3.Location = new System.Drawing.Point(757, 1104);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 40);
            this.button3.TabIndex = 1246;
            this.button3.Text = "台下调速";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button4.Location = new System.Drawing.Point(603, 1104);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(112, 40);
            this.button4.TabIndex = 1245;
            this.button4.Text = "台上调速";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label159
            // 
            this.label159.AutoSize = true;
            this.label159.Location = new System.Drawing.Point(1375, 1124);
            this.label159.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(0, 12);
            this.label159.TabIndex = 1244;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button5.Location = new System.Drawing.Point(1548, 1241);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(200, 70);
            this.button5.TabIndex = 1182;
            this.button5.Text = "返回";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button6.Location = new System.Drawing.Point(-92, 1241);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(200, 70);
            this.button6.TabIndex = 1181;
            this.button6.Text = "返回";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // label286
            // 
            this.label286.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label286.Location = new System.Drawing.Point(156, 270);
            this.label286.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label286.Name = "label286";
            this.label286.Size = new System.Drawing.Size(2, 435);
            this.label286.TabIndex = 1355;
            // 
            // BPQ_TXTS
            // 
            this.BPQ_TXTS.BackColor = System.Drawing.Color.White;
            this.BPQ_TXTS.Font = new System.Drawing.Font("宋体", 14.2F);
            this.BPQ_TXTS.Location = new System.Drawing.Point(976, 820);
            this.BPQ_TXTS.Margin = new System.Windows.Forms.Padding(2);
            this.BPQ_TXTS.Name = "BPQ_TXTS";
            this.BPQ_TXTS.Size = new System.Drawing.Size(112, 40);
            this.BPQ_TXTS.TabIndex = 1373;
            this.BPQ_TXTS.Text = "台下调速";
            this.BPQ_TXTS.UseVisualStyleBackColor = false;
            this.BPQ_TXTS.Click += new System.EventHandler(this.BPQ_TXTS_Click);
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label43.Location = new System.Drawing.Point(385, 240);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(2, 30);
            this.label43.TabIndex = 1385;
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label44.Location = new System.Drawing.Point(535, 240);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(2, 30);
            this.label44.TabIndex = 1386;
            // 
            // label45
            // 
            this.label45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label45.Location = new System.Drawing.Point(685, 240);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(2, 30);
            this.label45.TabIndex = 1387;
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label46.Location = new System.Drawing.Point(835, 240);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(2, 30);
            this.label46.TabIndex = 1388;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label47.Location = new System.Drawing.Point(985, 240);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(2, 30);
            this.label47.TabIndex = 1389;
            // 
            // label48
            // 
            this.label48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label48.Location = new System.Drawing.Point(1135, 240);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(2, 30);
            this.label48.TabIndex = 1390;
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label49.Location = new System.Drawing.Point(1285, 240);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(2, 30);
            this.label49.TabIndex = 1391;
            // 
            // label50
            // 
            this.label50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label50.Location = new System.Drawing.Point(1435, 240);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(2, 30);
            this.label50.TabIndex = 1392;
            // 
            // label51
            // 
            this.label51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label51.Location = new System.Drawing.Point(1585, 240);
            this.label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(2, 30);
            this.label51.TabIndex = 1393;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(1585, 455);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(2, 30);
            this.label1.TabIndex = 1404;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label37.Location = new System.Drawing.Point(1435, 455);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(2, 30);
            this.label37.TabIndex = 1403;
            // 
            // label52
            // 
            this.label52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label52.Location = new System.Drawing.Point(1285, 455);
            this.label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(2, 30);
            this.label52.TabIndex = 1402;
            // 
            // label53
            // 
            this.label53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label53.Location = new System.Drawing.Point(1135, 455);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(2, 30);
            this.label53.TabIndex = 1401;
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label54.Location = new System.Drawing.Point(985, 455);
            this.label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(2, 30);
            this.label54.TabIndex = 1400;
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label55.Location = new System.Drawing.Point(835, 455);
            this.label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(2, 30);
            this.label55.TabIndex = 1399;
            // 
            // label56
            // 
            this.label56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label56.Location = new System.Drawing.Point(685, 455);
            this.label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(2, 30);
            this.label56.TabIndex = 1398;
            // 
            // label57
            // 
            this.label57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label57.Location = new System.Drawing.Point(535, 455);
            this.label57.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(2, 30);
            this.label57.TabIndex = 1397;
            // 
            // label58
            // 
            this.label58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label58.Location = new System.Drawing.Point(385, 455);
            this.label58.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(2, 30);
            this.label58.TabIndex = 1396;
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label59.Location = new System.Drawing.Point(156, 485);
            this.label59.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(1700, 2);
            this.label59.TabIndex = 1395;
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label60.Location = new System.Drawing.Point(235, 455);
            this.label60.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(2, 30);
            this.label60.TabIndex = 1394;
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label65.Location = new System.Drawing.Point(1135, 672);
            this.label65.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(2, 30);
            this.label65.TabIndex = 1413;
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label66.Location = new System.Drawing.Point(985, 672);
            this.label66.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(2, 30);
            this.label66.TabIndex = 1412;
            // 
            // label67
            // 
            this.label67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label67.Location = new System.Drawing.Point(835, 672);
            this.label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(2, 30);
            this.label67.TabIndex = 1411;
            // 
            // label68
            // 
            this.label68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label68.Location = new System.Drawing.Point(685, 672);
            this.label68.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(2, 30);
            this.label68.TabIndex = 1410;
            // 
            // label69
            // 
            this.label69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label69.Location = new System.Drawing.Point(535, 672);
            this.label69.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(2, 30);
            this.label69.TabIndex = 1409;
            // 
            // label70
            // 
            this.label70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label70.Location = new System.Drawing.Point(385, 672);
            this.label70.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(2, 30);
            this.label70.TabIndex = 1408;
            // 
            // label72
            // 
            this.label72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label72.Location = new System.Drawing.Point(156, 702);
            this.label72.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(1700, 2);
            this.label72.TabIndex = 1406;
            // 
            // label73
            // 
            this.label73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label73.Location = new System.Drawing.Point(235, 671);
            this.label73.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(2, 30);
            this.label73.TabIndex = 1405;
            // 
            // label74
            // 
            this.label74.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label74.Location = new System.Drawing.Point(1585, 672);
            this.label74.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(2, 30);
            this.label74.TabIndex = 1416;
            // 
            // label75
            // 
            this.label75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label75.Location = new System.Drawing.Point(1435, 672);
            this.label75.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(2, 30);
            this.label75.TabIndex = 1415;
            // 
            // label76
            // 
            this.label76.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label76.Location = new System.Drawing.Point(1285, 672);
            this.label76.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(2, 30);
            this.label76.TabIndex = 1414;
            // 
            // BPQ_TR
            // 
            this.BPQ_TR.ForeColor = System.Drawing.Color.Black;
            this.BPQ_TR.Image = global::BigPro.Properties.Resources.ToRight;
            this.BPQ_TR.Location = new System.Drawing.Point(1830, 18);
            this.BPQ_TR.Margin = new System.Windows.Forms.Padding(2);
            this.BPQ_TR.Name = "BPQ_TR";
            this.BPQ_TR.Size = new System.Drawing.Size(50, 50);
            this.BPQ_TR.TabIndex = 1372;
            this.BPQ_TR.UseVisualStyleBackColor = true;
            this.BPQ_TR.Click += new System.EventHandler(this.BPQ_TR_Click);
            // 
            // BPQ_ToL
            // 
            this.BPQ_ToL.ForeColor = System.Drawing.Color.Black;
            this.BPQ_ToL.Image = global::BigPro.Properties.Resources.Toleft;
            this.BPQ_ToL.Location = new System.Drawing.Point(23, 9);
            this.BPQ_ToL.Margin = new System.Windows.Forms.Padding(2);
            this.BPQ_ToL.Name = "BPQ_ToL";
            this.BPQ_ToL.Size = new System.Drawing.Size(50, 50);
            this.BPQ_ToL.TabIndex = 1371;
            this.BPQ_ToL.UseVisualStyleBackColor = true;
            this.BPQ_ToL.Click += new System.EventHandler(this.BPQ_ToL_Click);
            // 
            // bianpinqi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.label76);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.label70);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.label73);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.BPQ_TXTS);
            this.Controls.Add(this.BPQ_TR);
            this.Controls.Add(this.BPQ_ToL);
            this.Controls.Add(this.label286);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label159);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.BPQ_TSTS);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.BPQ_Back2Main);
            this.Controls.Add(this.BPQ_Back);
            this.Controls.Add(this.BPQ_MiddleL);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "bianpinqi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "bianpinqi";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.bianpinqi_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BPQ_Back2Main;
        private System.Windows.Forms.Button BPQ_Back;
        private System.Windows.Forms.Label BPQ_MiddleL;
        private System.Windows.Forms.Button BPQ_TSTS;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label286;
        private System.Windows.Forms.Button BPQ_TR;
        private System.Windows.Forms.Button BPQ_ToL;
        private System.Windows.Forms.Button BPQ_TXTS;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
    }
}