﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class panglusheding : Form
    {
        private static int allshebei;
        private static string[] shebei;
        private static int clickcount;
        private int n, k, m, p;
        private bool IFCancel;//false:可以旁路 true:不可旁路
        private bool IFYunXu;//true:允许 false:禁止
        public panglusheding()
        {
            InitializeComponent();
        }


        private void panglushezhi_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            IFCancel = false;
            PL_TJSB.Enabled = false;
            PL_TJSB.BackColor = Color.AliceBlue;
            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                int t = totalshebei + 2;
                ChangCiSheZhiGlobalData.IF_PangLu = new bool[t];
                //for (int i = 0; i < t; i++) {
                //    ChangCiSheZhiGlobalData.IF_PangLu[i] = false;
                //}
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                //for(int i = 0; i < shebei.Length; i++)
                //{
                //    Console.WriteLine("++++++=+==" + shebei[i]);
                //}
                if (totalshebei <= 40)
                {
                    if (0 <= totalshebei && totalshebei <= 10)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                    }
                    else if (totalshebei > 10 && totalshebei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                    }
                    else if (totalshebei > 20 && totalshebei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                        for (int i = 30; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.PangLuShengYuSheBei = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(130 + 170 * (i - 30), 550, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.PangLuShengYuSheBei = totalshebei - 40;
                }
            }
        }

        private void DKXZ_ToLeft_Click(object sender, EventArgs e)
        {
            clickcount--;
            if (ChangCiSheZhiGlobalData.PangLuShengYuSheBei >= allshebei - 40)
            {
                MessageBox.Show("没有更多已编组设备！");
                clickcount++;
                //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
            }
            else
            {
                delpanelall();

                for (int i = 0; i < 10; i++)
                {
                    panelset(130 + 170 * i, 250, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                for (int i = 10; i < 20; i++)
                {
                    panelset(130 + 170 * (i - 10), 350, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                for (int i = 20; i < 30; i++)
                {
                    panelset(130 + 170 * (i - 20), 450, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                for (int i = 30; i < 40; i++)
                {
                    panelset(130 + 170 * (i - 30), 550, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                if (ChangCiSheZhiGlobalData.PangLuShengYuSheBei == 0)
                {
                    if (allshebei % 40 == 0)
                    {
                        ChangCiSheZhiGlobalData.PangLuShengYuSheBei = 40;
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.PangLuShengYuSheBei = allshebei % 40;
                    }
                }
                else
                {
                    ChangCiSheZhiGlobalData.PangLuShengYuSheBei = ChangCiSheZhiGlobalData.PangLuShengYuSheBei + 40;
                }
            }
        }

        private void DKXZ_ToRight_Click(object sender, EventArgs e)
        {
            clickcount++;
            if (ChangCiSheZhiGlobalData.PangLuShengYuSheBei == 0)
            {
                MessageBox.Show("没有更多已编组设备！");
                // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                clickcount--;
            }
            else
            {
                delpanelall();
                if (ChangCiSheZhiGlobalData.PangLuShengYuSheBei < 40)
                {

                    if (0 <= ChangCiSheZhiGlobalData.PangLuShengYuSheBei && ChangCiSheZhiGlobalData.PangLuShengYuSheBei <= 10)
                    {
                        for (int i = 0; i < ChangCiSheZhiGlobalData.PangLuShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                    }
                    else if (ChangCiSheZhiGlobalData.PangLuShengYuSheBei > 10 && ChangCiSheZhiGlobalData.PangLuShengYuSheBei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                        for (int i = 10; i < ChangCiSheZhiGlobalData.PangLuShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                        }
                    }
                    else if (ChangCiSheZhiGlobalData.PangLuShengYuSheBei > 20 && ChangCiSheZhiGlobalData.PangLuShengYuSheBei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                        }
                        for (int i = 20; i < ChangCiSheZhiGlobalData.PangLuShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[40 * clickcount + i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[40 * clickcount + i]);
                        }
                        for (int i = 30; i < ChangCiSheZhiGlobalData.PangLuShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[40 * clickcount + i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.PangLuShengYuSheBei = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[40 * clickcount + i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(130 + 170 * (i - 30), 550, shebei[40 * clickcount + i]);
                    }
                    ChangCiSheZhiGlobalData.PangLuShengYuSheBei = ChangCiSheZhiGlobalData.PangLuShengYuSheBei - 40;
                }
            }
        }

        private void PL_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PL_MainPage_Click(object sender, EventArgs e)
        {
            var frm = new main();
            frm.Show();
            this.Close();
        }

        private void PL_QXPL_Click(object sender, EventArgs e)
        {
            //for (int m = 0; m < ChangCiSheZhiGlobalData.IF_PangLu.Length; m++)
            //{
            //    Console.WriteLine("QX" + m + ":" + ChangCiSheZhiGlobalData.IF_PangLu[m]);
            //}
            if (IFYunXu == true)
            {
                PL_TJSB.Enabled = true;
                PL_TJSB.BackColor = Color.White;
                PL_QXPL.Enabled=false;
                PL_QXPL.BackColor = Color.AliceBlue;
                IFCancel = true;
                delpanelall();
                if (File.Exists("SBSD.txt"))
                {
                    List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                    n = int.Parse(nkmp[0]);
                    k = int.Parse(nkmp[1]);
                    m = int.Parse(nkmp[2]);
                    p = int.Parse(nkmp[3]);
                    int totalshebei = 0;
                    nkmp.Clear();
                    for (int i = 0; i < n; i++)
                    {
                        int j = i + 1;
                        if (ChangCiSheZhiGlobalData.IF_PangLu[i+1] == true)
                        {
                            nkmp.Add("调速设备" + j);
                            totalshebei++;
                        }
                    }
                    for (int i = n; i < n + k; i++)
                    {
                        int j = i + 1 - n;
                        if (ChangCiSheZhiGlobalData.IF_PangLu[i + 1] == true)
                        {
                            nkmp.Add("调速互锁类设备" + j);
                            totalshebei++;
                        }
                    }
                    for (int i = n + k; i < n + k + m; i++)
                    {
                        int j = i + 1 - n - k;
                        if (ChangCiSheZhiGlobalData.IF_PangLu[i + 1] == true)
                        {
                            nkmp.Add("定速定位设备" + j);
                            totalshebei++;
                        }
                    }
                    for (int i = n + k + m; i < n + k + m + p; i++)
                    {
                        int j = i + 1 - n - k - m;
                        if (ChangCiSheZhiGlobalData.IF_PangLu[i + 1] == true)
                        {
                            nkmp.Add("定速设备" + j);
                            totalshebei++;
                        }
                    }
                    Console.WriteLine("QXTotalShebei" + totalshebei);
                    Console.WriteLine("QXnkmp" + nkmp.Count);
                    allshebei = totalshebei;
                    shebei = nkmp.ToArray();
                    if (totalshebei <= 40)
                    {
                        if (0 <= totalshebei && totalshebei <= 10)
                        {
                            for (int i = 0; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                        }
                        else if (totalshebei > 10 && totalshebei <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                        }
                        else if (totalshebei > 20 && totalshebei <= 30)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                            for (int i = 20; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 20), 450, shebei[i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                            for (int i = 20; i < 30; i++)
                            {
                                panelset(130 + 170 * (i - 20), 450, shebei[i]);
                            }
                            for (int i = 30; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 30), 550, shebei[i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.PangLuShengYuSheBei = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                        for (int i = 30; i < 40; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[i]);
                        }
                        ChangCiSheZhiGlobalData.PangLuShengYuSheBei = totalshebei - 40;
                    }
                }
            }
            else
            {
                MessageBox.Show("处于禁止状态,请先点击允许按钮!");
            }
        }

        private void PL_TJSB_Click(object sender, EventArgs e)
        {
            //for (int m = 0; m < ChangCiSheZhiGlobalData.IF_PangLu.Length; m++)
            //{
            //    Console.WriteLine("TJ" + m + ":" + ChangCiSheZhiGlobalData.IF_PangLu[m]);
            //}
            //Console.WriteLine("TJlength"  + ":" + ChangCiSheZhiGlobalData.IF_PangLu.Length);
            if (IFYunXu == true)
            {
                IFCancel = false;
                PL_QXPL.Enabled = true;
                PL_QXPL.BackColor = Color.White;
                PL_TJSB.Enabled = false;
                PL_TJSB.BackColor = Color.AliceBlue;
                IFCancel = false;
                delpanelall();
                if (File.Exists("SBSD.txt"))
                {
                    List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                    n = int.Parse(nkmp[0]);
                    k = int.Parse(nkmp[1]);
                    m = int.Parse(nkmp[2]);
                    p = int.Parse(nkmp[3]);
                    int totalshebei = 0;
                    nkmp.Clear();
                    for (int i = 0; i < n; i++)
                    {
                        int j = i + 1;
                        if (ChangCiSheZhiGlobalData.IF_PangLu[i + 1] == false)
                        {
                            nkmp.Add("调速设备" + j);
                            totalshebei++;
                        }
                    }
                    for (int i = n; i < n + k; i++)
                    {
                        int j = i + 1 - n;
                        if (ChangCiSheZhiGlobalData.IF_PangLu[i + 1] == false)
                        {
                            nkmp.Add("调速互锁类设备" + j);
                            totalshebei++;
                        }
                    }
                    for (int i = n + k; i < n + k + m; i++)
                    {
                        int j = i + 1 - n - k;
                        if (ChangCiSheZhiGlobalData.IF_PangLu[i + 1] == false)
                        {
                            nkmp.Add("定速定位设备" + j);
                            totalshebei++;
                        }
                    }
                    for (int i = n + k + m; i < n + k + m + p; i++)
                    {
                        int j = i + 1 - n - k - m;
                        if (ChangCiSheZhiGlobalData.IF_PangLu[i + 1] == false)
                        {
                            nkmp.Add("定速设备" + j);
                            totalshebei++;
                        }
                    }
                    Console.WriteLine("TJTotalShebei" + totalshebei);
                    Console.WriteLine("TJnkmp" + nkmp.Count);
                    allshebei = totalshebei;
                    shebei = nkmp.ToArray();
                    if (totalshebei <= 40)
                    {
                        if (0 <= totalshebei && totalshebei <= 10)
                        {
                            for (int i = 0; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                        }
                        else if (totalshebei > 10 && totalshebei <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                        }
                        else if (totalshebei > 20 && totalshebei <= 30)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                            for (int i = 20; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 20), 450, shebei[i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                            for (int i = 20; i < 30; i++)
                            {
                                panelset(130 + 170 * (i - 20), 450, shebei[i]);
                            }
                            for (int i = 30; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 30), 550, shebei[i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.PangLuShengYuSheBei = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                        for (int i = 30; i < 40; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[i]);
                        }
                        ChangCiSheZhiGlobalData.PangLuShengYuSheBei = totalshebei - 40;
                    }
                }
            }
            else
            {
                MessageBox.Show("处于禁止状态,请先点击允许按钮!");
            }
        }

        private void PL_YX_Click(object sender, EventArgs e)
        {
            if (IFYunXu == false)
            {
                IFYunXu = true;
                MessageBox.Show("处于允许状态!");
            }
            else
            {
                IFYunXu = false;
                MessageBox.Show("处于禁止状态!");
            }
        }

        private void PLAll_Cancel_Click(object sender, EventArgs e)
        {
            if (IFYunXu == true)
            {
                for(int i = 1; i < ChangCiSheZhiGlobalData.IF_PangLu.Length; i++)
                {
                    ChangCiSheZhiGlobalData.IF_PangLu[i] = false;    
                }
                MessageBox.Show("所有设备旁路已经取消!");
            }
            else
            {
                MessageBox.Show("处于禁止状态,请先点击允许按钮!");
            }
        }

        private void panelset(int x, int y, string shebeiname)
        {

            // 
            // Shebei_DanKong
            // 
            Button Shebei_PangLu = new Button();
            Shebei_PangLu.Font = new System.Drawing.Font("宋体", 10F);
            // Shebei_PangLu.Location = new System.Drawing.Point(1660, 550);
            Shebei_PangLu.Margin = new System.Windows.Forms.Padding(2);
            Shebei_PangLu.Name = shebeiname + x + y;
            Shebei_PangLu.Size = new System.Drawing.Size(90, 40);
            Shebei_PangLu.Text = shebeiname;
            Shebei_PangLu.UseVisualStyleBackColor = true;
            Shebei_PangLu.Click += (e, a) => this.Shebei_PangLu(shebeiname);
            // 


            Panel SheBeiPangLu_Panel = new Panel();
            SheBeiPangLu_Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SheBeiPangLu_Panel.Controls.Add(Shebei_PangLu);
            SheBeiPangLu_Panel.Location = new System.Drawing.Point(x, y);
            SheBeiPangLu_Panel.Margin = new System.Windows.Forms.Padding(2);
            SheBeiPangLu_Panel.Name = "SheBeiPangLu_Panel" + x + y;
            SheBeiPangLu_Panel.Size = new System.Drawing.Size(91, 41);
            this.Controls.Add(SheBeiPangLu_Panel);
        }

        private void PL_QR_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("确定吗？", "旁路确认", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                MessageBox.Show("旁路确认!");
            }
        }
        private void Shebei_PangLu(string shebeiname)
        {
            if (IFYunXu == true) {
                if (IFCancel == false)
                {
                    ChangCiSheZhiGlobalData.IF_PangLu[GetIndex(shebeiname)] = true;
                    MessageBox.Show(shebeiname+"可以旁路!");
                }
                else
                {
                    ChangCiSheZhiGlobalData.IF_PangLu[GetIndex(shebeiname)] = false;
                    MessageBox.Show(shebeiname + "已取消旁路!");

                }
            }
            else
            {
                MessageBox.Show("处于禁止状态,请先点击允许按钮!");
            }
        }

        private void delpanelall()
        {
            if (Controls["SheBeiPangLu_Panel130250"] != null)
            {
                Controls["SheBeiPangLu_Panel130250"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel300250"] != null)
            {
                Controls["SheBeiPangLu_Panel300250"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel470250"] != null)
            {
                Controls["SheBeiPangLu_Panel470250"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel640250"] != null)
            {
                Controls["SheBeiPangLu_Panel640250"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel810250"] != null)
            {
                Controls["SheBeiPangLu_Panel810250"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel980250"] != null)
            {
                Controls["SheBeiPangLu_Panel980250"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1150250"] != null)
            {
                Controls["SheBeiPangLu_Panel1150250"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1320250"] != null)
            {
                Controls["SheBeiPangLu_Panel1320250"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1490250"] != null)
            {
                Controls["SheBeiPangLu_Panel1490250"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1660250"] != null)
            {
                Controls["SheBeiPangLu_Panel1660250"].Dispose();
            }


            if (Controls["SheBeiPangLu_Panel130350"] != null)
            {
                Controls["SheBeiPangLu_Panel130350"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel300350"] != null)
            {
                Controls["SheBeiPangLu_Panel300350"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel470350"] != null)
            {
                Controls["SheBeiPangLu_Panel470350"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel640350"] != null)
            {
                Controls["SheBeiPangLu_Panel640350"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel810350"] != null)
            {
                Controls["SheBeiPangLu_Panel810350"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel980350"] != null)
            {
                Controls["SheBeiPangLu_Panel980350"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1150350"] != null)
            {
                Controls["SheBeiPangLu_Panel1150350"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1320350"] != null)
            {
                Controls["SheBeiPangLu_Panel1320350"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1490350"] != null)
            {
                Controls["SheBeiPangLu_Panel1490350"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1660350"] != null)
            {
                Controls["SheBeiPangLu_Panel1660350"].Dispose();
            }


            if (Controls["SheBeiPangLu_Panel130450"] != null)
            {
                Controls["SheBeiPangLu_Panel130450"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel300450"] != null)
            {
                Controls["SheBeiPangLu_Panel300450"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel470450"] != null)
            {
                Controls["SheBeiPangLu_Panel470450"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel640450"] != null)
            {
                Controls["SheBeiPangLu_Panel640450"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel810450"] != null)
            {
                Controls["SheBeiPangLu_Panel810450"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel980450"] != null)
            {
                Controls["SheBeiPangLu_Panel980450"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1150450"] != null)
            {
                Controls["SheBeiPangLu_Panel1150450"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1320450"] != null)
            {
                Controls["SheBeiPangLu_Panel1320450"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1490450"] != null)
            {
                Controls["SheBeiPangLu_Panel1490450"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1660450"] != null)
            {
                Controls["SheBeiPangLu_Panel1660450"].Dispose();
            }

            if (Controls["SheBeiPangLu_Panel130550"] != null)
            {
                Controls["SheBeiPangLu_Panel130550"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel300550"] != null)
            {
                Controls["SheBeiPangLu_Panel300550"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel470550"] != null)
            {
                Controls["SheBeiPangLu_Panel470550"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel640550"] != null)
            {
                Controls["SheBeiPangLu_Panel640550"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel810550"] != null)
            {
                Controls["SheBeiPangLu_Panel810550"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel980550"] != null)
            {
                Controls["SheBeiPangLu_Panel980550"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1150550"] != null)
            {
                Controls["SheBeiPangLu_Panel1150550"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1320550"] != null)
            {
                Controls["SheBeiPangLu_Panel1320550"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1490550"] != null)
            {
                Controls["SheBeiPangLu_Panel1490550"].Dispose();
            }
            if (Controls["SheBeiPangLu_Panel1660550"] != null)
            {
                Controls["SheBeiPangLu_Panel1660550"].Dispose();
            }
        }

        public int GetIndex(string shebeiname)
        {
            if (shebeiname.Contains("调速设备"))
            {
                int i = int.Parse(shebeiname.Substring(4));
                return i;
            }
            else if (shebeiname.Contains("调速互锁类设备"))
            {
                int i = int.Parse(shebeiname.Substring(7));
                return i + n;
            }
            else if (shebeiname.Contains("定速定位设备"))
            {
                int i = int.Parse(shebeiname.Substring(6));
                return i + n + k;
            }
            else if (shebeiname.Contains("定速设备"))
            {
                int i = int.Parse(shebeiname.Substring(4));
                return i + n + k + m;
            }
            return 0;
        }
    }
}
