﻿namespace BigPro
{
    partial class _2changciquxian
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.CCQX_FF = new System.Windows.Forms.Button();
            this.CCQX_DuoD = new System.Windows.Forms.Button();
            this.CCQX_DanD = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button39 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.QuXiXZSB = new System.Windows.Forms.ListBox();
            this.QuX_Dx = new System.Windows.Forms.ListBox();
            this.QuXiCue_List = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.QuXiLabel = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button9.Location = new System.Drawing.Point(274, 142);
            this.button9.Margin = new System.Windows.Forms.Padding(2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(150, 56);
            this.button9.TabIndex = 4;
            this.button9.Text = "当前位置";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Red;
            this.button8.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button8.Location = new System.Drawing.Point(45, 142);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(150, 56);
            this.button8.TabIndex = 3;
            this.button8.Text = "曲线";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // CCQX_FF
            // 
            this.CCQX_FF.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCQX_FF.Location = new System.Drawing.Point(502, 30);
            this.CCQX_FF.Margin = new System.Windows.Forms.Padding(2);
            this.CCQX_FF.Name = "CCQX_FF";
            this.CCQX_FF.Size = new System.Drawing.Size(150, 56);
            this.CCQX_FF.TabIndex = 2;
            this.CCQX_FF.Text = "反复";
            this.CCQX_FF.UseVisualStyleBackColor = true;
            this.CCQX_FF.Click += new System.EventHandler(this.CCQX_FF_Click);
            // 
            // CCQX_DuoD
            // 
            this.CCQX_DuoD.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCQX_DuoD.Location = new System.Drawing.Point(274, 30);
            this.CCQX_DuoD.Margin = new System.Windows.Forms.Padding(2);
            this.CCQX_DuoD.Name = "CCQX_DuoD";
            this.CCQX_DuoD.Size = new System.Drawing.Size(150, 56);
            this.CCQX_DuoD.TabIndex = 1;
            this.CCQX_DuoD.Text = "多段";
            this.CCQX_DuoD.UseVisualStyleBackColor = true;
            this.CCQX_DuoD.Click += new System.EventHandler(this.CCQX_DuoD_Click);
            // 
            // CCQX_DanD
            // 
            this.CCQX_DanD.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCQX_DanD.Location = new System.Drawing.Point(45, 30);
            this.CCQX_DanD.Margin = new System.Windows.Forms.Padding(2);
            this.CCQX_DanD.Name = "CCQX_DanD";
            this.CCQX_DanD.Size = new System.Drawing.Size(150, 56);
            this.CCQX_DanD.TabIndex = 0;
            this.CCQX_DanD.Text = "单段";
            this.CCQX_DanD.UseVisualStyleBackColor = true;
            this.CCQX_DanD.Click += new System.EventHandler(this.CCQX_DanD_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.button12);
            this.panel3.Controls.Add(this.button11);
            this.panel3.Controls.Add(this.button10);
            this.panel3.Location = new System.Drawing.Point(122, 595);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1175, 68);
            this.panel3.TabIndex = 34;
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button12.Location = new System.Drawing.Point(772, 10);
            this.button12.Margin = new System.Windows.Forms.Padding(2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(112, 48);
            this.button12.TabIndex = 2;
            this.button12.Text = "确认";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button11.Location = new System.Drawing.Point(532, 10);
            this.button11.Margin = new System.Windows.Forms.Padding(2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(112, 48);
            this.button11.TabIndex = 1;
            this.button11.Text = "删除";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button10.Location = new System.Drawing.Point(273, 7);
            this.button10.Margin = new System.Windows.Forms.Padding(2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(112, 48);
            this.button10.TabIndex = 0;
            this.button10.Text = "复制";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(161, 138);
            this.button49.Margin = new System.Windows.Forms.Padding(2);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(38, 40);
            this.button49.TabIndex = 17;
            this.button49.Text = "b";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button14.Location = new System.Drawing.Point(604, 682);
            this.button14.Margin = new System.Windows.Forms.Padding(2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(112, 48);
            this.button14.TabIndex = 35;
            this.button14.Text = "保存";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button13.Location = new System.Drawing.Point(9, 682);
            this.button13.Margin = new System.Windows.Forms.Padding(2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(112, 48);
            this.button13.TabIndex = 25;
            this.button13.Text = "返回";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(108, 138);
            this.button48.Margin = new System.Windows.Forms.Padding(2);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(38, 40);
            this.button48.TabIndex = 16;
            this.button48.Text = "*";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(57, 138);
            this.button47.Margin = new System.Windows.Forms.Padding(2);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(38, 40);
            this.button47.TabIndex = 15;
            this.button47.Text = ".";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(2, 138);
            this.button46.Margin = new System.Windows.Forms.Padding(2);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(38, 40);
            this.button46.TabIndex = 14;
            this.button46.Text = "0";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(161, 93);
            this.button45.Margin = new System.Windows.Forms.Padding(2);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(38, 40);
            this.button45.TabIndex = 13;
            this.button45.Text = "b";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(161, 48);
            this.button44.Margin = new System.Windows.Forms.Padding(2);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(38, 40);
            this.button44.TabIndex = 12;
            this.button44.Text = "b";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(161, 3);
            this.button43.Margin = new System.Windows.Forms.Padding(2);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(38, 40);
            this.button43.TabIndex = 11;
            this.button43.Text = "b";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(108, 93);
            this.button42.Margin = new System.Windows.Forms.Padding(2);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(38, 40);
            this.button42.TabIndex = 10;
            this.button42.Text = "9";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(108, 48);
            this.button41.Margin = new System.Windows.Forms.Padding(2);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(38, 40);
            this.button41.TabIndex = 9;
            this.button41.Text = "6";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button16.Location = new System.Drawing.Point(1322, 682);
            this.button16.Margin = new System.Windows.Forms.Padding(2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(112, 48);
            this.button16.TabIndex = 37;
            this.button16.Text = "回首页";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(108, 3);
            this.button40.Margin = new System.Windows.Forms.Padding(2);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(38, 40);
            this.button40.TabIndex = 8;
            this.button40.Text = "3";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button15.Location = new System.Drawing.Point(739, 682);
            this.button15.Margin = new System.Windows.Forms.Padding(2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(112, 48);
            this.button15.TabIndex = 36;
            this.button15.Text = "场景";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.CCQX_FF);
            this.panel1.Controls.Add(this.CCQX_DuoD);
            this.panel1.Controls.Add(this.CCQX_DanD);
            this.panel1.Location = new System.Drawing.Point(582, 138);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(714, 460);
            this.panel1.TabIndex = 33;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.button49);
            this.panel2.Controls.Add(this.button48);
            this.panel2.Controls.Add(this.button47);
            this.panel2.Controls.Add(this.button46);
            this.panel2.Controls.Add(this.button45);
            this.panel2.Controls.Add(this.button44);
            this.panel2.Controls.Add(this.button43);
            this.panel2.Controls.Add(this.button42);
            this.panel2.Controls.Add(this.button41);
            this.panel2.Controls.Add(this.button40);
            this.panel2.Controls.Add(this.button39);
            this.panel2.Controls.Add(this.button36);
            this.panel2.Controls.Add(this.button35);
            this.panel2.Controls.Add(this.button34);
            this.panel2.Controls.Add(this.button32);
            this.panel2.Controls.Add(this.button33);
            this.panel2.Controls.Add(this.button31);
            this.panel2.Location = new System.Drawing.Point(490, 250);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(205, 186);
            this.panel2.TabIndex = 28;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(57, 93);
            this.button39.Margin = new System.Windows.Forms.Padding(2);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(38, 40);
            this.button39.TabIndex = 7;
            this.button39.Text = "8";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(57, 48);
            this.button36.Margin = new System.Windows.Forms.Padding(2);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(38, 40);
            this.button36.TabIndex = 6;
            this.button36.Text = "5";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(57, 3);
            this.button35.Margin = new System.Windows.Forms.Padding(2);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(38, 40);
            this.button35.TabIndex = 5;
            this.button35.Text = "2";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(2, 93);
            this.button34.Margin = new System.Windows.Forms.Padding(2);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(38, 40);
            this.button34.TabIndex = 4;
            this.button34.Text = "7";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(2, 48);
            this.button32.Margin = new System.Windows.Forms.Padding(2);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(38, 40);
            this.button32.TabIndex = 3;
            this.button32.Text = "4";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(62, 0);
            this.button33.Margin = new System.Windows.Forms.Padding(2);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(0, 0);
            this.button33.TabIndex = 2;
            this.button33.Text = "button33";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(2, 3);
            this.button31.Margin = new System.Windows.Forms.Padding(2);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(38, 40);
            this.button31.TabIndex = 0;
            this.button31.Text = "1";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button3.Enabled = false;
            this.button3.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(447, 138);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(136, 50);
            this.button3.TabIndex = 32;
            this.button3.Text = "选中设备";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Enabled = false;
            this.button1.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(313, 138);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 50);
            this.button1.TabIndex = 31;
            this.button1.Text = "待选设备";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // QuXiXZSB
            // 
            this.QuXiXZSB.Font = new System.Drawing.Font("宋体", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.QuXiXZSB.FormattingEnabled = true;
            this.QuXiXZSB.ItemHeight = 14;
            this.QuXiXZSB.Location = new System.Drawing.Point(447, 187);
            this.QuXiXZSB.Name = "QuXiXZSB";
            this.QuXiXZSB.ScrollAlwaysVisible = true;
            this.QuXiXZSB.Size = new System.Drawing.Size(138, 396);
            this.QuXiXZSB.TabIndex = 30;
            // 
            // QuX_Dx
            // 
            this.QuX_Dx.Font = new System.Drawing.Font("宋体", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.QuX_Dx.FormattingEnabled = true;
            this.QuX_Dx.ItemHeight = 14;
            this.QuX_Dx.Location = new System.Drawing.Point(313, 186);
            this.QuX_Dx.Name = "QuX_Dx";
            this.QuX_Dx.ScrollAlwaysVisible = true;
            this.QuX_Dx.Size = new System.Drawing.Size(138, 396);
            this.QuX_Dx.TabIndex = 29;
            this.QuX_Dx.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // QuXiCue_List
            // 
            this.QuXiCue_List.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.QuXiCue_List.FormattingEnabled = true;
            this.QuXiCue_List.ItemHeight = 16;
            this.QuXiCue_List.Location = new System.Drawing.Point(122, 138);
            this.QuXiCue_List.Name = "QuXiCue_List";
            this.QuXiCue_List.ScrollAlwaysVisible = true;
            this.QuXiCue_List.Size = new System.Drawing.Size(193, 452);
            this.QuXiCue_List.TabIndex = 28;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Enabled = false;
            this.button2.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(122, 85);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(192, 55);
            this.button2.TabIndex = 26;
            this.button2.Text = "江姐";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(593, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 27);
            this.label1.TabIndex = 24;
            this.label1.Text = "场次设置";
            // 
            // QuXiLabel
            // 
            this.QuXiLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.QuXiLabel.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.QuXiLabel.Location = new System.Drawing.Point(313, 85);
            this.QuXiLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.QuXiLabel.Name = "QuXiLabel";
            this.QuXiLabel.Size = new System.Drawing.Size(983, 53);
            this.QuXiLabel.TabIndex = 64;
            this.QuXiLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _2changciquxian
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1443, 780);
            this.Controls.Add(this.QuXiLabel);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.QuXiXZSB);
            this.Controls.Add(this.QuX_Dx);
            this.Controls.Add(this.QuXiCue_List);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "_2changciquxian";
            this.Text = "_2changciquxian";
            this.Load += new System.EventHandler(this._2changciquxian_Load);
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button CCQX_FF;
        private System.Windows.Forms.Button CCQX_DuoD;
        private System.Windows.Forms.Button CCQX_DanD;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox QuXiXZSB;
        private System.Windows.Forms.ListBox QuX_Dx;
        private System.Windows.Forms.ListBox QuXiCue_List;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label QuXiLabel;
    }
}