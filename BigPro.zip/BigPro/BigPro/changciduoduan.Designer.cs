﻿namespace BigPro
{
    partial class _2changciduoduan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button17 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button49 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.La_DT = new System.Windows.Forms.Label();
            this.La_DL = new System.Windows.Forms.Label();
            this.La_DS = new System.Windows.Forms.Label();
            this.DuoD_T = new System.Windows.Forms.Button();
            this.DuoD_Wz = new System.Windows.Forms.Button();
            this.DuoD_DS = new System.Windows.Forms.Button();
            this.CCDuoD_DanD = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.CCDuoD_QX = new System.Windows.Forms.Button();
            this.CCDuoD_FF = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.DuoDXZSB = new System.Windows.Forms.ListBox();
            this.DuoDCue_List = new System.Windows.Forms.ListBox();
            this.button21 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.DuoD_DelData = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.DuoDLabel = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button17.Location = new System.Drawing.Point(741, 680);
            this.button17.Margin = new System.Windows.Forms.Padding(2);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(112, 48);
            this.button17.TabIndex = 60;
            this.button17.Text = "场景";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(108, 138);
            this.button48.Margin = new System.Windows.Forms.Padding(2);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(38, 40);
            this.button48.TabIndex = 16;
            this.button48.Text = "*";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(57, 138);
            this.button47.Margin = new System.Windows.Forms.Padding(2);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(38, 40);
            this.button47.TabIndex = 15;
            this.button47.Text = ".";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(2, 138);
            this.button46.Margin = new System.Windows.Forms.Padding(2);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(38, 40);
            this.button46.TabIndex = 14;
            this.button46.Text = "0";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(161, 93);
            this.button45.Margin = new System.Windows.Forms.Padding(2);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(38, 40);
            this.button45.TabIndex = 13;
            this.button45.Text = "b";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(161, 48);
            this.button44.Margin = new System.Windows.Forms.Padding(2);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(38, 40);
            this.button44.TabIndex = 12;
            this.button44.Text = "b";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(161, 3);
            this.button43.Margin = new System.Windows.Forms.Padding(2);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(38, 40);
            this.button43.TabIndex = 11;
            this.button43.Text = "b";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(108, 93);
            this.button42.Margin = new System.Windows.Forms.Padding(2);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(38, 40);
            this.button42.TabIndex = 10;
            this.button42.Text = "9";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(108, 48);
            this.button41.Margin = new System.Windows.Forms.Padding(2);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(38, 40);
            this.button41.TabIndex = 9;
            this.button41.Text = "6";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.button49);
            this.panel2.Controls.Add(this.button48);
            this.panel2.Controls.Add(this.button47);
            this.panel2.Controls.Add(this.button46);
            this.panel2.Controls.Add(this.button45);
            this.panel2.Controls.Add(this.button44);
            this.panel2.Controls.Add(this.button43);
            this.panel2.Controls.Add(this.button42);
            this.panel2.Controls.Add(this.button41);
            this.panel2.Controls.Add(this.button40);
            this.panel2.Controls.Add(this.button39);
            this.panel2.Controls.Add(this.button36);
            this.panel2.Controls.Add(this.button35);
            this.panel2.Controls.Add(this.button34);
            this.panel2.Controls.Add(this.button32);
            this.panel2.Controls.Add(this.button33);
            this.panel2.Controls.Add(this.button31);
            this.panel2.Location = new System.Drawing.Point(490, 250);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(204, 186);
            this.panel2.TabIndex = 28;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(161, 138);
            this.button49.Margin = new System.Windows.Forms.Padding(2);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(38, 40);
            this.button49.TabIndex = 17;
            this.button49.Text = "b";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(108, 3);
            this.button40.Margin = new System.Windows.Forms.Padding(2);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(38, 40);
            this.button40.TabIndex = 8;
            this.button40.Text = "3";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(57, 93);
            this.button39.Margin = new System.Windows.Forms.Padding(2);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(38, 40);
            this.button39.TabIndex = 7;
            this.button39.Text = "8";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(57, 48);
            this.button36.Margin = new System.Windows.Forms.Padding(2);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(38, 40);
            this.button36.TabIndex = 6;
            this.button36.Text = "5";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(57, 3);
            this.button35.Margin = new System.Windows.Forms.Padding(2);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(38, 40);
            this.button35.TabIndex = 5;
            this.button35.Text = "2";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(2, 93);
            this.button34.Margin = new System.Windows.Forms.Padding(2);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(38, 40);
            this.button34.TabIndex = 4;
            this.button34.Text = "7";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(2, 48);
            this.button32.Margin = new System.Windows.Forms.Padding(2);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(38, 40);
            this.button32.TabIndex = 3;
            this.button32.Text = "4";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(62, 0);
            this.button33.Margin = new System.Windows.Forms.Padding(2);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(0, 0);
            this.button33.TabIndex = 2;
            this.button33.Text = "button33";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(2, 3);
            this.button31.Margin = new System.Windows.Forms.Padding(2);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(38, 40);
            this.button31.TabIndex = 0;
            this.button31.Text = "1";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.CCDuoD_DanD);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.CCDuoD_QX);
            this.panel1.Controls.Add(this.CCDuoD_FF);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Location = new System.Drawing.Point(462, 131);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(838, 459);
            this.panel1.TabIndex = 57;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.La_DT);
            this.panel5.Controls.Add(this.La_DL);
            this.panel5.Controls.Add(this.La_DS);
            this.panel5.Controls.Add(this.DuoD_T);
            this.panel5.Controls.Add(this.DuoD_Wz);
            this.panel5.Controls.Add(this.DuoD_DS);
            this.panel5.Location = new System.Drawing.Point(45, 223);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(235, 182);
            this.panel5.TabIndex = 31;
            // 
            // La_DT
            // 
            this.La_DT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.La_DT.Location = new System.Drawing.Point(147, 121);
            this.La_DT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.La_DT.Name = "La_DT";
            this.La_DT.Size = new System.Drawing.Size(76, 47);
            this.La_DT.TabIndex = 5;
            this.La_DT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // La_DL
            // 
            this.La_DL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.La_DL.Location = new System.Drawing.Point(147, 68);
            this.La_DL.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.La_DL.Name = "La_DL";
            this.La_DL.Size = new System.Drawing.Size(76, 47);
            this.La_DL.TabIndex = 4;
            this.La_DL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // La_DS
            // 
            this.La_DS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.La_DS.Location = new System.Drawing.Point(147, 15);
            this.La_DS.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.La_DS.Name = "La_DS";
            this.La_DS.Size = new System.Drawing.Size(76, 47);
            this.La_DS.TabIndex = 3;
            this.La_DS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DuoD_T
            // 
            this.DuoD_T.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DuoD_T.Location = new System.Drawing.Point(14, 121);
            this.DuoD_T.Margin = new System.Windows.Forms.Padding(2);
            this.DuoD_T.Name = "DuoD_T";
            this.DuoD_T.Size = new System.Drawing.Size(120, 46);
            this.DuoD_T.TabIndex = 2;
            this.DuoD_T.Text = "延时时间";
            this.DuoD_T.UseVisualStyleBackColor = true;
            this.DuoD_T.Click += new System.EventHandler(this.DuoD_T_Click);
            // 
            // DuoD_Wz
            // 
            this.DuoD_Wz.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DuoD_Wz.Location = new System.Drawing.Point(14, 68);
            this.DuoD_Wz.Margin = new System.Windows.Forms.Padding(2);
            this.DuoD_Wz.Name = "DuoD_Wz";
            this.DuoD_Wz.Size = new System.Drawing.Size(120, 46);
            this.DuoD_Wz.TabIndex = 1;
            this.DuoD_Wz.Text = "设定位置";
            this.DuoD_Wz.UseVisualStyleBackColor = true;
            this.DuoD_Wz.Click += new System.EventHandler(this.DuoD_Wz_Click);
            // 
            // DuoD_DS
            // 
            this.DuoD_DS.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DuoD_DS.Location = new System.Drawing.Point(14, 15);
            this.DuoD_DS.Margin = new System.Windows.Forms.Padding(2);
            this.DuoD_DS.Name = "DuoD_DS";
            this.DuoD_DS.Size = new System.Drawing.Size(120, 46);
            this.DuoD_DS.TabIndex = 0;
            this.DuoD_DS.Text = "段数(1-4)";
            this.DuoD_DS.UseVisualStyleBackColor = true;
            this.DuoD_DS.Click += new System.EventHandler(this.DuoD_DS_Click);
            // 
            // CCDuoD_DanD
            // 
            this.CCDuoD_DanD.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCDuoD_DanD.Location = new System.Drawing.Point(45, 30);
            this.CCDuoD_DanD.Margin = new System.Windows.Forms.Padding(2);
            this.CCDuoD_DanD.Name = "CCDuoD_DanD";
            this.CCDuoD_DanD.Size = new System.Drawing.Size(150, 56);
            this.CCDuoD_DanD.TabIndex = 30;
            this.CCDuoD_DanD.Text = "单段";
            this.CCDuoD_DanD.UseVisualStyleBackColor = true;
            this.CCDuoD_DanD.Click += new System.EventHandler(this.CCDuoD_DanD_Click);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button9.Location = new System.Drawing.Point(274, 142);
            this.button9.Margin = new System.Windows.Forms.Padding(2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(150, 56);
            this.button9.TabIndex = 4;
            this.button9.Text = "当前位置";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // CCDuoD_QX
            // 
            this.CCDuoD_QX.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCDuoD_QX.Location = new System.Drawing.Point(45, 142);
            this.CCDuoD_QX.Margin = new System.Windows.Forms.Padding(2);
            this.CCDuoD_QX.Name = "CCDuoD_QX";
            this.CCDuoD_QX.Size = new System.Drawing.Size(150, 56);
            this.CCDuoD_QX.TabIndex = 3;
            this.CCDuoD_QX.Text = "曲线";
            this.CCDuoD_QX.UseVisualStyleBackColor = true;
            this.CCDuoD_QX.Click += new System.EventHandler(this.CCDuoD_QX_Click);
            // 
            // CCDuoD_FF
            // 
            this.CCDuoD_FF.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCDuoD_FF.Location = new System.Drawing.Point(502, 30);
            this.CCDuoD_FF.Margin = new System.Windows.Forms.Padding(2);
            this.CCDuoD_FF.Name = "CCDuoD_FF";
            this.CCDuoD_FF.Size = new System.Drawing.Size(150, 56);
            this.CCDuoD_FF.TabIndex = 2;
            this.CCDuoD_FF.Text = "反复";
            this.CCDuoD_FF.UseVisualStyleBackColor = true;
            this.CCDuoD_FF.Click += new System.EventHandler(this.CCDuoD_FF_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Red;
            this.button5.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button5.Location = new System.Drawing.Point(274, 30);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(150, 56);
            this.button5.TabIndex = 1;
            this.button5.Text = "多段";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button18.Enabled = false;
            this.button18.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button18.Location = new System.Drawing.Point(314, 131);
            this.button18.Margin = new System.Windows.Forms.Padding(2);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(150, 50);
            this.button18.TabIndex = 56;
            this.button18.Text = "选中设备";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // DuoDXZSB
            // 
            this.DuoDXZSB.Font = new System.Drawing.Font("宋体", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DuoDXZSB.FormattingEnabled = true;
            this.DuoDXZSB.ItemHeight = 14;
            this.DuoDXZSB.Location = new System.Drawing.Point(314, 179);
            this.DuoDXZSB.Name = "DuoDXZSB";
            this.DuoDXZSB.ScrollAlwaysVisible = true;
            this.DuoDXZSB.Size = new System.Drawing.Size(150, 410);
            this.DuoDXZSB.TabIndex = 54;
            // 
            // DuoDCue_List
            // 
            this.DuoDCue_List.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DuoDCue_List.FormattingEnabled = true;
            this.DuoDCue_List.ItemHeight = 16;
            this.DuoDCue_List.Location = new System.Drawing.Point(123, 131);
            this.DuoDCue_List.Name = "DuoDCue_List";
            this.DuoDCue_List.ScrollAlwaysVisible = true;
            this.DuoDCue_List.Size = new System.Drawing.Size(193, 452);
            this.DuoDCue_List.TabIndex = 52;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button21.Enabled = false;
            this.button21.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button21.Location = new System.Drawing.Point(123, 78);
            this.button21.Margin = new System.Windows.Forms.Padding(2);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(192, 55);
            this.button21.TabIndex = 50;
            this.button21.Text = "江姐";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(595, 7);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 27);
            this.label2.TabIndex = 48;
            this.label2.Text = "场次设置";
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button13.Location = new System.Drawing.Point(-403, 526);
            this.button13.Margin = new System.Windows.Forms.Padding(2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(112, 48);
            this.button13.TabIndex = 47;
            this.button13.Text = "返回";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.button4);
            this.panel3.Controls.Add(this.button12);
            this.panel3.Controls.Add(this.DuoD_DelData);
            this.panel3.Controls.Add(this.button10);
            this.panel3.Location = new System.Drawing.Point(123, 589);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1177, 68);
            this.panel3.TabIndex = 58;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(1041, 10);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 48);
            this.button3.TabIndex = 8;
            this.button3.Text = "一致";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(844, 10);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 48);
            this.button2.TabIndex = 7;
            this.button2.Text = "位置一致";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4.Location = new System.Drawing.Point(452, 10);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(112, 48);
            this.button4.TabIndex = 6;
            this.button4.Text = "速度一致";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button12.Location = new System.Drawing.Point(648, 10);
            this.button12.Margin = new System.Windows.Forms.Padding(2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(112, 48);
            this.button12.TabIndex = 2;
            this.button12.Text = "确认";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // DuoD_DelData
            // 
            this.DuoD_DelData.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DuoD_DelData.Location = new System.Drawing.Point(255, 10);
            this.DuoD_DelData.Margin = new System.Windows.Forms.Padding(2);
            this.DuoD_DelData.Name = "DuoD_DelData";
            this.DuoD_DelData.Size = new System.Drawing.Size(112, 48);
            this.DuoD_DelData.TabIndex = 1;
            this.DuoD_DelData.Text = "删除";
            this.DuoD_DelData.UseVisualStyleBackColor = true;
            this.DuoD_DelData.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DuoD_DelData_MouseClick);
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button10.Location = new System.Drawing.Point(58, 10);
            this.button10.Margin = new System.Windows.Forms.Padding(2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(112, 48);
            this.button10.TabIndex = 0;
            this.button10.Text = "复制";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button14.Location = new System.Drawing.Point(613, 680);
            this.button14.Margin = new System.Windows.Forms.Padding(2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(112, 48);
            this.button14.TabIndex = 59;
            this.button14.Text = "保存";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button15.Location = new System.Drawing.Point(9, 680);
            this.button15.Margin = new System.Windows.Forms.Padding(2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(112, 48);
            this.button15.TabIndex = 49;
            this.button15.Text = "返回";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button16.Location = new System.Drawing.Point(1316, 680);
            this.button16.Margin = new System.Windows.Forms.Padding(2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(112, 48);
            this.button16.TabIndex = 61;
            this.button16.Text = "回首页";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // DuoDLabel
            // 
            this.DuoDLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DuoDLabel.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DuoDLabel.Location = new System.Drawing.Point(314, 78);
            this.DuoDLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DuoDLabel.Name = "DuoDLabel";
            this.DuoDLabel.Size = new System.Drawing.Size(988, 53);
            this.DuoDLabel.TabIndex = 62;
            this.DuoDLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.DuoDLabel.Click += new System.EventHandler(this.DuoDLabel_Click);
            // 
            // _2changciduoduan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1443, 844);
            this.Controls.Add(this.DuoDLabel);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.DuoDXZSB);
            this.Controls.Add(this.DuoDCue_List);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button16);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "_2changciduoduan";
            this.Text = "_2changciduoduan";
            this.Load += new System.EventHandler(this._2changciduoduan_Load);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button CCDuoD_QX;
        private System.Windows.Forms.Button CCDuoD_FF;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.ListBox DuoDXZSB;
        private System.Windows.Forms.ListBox DuoDCue_List;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button DuoD_DelData;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button DuoD_T;
        private System.Windows.Forms.Button DuoD_Wz;
        private System.Windows.Forms.Button DuoD_DS;
        private System.Windows.Forms.Button CCDuoD_DanD;
        private System.Windows.Forms.Label DuoDLabel;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label La_DT;
        private System.Windows.Forms.Label La_DL;
        private System.Windows.Forms.Label La_DS;
    }
}