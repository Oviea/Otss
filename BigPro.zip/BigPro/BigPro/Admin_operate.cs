﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class admin_operate : Form
    {
        public admin_operate()
        {
            InitializeComponent();
        }
        private void btn_bound_Click(object sender, EventArgs e)
        {
            this.Close();
            var bound = new Bound();
            bound.Show();
        }

        private void btn_pluse_Click(object sender, EventArgs e)
        {
            this.Close();
            var pluse = new Pluse();
            pluse.Show();
        }

        private void btn_forbidden_Click(object sender, EventArgs e)
        {
            this.Close();
            var forbid = new jinyong();
            forbid.Show();
        }

        private void btn_history_Click(object sender, EventArgs e)
        {

        }

        private void btn_tbd1_Click(object sender, EventArgs e)
        {
            var yings = new SheBeiYingShe();
            yings.Show();
            this.Close();
        }

        private void btn_tbd2_Click(object sender, EventArgs e)
        {

        }

        private void btn_tbd3_Click(object sender, EventArgs e)
        {

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btn_home_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void admin_operate_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void btn_recover_Click(object sender, EventArgs e)
        {

        }
    }
}
