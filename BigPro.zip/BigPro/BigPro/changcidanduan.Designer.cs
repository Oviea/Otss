﻿namespace BigPro
{
    partial class _2changcidanduan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button13 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.CCDanD_QX = new System.Windows.Forms.Button();
            this.CCDanD_FF = new System.Windows.Forms.Button();
            this.CCDDl = new System.Windows.Forms.Button();
            this.CCDDLoc = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.DD_VLTdel = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.La_T = new System.Windows.Forms.Label();
            this.La_L = new System.Windows.Forms.Label();
            this.La_V = new System.Windows.Forms.Label();
            this.DD_T = new System.Windows.Forms.Button();
            this.DD_L = new System.Windows.Forms.Button();
            this.DD_V = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button39 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.DDXZSB = new System.Windows.Forms.ListBox();
            this.DDCue_List = new System.Windows.Forms.ListBox();
            this.button21 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.DDLabel = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button13.Location = new System.Drawing.Point(-403, 526);
            this.button13.Margin = new System.Windows.Forms.Padding(2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(112, 48);
            this.button13.TabIndex = 25;
            this.button13.Text = "返回";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button9.Location = new System.Drawing.Point(274, 142);
            this.button9.Margin = new System.Windows.Forms.Padding(2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(150, 56);
            this.button9.TabIndex = 4;
            this.button9.Text = "当前位置";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // CCDanD_QX
            // 
            this.CCDanD_QX.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCDanD_QX.Location = new System.Drawing.Point(45, 142);
            this.CCDanD_QX.Margin = new System.Windows.Forms.Padding(2);
            this.CCDanD_QX.Name = "CCDanD_QX";
            this.CCDanD_QX.Size = new System.Drawing.Size(150, 56);
            this.CCDanD_QX.TabIndex = 3;
            this.CCDanD_QX.Text = "曲线";
            this.CCDanD_QX.UseVisualStyleBackColor = true;
            this.CCDanD_QX.Click += new System.EventHandler(this.CCDanD_QX_Click);
            // 
            // CCDanD_FF
            // 
            this.CCDanD_FF.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCDanD_FF.Location = new System.Drawing.Point(502, 30);
            this.CCDanD_FF.Margin = new System.Windows.Forms.Padding(2);
            this.CCDanD_FF.Name = "CCDanD_FF";
            this.CCDanD_FF.Size = new System.Drawing.Size(150, 56);
            this.CCDanD_FF.TabIndex = 2;
            this.CCDanD_FF.Text = "反复";
            this.CCDanD_FF.UseVisualStyleBackColor = true;
            this.CCDanD_FF.Click += new System.EventHandler(this.CCDanD_FF_Click);
            // 
            // CCDDl
            // 
            this.CCDDl.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCDDl.Location = new System.Drawing.Point(274, 30);
            this.CCDDl.Margin = new System.Windows.Forms.Padding(2);
            this.CCDDl.Name = "CCDDl";
            this.CCDDl.Size = new System.Drawing.Size(150, 56);
            this.CCDDl.TabIndex = 1;
            this.CCDDl.Text = "多段";
            this.CCDDl.UseVisualStyleBackColor = true;
            this.CCDDl.Click += new System.EventHandler(this.CCDDl_Click);
            // 
            // CCDDLoc
            // 
            this.CCDDLoc.BackColor = System.Drawing.Color.Red;
            this.CCDDLoc.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCDDLoc.Location = new System.Drawing.Point(45, 30);
            this.CCDDLoc.Margin = new System.Windows.Forms.Padding(2);
            this.CCDDLoc.Name = "CCDDLoc";
            this.CCDDLoc.Size = new System.Drawing.Size(150, 56);
            this.CCDDLoc.TabIndex = 0;
            this.CCDDLoc.Text = "单段";
            this.CCDDLoc.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.button12);
            this.panel3.Controls.Add(this.DD_VLTdel);
            this.panel3.Controls.Add(this.button10);
            this.panel3.Location = new System.Drawing.Point(123, 589);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1177, 68);
            this.panel3.TabIndex = 43;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(1041, 10);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 48);
            this.button3.TabIndex = 5;
            this.button3.Text = "一致";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(844, 10);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 48);
            this.button2.TabIndex = 4;
            this.button2.Text = "位置一致";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(648, 10);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 48);
            this.button1.TabIndex = 3;
            this.button1.Text = "速度一致";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button12.Location = new System.Drawing.Point(452, 10);
            this.button12.Margin = new System.Windows.Forms.Padding(2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(112, 48);
            this.button12.TabIndex = 2;
            this.button12.Text = "确认";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // DD_VLTdel
            // 
            this.DD_VLTdel.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DD_VLTdel.Location = new System.Drawing.Point(255, 10);
            this.DD_VLTdel.Margin = new System.Windows.Forms.Padding(2);
            this.DD_VLTdel.Name = "DD_VLTdel";
            this.DD_VLTdel.Size = new System.Drawing.Size(112, 48);
            this.DD_VLTdel.TabIndex = 1;
            this.DD_VLTdel.Text = "删除";
            this.DD_VLTdel.UseVisualStyleBackColor = true;
            this.DD_VLTdel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DD_VLTdel_MouseClick);
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button10.Location = new System.Drawing.Point(58, 10);
            this.button10.Margin = new System.Windows.Forms.Padding(2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(112, 48);
            this.button10.TabIndex = 0;
            this.button10.Text = "复制";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(161, 138);
            this.button49.Margin = new System.Windows.Forms.Padding(2);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(38, 40);
            this.button49.TabIndex = 17;
            this.button49.Text = "b";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button14.Location = new System.Drawing.Point(599, 676);
            this.button14.Margin = new System.Windows.Forms.Padding(2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(112, 48);
            this.button14.TabIndex = 44;
            this.button14.Text = "保存";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button15.Location = new System.Drawing.Point(9, 676);
            this.button15.Margin = new System.Windows.Forms.Padding(2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(112, 48);
            this.button15.TabIndex = 34;
            this.button15.Text = "返回";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(108, 138);
            this.button48.Margin = new System.Windows.Forms.Padding(2);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(38, 40);
            this.button48.TabIndex = 16;
            this.button48.Text = "*";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(57, 138);
            this.button47.Margin = new System.Windows.Forms.Padding(2);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(38, 40);
            this.button47.TabIndex = 15;
            this.button47.Text = ".";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(2, 138);
            this.button46.Margin = new System.Windows.Forms.Padding(2);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(38, 40);
            this.button46.TabIndex = 14;
            this.button46.Text = "0";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(161, 93);
            this.button45.Margin = new System.Windows.Forms.Padding(2);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(38, 40);
            this.button45.TabIndex = 13;
            this.button45.Text = "b";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(161, 48);
            this.button44.Margin = new System.Windows.Forms.Padding(2);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(38, 40);
            this.button44.TabIndex = 12;
            this.button44.Text = "b";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(161, 3);
            this.button43.Margin = new System.Windows.Forms.Padding(2);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(38, 40);
            this.button43.TabIndex = 11;
            this.button43.Text = "b";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(108, 93);
            this.button42.Margin = new System.Windows.Forms.Padding(2);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(38, 40);
            this.button42.TabIndex = 10;
            this.button42.Text = "9";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(108, 48);
            this.button41.Margin = new System.Windows.Forms.Padding(2);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(38, 40);
            this.button41.TabIndex = 9;
            this.button41.Text = "6";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button16.Location = new System.Drawing.Point(1322, 676);
            this.button16.Margin = new System.Windows.Forms.Padding(2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(112, 48);
            this.button16.TabIndex = 46;
            this.button16.Text = "回首页";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(108, 3);
            this.button40.Margin = new System.Windows.Forms.Padding(2);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(38, 40);
            this.button40.TabIndex = 8;
            this.button40.Text = "3";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button17.Location = new System.Drawing.Point(742, 676);
            this.button17.Margin = new System.Windows.Forms.Padding(2);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(112, 48);
            this.button17.TabIndex = 45;
            this.button17.Text = "场景";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.CCDanD_QX);
            this.panel1.Controls.Add(this.CCDanD_FF);
            this.panel1.Controls.Add(this.CCDDl);
            this.panel1.Controls.Add(this.CCDDLoc);
            this.panel1.Location = new System.Drawing.Point(459, 131);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(841, 459);
            this.panel1.TabIndex = 42;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.La_T);
            this.panel4.Controls.Add(this.La_L);
            this.panel4.Controls.Add(this.La_V);
            this.panel4.Controls.Add(this.DD_T);
            this.panel4.Controls.Add(this.DD_L);
            this.panel4.Controls.Add(this.DD_V);
            this.panel4.Location = new System.Drawing.Point(177, 250);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(247, 186);
            this.panel4.TabIndex = 29;
            // 
            // La_T
            // 
            this.La_T.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.La_T.Location = new System.Drawing.Point(158, 121);
            this.La_T.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.La_T.Name = "La_T";
            this.La_T.Size = new System.Drawing.Size(76, 47);
            this.La_T.TabIndex = 5;
            this.La_T.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // La_L
            // 
            this.La_L.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.La_L.Location = new System.Drawing.Point(159, 68);
            this.La_L.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.La_L.Name = "La_L";
            this.La_L.Size = new System.Drawing.Size(76, 47);
            this.La_L.TabIndex = 4;
            this.La_L.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // La_V
            // 
            this.La_V.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.La_V.Location = new System.Drawing.Point(159, 15);
            this.La_V.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.La_V.Name = "La_V";
            this.La_V.Size = new System.Drawing.Size(76, 47);
            this.La_V.TabIndex = 3;
            this.La_V.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DD_T
            // 
            this.DD_T.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DD_T.Location = new System.Drawing.Point(14, 121);
            this.DD_T.Margin = new System.Windows.Forms.Padding(2);
            this.DD_T.Name = "DD_T";
            this.DD_T.Size = new System.Drawing.Size(140, 46);
            this.DD_T.TabIndex = 2;
            this.DD_T.Text = "延时时间";
            this.DD_T.UseVisualStyleBackColor = true;
            this.DD_T.Click += new System.EventHandler(this.DD_T_Click);
            // 
            // DD_L
            // 
            this.DD_L.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DD_L.Location = new System.Drawing.Point(14, 68);
            this.DD_L.Margin = new System.Windows.Forms.Padding(2);
            this.DD_L.Name = "DD_L";
            this.DD_L.Size = new System.Drawing.Size(140, 46);
            this.DD_L.TabIndex = 1;
            this.DD_L.Text = "设定位置(上升)";
            this.DD_L.UseVisualStyleBackColor = true;
            this.DD_L.Click += new System.EventHandler(this.DD_L_Click);
            // 
            // DD_V
            // 
            this.DD_V.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DD_V.Location = new System.Drawing.Point(14, 15);
            this.DD_V.Margin = new System.Windows.Forms.Padding(2);
            this.DD_V.Name = "DD_V";
            this.DD_V.Size = new System.Drawing.Size(140, 46);
            this.DD_V.TabIndex = 0;
            this.DD_V.Text = "设定速度(下降)";
            this.DD_V.UseVisualStyleBackColor = true;
            this.DD_V.Click += new System.EventHandler(this.DD_V_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.button49);
            this.panel2.Controls.Add(this.button48);
            this.panel2.Controls.Add(this.button47);
            this.panel2.Controls.Add(this.button46);
            this.panel2.Controls.Add(this.button45);
            this.panel2.Controls.Add(this.button44);
            this.panel2.Controls.Add(this.button43);
            this.panel2.Controls.Add(this.button42);
            this.panel2.Controls.Add(this.button41);
            this.panel2.Controls.Add(this.button40);
            this.panel2.Controls.Add(this.button39);
            this.panel2.Controls.Add(this.button36);
            this.panel2.Controls.Add(this.button35);
            this.panel2.Controls.Add(this.button34);
            this.panel2.Controls.Add(this.button32);
            this.panel2.Controls.Add(this.button33);
            this.panel2.Controls.Add(this.button31);
            this.panel2.Location = new System.Drawing.Point(490, 250);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(203, 186);
            this.panel2.TabIndex = 28;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(57, 93);
            this.button39.Margin = new System.Windows.Forms.Padding(2);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(38, 40);
            this.button39.TabIndex = 7;
            this.button39.Text = "8";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(57, 48);
            this.button36.Margin = new System.Windows.Forms.Padding(2);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(38, 40);
            this.button36.TabIndex = 6;
            this.button36.Text = "5";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(57, 3);
            this.button35.Margin = new System.Windows.Forms.Padding(2);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(38, 40);
            this.button35.TabIndex = 5;
            this.button35.Text = "2";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(2, 93);
            this.button34.Margin = new System.Windows.Forms.Padding(2);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(38, 40);
            this.button34.TabIndex = 4;
            this.button34.Text = "7";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(2, 48);
            this.button32.Margin = new System.Windows.Forms.Padding(2);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(38, 40);
            this.button32.TabIndex = 3;
            this.button32.Text = "4";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(62, 0);
            this.button33.Margin = new System.Windows.Forms.Padding(2);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(0, 0);
            this.button33.TabIndex = 2;
            this.button33.Text = "button33";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(2, 3);
            this.button31.Margin = new System.Windows.Forms.Padding(2);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(38, 40);
            this.button31.TabIndex = 0;
            this.button31.Text = "1";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button18.Enabled = false;
            this.button18.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button18.Location = new System.Drawing.Point(314, 131);
            this.button18.Margin = new System.Windows.Forms.Padding(2);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(150, 50);
            this.button18.TabIndex = 41;
            this.button18.Text = "选中设备";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // DDXZSB
            // 
            this.DDXZSB.Font = new System.Drawing.Font("宋体", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DDXZSB.FormattingEnabled = true;
            this.DDXZSB.ItemHeight = 14;
            this.DDXZSB.Location = new System.Drawing.Point(314, 179);
            this.DDXZSB.Name = "DDXZSB";
            this.DDXZSB.ScrollAlwaysVisible = true;
            this.DDXZSB.Size = new System.Drawing.Size(150, 410);
            this.DDXZSB.TabIndex = 39;
            this.DDXZSB.SelectedIndexChanged += new System.EventHandler(this.DDXZSB_SelectedIndexChanged);
            // 
            // DDCue_List
            // 
            this.DDCue_List.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DDCue_List.FormattingEnabled = true;
            this.DDCue_List.ItemHeight = 16;
            this.DDCue_List.Location = new System.Drawing.Point(123, 131);
            this.DDCue_List.Name = "DDCue_List";
            this.DDCue_List.ScrollAlwaysVisible = true;
            this.DDCue_List.Size = new System.Drawing.Size(193, 452);
            this.DDCue_List.TabIndex = 37;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button21.Enabled = false;
            this.button21.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button21.Location = new System.Drawing.Point(123, 78);
            this.button21.Margin = new System.Windows.Forms.Padding(2);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(192, 55);
            this.button21.TabIndex = 35;
            this.button21.Text = "江姐";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(595, 7);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 27);
            this.label2.TabIndex = 33;
            this.label2.Text = "场次设置";
            // 
            // DDLabel
            // 
            this.DDLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DDLabel.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DDLabel.Location = new System.Drawing.Point(314, 78);
            this.DDLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DDLabel.Name = "DDLabel";
            this.DDLabel.Size = new System.Drawing.Size(988, 53);
            this.DDLabel.TabIndex = 47;
            this.DDLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _2changcidanduan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1443, 844);
            this.Controls.Add(this.DDLabel);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.DDXZSB);
            this.Controls.Add(this.DDCue_List);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button13);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "_2changcidanduan";
            this.Text = "_2changcidanduan";
            this.Load += new System.EventHandler(this._2changcidanduan_Load);
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button CCDanD_QX;
        private System.Windows.Forms.Button CCDanD_FF;
        private System.Windows.Forms.Button CCDDl;
        private System.Windows.Forms.Button CCDDLoc;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button DD_VLTdel;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.ListBox DDXZSB;
        private System.Windows.Forms.ListBox DDCue_List;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button DD_T;
        private System.Windows.Forms.Button DD_L;
        private System.Windows.Forms.Button DD_V;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label DDLabel;
        private System.Windows.Forms.Label La_T;
        private System.Windows.Forms.Label La_L;
        private System.Windows.Forms.Label La_V;
    }
}