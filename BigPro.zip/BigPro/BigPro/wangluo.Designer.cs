﻿namespace BigPro
{
    partial class wangluo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label192 = new System.Windows.Forms.Label();
            this.label191 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.label189 = new System.Windows.Forms.Label();
            this.label188 = new System.Windows.Forms.Label();
            this.label186 = new System.Windows.Forms.Label();
            this.label185 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.label183 = new System.Windows.Forms.Label();
            this.label182 = new System.Windows.Forms.Label();
            this.label181 = new System.Windows.Forms.Label();
            this.label180 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.label178 = new System.Windows.Forms.Label();
            this.label177 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.label175 = new System.Windows.Forms.Label();
            this.label174 = new System.Windows.Forms.Label();
            this.label173 = new System.Windows.Forms.Label();
            this.label172 = new System.Windows.Forms.Label();
            this.label171 = new System.Windows.Forms.Label();
            this.label170 = new System.Windows.Forms.Label();
            this.label169 = new System.Windows.Forms.Label();
            this.label167 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.WL_Back2Main = new System.Windows.Forms.Button();
            this.WL_Back = new System.Windows.Forms.Button();
            this.label105 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox61 = new System.Windows.Forms.PictureBox();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label193 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.label95 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.label160 = new System.Windows.Forms.Label();
            this.WL_TXTS = new System.Windows.Forms.Button();
            this.WL_TSTX = new System.Windows.Forms.Button();
            this.WL_ML = new System.Windows.Forms.Label();
            this.WL_TL = new System.Windows.Forms.Button();
            this.WL_TR = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            this.SuspendLayout();
            // 
            // label192
            // 
            this.label192.AutoSize = true;
            this.label192.Location = new System.Drawing.Point(565, 772);
            this.label192.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(0, 12);
            this.label192.TabIndex = 866;
            // 
            // label191
            // 
            this.label191.AutoSize = true;
            this.label191.Location = new System.Drawing.Point(1300, 730);
            this.label191.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(0, 12);
            this.label191.TabIndex = 865;
            // 
            // label190
            // 
            this.label190.AutoSize = true;
            this.label190.Location = new System.Drawing.Point(1185, 687);
            this.label190.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(47, 12);
            this.label190.TabIndex = 864;
            this.label190.Text = "操作台1";
            // 
            // label189
            // 
            this.label189.AutoSize = true;
            this.label189.Location = new System.Drawing.Point(919, 687);
            this.label189.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(47, 12);
            this.label189.TabIndex = 863;
            this.label189.Text = "操作台1";
            // 
            // label188
            // 
            this.label188.AutoSize = true;
            this.label188.Location = new System.Drawing.Point(689, 687);
            this.label188.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label188.Name = "label188";
            this.label188.Size = new System.Drawing.Size(47, 12);
            this.label188.TabIndex = 862;
            this.label188.Text = "操作台1";
            // 
            // label186
            // 
            this.label186.AutoSize = true;
            this.label186.Location = new System.Drawing.Point(423, 687);
            this.label186.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label186.Name = "label186";
            this.label186.Size = new System.Drawing.Size(23, 12);
            this.label186.TabIndex = 860;
            this.label186.Text = "CPU";
            // 
            // label185
            // 
            this.label185.AutoSize = true;
            this.label185.Location = new System.Drawing.Point(220, 351);
            this.label185.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(17, 12);
            this.label185.TabIndex = 859;
            this.label185.Text = "ET";
            // 
            // label184
            // 
            this.label184.AutoSize = true;
            this.label184.Location = new System.Drawing.Point(189, 192);
            this.label184.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(17, 12);
            this.label184.TabIndex = 858;
            this.label184.Text = "ET";
            // 
            // label183
            // 
            this.label183.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label183.Location = new System.Drawing.Point(1203, 734);
            this.label183.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(2, 35);
            this.label183.TabIndex = 857;
            // 
            // label182
            // 
            this.label182.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label182.Location = new System.Drawing.Point(945, 722);
            this.label182.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(2, 35);
            this.label182.TabIndex = 856;
            // 
            // label181
            // 
            this.label181.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label181.Location = new System.Drawing.Point(717, 712);
            this.label181.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(2, 35);
            this.label181.TabIndex = 855;
            // 
            // label180
            // 
            this.label180.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label180.Location = new System.Drawing.Point(423, 712);
            this.label180.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(2, 35);
            this.label180.TabIndex = 854;
            // 
            // label179
            // 
            this.label179.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label179.Location = new System.Drawing.Point(416, 722);
            this.label179.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(2, 35);
            this.label179.TabIndex = 853;
            // 
            // label178
            // 
            this.label178.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label178.Location = new System.Drawing.Point(405, 732);
            this.label178.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(2, 35);
            this.label178.TabIndex = 852;
            // 
            // label177
            // 
            this.label177.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label177.Location = new System.Drawing.Point(405, 767);
            this.label177.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(800, 2);
            this.label177.TabIndex = 851;
            // 
            // label176
            // 
            this.label176.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label176.Location = new System.Drawing.Point(416, 756);
            this.label176.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(530, 2);
            this.label176.TabIndex = 850;
            // 
            // label175
            // 
            this.label175.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label175.Location = new System.Drawing.Point(423, 747);
            this.label175.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(296, 2);
            this.label175.TabIndex = 849;
            // 
            // label174
            // 
            this.label174.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label174.Location = new System.Drawing.Point(220, 702);
            this.label174.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label174.Name = "label174";
            this.label174.Size = new System.Drawing.Size(190, 2);
            this.label174.TabIndex = 844;
            // 
            // label173
            // 
            this.label173.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label173.Location = new System.Drawing.Point(167, 712);
            this.label173.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(250, 2);
            this.label173.TabIndex = 843;
            // 
            // label172
            // 
            this.label172.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label172.Location = new System.Drawing.Point(110, 722);
            this.label172.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label172.Name = "label172";
            this.label172.Size = new System.Drawing.Size(290, 2);
            this.label172.TabIndex = 842;
            // 
            // label171
            // 
            this.label171.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label171.Location = new System.Drawing.Point(220, 622);
            this.label171.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label171.Name = "label171";
            this.label171.Size = new System.Drawing.Size(2, 82);
            this.label171.TabIndex = 841;
            // 
            // label170
            // 
            this.label170.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label170.Location = new System.Drawing.Point(167, 457);
            this.label170.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label170.Name = "label170";
            this.label170.Size = new System.Drawing.Size(2, 255);
            this.label170.TabIndex = 840;
            // 
            // label169
            // 
            this.label169.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label169.Location = new System.Drawing.Point(110, 296);
            this.label169.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label169.Name = "label169";
            this.label169.Size = new System.Drawing.Size(2, 428);
            this.label169.TabIndex = 839;
            // 
            // label167
            // 
            this.label167.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label167.Location = new System.Drawing.Point(204, 402);
            this.label167.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label167.Name = "label167";
            this.label167.Size = new System.Drawing.Size(2, 57);
            this.label167.TabIndex = 836;
            // 
            // label50
            // 
            this.label50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label50.Location = new System.Drawing.Point(875, 431);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(2, 28);
            this.label50.TabIndex = 722;
            // 
            // label53
            // 
            this.label53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label53.Location = new System.Drawing.Point(775, 431);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(2, 28);
            this.label53.TabIndex = 718;
            // 
            // label56
            // 
            this.label56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label56.Location = new System.Drawing.Point(675, 431);
            this.label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(2, 28);
            this.label56.TabIndex = 714;
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label59.Location = new System.Drawing.Point(575, 431);
            this.label59.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(2, 28);
            this.label59.TabIndex = 710;
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label62.Location = new System.Drawing.Point(475, 431);
            this.label62.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(2, 28);
            this.label62.TabIndex = 706;
            // 
            // label152
            // 
            this.label152.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label152.Location = new System.Drawing.Point(375, 430);
            this.label152.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(2, 28);
            this.label152.TabIndex = 702;
            // 
            // label143
            // 
            this.label143.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label143.Location = new System.Drawing.Point(1475, 268);
            this.label143.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(2, 28);
            this.label143.TabIndex = 686;
            // 
            // label146
            // 
            this.label146.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label146.Location = new System.Drawing.Point(0, 0);
            this.label146.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(2, 28);
            this.label146.TabIndex = 682;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label31.Location = new System.Drawing.Point(1375, 268);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(2, 28);
            this.label31.TabIndex = 674;
            // 
            // label69
            // 
            this.label69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label69.Location = new System.Drawing.Point(1275, 268);
            this.label69.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(2, 28);
            this.label69.TabIndex = 670;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label19.Location = new System.Drawing.Point(1175, 268);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(2, 28);
            this.label19.TabIndex = 666;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label22.Location = new System.Drawing.Point(1075, 268);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(2, 28);
            this.label22.TabIndex = 662;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label25.Location = new System.Drawing.Point(975, 268);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(2, 28);
            this.label25.TabIndex = 658;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label10.Location = new System.Drawing.Point(875, 268);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(2, 28);
            this.label10.TabIndex = 654;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label13.Location = new System.Drawing.Point(775, 268);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(2, 28);
            this.label13.TabIndex = 650;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label16.Location = new System.Drawing.Point(675, 268);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(2, 28);
            this.label16.TabIndex = 646;
            // 
            // label142
            // 
            this.label142.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label142.Location = new System.Drawing.Point(168, 241);
            this.label142.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(2, 57);
            this.label142.TabIndex = 642;
            // 
            // WL_Back2Main
            // 
            this.WL_Back2Main.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.WL_Back2Main.Location = new System.Drawing.Point(1641, 912);
            this.WL_Back2Main.Margin = new System.Windows.Forms.Padding(2);
            this.WL_Back2Main.Name = "WL_Back2Main";
            this.WL_Back2Main.Size = new System.Drawing.Size(200, 70);
            this.WL_Back2Main.TabIndex = 640;
            this.WL_Back2Main.Text = "回首页";
            this.WL_Back2Main.UseVisualStyleBackColor = true;
            this.WL_Back2Main.Click += new System.EventHandler(this.WL_Back2Main_Click);
            // 
            // WL_Back
            // 
            this.WL_Back.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.WL_Back.Location = new System.Drawing.Point(50, 912);
            this.WL_Back.Margin = new System.Windows.Forms.Padding(2);
            this.WL_Back.Name = "WL_Back";
            this.WL_Back.Size = new System.Drawing.Size(200, 70);
            this.WL_Back.TabIndex = 639;
            this.WL_Back.Text = "返回";
            this.WL_Back.UseVisualStyleBackColor = true;
            this.WL_Back.Click += new System.EventHandler(this.WL_Back_Click);
            // 
            // label105
            // 
            this.label105.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label105.Location = new System.Drawing.Point(220, 620);
            this.label105.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(1500, 2);
            this.label105.TabIndex = 638;
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label65.Location = new System.Drawing.Point(168, 457);
            this.label65.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(1550, 2);
            this.label65.TabIndex = 637;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label34.Location = new System.Drawing.Point(110, 296);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(1600, 2);
            this.label34.TabIndex = 624;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(575, 268);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(2, 28);
            this.label7.TabIndex = 623;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(475, 268);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(2, 28);
            this.label4.TabIndex = 619;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(375, 268);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(2, 28);
            this.label3.TabIndex = 615;
            // 
            // pictureBox60
            // 
            this.pictureBox60.Image = global::BigPro.Properties.Resources.操作台;
            this.pictureBox60.Location = new System.Drawing.Point(902, 702);
            this.pictureBox60.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(75, 35);
            this.pictureBox60.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox60.TabIndex = 847;
            this.pictureBox60.TabStop = false;
            // 
            // pictureBox61
            // 
            this.pictureBox61.Image = global::BigPro.Properties.Resources.操作台;
            this.pictureBox61.Location = new System.Drawing.Point(1170, 702);
            this.pictureBox61.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox61.Name = "pictureBox61";
            this.pictureBox61.Size = new System.Drawing.Size(75, 35);
            this.pictureBox61.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox61.TabIndex = 848;
            this.pictureBox61.TabStop = false;
            // 
            // pictureBox59
            // 
            this.pictureBox59.Image = global::BigPro.Properties.Resources.操作台;
            this.pictureBox59.Location = new System.Drawing.Point(676, 702);
            this.pictureBox59.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(75, 35);
            this.pictureBox59.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox59.TabIndex = 846;
            this.pictureBox59.TabStop = false;
            // 
            // pictureBox58
            // 
            this.pictureBox58.Image = global::BigPro.Properties.Resources.cpu;
            this.pictureBox58.Location = new System.Drawing.Point(398, 700);
            this.pictureBox58.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(75, 35);
            this.pictureBox58.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox58.TabIndex = 845;
            this.pictureBox58.TabStop = false;
            // 
            // pictureBox48
            // 
            this.pictureBox48.Image = global::BigPro.Properties.Resources.et;
            this.pictureBox48.Location = new System.Drawing.Point(191, 365);
            this.pictureBox48.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(75, 35);
            this.pictureBox48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox48.TabIndex = 835;
            this.pictureBox48.TabStop = false;
            // 
            // pictureBox47
            // 
            this.pictureBox47.Image = global::BigPro.Properties.Resources.et;
            this.pictureBox47.Location = new System.Drawing.Point(160, 204);
            this.pictureBox47.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(75, 35);
            this.pictureBox47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox47.TabIndex = 641;
            this.pictureBox47.TabStop = false;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label38.Location = new System.Drawing.Point(1375, 430);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(2, 28);
            this.label38.TabIndex = 894;
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label41.Location = new System.Drawing.Point(1275, 430);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(2, 28);
            this.label41.TabIndex = 890;
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label44.Location = new System.Drawing.Point(1175, 430);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(2, 28);
            this.label44.TabIndex = 886;
            // 
            // label149
            // 
            this.label149.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label149.Location = new System.Drawing.Point(1075, 430);
            this.label149.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(2, 28);
            this.label149.TabIndex = 878;
            // 
            // label193
            // 
            this.label193.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label193.Location = new System.Drawing.Point(975, 430);
            this.label193.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label193.Name = "label193";
            this.label193.Size = new System.Drawing.Size(2, 28);
            this.label193.TabIndex = 874;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label47.Location = new System.Drawing.Point(1475, 430);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(2, 28);
            this.label47.TabIndex = 898;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label35.Location = new System.Drawing.Point(1475, 592);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(2, 28);
            this.label35.TabIndex = 957;
            // 
            // label72
            // 
            this.label72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label72.Location = new System.Drawing.Point(1375, 592);
            this.label72.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(2, 28);
            this.label72.TabIndex = 953;
            // 
            // label75
            // 
            this.label75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label75.Location = new System.Drawing.Point(1275, 592);
            this.label75.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(2, 28);
            this.label75.TabIndex = 949;
            // 
            // label78
            // 
            this.label78.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label78.Location = new System.Drawing.Point(1175, 592);
            this.label78.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(2, 28);
            this.label78.TabIndex = 945;
            // 
            // label84
            // 
            this.label84.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label84.Location = new System.Drawing.Point(1075, 592);
            this.label84.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(2, 28);
            this.label84.TabIndex = 937;
            // 
            // label87
            // 
            this.label87.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label87.Location = new System.Drawing.Point(975, 592);
            this.label87.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(2, 28);
            this.label87.TabIndex = 933;
            // 
            // label90
            // 
            this.label90.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label90.Location = new System.Drawing.Point(875, 592);
            this.label90.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(2, 28);
            this.label90.TabIndex = 929;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(251, 515);
            this.label93.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(17, 12);
            this.label93.TabIndex = 925;
            this.label93.Text = "ET";
            // 
            // label94
            // 
            this.label94.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label94.Location = new System.Drawing.Point(228, 564);
            this.label94.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(2, 57);
            this.label94.TabIndex = 924;
            // 
            // pictureBox31
            // 
            this.pictureBox31.Image = global::BigPro.Properties.Resources.et;
            this.pictureBox31.Location = new System.Drawing.Point(222, 528);
            this.pictureBox31.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(75, 35);
            this.pictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox31.TabIndex = 923;
            this.pictureBox31.TabStop = false;
            // 
            // label95
            // 
            this.label95.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label95.Location = new System.Drawing.Point(775, 593);
            this.label95.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(2, 28);
            this.label95.TabIndex = 922;
            // 
            // label101
            // 
            this.label101.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label101.Location = new System.Drawing.Point(675, 593);
            this.label101.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(2, 28);
            this.label101.TabIndex = 914;
            // 
            // label104
            // 
            this.label104.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label104.Location = new System.Drawing.Point(575, 593);
            this.label104.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(2, 28);
            this.label104.TabIndex = 910;
            // 
            // label157
            // 
            this.label157.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label157.Location = new System.Drawing.Point(475, 593);
            this.label157.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(2, 28);
            this.label157.TabIndex = 906;
            // 
            // label160
            // 
            this.label160.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label160.Location = new System.Drawing.Point(375, 593);
            this.label160.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(2, 28);
            this.label160.TabIndex = 902;
            // 
            // WL_TXTS
            // 
            this.WL_TXTS.BackColor = System.Drawing.Color.White;
            this.WL_TXTS.Font = new System.Drawing.Font("宋体", 14.2F);
            this.WL_TXTS.Location = new System.Drawing.Point(963, 873);
            this.WL_TXTS.Margin = new System.Windows.Forms.Padding(2);
            this.WL_TXTS.Name = "WL_TXTS";
            this.WL_TXTS.Size = new System.Drawing.Size(112, 40);
            this.WL_TXTS.TabIndex = 1359;
            this.WL_TXTS.Text = "台下调速";
            this.WL_TXTS.UseVisualStyleBackColor = false;
            this.WL_TXTS.Click += new System.EventHandler(this.WL_TXTS_Click);
            // 
            // WL_TSTX
            // 
            this.WL_TSTX.BackColor = System.Drawing.Color.White;
            this.WL_TSTX.Font = new System.Drawing.Font("宋体", 14.2F);
            this.WL_TSTX.Location = new System.Drawing.Point(809, 873);
            this.WL_TSTX.Margin = new System.Windows.Forms.Padding(2);
            this.WL_TSTX.Name = "WL_TSTX";
            this.WL_TSTX.Size = new System.Drawing.Size(112, 40);
            this.WL_TSTX.TabIndex = 1358;
            this.WL_TSTX.Text = "台上调速";
            this.WL_TSTX.UseVisualStyleBackColor = false;
            this.WL_TSTX.Click += new System.EventHandler(this.WL_TSTX_Click);
            // 
            // WL_ML
            // 
            this.WL_ML.AutoSize = true;
            this.WL_ML.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.WL_ML.Location = new System.Drawing.Point(874, 31);
            this.WL_ML.Name = "WL_ML";
            this.WL_ML.Size = new System.Drawing.Size(106, 24);
            this.WL_ML.TabIndex = 1360;
            this.WL_ML.Text = "台上调速";
            // 
            // WL_TL
            // 
            this.WL_TL.ForeColor = System.Drawing.Color.Black;
            this.WL_TL.Image = global::BigPro.Properties.Resources.Toleft;
            this.WL_TL.Location = new System.Drawing.Point(11, 11);
            this.WL_TL.Margin = new System.Windows.Forms.Padding(2);
            this.WL_TL.Name = "WL_TL";
            this.WL_TL.Size = new System.Drawing.Size(50, 50);
            this.WL_TL.TabIndex = 3097;
            this.WL_TL.UseVisualStyleBackColor = true;
            this.WL_TL.Click += new System.EventHandler(this.WL_TL_Click);
            // 
            // WL_TR
            // 
            this.WL_TR.ForeColor = System.Drawing.Color.Black;
            this.WL_TR.Image = global::BigPro.Properties.Resources.ToRight;
            this.WL_TR.Location = new System.Drawing.Point(1842, 11);
            this.WL_TR.Margin = new System.Windows.Forms.Padding(2);
            this.WL_TR.Name = "WL_TR";
            this.WL_TR.Size = new System.Drawing.Size(50, 50);
            this.WL_TR.TabIndex = 3098;
            this.WL_TR.UseVisualStyleBackColor = true;
            this.WL_TR.Click += new System.EventHandler(this.WL_TR_Click);
            // 
            // wangluo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.WL_TR);
            this.Controls.Add(this.WL_TL);
            this.Controls.Add(this.WL_ML);
            this.Controls.Add(this.WL_TXTS);
            this.Controls.Add(this.WL_TSTX);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.label78);
            this.Controls.Add(this.label84);
            this.Controls.Add(this.label87);
            this.Controls.Add(this.label90);
            this.Controls.Add(this.label93);
            this.Controls.Add(this.label94);
            this.Controls.Add(this.pictureBox31);
            this.Controls.Add(this.label95);
            this.Controls.Add(this.label101);
            this.Controls.Add(this.label104);
            this.Controls.Add(this.label157);
            this.Controls.Add(this.label160);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label149);
            this.Controls.Add(this.label193);
            this.Controls.Add(this.label192);
            this.Controls.Add(this.label191);
            this.Controls.Add(this.label190);
            this.Controls.Add(this.label189);
            this.Controls.Add(this.label188);
            this.Controls.Add(this.label186);
            this.Controls.Add(this.label185);
            this.Controls.Add(this.label184);
            this.Controls.Add(this.pictureBox60);
            this.Controls.Add(this.pictureBox61);
            this.Controls.Add(this.label183);
            this.Controls.Add(this.label182);
            this.Controls.Add(this.pictureBox59);
            this.Controls.Add(this.label181);
            this.Controls.Add(this.pictureBox58);
            this.Controls.Add(this.label180);
            this.Controls.Add(this.label179);
            this.Controls.Add(this.label178);
            this.Controls.Add(this.label177);
            this.Controls.Add(this.label176);
            this.Controls.Add(this.label175);
            this.Controls.Add(this.label174);
            this.Controls.Add(this.label173);
            this.Controls.Add(this.label172);
            this.Controls.Add(this.label171);
            this.Controls.Add(this.label170);
            this.Controls.Add(this.label169);
            this.Controls.Add(this.label167);
            this.Controls.Add(this.pictureBox48);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label152);
            this.Controls.Add(this.label143);
            this.Controls.Add(this.label146);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label142);
            this.Controls.Add(this.pictureBox47);
            this.Controls.Add(this.WL_Back2Main);
            this.Controls.Add(this.WL_Back);
            this.Controls.Add(this.label105);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "wangluo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "wangluo";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.wangluo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label192;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.Label label186;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.Label label182;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.Label label171;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.Label label169;
        private System.Windows.Forms.Label label167;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.Button WL_Back2Main;
        private System.Windows.Forms.Button WL_Back;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label193;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Button WL_TXTS;
        private System.Windows.Forms.Button WL_TSTX;
        private System.Windows.Forms.Label WL_ML;
        private System.Windows.Forms.Button WL_TL;
        private System.Windows.Forms.Button WL_TR;
    }
}