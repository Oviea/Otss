﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class main : Form
    {
        DBB1 dBB1;
        int pcnum = 1;
        public main()
        {
           
            InitializeComponent();
        }
        static void WriteWS(string filePath, string writestr)
        {
            FileStream fs = new FileStream(filePath, FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            try
            {
                sw.WriteLine(writestr);
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine("Writing has been completed");
            }
            catch (IOException e)
            {
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine(e.ToString());
            }
        }
        private void button18_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            new chengkongjieru().Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!File.Exists("SBSD.txt"))
            {
                string strts = Interaction.InputBox("请输入调速设备数量", "调速设备数量设置", "调速设备数量", -1, -1);
                if (strts != "调速设备数量" && strts != "")
                {
                    ChangCiSheZhiGlobalData.N = int.Parse(strts);
                    WriteWS("SBSD.txt",strts);
                    string strtshs = Interaction.InputBox("请输入调速互锁类设备数量", "调速互锁类设备数量设置", "调速互锁设备数量", -1, -1);
                    if (strtshs != "调速设备数量" && strtshs != "")
                    {
                        ChangCiSheZhiGlobalData.K = int.Parse(strtshs);
                        WriteWS("SBSD.txt", strtshs);
                        string strdsdw = Interaction.InputBox("请输入定速定位类设备数量", "定速定位数量设置", "定速定位设备数量", -1, -1);
                        if (strdsdw != "调速设备数量" && strdsdw != "")
                        {
                            //ChangCiSheZhiGlobalData.M = int.Parse(strdsdw);
                            WriteWS("SBSD.txt", strdsdw);
                            string strds = Interaction.InputBox("请输入定速类设备数量", "定速数量设置", "定速设备数量", -1, -1);
                            if (strds != "调速设备数量" && strds != "")
                            {
                                WriteWS("SBSD.txt", strds);
                                int n= int.Parse(strts);
                                int k= int.Parse(strtshs);
                                int m = int.Parse(strdsdw);
                                int p = int.Parse(strds);
                                int t = n + m + k + p + 1;
                                ChangCiSheZhiGlobalData.A_SheBei = new bool[t];
                                ChangCiSheZhiGlobalData.B_SheBei = new bool[t];
                            }
                            else if (strds == "定速设备数量")
                            {
                                MessageBox.Show("请输入定速设备数量！");
                            }

                        }
                        else if (strdsdw == "定速定位设备数量")
                        {
                            MessageBox.Show("请输入定速定位设备数量！");
                        }

                    }
                    else if (strtshs == "调速互锁设备数量")
                    {
                        MessageBox.Show("请输入调速互锁设备数量！");
                    }
                }
                else if (strts == "调速设备数量")
                {
                    MessageBox.Show("请输入调速设备数量！");
                }
            }
            else
            {
                List<string> liness = new List<string>(File.ReadAllLines("SBSD.txt"));
                string[] ss = liness.ToArray();
                ChangCiSheZhiGlobalData.N = int.Parse(ss[0]);
                ChangCiSheZhiGlobalData.K = int.Parse(ss[1]);
                int n = int.Parse(ss[0]);
                int k = int.Parse(ss[1]);
                int m = int.Parse(ss[2]);
                int p = int.Parse(ss[3]);
                int t = n + m + k + p + 1;
                ChangCiSheZhiGlobalData.A_SheBei = new bool[t];
                ChangCiSheZhiGlobalData.B_SheBei = new bool[t];
            }

            int[] num = new int[4];
            List<string> lines = new List<string>(File.ReadAllLines("SBSD.txt"));
            for (int i = 0; i < 4; i++)
            {
                num[i] = Convert.ToInt32(lines[i]);


            }
            dBB1 = new DBB1(num[0], num[1], num[2], num[3]);
            dBB1.Table1();
            var frm = new jumu(this.dBB1);
            frm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var frm = new changjing();
            frm.Show();
            this.Hide();
           
        }

        private void main_Load(object sender, EventArgs e)
        {
           // this.FormBorderStyle = FormBorderStyle.None;
          //  this.TopMost = true;
            this.WindowState = FormWindowState.Maximized;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var frm = new dankong();
            frm.Show();
            

        }

        private void button6_Click(object sender, EventArgs e)
        {
            var frm = new dankongzhuangtai();
            frm.Show();
          
        }

        private void button7_Click(object sender, EventArgs e)
        {
            var frm = new bianpinqi();
            frm.Show();
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            var frm = new shuzhishezhi(this.dBB1);
            frm.Show();
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            var frm = new weizhizhuangtai();
            frm.Show();
         
        }

        private void button10_Click(object sender, EventArgs e)
        {
            var frm = new bangtu();
            frm.Show();
           
        }

        private void button12_Click(object sender, EventArgs e)
        {
            var frm = new wangluo();
            frm.Show();
            
        }

        private void button13_Click(object sender, EventArgs e)
        {
            var frm = new panglusheding();
            frm.Show();
            
        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            var f = new zaihequxian();
            f.Show();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            var f = new admin_operate();
            f .Show();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            new IO().Show();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            this.button20.BackColor = System.Drawing.SystemColors.Control;
            this.button19.BackColor = System.Drawing.SystemColors.Highlight;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            this.button20.BackColor = System.Drawing.SystemColors.Highlight;
            this.button19.BackColor = System.Drawing.SystemColors.Control;
        }
        void changeSize()
        {
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.OptimizedDoubleBuffer, true); // 双缓冲DoubleBuffer

            //main.projectUrl = Path.GetDirectoryName(Application.ExecutablePath);
            x = this.Width;
            y = this.Height;
            setTag(this);
            if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
            }
            else
            {
                this.FormBorderStyle = FormBorderStyle.None;
                this.WindowState = FormWindowState.Maximized;
            }
        }

        #region 控件大小随窗体大小等比例缩放
        private float x;//定义当前窗体的宽度
        private float y;//定义当前窗体的高度
        private void setTag(Control cons)
        {
            foreach (Control con in cons.Controls)
            {
                con.Tag = con.Width + ";" + con.Height + ";" + con.Left + ";" + con.Top + ";" + con.Font.Size;
                if (con.Controls.Count > 0)
                {
                    setTag(con);
                }
            }
        }
        //设置双缓冲区、解决闪屏问题
        public static void SetDouble(Control cc)
        {

            cc.GetType().GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance |
                         System.Reflection.BindingFlags.NonPublic).SetValue(cc, true, null);

        }
        private void setControls(float newx, float newy, Control cons)
        {
            //遍历窗体中的控件，重新设置控件的值
            foreach (Control con in cons.Controls)
            {
               
                SetDouble(this);
                SetDouble(con);
                if (con.Tag != null)
                {

                    string[] mytag = con.Tag.ToString().Split(new char[] { ';' });
                    //根据窗体缩放的比例确定控件的值
                    con.Width = Convert.ToInt32(System.Convert.ToSingle(mytag[0]) * newx);//宽度
                    con.Height = Convert.ToInt32(System.Convert.ToSingle(mytag[1]) * newy);//高度
                    con.Left = Convert.ToInt32(System.Convert.ToSingle(mytag[2]) * newx);//左边距
                    con.Top = Convert.ToInt32(System.Convert.ToSingle(mytag[3]) * newy);//顶边距
                    Single currentSize = System.Convert.ToSingle(mytag[4]) * newy;//字体大小
                    con.Font = new Font(con.Font.Name, currentSize, con.Font.Style, con.Font.Unit);
                    if (con.Controls.Count > 0)
                    {
                        setControls(newx, newy, con);
                    }
                }


            }
        }

        //在窗体的的时间中添加Resize事件
        private void Login_Resize(object sender, EventArgs e)
        {
            float newx = (this.Width) / x;
            float newy = (this.Height) / y;
            setControls(newx, newy, this);
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
#endregion