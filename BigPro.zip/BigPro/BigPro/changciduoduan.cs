﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class _2changciduoduan : Form
    {
        private static string JuTiJuMu;
        private static string JuTiChangCi;
        private static string JuTiSheBei;
        private static string WZ;
        private static string SD;
        public DBB1 dBB1;
        public _2changciduoduan(DBB1 dBB1)
        {
            this.dBB1 = dBB1;
            InitializeComponent();
        }
        static void WriteWS(string filePath, string writestr)
        {
            FileStream fs = new FileStream(filePath, FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            try
            {
                sw.WriteLine(writestr);
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine("Writing has been completed");
            }
            catch (IOException e)
            {
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine(e.ToString());
            }
        }
        static void WriteC(string filePath, string writestr)
        {
            FileStream fs = new FileStream(filePath, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            try
            {
                sw.WriteLine(writestr);
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine("Writing has been completed");
            }
            catch (IOException e)
            {
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine(e.ToString());
            }
        }
        private void _2changciduoduan_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.WindowState = FormWindowState.Maximized;
            JuTiJuMu = ChangCiSheZhiGlobalData.NageJuMu;
            JuTiChangCi = ChangCiSheZhiGlobalData.JuTiChangCi;
            JuTiSheBei = ChangCiSheZhiGlobalData.JuTiSheBei;
            if (!Directory.Exists(JuTiJuMu + "\\" + JuTiChangCi + "\\" + JuTiSheBei))
            {
                Directory.CreateDirectory(JuTiJuMu + "\\" + JuTiChangCi +  "\\" + JuTiSheBei);
            }
            if (File.Exists("" + JuTiJuMu + "\\" + JuTiJuMu + ".txt"))
            {
                //List<string> lines = new List<string>(File.ReadAllLines("" + JuTiJuMu + "\\" + JuTiJuMu + ".txt"));
                //foreach (string s in lines)
                //{
                //    DuoDCue_List.Items.Add(s);
                //}
                DuoDCue_List.Items.Add("场次:" + JuTiChangCi.Substring(2));
                DuoDXZSB.Items.Add(JuTiSheBei);
                DuoDLabel.Text = JuTiChangCi + "/" + JuTiSheBei;
            }
            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            // Console.WriteLine("%%%%"+sbsd[0].ToString());
            int j = 1;
            //for (int i = 0; i < int.Parse(sbsd[0].ToString()); i++)
            //{
            //    DuoD_Dx.Items.Add("调速设备" + j);
            //    j++;
            //}
            //j = 1;
            //for (int i = 0; i < int.Parse(sbsd[1].ToString()); i++)
            //{
            //    DuoD_Dx.Items.Add("调速互锁类设备" + j);
            //    j++;
            //}
            //j = 1;
            //for (int i = 0; i < int.Parse(sbsd[2].ToString()); i++)
            //{
            //    DuoD_Dx.Items.Add("定速定位设备" + j);
            //    j++;
            //}
            //j = 1;
            //for (int i = 0; i < int.Parse(sbsd[3].ToString()); i++)
            //{
            //    DuoD_Dx.Items.Add("定速设备" + j);
            //    j++;
            //}

        }

        private void button15_Click(object sender, EventArgs e)
        { 
            new _2changci(dBB1).Show();
            this.Close();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            new main().Show();
            this.Close();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            new changjing().Show();
        }

       

        private void DuoD_DS_Click(object sender, EventArgs e)
        {   
            string str = Interaction.InputBox("请输入段数", "输入段数", "段数", -1, -1);
            int zongds = int.Parse(str);
            if (str != "") {
                if (str != "段数")
                {
                    if (int.Parse(str) >= 1 && int.Parse(str) <= 4)
                    {
                        if (File.Exists(JuTiJuMu + "\\" + JuTiChangCi + "\\" + JuTiSheBei + "\\" + JuTiSheBei + "DuoDs" + ".txt"))
                        {
                            File.Delete(JuTiJuMu + "\\" + JuTiChangCi + "\\" + JuTiSheBei + "\\" + JuTiSheBei + "DuoDs" + ".txt");
                        }
                        if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
                        {
                            ChangCiSheZhiGlobalData.TSDuoDuanDS[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(str);
                            La_DS.Text = str;
                        }
                        else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
                        {
                            ChangCiSheZhiGlobalData.TSHSDuoDuanDS[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(str);
                            La_DS.Text = str;
                        }
                        else
                        {
                            MessageBox.Show("请选择设备！");
                        }
                       
                       
                        for (int i = 0; i < int.Parse(str); i++)
                        {
                            int j = i + 1;
                            string Endl = Interaction.InputBox("请输入段" + j + "末端位置", "输入末端位置", "末端位置", -1, -1);
                            if (Endl != "末端位置")
                            {
                                WZ = WZ + '#' + Endl;
                                string Dv = Interaction.InputBox("请输入段" + j + "速度", "输入速度", "速度", -1, -1);
                                if (Dv != "速度")
                                {
                                SD = SD + '#' + Dv;

                                    WriteWS(JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "DuoDs" + ".txt", Endl + " " + Dv);
                                }
                                else
                                {
                                    MessageBox.Show("请输入末端速度！");
                                }
                            }
                            else
                            {
                                MessageBox.Show("请输入末端位置！");
                            }

                        }
                        Console.WriteLine("WZWZ" + WZ);
                        Console.WriteLine("SDSD" + SD);
                        string[]weizhi=WZ.Split('#');
                        string[]sudu = SD.Split('#');
                        if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
                        {
                            switch (zongds)
                            {
                                case 1:
                                    ChangCiSheZhiGlobalData.TSwz1[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(weizhi[1]);
                                    break;
                                case 2:
                                    ChangCiSheZhiGlobalData.TSwz1[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(weizhi[1]);
                                    ChangCiSheZhiGlobalData.TSwz1[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(weizhi[2]);
                                    break;
                                case 3:
                                    ChangCiSheZhiGlobalData.TSwz1[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(weizhi[1]);
                                    ChangCiSheZhiGlobalData.TSwz1[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(weizhi[2]);
                                    ChangCiSheZhiGlobalData.TSwz1[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(weizhi[3]);
                                    break;
                                case 4:
                                    ChangCiSheZhiGlobalData.TSwz1[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(weizhi[1]);
                                    ChangCiSheZhiGlobalData.TSwz1[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(weizhi[2]);
                                    ChangCiSheZhiGlobalData.TSwz1[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(weizhi[3]);
                                    ChangCiSheZhiGlobalData.TSwz1[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(weizhi[4]);
                                    break;

                            }
          

                        }
                        else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
                        {
                            switch (zongds)
                            {
                                case 1:
                                    ChangCiSheZhiGlobalData.TSHSwz1[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(weizhi[1]);
                                    break;
                                case 2:
                                    ChangCiSheZhiGlobalData.TSHSwz1[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(weizhi[1]);
                                    ChangCiSheZhiGlobalData.TSHSwz1[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(weizhi[2]);
                                    break;
                                case 3:
                                    ChangCiSheZhiGlobalData.TSHSwz1[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(weizhi[1]);
                                    ChangCiSheZhiGlobalData.TSHSwz1[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(weizhi[2]);
                                    ChangCiSheZhiGlobalData.TSHSwz1[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(weizhi[3]);
                                    break;
                                case 4:
                                    ChangCiSheZhiGlobalData.TSHSwz1[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(weizhi[1]);
                                    ChangCiSheZhiGlobalData.TSHSwz1[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(weizhi[2]);
                                    ChangCiSheZhiGlobalData.TSHSwz1[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(weizhi[3]);
                                    ChangCiSheZhiGlobalData.TSHSwz1[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(weizhi[4]);
                                    break;

                            }
                      
                        }
                        else
                        {
                            MessageBox.Show("请选择设备！");
                        }

                    }
                    else
                    {
                        MessageBox.Show("段数不合法 1<=段数<=4");
                    }
                }
            }
            else
            {
                MessageBox.Show("请输入段数！");
            }
        }

        private void DuoD_Wz_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入设定位置", "设置设定位置", "设定位置", -1, -1);
            if (str != "")
            {
                if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
                {
                    ChangCiSheZhiGlobalData.TSDanDuanSDWZ[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(str);
                    La_DL.Text = str;
                }
                else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
                {
                    ChangCiSheZhiGlobalData.TSHSDuoDuanSDWZ[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(str);
                    La_DL.Text = str;
                }
                else
                {
                    MessageBox.Show("请选择设备！");
                }
                if (str != "设定位置")
                {
                    
                    WriteC(JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "DuoWZ" + ".txt", str);
                    MessageBox.Show("设置成功！");
                }
                else
                {
                    MessageBox.Show("请输入设定位置！");
                }
            }
        }

        private void DuoD_T_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入延时时间", "设置延时时间", "延时时间", -1, -1);
            if (str != "")
            {
                if (str != "延时时间")
                {
                    if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
                    {
                        ChangCiSheZhiGlobalData.TSDanDuanYSSJ[ChangCiSheZhiGlobalData.TSSheBeiIndex] = int.Parse(str);
                        La_DT.Text = str;
                    }
                    else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
                    {
                        ChangCiSheZhiGlobalData.TSHSDuoDuanYSSJ[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = int.Parse(str);
                        La_DT.Text = str;
                    }
                    else
                    {
                        MessageBox.Show("请选择设备！");
                    }
                    WriteC(JuTiJuMu + "\\" + JuTiChangCi + "\\" + JuTiSheBei + "\\" + JuTiSheBei + "DuoYS" + ".txt", str);
                    MessageBox.Show("设置成功！");
                }
                else
                {
                    MessageBox.Show("请输入延时时间！");
                }
            }
        }

        private void DuoD_DelData_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                DialogResult result = MessageBox.Show("确定删除吗？", "多段设定删除", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    File.Delete(JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "DuoDs" + ".txt");
                    File.Delete(JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "DuoWZ" + ".txt");
                    File.Delete(JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "DuoYS" + ".txt");


                }
            }
        }

        private void CCDuoD_DanD_Click(object sender, EventArgs e)
        {
            if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
            {
                ChangCiSheZhiGlobalData.TSDanDuanflag[ChangCiSheZhiGlobalData.TSSheBeiIndex] = true;

            }
            else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
            {
                ChangCiSheZhiGlobalData.TSHSDanDuanflag[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = true;
            }
            else
            {
                MessageBox.Show("请选择设备！");
            }
            var frm = new _2changcidanduan(dBB1);
            frm.Show();
            this.Close();
        }

        private void CCDuoD_FF_Click(object sender, EventArgs e)
        {
            if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
            {
                ChangCiSheZhiGlobalData.TSFanFuflag[ChangCiSheZhiGlobalData.TSSheBeiIndex] = true;

            }
            else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
            {
                ChangCiSheZhiGlobalData.TSHSFanFuflag[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = true;
            }
            else
            {
                MessageBox.Show("请选择设备！");
            }
            var frm = new _2changcifanfu(dBB1);
            frm.Show();
            this.Close();
        }

        private void CCDuoD_QX_Click(object sender, EventArgs e)
        {
            var frm = new _2changciquxian(dBB1);
            frm.Show();
            this.Close();
        }

        private void DuoDuanQR_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("数据设置确定？", "数值设定", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {

                if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
                {
                  dBB1.Tsduoduan(ChangCiSheZhiGlobalData.TSDuoDuanflag, ChangCiSheZhiGlobalData.TSDuoDuanDS, ChangCiSheZhiGlobalData.TSDuoDuanSDWZ, ChangCiSheZhiGlobalData.TSDuoDuanYSSJ, ChangCiSheZhiGlobalData.TSwz1,  ChangCiSheZhiGlobalData.TSwz2,  ChangCiSheZhiGlobalData.TSwz3, ChangCiSheZhiGlobalData.TSwz4, ChangCiSheZhiGlobalData.TSsd1, ChangCiSheZhiGlobalData.TSsd2, ChangCiSheZhiGlobalData.TSsd3, ChangCiSheZhiGlobalData.TSsd4);

                }
                else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
                {
                    dBB1.Tshsduoduan(ChangCiSheZhiGlobalData.TSHSDuoDuanflag, ChangCiSheZhiGlobalData.TSHSDuoDuanDS, ChangCiSheZhiGlobalData.TSHSDuoDuanSDWZ, ChangCiSheZhiGlobalData.TSHSDuoDuanYSSJ, ChangCiSheZhiGlobalData.TSHSwz1, ChangCiSheZhiGlobalData.TSHSwz2,ChangCiSheZhiGlobalData.TSHSwz3, ChangCiSheZhiGlobalData.TSHSwz4, ChangCiSheZhiGlobalData.TSHSsd1, ChangCiSheZhiGlobalData.TSHSsd2, ChangCiSheZhiGlobalData.TSHSsd3, ChangCiSheZhiGlobalData.TSHSsd4);

                }
            }
        }

        private void DuoDLabel_Click(object sender, EventArgs e)
        {

        }

        private void DuoD_Dx_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
