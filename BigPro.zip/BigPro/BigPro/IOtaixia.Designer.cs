﻿namespace BigPro
{
    partial class IOtaixia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.button45 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.label191 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button38 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.button39 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.button40 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.button31 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button34 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.button35 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.button33 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.button32 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.button30 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_home = new System.Windows.Forms.Button();
            this.btn_back = new System.Windows.Forms.Button();
            this.label115 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.button47 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.button46 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(488, 459);
            this.button28.Margin = new System.Windows.Forms.Padding(4);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(40, 38);
            this.button28.TabIndex = 1507;
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(367, 459);
            this.button29.Margin = new System.Windows.Forms.Padding(4);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(40, 38);
            this.button29.TabIndex = 1506;
            this.button29.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("宋体", 18F);
            this.label19.Location = new System.Drawing.Point(318, 403);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(268, 30);
            this.label19.TabIndex = 1505;
            this.label19.Text = "上升互锁 下降互锁";
            // 
            // button45
            // 
            this.button45.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button45.Location = new System.Drawing.Point(1243, 952);
            this.button45.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(220, 78);
            this.button45.TabIndex = 1502;
            this.button45.Text = "定速设备";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button36.Location = new System.Drawing.Point(1648, 969);
            this.button36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(150, 50);
            this.button36.TabIndex = 1500;
            this.button36.Text = "返回";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button37.Location = new System.Drawing.Point(117, 969);
            this.button37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(150, 50);
            this.button37.TabIndex = 1499;
            this.button37.Text = "回首页";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button41.Location = new System.Drawing.Point(977, 952);
            this.button41.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(220, 78);
            this.button41.TabIndex = 1498;
            this.button41.Text = "定速定位设备";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button42.Location = new System.Drawing.Point(427, 949);
            this.button42.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(220, 78);
            this.button42.TabIndex = 1497;
            this.button42.Text = "台上调速设备";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // label191
            // 
            this.label191.AutoSize = true;
            this.label191.Location = new System.Drawing.Point(1731, 926);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(0, 15);
            this.label191.TabIndex = 1496;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.Control;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("宋体", 12.2F);
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label9.Location = new System.Drawing.Point(306, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(1235, 73);
            this.label9.TabIndex = 1495;
            this.label9.Text = "设备I/O";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(1101, 830);
            this.button38.Margin = new System.Windows.Forms.Padding(0);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(124, 30);
            this.button38.TabIndex = 1492;
            this.button38.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 18F);
            this.label10.Location = new System.Drawing.Point(960, 830);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(133, 30);
            this.label10.TabIndex = 1491;
            this.label10.Text = "设定位置";
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(790, 830);
            this.button39.Margin = new System.Windows.Forms.Padding(0);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(124, 30);
            this.button39.TabIndex = 1490;
            this.button39.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 18F);
            this.label11.Location = new System.Drawing.Point(649, 830);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(133, 30);
            this.label11.TabIndex = 1489;
            this.label11.Text = "设定速度";
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(473, 830);
            this.button40.Margin = new System.Windows.Forms.Padding(0);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(124, 30);
            this.button40.TabIndex = 1488;
            this.button40.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("宋体", 18F);
            this.label12.Location = new System.Drawing.Point(332, 830);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(118, 30);
            this.label12.TabIndex = 1487;
            this.label12.Text = "控制字1";
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(1398, 734);
            this.button31.Margin = new System.Windows.Forms.Padding(0);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(124, 30);
            this.button31.TabIndex = 1486;
            this.button31.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 18F);
            this.label5.Location = new System.Drawing.Point(1257, 734);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 30);
            this.label5.TabIndex = 1485;
            this.label5.Text = "  载荷";
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(1101, 734);
            this.button34.Margin = new System.Windows.Forms.Padding(0);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(124, 30);
            this.button34.TabIndex = 1484;
            this.button34.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 18F);
            this.label6.Location = new System.Drawing.Point(960, 734);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 30);
            this.label6.TabIndex = 1483;
            this.label6.Text = "运行速度";
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(790, 734);
            this.button35.Margin = new System.Windows.Forms.Padding(0);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(124, 30);
            this.button35.TabIndex = 1482;
            this.button35.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 18F);
            this.label7.Location = new System.Drawing.Point(649, 734);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 30);
            this.label7.TabIndex = 1481;
            this.label7.Text = "  故障";
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(1398, 642);
            this.button33.Margin = new System.Windows.Forms.Padding(0);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(124, 30);
            this.button33.TabIndex = 1480;
            this.button33.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("宋体", 18F);
            this.label17.Location = new System.Drawing.Point(1257, 642);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(133, 30);
            this.label17.TabIndex = 1479;
            this.label17.Text = "运行电流";
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(1101, 642);
            this.button32.Margin = new System.Windows.Forms.Padding(0);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(124, 30);
            this.button32.TabIndex = 1478;
            this.button32.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("宋体", 18F);
            this.label16.Location = new System.Drawing.Point(960, 642);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(133, 30);
            this.label16.TabIndex = 1477;
            this.label16.Text = "运行位置";
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(790, 642);
            this.button30.Margin = new System.Windows.Forms.Padding(0);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(124, 30);
            this.button30.TabIndex = 1476;
            this.button30.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 18F);
            this.label4.Location = new System.Drawing.Point(649, 642);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 30);
            this.label4.TabIndex = 1475;
            this.label4.Text = "状态字2";
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button21.Location = new System.Drawing.Point(1441, 459);
            this.button21.Margin = new System.Windows.Forms.Padding(4);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(40, 38);
            this.button21.TabIndex = 1474;
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(1319, 459);
            this.button22.Margin = new System.Windows.Forms.Padding(4);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(40, 38);
            this.button22.TabIndex = 1473;
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(1166, 459);
            this.button23.Margin = new System.Windows.Forms.Padding(4);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(40, 38);
            this.button23.TabIndex = 1472;
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button24.Location = new System.Drawing.Point(1023, 459);
            this.button24.Margin = new System.Windows.Forms.Padding(4);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(40, 38);
            this.button24.TabIndex = 1471;
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(874, 459);
            this.button25.Margin = new System.Windows.Forms.Padding(4);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(40, 38);
            this.button25.TabIndex = 1470;
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.White;
            this.button26.Location = new System.Drawing.Point(753, 459);
            this.button26.Margin = new System.Windows.Forms.Padding(4);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(40, 38);
            this.button26.TabIndex = 1469;
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.White;
            this.button27.Location = new System.Drawing.Point(619, 459);
            this.button27.Margin = new System.Windows.Forms.Padding(4);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(40, 38);
            this.button27.TabIndex = 1468;
            this.button27.UseVisualStyleBackColor = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("宋体", 18F);
            this.label15.Location = new System.Drawing.Point(842, 403);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(658, 30);
            this.label15.TabIndex = 1467;
            this.label15.Text = "设备禁用   选通      旁路      上升    下降";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(1441, 349);
            this.button12.Margin = new System.Windows.Forms.Padding(4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(40, 38);
            this.button12.TabIndex = 1466;
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(1319, 349);
            this.button13.Margin = new System.Windows.Forms.Padding(4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(40, 38);
            this.button13.TabIndex = 1465;
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(1166, 349);
            this.button14.Margin = new System.Windows.Forms.Padding(4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(40, 38);
            this.button14.TabIndex = 1464;
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(1023, 349);
            this.button15.Margin = new System.Windows.Forms.Padding(4);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(40, 38);
            this.button15.TabIndex = 1463;
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(874, 349);
            this.button16.Margin = new System.Windows.Forms.Padding(4);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(40, 38);
            this.button16.TabIndex = 1462;
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(753, 349);
            this.button17.Margin = new System.Windows.Forms.Padding(4);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(40, 38);
            this.button17.TabIndex = 1461;
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(619, 349);
            this.button18.Margin = new System.Windows.Forms.Padding(4);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(40, 38);
            this.button18.TabIndex = 1460;
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(488, 349);
            this.button19.Margin = new System.Windows.Forms.Padding(4);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(40, 38);
            this.button19.TabIndex = 1459;
            this.button19.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 18F);
            this.label14.Location = new System.Drawing.Point(348, 293);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(1183, 30);
            this.label14.TabIndex = 1458;
            this.label14.Text = "乱绳    松绳 变频器报警 变频器断 同步超差  通道门1  通道门2   临边剪切  剪切  ";
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(367, 349);
            this.button20.Margin = new System.Windows.Forms.Padding(4);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(40, 38);
            this.button20.TabIndex = 1457;
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(723, 20);
            this.button11.Margin = new System.Windows.Forms.Padding(4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(40, 38);
            this.button11.TabIndex = 1456;
            this.button11.Text = "▼";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(568, 20);
            this.button10.Margin = new System.Windows.Forms.Padding(0);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(160, 38);
            this.button10.TabIndex = 1455;
            this.button10.Text = "台下调速设备";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(473, 642);
            this.button44.Margin = new System.Windows.Forms.Padding(0);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(124, 30);
            this.button44.TabIndex = 1454;
            this.button44.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 18F);
            this.label3.Location = new System.Drawing.Point(332, 642);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 30);
            this.label3.TabIndex = 1453;
            this.label3.Text = "状态字1";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(1441, 239);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(40, 38);
            this.button9.TabIndex = 1452;
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(1319, 239);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(40, 38);
            this.button8.TabIndex = 1451;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(1166, 239);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(40, 38);
            this.button7.TabIndex = 1450;
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(1023, 239);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(40, 38);
            this.button6.TabIndex = 1449;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(874, 239);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(40, 38);
            this.button5.TabIndex = 1448;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(753, 239);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(40, 38);
            this.button4.TabIndex = 1447;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(619, 239);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(40, 38);
            this.button3.TabIndex = 1446;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(488, 239);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(40, 38);
            this.button2.TabIndex = 1445;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 18F);
            this.label2.Location = new System.Drawing.Point(348, 183);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1183, 30);
            this.label2.TabIndex = 1444;
            this.label2.Text = "上限    下限    上极限   下极限   维修    制动故障  电阻过热  电机过热  超载  ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(367, 239);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(40, 38);
            this.button1.TabIndex = 1443;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("宋体", 20F);
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(-291, -107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1940, 62);
            this.label1.TabIndex = 1442;
            this.label1.Text = "台上调速设备I/O状态";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btn_home
            // 
            this.btn_home.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_home.Font = new System.Drawing.Font("宋体", 20F);
            this.btn_home.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn_home.Location = new System.Drawing.Point(1949, 1073);
            this.btn_home.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(267, 88);
            this.btn_home.TabIndex = 1441;
            this.btn_home.Text = "回首页";
            this.btn_home.UseVisualStyleBackColor = true;
            // 
            // btn_back
            // 
            this.btn_back.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_back.AutoSize = true;
            this.btn_back.Font = new System.Drawing.Font("宋体", 20F);
            this.btn_back.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn_back.Location = new System.Drawing.Point(-238, 1073);
            this.btn_back.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(267, 88);
            this.btn_back.TabIndex = 1440;
            this.btn_back.Text = "返回";
            this.btn_back.UseVisualStyleBackColor = true;
            // 
            // label115
            // 
            this.label115.BackColor = System.Drawing.SystemColors.Control;
            this.label115.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label115.Font = new System.Drawing.Font("宋体", 12.2F);
            this.label115.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label115.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label115.Location = new System.Drawing.Point(306, 142);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(1235, 384);
            this.label115.TabIndex = 1493;
            this.label115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("宋体", 12.2F);
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label8.Location = new System.Drawing.Point(306, 616);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(1235, 288);
            this.label8.TabIndex = 1494;
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.Font = new System.Drawing.Font("宋体", 20F);
            this.label18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label18.Location = new System.Drawing.Point(0, 20);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(1940, 62);
            this.label18.TabIndex = 1504;
            this.label18.Text = "台上调速设备I/O状态";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.SystemColors.Control;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Font = new System.Drawing.Font("宋体", 12.2F);
            this.label20.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label20.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label20.Location = new System.Drawing.Point(306, 526);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(1235, 63);
            this.label20.TabIndex = 1508;
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button47
            // 
            this.button47.Font = new System.Drawing.Font("宋体", 18F);
            this.button47.Location = new System.Drawing.Point(1080, 538);
            this.button47.Margin = new System.Windows.Forms.Padding(0);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(145, 40);
            this.button47.TabIndex = 1514;
            this.button47.Text = "设备类别";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("宋体", 18F);
            this.label23.Location = new System.Drawing.Point(695, 543);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(103, 30);
            this.label23.TabIndex = 1511;
            this.label23.Text = "互锁码";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("宋体", 18F);
            this.label24.Location = new System.Drawing.Point(332, 543);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(133, 30);
            this.label24.TabIndex = 1509;
            this.label24.Text = "互锁设备";
            // 
            // button46
            // 
            this.button46.Font = new System.Drawing.Font("宋体", 18F);
            this.button46.Location = new System.Drawing.Point(1336, 538);
            this.button46.Margin = new System.Windows.Forms.Padding(0);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(145, 40);
            this.button46.TabIndex = 1515;
            this.button46.Text = "查看";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Font = new System.Drawing.Font("宋体", 18F);
            this.button49.Location = new System.Drawing.Point(469, 538);
            this.button49.Margin = new System.Windows.Forms.Padding(0);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(145, 40);
            this.button49.TabIndex = 1516;
            this.button49.Text = "有/无";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Font = new System.Drawing.Font("宋体", 18F);
            this.button48.Location = new System.Drawing.Point(821, 538);
            this.button48.Margin = new System.Windows.Forms.Padding(0);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(145, 40);
            this.button48.TabIndex = 1517;
            this.button48.Text = "查看";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button43.Font = new System.Drawing.Font("宋体", 14.2F);
            this.button43.Location = new System.Drawing.Point(709, 949);
            this.button43.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(220, 78);
            this.button43.TabIndex = 1518;
            this.button43.Text = "台下调速设备";
            this.button43.UseVisualStyleBackColor = false;
            // 
            // IOtaixia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.label191);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_home);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.label115);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label20);
            this.Name = "IOtaixia";
            this.Text = "IOtaixia";
            this.Load += new System.EventHandler(this.IOtaixia_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_home;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button43;
    }
}