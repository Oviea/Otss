﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class SheBeiYingShe : Form
    {
        private static int allshebei;
        private static string[] shebei;
        private static int clickcount;
        private int n, k, m, p;
        public SheBeiYingShe()
        {
            InitializeComponent();
        }

        private void SheBeiYingShe_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                int t = totalshebei + 2;
                ChangCiSheZhiGlobalData.YingSheName = new string[t];
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                for(int i = 0; i < shebei.Length; i++)
                {
                    ChangCiSheZhiGlobalData.YingSheName[i + 1] = shebei[i];
                }
                //for(int i = 0; i < shebei.Length; i++)
                //{
                //    Console.WriteLine("++++++=+==" + shebei[i]);
                //}
                if (totalshebei <= 40)
                {
                    if (0 <= totalshebei && totalshebei <= 10)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                    }
                    else if (totalshebei > 10 && totalshebei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                    }
                    else if (totalshebei > 20 && totalshebei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                        for (int i = 30; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(130 + 170 * (i - 30), 550, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei = totalshebei - 40;
                }
            }
        }

        private void SBYS_ToLeft_Click(object sender, EventArgs e)
        {
            clickcount--;
            if (ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei >= allshebei - 40)
            {
                MessageBox.Show("没有更多已编组设备！");
                clickcount++;
                //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
            }
            else
            {
                delpanelall();

                for (int i = 0; i < 10; i++)
                {
                    panelset(130 + 170 * i, 250, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                for (int i = 10; i < 20; i++)
                {
                    panelset(130 + 170 * (i - 10), 350, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                for (int i = 20; i < 30; i++)
                {
                    panelset(130 + 170 * (i - 20), 450, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                for (int i = 30; i < 40; i++)
                {
                    panelset(130 + 170 * (i - 30), 550, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                if (ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei == 0)
                {
                    if (allshebei % 40 == 0)
                    {
                        ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei = 40;
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei = allshebei % 40;
                    }
                }
                else
                {
                    ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei = ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei + 40;
                }
            }
        }

        private void SBYS_ToRight_Click(object sender, EventArgs e)
        {
            clickcount++;
            if (ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei == 0)
            {
                MessageBox.Show("没有更多已编组设备！");
                // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                clickcount--;
            }
            else
            {
                delpanelall();
                if (ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei < 40)
                {

                    if (0 <= ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei && ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei <= 10)
                    {
                        for (int i = 0; i < ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                    }
                    else if (ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei > 10 && ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                        for (int i = 10; i < ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                        }
                    }
                    else if (ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei > 20 && ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                        }
                        for (int i = 20; i < ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[40 * clickcount + i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[40 * clickcount + i]);
                        }
                        for (int i = 30; i < ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[40 * clickcount + i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[40 * clickcount + i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(130 + 170 * (i - 30), 550, shebei[40 * clickcount + i]);
                    }
                    ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei = ChangCiSheZhiGlobalData.SheBeiYingSheShengYuSheBei - 40;
                }
            }
        }

        private void delpanelall()
        {
            if (Controls["SheBeiYingShe_Panel130250"] != null)
            {
                Controls["SheBeiYingShe_Panel130250"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel300250"] != null)
            {
                Controls["SheBeiYingShe_Panel300250"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel470250"] != null)
            {
                Controls["SheBeiYingShe_Panel470250"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel640250"] != null)
            {
                Controls["SheBeiYingShe_Panel640250"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel810250"] != null)
            {
                Controls["SheBeiYingShe_Panel810250"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel980250"] != null)
            {
                Controls["SheBeiYingShe_Panel980250"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1150250"] != null)
            {
                Controls["SheBeiYingShe_Panel1150250"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1320250"] != null)
            {
                Controls["SheBeiYingShe_Panel1320250"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1490250"] != null)
            {
                Controls["SheBeiYingShe_Panel1490250"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1660250"] != null)
            {
                Controls["SheBeiYingShe_Panel1660250"].Dispose();
            }


            if (Controls["SheBeiYingShe_Panel130350"] != null)
            {
                Controls["SheBeiYingShe_Panel130350"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel300350"] != null)
            {
                Controls["SheBeiYingShe_Panel300350"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel470350"] != null)
            {
                Controls["SheBeiYingShe_Panel470350"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel640350"] != null)
            {
                Controls["SheBeiYingShe_Panel640350"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel810350"] != null)
            {
                Controls["SheBeiYingShe_Panel810350"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel980350"] != null)
            {
                Controls["SheBeiYingShe_Panel980350"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1150350"] != null)
            {
                Controls["SheBeiYingShe_Panel1150350"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1320350"] != null)
            {
                Controls["SheBeiYingShe_Panel1320350"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1490350"] != null)
            {
                Controls["SheBeiYingShe_Panel1490350"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1660350"] != null)
            {
                Controls["SheBeiYingShe_Panel1660350"].Dispose();
            }


            if (Controls["SheBeiYingShe_Panel130450"] != null)
            {
                Controls["SheBeiYingShe_Panel130450"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel300450"] != null)
            {
                Controls["SheBeiYingShe_Panel300450"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel470450"] != null)
            {
                Controls["SheBeiYingShe_Panel470450"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel640450"] != null)
            {
                Controls["SheBeiYingShe_Panel640450"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel810450"] != null)
            {
                Controls["SheBeiYingShe_Panel810450"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel980450"] != null)
            {
                Controls["SheBeiYingShe_Panel980450"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1150450"] != null)
            {
                Controls["SheBeiYingShe_Panel1150450"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1320450"] != null)
            {
                Controls["SheBeiYingShe_Panel1320450"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1490450"] != null)
            {
                Controls["SheBeiYingShe_Panel1490450"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1660450"] != null)
            {
                Controls["SheBeiYingShe_Panel1660450"].Dispose();
            }

            if (Controls["SheBeiYingShe_Panel130550"] != null)
            {
                Controls["SheBeiYingShe_Panel130550"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel300550"] != null)
            {
                Controls["SheBeiYingShe_Panel300550"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel470550"] != null)
            {
                Controls["SheBeiYingShe_Panel470550"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel640550"] != null)
            {
                Controls["SheBeiYingShe_Panel640550"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel810550"] != null)
            {
                Controls["SheBeiYingShe_Panel810550"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel980550"] != null)
            {
                Controls["SheBeiYingShe_Panel980550"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1150550"] != null)
            {
                Controls["SheBeiYingShe_Panel1150550"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1320550"] != null)
            {
                Controls["SheBeiYingShe_Panel1320550"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1490550"] != null)
            {
                Controls["SheBeiYingShe_Panel1490550"].Dispose();
            }
            if (Controls["SheBeiYingShe_Panel1660550"] != null)
            {
                Controls["SheBeiYingShe_Panel1660550"].Dispose();
            }
        }

        private void YS_QR_Click(object sender, EventArgs e)
        {
            DialogResult result= MessageBox.Show("确定保存映射？", "映射", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(result== DialogResult.Yes)
            {
                if(File.Exists("" + "YS.txt"))
                {
                    File.Delete("" + "YS.txt");
                }
                string[] ys = new string[ChangCiSheZhiGlobalData.YingSheName.Length - 1]; 
                for(int i = 0; i < ys.Length; i++)
                {
                    ys[i] = ChangCiSheZhiGlobalData.YingSheName[i + 1];
                }
                File.WriteAllLines("" + "YS.txt",ys);
                MessageBox.Show("保存成功!");
            }
        }

        private void panelset(int x, int y, string shebeiname)
        {
            Button Shebei_YingShe = new Button();
            Shebei_YingShe.Font = new System.Drawing.Font("宋体", 10F);
            // Shebei_YingShe.Location = new System.Drawing.Point(1660, 550);
            Shebei_YingShe.Margin = new System.Windows.Forms.Padding(2);
            Shebei_YingShe.Name = shebeiname + x + y;
            Shebei_YingShe.Size = new System.Drawing.Size(90, 40);
            Shebei_YingShe.Text = shebeiname;
            Shebei_YingShe.UseVisualStyleBackColor = true;
            Shebei_YingShe.Click += (e, a) => this.Shebei_YingShe(shebeiname,x,y);
            // 


            Panel SheBeiYingShe_Panel = new Panel();
            SheBeiYingShe_Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SheBeiYingShe_Panel.Controls.Add(Shebei_YingShe);
            SheBeiYingShe_Panel.Location = new System.Drawing.Point(x, y);
            SheBeiYingShe_Panel.Margin = new System.Windows.Forms.Padding(2);
            SheBeiYingShe_Panel.Name = "SheBeiYingShe_Panel" + x + y;
            SheBeiYingShe_Panel.Size = new System.Drawing.Size(91, 41);
            this.Controls.Add(SheBeiYingShe_Panel);
        }

        private void Shebei_YingShe(string shebeiname,int x,int y)
        {
            string yinstr = Interaction.InputBox("请输入映射名称", "映射名称设置", "映射名称", -1, -1);
            if (yinstr != "映射名称" && yinstr != "")
            {
                ChangCiSheZhiGlobalData.YingSheName[GetIndex(shebeiname)] = yinstr;
                if(Controls["SheBeiYingShe_Panel" + x+y] != null)
                {
                    Controls["SheBeiYingShe_Panel" + x + y].Controls[0].Text = yinstr;
                }
                MessageBox.Show(shebeiname + "映射为:" + yinstr);
            }
            else if (yinstr == "")
            {
                MessageBox.Show("请输入映射名!");
            }
            else if(yinstr == "映射名称")
            {
                ChangCiSheZhiGlobalData.YingSheName[GetIndex(shebeiname)] = shebeiname;
                MessageBox.Show(shebeiname + "映射为:" +shebeiname);
            }
        }

        public int GetIndex(string shebeiname)
        {
            if (shebeiname.Contains("调速设备"))
            {
                int i = int.Parse(shebeiname.Substring(4));
                return i;
            }
            else if (shebeiname.Contains("调速互锁类设备"))
            {
                int i = int.Parse(shebeiname.Substring(7));
                return i + n;
            }
            else if (shebeiname.Contains("定速定位设备"))
            {
                int i = int.Parse(shebeiname.Substring(6));
                return i + n + k;
            }
            else if (shebeiname.Contains("定速设备"))
            {
                int i = int.Parse(shebeiname.Substring(4));
                return i + n + k + m;
            }
            return 0;
        }
    }
}
