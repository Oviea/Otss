﻿namespace BigPro
{
    partial class shuzhishezhi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.ToLeft_SZ = new System.Windows.Forms.Button();
            this.ToRight_SZ = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button32 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.Bt_P = new System.Windows.Forms.Button();
            this.Bt_K = new System.Windows.Forms.Button();
            this.Bt_M = new System.Windows.Forms.Button();
            this.Bt_N = new System.Windows.Forms.Button();
            this.SHQR = new System.Windows.Forms.Button();
            this.AllowEdit_Button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1425, 848);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 12);
            this.label3.TabIndex = 438;
            // 
            // ToLeft_SZ
            // 
            this.ToLeft_SZ.ForeColor = System.Drawing.Color.Black;
            this.ToLeft_SZ.Image = global::BigPro.Properties.Resources.Toleft;
            this.ToLeft_SZ.Location = new System.Drawing.Point(9, 9);
            this.ToLeft_SZ.Margin = new System.Windows.Forms.Padding(2);
            this.ToLeft_SZ.Name = "ToLeft_SZ";
            this.ToLeft_SZ.Size = new System.Drawing.Size(50, 50);
            this.ToLeft_SZ.TabIndex = 437;
            this.ToLeft_SZ.UseVisualStyleBackColor = true;
            this.ToLeft_SZ.Click += new System.EventHandler(this.ToLeft_SZ_Click);
            // 
            // ToRight_SZ
            // 
            this.ToRight_SZ.ForeColor = System.Drawing.Color.Black;
            this.ToRight_SZ.Image = global::BigPro.Properties.Resources.ToRight;
            this.ToRight_SZ.Location = new System.Drawing.Point(1825, 9);
            this.ToRight_SZ.Margin = new System.Windows.Forms.Padding(2);
            this.ToRight_SZ.Name = "ToRight_SZ";
            this.ToRight_SZ.Size = new System.Drawing.Size(50, 50);
            this.ToRight_SZ.TabIndex = 436;
            this.ToRight_SZ.UseVisualStyleBackColor = true;
            this.ToRight_SZ.Click += new System.EventHandler(this.ToRight_SZ_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1658, 332);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 12);
            this.label2.TabIndex = 435;
            // 
            // button32
            // 
            this.button32.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button32.Location = new System.Drawing.Point(27, 848);
            this.button32.Margin = new System.Windows.Forms.Padding(2);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(200, 70);
            this.button32.TabIndex = 434;
            this.button32.Text = "返回";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button29
            // 
            this.button29.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button29.Location = new System.Drawing.Point(1694, 848);
            this.button29.Margin = new System.Windows.Forms.Padding(2);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(200, 70);
            this.button29.TabIndex = 433;
            this.button29.Text = "回首页";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // Bt_P
            // 
            this.Bt_P.BackColor = System.Drawing.Color.White;
            this.Bt_P.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Bt_P.Location = new System.Drawing.Point(1156, 696);
            this.Bt_P.Margin = new System.Windows.Forms.Padding(2);
            this.Bt_P.Name = "Bt_P";
            this.Bt_P.Size = new System.Drawing.Size(150, 56);
            this.Bt_P.TabIndex = 432;
            this.Bt_P.Text = "台下调速";
            this.Bt_P.UseVisualStyleBackColor = false;
            this.Bt_P.Click += new System.EventHandler(this.Bt_P_Click);
            // 
            // Bt_K
            // 
            this.Bt_K.BackColor = System.Drawing.Color.White;
            this.Bt_K.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Bt_K.Location = new System.Drawing.Point(963, 696);
            this.Bt_K.Margin = new System.Windows.Forms.Padding(2);
            this.Bt_K.Name = "Bt_K";
            this.Bt_K.Size = new System.Drawing.Size(150, 56);
            this.Bt_K.TabIndex = 431;
            this.Bt_K.Text = "台下设备";
            this.Bt_K.UseVisualStyleBackColor = false;
            this.Bt_K.Click += new System.EventHandler(this.Bt_K_Click);
            // 
            // Bt_M
            // 
            this.Bt_M.BackColor = System.Drawing.Color.White;
            this.Bt_M.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Bt_M.Location = new System.Drawing.Point(771, 696);
            this.Bt_M.Margin = new System.Windows.Forms.Padding(2);
            this.Bt_M.Name = "Bt_M";
            this.Bt_M.Size = new System.Drawing.Size(150, 56);
            this.Bt_M.TabIndex = 430;
            this.Bt_M.Text = "台上其他";
            this.Bt_M.UseVisualStyleBackColor = false;
            this.Bt_M.Click += new System.EventHandler(this.Bt_M_Click);
            // 
            // Bt_N
            // 
            this.Bt_N.BackColor = System.Drawing.Color.White;
            this.Bt_N.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Bt_N.Location = new System.Drawing.Point(577, 696);
            this.Bt_N.Margin = new System.Windows.Forms.Padding(2);
            this.Bt_N.Name = "Bt_N";
            this.Bt_N.Size = new System.Drawing.Size(150, 56);
            this.Bt_N.TabIndex = 429;
            this.Bt_N.Text = "吊灯灯杆";
            this.Bt_N.UseVisualStyleBackColor = false;
            this.Bt_N.Click += new System.EventHandler(this.Bt_N_Click);
            // 
            // SHQR
            // 
            this.SHQR.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SHQR.Location = new System.Drawing.Point(1064, 13);
            this.SHQR.Margin = new System.Windows.Forms.Padding(2);
            this.SHQR.Name = "SHQR";
            this.SHQR.Size = new System.Drawing.Size(150, 56);
            this.SHQR.TabIndex = 427;
            this.SHQR.Text = "确认";
            this.SHQR.UseVisualStyleBackColor = true;
            this.SHQR.Click += new System.EventHandler(this.SHQR_Click);
            // 
            // AllowEdit_Button
            // 
            this.AllowEdit_Button.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AllowEdit_Button.Location = new System.Drawing.Point(740, 13);
            this.AllowEdit_Button.Margin = new System.Windows.Forms.Padding(2);
            this.AllowEdit_Button.Name = "AllowEdit_Button";
            this.AllowEdit_Button.Size = new System.Drawing.Size(150, 56);
            this.AllowEdit_Button.TabIndex = 426;
            this.AllowEdit_Button.Text = "允许";
            this.AllowEdit_Button.UseVisualStyleBackColor = false;
            this.AllowEdit_Button.Click += new System.EventHandler(this.AllowEdit_Button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 20F);
            this.label1.Location = new System.Drawing.Point(923, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 27);
            this.label1.TabIndex = 428;
            this.label1.Text = "数值设置";
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView1.Location = new System.Drawing.Point(281, 123);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView1.Size = new System.Drawing.Size(1352, 115);
            this.dataGridView1.TabIndex = 439;
            this.dataGridView1.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView2.Location = new System.Drawing.Point(281, 310);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView2.Size = new System.Drawing.Size(1352, 115);
            this.dataGridView2.TabIndex = 440;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AllowUserToResizeColumns = false;
            this.dataGridView3.AllowUserToResizeRows = false;
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView3.Location = new System.Drawing.Point(281, 497);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView3.Size = new System.Drawing.Size(1352, 115);
            this.dataGridView3.TabIndex = 441;
            // 
            // shuzhishezhi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ToLeft_SZ);
            this.Controls.Add(this.ToRight_SZ);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.Bt_P);
            this.Controls.Add(this.Bt_K);
            this.Controls.Add(this.Bt_M);
            this.Controls.Add(this.Bt_N);
            this.Controls.Add(this.SHQR);
            this.Controls.Add(this.AllowEdit_Button);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "shuzhishezhi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "shuzhishezhi";
            this.Load += new System.EventHandler(this.shuzhishezhi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button ToLeft_SZ;
        private System.Windows.Forms.Button ToRight_SZ;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button Bt_P;
        private System.Windows.Forms.Button Bt_K;
        private System.Windows.Forms.Button Bt_M;
        private System.Windows.Forms.Button Bt_N;
        private System.Windows.Forms.Button SHQR;
        private System.Windows.Forms.Button AllowEdit_Button;
        private System.Windows.Forms.Label label1;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView2;
    }
}