﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class _2changciquxian : Form
    {
        private static string JuTiJuMu;
        private static string JuTiChangCi;
        private static string JuTiSheBei;
        static void WriteWS(string filePath, string writestr)
        {
            FileStream fs = new FileStream(filePath, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            try
            {
                sw.WriteLine(writestr);
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine("Writing has been completed");
            }
            catch (IOException e)
            {
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine(e.ToString());
            }
        }
        public DBB1 dBB1;
        public _2changciquxian(DBB1 dBB1)
        {
            this.dBB1 = dBB1;
            InitializeComponent();
        }

        private void _2changciquxian_Load(object sender, EventArgs e)
        {

            JuTiJuMu = ChangCiSheZhiGlobalData.NageJuMu;
            JuTiChangCi = ChangCiSheZhiGlobalData.JuTiChangCi;
            JuTiSheBei = ChangCiSheZhiGlobalData.JuTiSheBei;
            if (!Directory.Exists("" + JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei))
            {
                Directory.CreateDirectory("" + JuTiJuMu + "\\" + JuTiChangCi + "\\" + JuTiSheBei);
            }
            if (File.Exists("" + JuTiJuMu + "\\" + JuTiJuMu + ".txt"))
            {
                //List<string> lines = new List<string>(File.ReadAllLines("" + JuTiJuMu + "\\" + JuTiJuMu + ".txt"));
                //foreach (string s in lines)
                //{
                //    QuXiCue_List.Items.Add(s);
                //}

                QuXiCue_List.Items.Add("场次:" + JuTiChangCi.Substring(2));
                QuXiXZSB.Items.Add(JuTiSheBei);
                QuXiLabel.Text = JuTiChangCi + "/"  + JuTiSheBei;
            }
            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            // Console.WriteLine("%%%%"+sbsd[0].ToString());
            int j = 1;
            for (int i = 0; i < int.Parse(sbsd[0].ToString()); i++)
            {
                QuX_Dx.Items.Add("调速设备" + j);
                j++;
            }
            j = 1;
            for (int i = 0; i < int.Parse(sbsd[1].ToString()); i++)
            {
                QuX_Dx.Items.Add("调速互锁类设备" + j);
                j++;
            }
            j = 1;
            for (int i = 0; i < int.Parse(sbsd[2].ToString()); i++)
            {
                QuX_Dx.Items.Add("定速定位设备" + j);
                j++;
            }
            j = 1;
            for (int i = 0; i < int.Parse(sbsd[3].ToString()); i++)
            {
                QuX_Dx.Items.Add("定速设备" + j);
                j++;
            }
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            new _2changci(dBB1).Show();
            this.Close();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            new main().Show();
            this.Close();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            new changjing().Show();
        }

        private void CCQX_DanD_Click(object sender, EventArgs e)
        {
            var frm = new _2changcidanduan(dBB1);
            frm.Show();
            this.Close();
        }

        private void CCQX_DuoD_Click(object sender, EventArgs e)
        {
            var frm = new _2changciduoduan(dBB1);
            frm.Show();
            this.Close();
        }

        private void CCQX_FF_Click(object sender, EventArgs e)
        {
            var frm = new _2changcifanfu(dBB1);
            frm.Show();
            this.Close();
        }
    }
}
