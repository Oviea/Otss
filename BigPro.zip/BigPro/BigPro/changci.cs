﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace BigPro
{
    public partial class _2changci : Form
    {
        private static string JuTiJuMu;
        private static string JuTiChangCi;
        private string CC_num;
        public DBB1 dBB1;
        public _2changci(DBB1 dBB1)
        {
            this.dBB1 = dBB1;
            InitializeComponent();
            JuTiJuMu = ChangCiSheZhiGlobalData.NageJuMu;
            JuTiChangCi = ChangCiSheZhiGlobalData.JuTiChangCi;
        //    WriteWS("" + JuTiChangCi + ".txt", "ceshiceshi");
        }
        static void WriteWS(string filePath, string writestr)
        {
            FileStream fs = new FileStream(filePath, FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            try
            {
                sw.WriteLine(writestr);
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine("Writing has been completed");
            }
            catch (IOException e)
            {
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine(e.ToString());
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
            {
                Console.WriteLine("INDEX" + ChangCiSheZhiGlobalData.TSSheBeiIndex);
                ChangCiSheZhiGlobalData.TSDanDuanflag[ChangCiSheZhiGlobalData.TSSheBeiIndex] = true;

            }
            else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
            {
                ChangCiSheZhiGlobalData.TSHSDanDuanflag[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = true;
            }
            else
            {
                MessageBox.Show("请选择设备！");
            }
            var frm = new _2changcidanduan(dBB1);
            frm.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
            {
                ChangCiSheZhiGlobalData.TSDuoDuanflag[ChangCiSheZhiGlobalData.TSSheBeiIndex] = true;

            }
            else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
            {
                ChangCiSheZhiGlobalData.TSHSDuoDuanflag[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = true;
            }
            else
            {
                MessageBox.Show("请选择设备！");
            }
            var frm = new _2changciduoduan(dBB1);
            frm.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
            {
                ChangCiSheZhiGlobalData.TSFanFuflag[ChangCiSheZhiGlobalData.TSSheBeiIndex] = true;

            }
            else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
            {
                ChangCiSheZhiGlobalData.TSHSFanFuflag[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = true;
            }
            else
            {
                MessageBox.Show("请选择设备！");
            }
            var frm = new _2changcifanfu(dBB1);
            frm.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            var frm = new _2changciquxian(dBB1);
            frm.Show();
            this.Hide();
        }

        private void _2changci_Load(object sender, EventArgs e)
        {
           // this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            ChangCiSheZhiGlobalData.TSDanDuanflag = new bool[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSDanDuanSDSD = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSDanDuanSDWZ = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSDanDuanYSSJ = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSDuoDuanDS = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSDuoDuanflag = new bool[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSDuoDuanSDWZ = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSDuoDuanYSSJ = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSsd1 = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSsd2 = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSsd3 = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSsd4 = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSwz1 = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSwz2 = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSwz3 = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSwz4 = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSFanFSDSD = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSFanFuCS = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSFanFuflag = new bool[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSFanFwz1 = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSFanFwz2 = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSFanFYSSJ = new int[ChangCiSheZhiGlobalData.N];
            ChangCiSheZhiGlobalData.TSHSDanDuanflag = new bool[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSDanDuanSDSD = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSDanDuanSDWZ = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSDanDuanYSSJ = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSDuoDuanDS = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSDuoDuanflag = new bool[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSsd1 = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSsd2 = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSsd3 = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSsd4 = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSwz1 = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSwz2 = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSwz3 = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSwz4 = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSDuoDuanSDWZ = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSDuoDuanYSSJ = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSFanFSDSD = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSFanFuCS = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSFanFuflag = new bool[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSFanFwz1 = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSFanFwz2 = new int[ChangCiSheZhiGlobalData.K];
            ChangCiSheZhiGlobalData.TSHSFanFYSSJ = new int[ChangCiSheZhiGlobalData.K];
            if (File.Exists("" + JuTiJuMu + "\\" + JuTiJuMu + ".txt"))
            {
                List<string> lines = new List<string>(File.ReadAllLines("" + JuTiJuMu + "\\" + JuTiJuMu + ".txt"));
                foreach (string s in lines)
                {
                    Cue_List.Items.Add(s);
                }
            }
            LBDX.Items.Clear();
            XZSB.Items.Clear();
            CC_num = ChangCiSheZhiGlobalData.JuTiChangCi.Substring(2);
            int num = int.Parse(CC_num);
            num = num - 1;
            // Cue_List.SetSelected(num, true);
            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt" ));
            // Console.WriteLine("%%%%"+sbsd[0].ToString());
            int j = 1;
            for(int i = 0; i < int.Parse(sbsd[0].ToString()); i++)
            {   
                LBDX.Items.Add("调速设备"+j);
                j++;
            }
            j = 1;
            for (int i = 0; i < int.Parse(sbsd[1].ToString()); i++)
            {
                LBDX.Items.Add("调速互锁类设备" + j);
                j++;
            }
            j = 1;
            for (int i = 0; i < int.Parse(sbsd[2].ToString()); i++)
            {    
                LBDX.Items.Add("定速定位设备" + j);
                j++;
            }
            j = 1;
            for (int i = 0; i < int.Parse(sbsd[3].ToString()); i++)
            {     
                LBDX.Items.Add("定速设备" + j);
                j++;
            }
            Cue_List.SelectedIndex = num;
            ShowCueName.Text = ChangCiSheZhiGlobalData.YingSheQianChangCi;
            // ShowCueName.Text = "ffff";
           // Cue_List.SetSelected(2, true);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            var f = new jumu(dBB1);
            f.Show();
            this.Close();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            new changjing().Show();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LBDX.SelectedIndex == -1)
            {
                return;
            }
            else
            {
                DialogResult result = MessageBox.Show("确定选择该设备吗？", "选择", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (XZSB.Items.IndexOf(LBDX.SelectedItem) == -1)
                    {
                        XZSB.Items.Add(LBDX.SelectedItem);
                        string s = LBDX.SelectedItem.ToString();
                        Console.WriteLine("@!@!@!@!@!@" + "" + JuTiJuMu + "\\" + JuTiChangCi + "\\" + s);
                        if (!Directory.Exists("" + JuTiJuMu + "\\" + JuTiChangCi + "\\" + s))
                        {
                            Directory.CreateDirectory("" + JuTiJuMu + "\\" + JuTiChangCi + "\\" + s);
                        }
                        WriteWS("" + JuTiJuMu + "\\" + JuTiChangCi + "\\" + JuTiChangCi + ".txt", LBDX.SelectedItem.ToString());
                        LBDX.Items.RemoveAt(LBDX.SelectedIndex);
                    }
                    else
                    {
                        MessageBox.Show("设备已经被选择!!!请选择其他设备!");
                    }
                }

            }
            LBDX.SelectedIndex = -1;
        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        public void XZSB_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right) {
                int Y = e.Y;
                DialogResult result = MessageBox.Show("确定删除该设备吗？", "设备删除", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    int currentIndex = e.Y / XZSB.ItemHeight;
                    Console.WriteLine("((((((((((("+currentIndex);
                    string delstr = XZSB.Items[currentIndex].ToString();
                    XZSB.Items.RemoveAt(currentIndex);
                    List<string> lines = new List<string>(File.ReadAllLines("" + JuTiJuMu + "\\" + JuTiChangCi +"\\"+ JuTiChangCi + ".txt"));
                    lines.RemoveAt(currentIndex);
                    File.WriteAllLines("" + JuTiJuMu + "\\" + JuTiChangCi + "\\" + JuTiChangCi + ".txt", lines.ToArray());
                    Directory.Delete("" + JuTiJuMu + "\\" + JuTiChangCi + "\\" +delstr,true);
                   
                }
            }
        }

        private void XZSB_SelectedIndexChanged(object sender, EventArgs e)
        {
               
            if (XZSB.SelectedIndex == -1)
            {
                return;
            }
            else
            {
                string shebei = XZSB.SelectedItem.ToString();
                if (shebei.Contains("调速设备"))
                {
                    int index = int.Parse(shebei.Substring(4));
                    Console.WriteLine("INNNNNDEXXXX"+index);
                    index = index - 1;
                    ChangCiSheZhiGlobalData.TSSheBeiIndex = index;
                    ChangCiSheZhiGlobalData.XuanZhongSheBei_Name = "调速设备";
                }
                else if (shebei.Contains("调速互锁类设备"))
                {
                    int index = int.Parse(shebei.Substring(7));
                    // Console.WriteLine("INNNNNDEXXXX"+index);
                    ChangCiSheZhiGlobalData.TSHSSheBeiIndex = index;
                    ChangCiSheZhiGlobalData.XuanZhongSheBei_Name = "调速互锁类设备";
                }
                Console.WriteLine("XXXX"+XZSB.SelectedIndex);
                ChangCiSheZhiGlobalData.NageJuMu = JuTiJuMu;
                ChangCiSheZhiGlobalData.JuTiChangCi = JuTiChangCi;
                ChangCiSheZhiGlobalData.JuTiSheBei = shebei;
                CC_DanD.Visible = true;
                CC_DuoD.Visible = true;
                CC_FanF.Visible = true;
                CC_QuX.Visible = true;
                CC_DangQ.Visible = true;

            }
            XZSB.SelectedIndex = -1;

        }

        

        private void Cue_List_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Cue_List.SelectedIndex == -1)
            {
                return;
            }
            else
            {
                // CueCount = 0;
                ShowCueName.Text = Cue_List.Items[Cue_List.SelectedIndex].ToString();
                string CC= Cue_List.Items[Cue_List.SelectedIndex].ToString();
                JuTiChangCi = "CC" + CC.Substring(3);
                ChangCiSheZhiGlobalData.JuTiChangCi = JuTiChangCi;
                XZSB.Items.Clear();
                //CueCount = readFileLines("" + JuTiJuMu + "\\" + JuTiChangCi+"\\" + JuTiChangCi + ".txt");
                if (File.Exists("" + JuTiJuMu + "\\" + JuTiChangCi+ "\\"+JuTiChangCi + ".txt"))
                {
                    List<string> lines = new List<string>(File.ReadAllLines("" + JuTiJuMu + "\\" + JuTiChangCi + "\\" + JuTiChangCi + ".txt"));
                    foreach (string s in lines)
                    {  
                        XZSB.Items.Add(s);
                        LBDX.Items.Remove(s);
                    }

                }
                else
                {
                    LBDX.Items.Clear();
                    List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
                    // Console.WriteLine("%%%%"+sbsd[0].ToString());
                    int j = 1;
                    for (int i = 0; i < int.Parse(sbsd[0].ToString()); i++)
                    {
                        LBDX.Items.Add("调速设备" + j);
                        j++;
                    }
                    j = 1;
                    for (int i = 0; i < int.Parse(sbsd[1].ToString()); i++)
                    {
                        LBDX.Items.Add("调速互锁类设备" + j);
                        j++;
                    }
                    j = 1;
                    for (int i = 0; i < int.Parse(sbsd[2].ToString()); i++)
                    {
                        LBDX.Items.Add("定速定位设备" + j);
                        j++;
                    }
                    j = 1;
                    for (int i = 0; i < int.Parse(sbsd[3].ToString()); i++)
                    {
                        LBDX.Items.Add("定速设备" + j);
                        j++;
                    }
                }
            }
            Cue_List.SelectedIndex = -1;
        }

       
        public static int readFileLines(string path)  //这里的参数是txt所在路径
        {
            int lines = 0;  //用来统计txt行数
            FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamReader sr = new StreamReader(fs);
            while (sr.ReadLine() != null)
            {

                lines++;
            }

            fs.Close();
            sr.Close();

            return lines;

        }

        private void Back_2_JuMu_Click(object sender, EventArgs e)
        {
            var frm = new jumu(dBB1);
            frm.Show();
            this.Close();
        }

        private void Back_2_Sy_Click(object sender, EventArgs e)
        {
            var frm = new main();
            frm.Show();
            this.Close();
        }

        private void ChangCi_QR_Click(object sender, EventArgs e)
        {
            //System.Diagnostics.Stopwatch stopwatch = new Stopwatch();
            //stopwatch.Start(); //  开始监视代码运行时间
            //this.dBB1.writer();                  //  需要测试的代码 ....
            //stopwatch.Stop(); //  停止监视
            //TimeSpan timespan = stopwatch.Elapsed; //  获取当前实例测量得出的总时间
            //double milliseconds = timespan.TotalMilliseconds;  //  总毫秒数
            //Console.WriteLine("ms:" + milliseconds);
        }

        private void Cue_List_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            //if the item state is selected them change the back color 
            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                e = new DrawItemEventArgs(e.Graphics, e.Font, e.Bounds, e.Index, e.State ^ DrawItemState.Selected, e.ForeColor, Color.LightBlue);//Choose the color

            // Draw the background of the ListBox control for each item.
            e.DrawBackground();
            // Draw the current item text
            e.Graphics.DrawString(Cue_List.Items[e.Index].ToString(),e.Font, Brushes.Black, e.Bounds,StringFormat.GenericDefault);
            // If the ListBox has focus,draw a focus rectangle around the selected item.
            e.DrawFocusRectangle();
        }
    }
}
