﻿namespace BigPro
{
    partial class SheBeiYingShe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SBYS_ToLeft = new System.Windows.Forms.Button();
            this.SBYS_ToRight = new System.Windows.Forms.Button();
            this.SBYS_MainPage = new System.Windows.Forms.Button();
            this.SBYS_Back = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.YS_QR = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // SBYS_ToLeft
            // 
            this.SBYS_ToLeft.ForeColor = System.Drawing.Color.Black;
            this.SBYS_ToLeft.Image = global::BigPro.Properties.Resources.Toleft;
            this.SBYS_ToLeft.Location = new System.Drawing.Point(11, 11);
            this.SBYS_ToLeft.Margin = new System.Windows.Forms.Padding(2);
            this.SBYS_ToLeft.Name = "SBYS_ToLeft";
            this.SBYS_ToLeft.Size = new System.Drawing.Size(50, 50);
            this.SBYS_ToLeft.TabIndex = 462;
            this.SBYS_ToLeft.UseVisualStyleBackColor = true;
            this.SBYS_ToLeft.Click += new System.EventHandler(this.SBYS_ToLeft_Click);
            // 
            // SBYS_ToRight
            // 
            this.SBYS_ToRight.ForeColor = System.Drawing.Color.Black;
            this.SBYS_ToRight.Image = global::BigPro.Properties.Resources.ToRight;
            this.SBYS_ToRight.Location = new System.Drawing.Point(1856, 15);
            this.SBYS_ToRight.Margin = new System.Windows.Forms.Padding(2);
            this.SBYS_ToRight.Name = "SBYS_ToRight";
            this.SBYS_ToRight.Size = new System.Drawing.Size(50, 50);
            this.SBYS_ToRight.TabIndex = 459;
            this.SBYS_ToRight.UseVisualStyleBackColor = true;
            this.SBYS_ToRight.Click += new System.EventHandler(this.SBYS_ToRight_Click);
            // 
            // SBYS_MainPage
            // 
            this.SBYS_MainPage.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SBYS_MainPage.Location = new System.Drawing.Point(1773, 932);
            this.SBYS_MainPage.Margin = new System.Windows.Forms.Padding(2);
            this.SBYS_MainPage.Name = "SBYS_MainPage";
            this.SBYS_MainPage.Size = new System.Drawing.Size(112, 40);
            this.SBYS_MainPage.TabIndex = 458;
            this.SBYS_MainPage.Text = "回首页";
            this.SBYS_MainPage.UseVisualStyleBackColor = true;
            // 
            // SBYS_Back
            // 
            this.SBYS_Back.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SBYS_Back.Location = new System.Drawing.Point(49, 932);
            this.SBYS_Back.Margin = new System.Windows.Forms.Padding(2);
            this.SBYS_Back.Name = "SBYS_Back";
            this.SBYS_Back.Size = new System.Drawing.Size(112, 40);
            this.SBYS_Back.TabIndex = 457;
            this.SBYS_Back.Text = "返回";
            this.SBYS_Back.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label4.Location = new System.Drawing.Point(1363, 665);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 19);
            this.label4.TabIndex = 455;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label2.Location = new System.Drawing.Point(-5, 133);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1940, 3);
            this.label2.TabIndex = 451;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(883, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 27);
            this.label1.TabIndex = 450;
            this.label1.Text = "设备映射";
            // 
            // YS_QR
            // 
            this.YS_QR.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.YS_QR.Location = new System.Drawing.Point(888, 918);
            this.YS_QR.Margin = new System.Windows.Forms.Padding(2);
            this.YS_QR.Name = "YS_QR";
            this.YS_QR.Size = new System.Drawing.Size(112, 40);
            this.YS_QR.TabIndex = 463;
            this.YS_QR.Text = "确认";
            this.YS_QR.UseVisualStyleBackColor = true;
            this.YS_QR.Click += new System.EventHandler(this.YS_QR_Click);
            // 
            // SheBeiYingShe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.YS_QR);
            this.Controls.Add(this.SBYS_ToLeft);
            this.Controls.Add(this.SBYS_ToRight);
            this.Controls.Add(this.SBYS_MainPage);
            this.Controls.Add(this.SBYS_Back);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "SheBeiYingShe";
            this.Text = "SheBeiYingShe";
            this.Load += new System.EventHandler(this.SheBeiYingShe_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SBYS_ToLeft;
        private System.Windows.Forms.Button SBYS_ToRight;
        private System.Windows.Forms.Button SBYS_MainPage;
        private System.Windows.Forms.Button SBYS_Back;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button YS_QR;
    }
}