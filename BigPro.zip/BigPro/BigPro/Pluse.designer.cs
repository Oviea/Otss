﻿namespace BigPro
{
    partial class Pluse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.MC_TL = new System.Windows.Forms.Button();
            this.MC_TR = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.MC_Back = new System.Windows.Forms.Button();
            this.MC_2Main = new System.Windows.Forms.Button();
            this.MC_TXTS = new System.Windows.Forms.Button();
            this.MC_DSDW = new System.Windows.Forms.Button();
            this.MC_TSTS = new System.Windows.Forms.Button();
            this.MC_QR = new System.Windows.Forms.Button();
            this.MC_Allow = new System.Windows.Forms.Button();
            this.MC_ML = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AllowUserToResizeColumns = false;
            this.dataGridView3.AllowUserToResizeRows = false;
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView3.Location = new System.Drawing.Point(292, 564);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView3.Size = new System.Drawing.Size(1352, 90);
            this.dataGridView3.TabIndex = 457;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView1.Location = new System.Drawing.Point(292, 190);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView1.Size = new System.Drawing.Size(1352, 90);
            this.dataGridView1.TabIndex = 455;
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView2.Location = new System.Drawing.Point(292, 377);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView2.Size = new System.Drawing.Size(1352, 90);
            this.dataGridView2.TabIndex = 456;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1427, 850);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 12);
            this.label3.TabIndex = 454;
            // 
            // MC_TL
            // 
            this.MC_TL.ForeColor = System.Drawing.Color.Black;
            this.MC_TL.Image = global::BigPro.Properties.Resources.Toleft;
            this.MC_TL.Location = new System.Drawing.Point(11, 11);
            this.MC_TL.Margin = new System.Windows.Forms.Padding(2);
            this.MC_TL.Name = "MC_TL";
            this.MC_TL.Size = new System.Drawing.Size(50, 50);
            this.MC_TL.TabIndex = 453;
            this.MC_TL.UseVisualStyleBackColor = true;
            this.MC_TL.Click += new System.EventHandler(this.MC_TL_Click);
            // 
            // MC_TR
            // 
            this.MC_TR.ForeColor = System.Drawing.Color.Black;
            this.MC_TR.Image = global::BigPro.Properties.Resources.ToRight;
            this.MC_TR.Location = new System.Drawing.Point(1827, 11);
            this.MC_TR.Margin = new System.Windows.Forms.Padding(2);
            this.MC_TR.Name = "MC_TR";
            this.MC_TR.Size = new System.Drawing.Size(50, 50);
            this.MC_TR.TabIndex = 452;
            this.MC_TR.UseVisualStyleBackColor = true;
            this.MC_TR.Click += new System.EventHandler(this.MC_TR_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1660, 334);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 12);
            this.label2.TabIndex = 451;
            // 
            // MC_Back
            // 
            this.MC_Back.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MC_Back.Location = new System.Drawing.Point(29, 850);
            this.MC_Back.Margin = new System.Windows.Forms.Padding(2);
            this.MC_Back.Name = "MC_Back";
            this.MC_Back.Size = new System.Drawing.Size(200, 70);
            this.MC_Back.TabIndex = 450;
            this.MC_Back.Text = "返回";
            this.MC_Back.UseVisualStyleBackColor = true;
            this.MC_Back.Click += new System.EventHandler(this.MC_Back_Click);
            // 
            // MC_2Main
            // 
            this.MC_2Main.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MC_2Main.Location = new System.Drawing.Point(1696, 850);
            this.MC_2Main.Margin = new System.Windows.Forms.Padding(2);
            this.MC_2Main.Name = "MC_2Main";
            this.MC_2Main.Size = new System.Drawing.Size(200, 70);
            this.MC_2Main.TabIndex = 449;
            this.MC_2Main.Text = "回首页";
            this.MC_2Main.UseVisualStyleBackColor = true;
            this.MC_2Main.Click += new System.EventHandler(this.MC_2Main_Click);
            // 
            // MC_TXTS
            // 
            this.MC_TXTS.BackColor = System.Drawing.Color.White;
            this.MC_TXTS.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MC_TXTS.Location = new System.Drawing.Point(878, 698);
            this.MC_TXTS.Margin = new System.Windows.Forms.Padding(2);
            this.MC_TXTS.Name = "MC_TXTS";
            this.MC_TXTS.Size = new System.Drawing.Size(150, 56);
            this.MC_TXTS.TabIndex = 448;
            this.MC_TXTS.Text = "台下调速";
            this.MC_TXTS.UseVisualStyleBackColor = false;
            this.MC_TXTS.Click += new System.EventHandler(this.MC_TXTS_Click);
            // 
            // MC_DSDW
            // 
            this.MC_DSDW.BackColor = System.Drawing.Color.White;
            this.MC_DSDW.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MC_DSDW.Location = new System.Drawing.Point(1177, 698);
            this.MC_DSDW.Margin = new System.Windows.Forms.Padding(2);
            this.MC_DSDW.Name = "MC_DSDW";
            this.MC_DSDW.Size = new System.Drawing.Size(150, 56);
            this.MC_DSDW.TabIndex = 447;
            this.MC_DSDW.Text = "定速定位";
            this.MC_DSDW.UseVisualStyleBackColor = false;
            this.MC_DSDW.Click += new System.EventHandler(this.MC_DSDW_Click);
            // 
            // MC_TSTS
            // 
            this.MC_TSTS.BackColor = System.Drawing.Color.White;
            this.MC_TSTS.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MC_TSTS.Location = new System.Drawing.Point(579, 698);
            this.MC_TSTS.Margin = new System.Windows.Forms.Padding(2);
            this.MC_TSTS.Name = "MC_TSTS";
            this.MC_TSTS.Size = new System.Drawing.Size(150, 56);
            this.MC_TSTS.TabIndex = 445;
            this.MC_TSTS.Text = "台上调速";
            this.MC_TSTS.UseVisualStyleBackColor = false;
            this.MC_TSTS.Click += new System.EventHandler(this.MC_TSTS_Click);
            // 
            // MC_QR
            // 
            this.MC_QR.BackColor = System.Drawing.Color.White;
            this.MC_QR.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MC_QR.Location = new System.Drawing.Point(1066, 15);
            this.MC_QR.Margin = new System.Windows.Forms.Padding(2);
            this.MC_QR.Name = "MC_QR";
            this.MC_QR.Size = new System.Drawing.Size(150, 56);
            this.MC_QR.TabIndex = 443;
            this.MC_QR.Text = "确认";
            this.MC_QR.UseVisualStyleBackColor = false;
            // 
            // MC_Allow
            // 
            this.MC_Allow.BackColor = System.Drawing.Color.White;
            this.MC_Allow.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MC_Allow.Location = new System.Drawing.Point(742, 15);
            this.MC_Allow.Margin = new System.Windows.Forms.Padding(2);
            this.MC_Allow.Name = "MC_Allow";
            this.MC_Allow.Size = new System.Drawing.Size(150, 56);
            this.MC_Allow.TabIndex = 442;
            this.MC_Allow.Text = "允许";
            this.MC_Allow.UseVisualStyleBackColor = false;
            this.MC_Allow.Click += new System.EventHandler(this.MC_Allow_Click);
            // 
            // MC_ML
            // 
            this.MC_ML.AutoSize = true;
            this.MC_ML.Font = new System.Drawing.Font("宋体", 20F);
            this.MC_ML.Location = new System.Drawing.Point(925, 30);
            this.MC_ML.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.MC_ML.Name = "MC_ML";
            this.MC_ML.Size = new System.Drawing.Size(120, 27);
            this.MC_ML.TabIndex = 444;
            this.MC_ML.Text = "脉冲系数";
            this.MC_ML.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Pluse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.MC_TL);
            this.Controls.Add(this.MC_TR);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.MC_Back);
            this.Controls.Add(this.MC_2Main);
            this.Controls.Add(this.MC_TXTS);
            this.Controls.Add(this.MC_DSDW);
            this.Controls.Add(this.MC_TSTS);
            this.Controls.Add(this.MC_QR);
            this.Controls.Add(this.MC_Allow);
            this.Controls.Add(this.MC_ML);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Pluse";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Pluse_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridViewRow bound_id;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button MC_TL;
        private System.Windows.Forms.Button MC_TR;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button MC_Back;
        private System.Windows.Forms.Button MC_2Main;
        private System.Windows.Forms.Button MC_TXTS;
        private System.Windows.Forms.Button MC_DSDW;
        private System.Windows.Forms.Button MC_TSTS;
        private System.Windows.Forms.Button MC_QR;
        private System.Windows.Forms.Button MC_Allow;
        private System.Windows.Forms.Label MC_ML;
    }
}