﻿namespace BigPro
{
    partial class admin_operate
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(admin_operate));
            this.label1 = new System.Windows.Forms.Label();
            this.btn_bound = new System.Windows.Forms.Button();
            this.btn_pluse = new System.Windows.Forms.Button();
            this.btn_forbidden = new System.Windows.Forms.Button();
            this.btn_history = new System.Windows.Forms.Button();
            this.btn_recover = new System.Windows.Forms.Button();
            this.btn_Yingshe = new System.Windows.Forms.Button();
            this.btn_tbd2 = new System.Windows.Forms.Button();
            this.btn_tbd3 = new System.Windows.Forms.Button();
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // btn_bound
            // 
            resources.ApplyResources(this.btn_bound, "btn_bound");
            this.btn_bound.Name = "btn_bound";
            this.btn_bound.UseVisualStyleBackColor = true;
            this.btn_bound.Click += new System.EventHandler(this.btn_bound_Click);
            // 
            // btn_pluse
            // 
            resources.ApplyResources(this.btn_pluse, "btn_pluse");
            this.btn_pluse.Name = "btn_pluse";
            this.btn_pluse.UseVisualStyleBackColor = true;
            this.btn_pluse.Click += new System.EventHandler(this.btn_pluse_Click);
            // 
            // btn_forbidden
            // 
            resources.ApplyResources(this.btn_forbidden, "btn_forbidden");
            this.btn_forbidden.Name = "btn_forbidden";
            this.btn_forbidden.UseVisualStyleBackColor = true;
            this.btn_forbidden.Click += new System.EventHandler(this.btn_forbidden_Click);
            // 
            // btn_history
            // 
            resources.ApplyResources(this.btn_history, "btn_history");
            this.btn_history.Name = "btn_history";
            this.btn_history.UseVisualStyleBackColor = true;
            this.btn_history.Click += new System.EventHandler(this.btn_history_Click);
            // 
            // btn_recover
            // 
            resources.ApplyResources(this.btn_recover, "btn_recover");
            this.btn_recover.Name = "btn_recover";
            this.btn_recover.UseVisualStyleBackColor = true;
            this.btn_recover.Click += new System.EventHandler(this.btn_recover_Click);
            // 
            // btn_Yingshe
            // 
            resources.ApplyResources(this.btn_Yingshe, "btn_Yingshe");
            this.btn_Yingshe.Name = "btn_Yingshe";
            this.btn_Yingshe.UseVisualStyleBackColor = true;
            this.btn_Yingshe.Click += new System.EventHandler(this.btn_tbd1_Click);
            // 
            // btn_tbd2
            // 
            resources.ApplyResources(this.btn_tbd2, "btn_tbd2");
            this.btn_tbd2.Name = "btn_tbd2";
            this.btn_tbd2.UseVisualStyleBackColor = true;
            this.btn_tbd2.Click += new System.EventHandler(this.btn_tbd2_Click);
            // 
            // btn_tbd3
            // 
            resources.ApplyResources(this.btn_tbd3, "btn_tbd3");
            this.btn_tbd3.Name = "btn_tbd3";
            this.btn_tbd3.UseVisualStyleBackColor = true;
            this.btn_tbd3.Click += new System.EventHandler(this.btn_tbd3_Click);
            // 
            // btn_back
            // 
            resources.ApplyResources(this.btn_back, "btn_back");
            this.btn_back.Name = "btn_back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_home
            // 
            resources.ApplyResources(this.btn_home, "btn_home");
            this.btn_home.Name = "btn_home";
            this.btn_home.UseVisualStyleBackColor = true;
            this.btn_home.Click += new System.EventHandler(this.btn_home_Click);
            // 
            // admin_operate
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.btn_home);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.btn_tbd3);
            this.Controls.Add(this.btn_tbd2);
            this.Controls.Add(this.btn_Yingshe);
            this.Controls.Add(this.btn_recover);
            this.Controls.Add(this.btn_history);
            this.Controls.Add(this.btn_forbidden);
            this.Controls.Add(this.btn_pluse);
            this.Controls.Add(this.btn_bound);
            this.Controls.Add(this.label1);
            this.Name = "admin_operate";
            this.ShowIcon = false;
            this.TopMost = true;
            this.Load += new System.EventHandler(this.admin_operate_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_bound;
        private System.Windows.Forms.Button btn_pluse;
        private System.Windows.Forms.Button btn_forbidden;
        private System.Windows.Forms.Button btn_history;
        private System.Windows.Forms.Button btn_recover;
        private System.Windows.Forms.Button btn_Yingshe;
        private System.Windows.Forms.Button btn_tbd2;
        private System.Windows.Forms.Button btn_tbd3;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_home;
    }
}

