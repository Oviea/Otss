﻿namespace BigPro
{
    partial class _2changcifanfu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button9 = new System.Windows.Forms.Button();
            this.CCFF_Qx = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.CCFF_DuoD = new System.Windows.Forms.Button();
            this.CCFF_DanD = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.FanF_QR = new System.Windows.Forms.Button();
            this.FanF_DelData = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.La_FWZ2 = new System.Windows.Forms.Label();
            this.La_FWZ1 = new System.Windows.Forms.Label();
            this.La_FT = new System.Windows.Forms.Label();
            this.La_FV = new System.Windows.Forms.Label();
            this.La_FCS = new System.Windows.Forms.Label();
            this.FanF_Wz2 = new System.Windows.Forms.Button();
            this.FanF_Wz1 = new System.Windows.Forms.Button();
            this.FanF_Sj = new System.Windows.Forms.Button();
            this.FanF_Sd = new System.Windows.Forms.Button();
            this.FanF_Cs = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button39 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.FFXZSB = new System.Windows.Forms.ListBox();
            this.FFCue_List = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.FFLabel = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button9.Location = new System.Drawing.Point(274, 142);
            this.button9.Margin = new System.Windows.Forms.Padding(2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(150, 56);
            this.button9.TabIndex = 4;
            this.button9.Text = "当前位置";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // CCFF_Qx
            // 
            this.CCFF_Qx.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCFF_Qx.Location = new System.Drawing.Point(45, 142);
            this.CCFF_Qx.Margin = new System.Windows.Forms.Padding(2);
            this.CCFF_Qx.Name = "CCFF_Qx";
            this.CCFF_Qx.Size = new System.Drawing.Size(150, 56);
            this.CCFF_Qx.TabIndex = 3;
            this.CCFF_Qx.Text = "曲线";
            this.CCFF_Qx.UseVisualStyleBackColor = true;
            this.CCFF_Qx.Click += new System.EventHandler(this.CCFF_Qx_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Red;
            this.button7.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button7.Location = new System.Drawing.Point(502, 30);
            this.button7.Margin = new System.Windows.Forms.Padding(2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(150, 56);
            this.button7.TabIndex = 2;
            this.button7.Text = "反复";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // CCFF_DuoD
            // 
            this.CCFF_DuoD.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCFF_DuoD.Location = new System.Drawing.Point(274, 30);
            this.CCFF_DuoD.Margin = new System.Windows.Forms.Padding(2);
            this.CCFF_DuoD.Name = "CCFF_DuoD";
            this.CCFF_DuoD.Size = new System.Drawing.Size(150, 56);
            this.CCFF_DuoD.TabIndex = 1;
            this.CCFF_DuoD.Text = "多段";
            this.CCFF_DuoD.UseVisualStyleBackColor = true;
            this.CCFF_DuoD.Click += new System.EventHandler(this.CCFF_DuoD_Click);
            // 
            // CCFF_DanD
            // 
            this.CCFF_DanD.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CCFF_DanD.Location = new System.Drawing.Point(45, 30);
            this.CCFF_DanD.Margin = new System.Windows.Forms.Padding(2);
            this.CCFF_DanD.Name = "CCFF_DanD";
            this.CCFF_DanD.Size = new System.Drawing.Size(150, 56);
            this.CCFF_DanD.TabIndex = 0;
            this.CCFF_DanD.Text = "单段";
            this.CCFF_DanD.UseVisualStyleBackColor = true;
            this.CCFF_DanD.Click += new System.EventHandler(this.CCFF_DanD_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.FanF_QR);
            this.panel3.Controls.Add(this.FanF_DelData);
            this.panel3.Controls.Add(this.button10);
            this.panel3.Location = new System.Drawing.Point(122, 595);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1177, 68);
            this.panel3.TabIndex = 34;
            // 
            // FanF_QR
            // 
            this.FanF_QR.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FanF_QR.Location = new System.Drawing.Point(772, 10);
            this.FanF_QR.Margin = new System.Windows.Forms.Padding(2);
            this.FanF_QR.Name = "FanF_QR";
            this.FanF_QR.Size = new System.Drawing.Size(112, 48);
            this.FanF_QR.TabIndex = 2;
            this.FanF_QR.Text = "确认";
            this.FanF_QR.UseVisualStyleBackColor = true;
            this.FanF_QR.Click += new System.EventHandler(this.FanF_QR_Click);
            // 
            // FanF_DelData
            // 
            this.FanF_DelData.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FanF_DelData.Location = new System.Drawing.Point(532, 10);
            this.FanF_DelData.Margin = new System.Windows.Forms.Padding(2);
            this.FanF_DelData.Name = "FanF_DelData";
            this.FanF_DelData.Size = new System.Drawing.Size(112, 48);
            this.FanF_DelData.TabIndex = 1;
            this.FanF_DelData.Text = "删除";
            this.FanF_DelData.UseVisualStyleBackColor = true;
            this.FanF_DelData.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FanF_DelData_MouseClick);
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button10.Location = new System.Drawing.Point(273, 7);
            this.button10.Margin = new System.Windows.Forms.Padding(2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(112, 48);
            this.button10.TabIndex = 0;
            this.button10.Text = "复制";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(161, 138);
            this.button49.Margin = new System.Windows.Forms.Padding(2);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(38, 40);
            this.button49.TabIndex = 17;
            this.button49.Text = "b";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button14.Location = new System.Drawing.Point(598, 680);
            this.button14.Margin = new System.Windows.Forms.Padding(2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(112, 48);
            this.button14.TabIndex = 35;
            this.button14.Text = "保存";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button13.Location = new System.Drawing.Point(9, 680);
            this.button13.Margin = new System.Windows.Forms.Padding(2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(112, 48);
            this.button13.TabIndex = 25;
            this.button13.Text = "返回";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(108, 138);
            this.button48.Margin = new System.Windows.Forms.Padding(2);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(38, 40);
            this.button48.TabIndex = 16;
            this.button48.Text = "*";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(57, 138);
            this.button47.Margin = new System.Windows.Forms.Padding(2);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(38, 40);
            this.button47.TabIndex = 15;
            this.button47.Text = ".";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(2, 138);
            this.button46.Margin = new System.Windows.Forms.Padding(2);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(38, 40);
            this.button46.TabIndex = 14;
            this.button46.Text = "0";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(161, 93);
            this.button45.Margin = new System.Windows.Forms.Padding(2);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(38, 40);
            this.button45.TabIndex = 13;
            this.button45.Text = "b";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(161, 48);
            this.button44.Margin = new System.Windows.Forms.Padding(2);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(38, 40);
            this.button44.TabIndex = 12;
            this.button44.Text = "b";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(161, 3);
            this.button43.Margin = new System.Windows.Forms.Padding(2);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(38, 40);
            this.button43.TabIndex = 11;
            this.button43.Text = "b";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(108, 93);
            this.button42.Margin = new System.Windows.Forms.Padding(2);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(38, 40);
            this.button42.TabIndex = 10;
            this.button42.Text = "9";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(108, 48);
            this.button41.Margin = new System.Windows.Forms.Padding(2);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(38, 40);
            this.button41.TabIndex = 9;
            this.button41.Text = "6";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button16.Location = new System.Drawing.Point(1322, 680);
            this.button16.Margin = new System.Windows.Forms.Padding(2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(112, 48);
            this.button16.TabIndex = 37;
            this.button16.Text = "回首页";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(108, 3);
            this.button40.Margin = new System.Windows.Forms.Padding(2);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(38, 40);
            this.button40.TabIndex = 8;
            this.button40.Text = "3";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button15.Location = new System.Drawing.Point(737, 680);
            this.button15.Margin = new System.Windows.Forms.Padding(2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(112, 48);
            this.button15.TabIndex = 36;
            this.button15.Text = "场景";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.CCFF_Qx);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.CCFF_DuoD);
            this.panel1.Controls.Add(this.CCFF_DanD);
            this.panel1.Location = new System.Drawing.Point(461, 138);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(838, 460);
            this.panel1.TabIndex = 33;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.La_FWZ2);
            this.panel5.Controls.Add(this.La_FWZ1);
            this.panel5.Controls.Add(this.La_FT);
            this.panel5.Controls.Add(this.La_FV);
            this.panel5.Controls.Add(this.La_FCS);
            this.panel5.Controls.Add(this.FanF_Wz2);
            this.panel5.Controls.Add(this.FanF_Wz1);
            this.panel5.Controls.Add(this.FanF_Sj);
            this.panel5.Controls.Add(this.FanF_Sd);
            this.panel5.Controls.Add(this.FanF_Cs);
            this.panel5.Location = new System.Drawing.Point(45, 212);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(244, 224);
            this.panel5.TabIndex = 32;
            // 
            // La_FWZ2
            // 
            this.La_FWZ2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.La_FWZ2.Location = new System.Drawing.Point(146, 178);
            this.La_FWZ2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.La_FWZ2.Name = "La_FWZ2";
            this.La_FWZ2.Size = new System.Drawing.Size(76, 32);
            this.La_FWZ2.TabIndex = 9;
            this.La_FWZ2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // La_FWZ1
            // 
            this.La_FWZ1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.La_FWZ1.Location = new System.Drawing.Point(146, 136);
            this.La_FWZ1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.La_FWZ1.Name = "La_FWZ1";
            this.La_FWZ1.Size = new System.Drawing.Size(76, 32);
            this.La_FWZ1.TabIndex = 8;
            this.La_FWZ1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // La_FT
            // 
            this.La_FT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.La_FT.Location = new System.Drawing.Point(146, 94);
            this.La_FT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.La_FT.Name = "La_FT";
            this.La_FT.Size = new System.Drawing.Size(76, 32);
            this.La_FT.TabIndex = 7;
            this.La_FT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // La_FV
            // 
            this.La_FV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.La_FV.Location = new System.Drawing.Point(146, 51);
            this.La_FV.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.La_FV.Name = "La_FV";
            this.La_FV.Size = new System.Drawing.Size(76, 32);
            this.La_FV.TabIndex = 6;
            this.La_FV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // La_FCS
            // 
            this.La_FCS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.La_FCS.Location = new System.Drawing.Point(146, 9);
            this.La_FCS.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.La_FCS.Name = "La_FCS";
            this.La_FCS.Size = new System.Drawing.Size(76, 32);
            this.La_FCS.TabIndex = 5;
            this.La_FCS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FanF_Wz2
            // 
            this.FanF_Wz2.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FanF_Wz2.Location = new System.Drawing.Point(14, 178);
            this.FanF_Wz2.Margin = new System.Windows.Forms.Padding(2);
            this.FanF_Wz2.Name = "FanF_Wz2";
            this.FanF_Wz2.Size = new System.Drawing.Size(112, 32);
            this.FanF_Wz2.TabIndex = 4;
            this.FanF_Wz2.Text = "位置二";
            this.FanF_Wz2.UseVisualStyleBackColor = true;
            this.FanF_Wz2.Click += new System.EventHandler(this.FanF_Wz2_Click);
            // 
            // FanF_Wz1
            // 
            this.FanF_Wz1.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FanF_Wz1.Location = new System.Drawing.Point(14, 136);
            this.FanF_Wz1.Margin = new System.Windows.Forms.Padding(2);
            this.FanF_Wz1.Name = "FanF_Wz1";
            this.FanF_Wz1.Size = new System.Drawing.Size(112, 32);
            this.FanF_Wz1.TabIndex = 3;
            this.FanF_Wz1.Text = "位置一";
            this.FanF_Wz1.UseVisualStyleBackColor = true;
            this.FanF_Wz1.Click += new System.EventHandler(this.FanF_Wz1_Click);
            // 
            // FanF_Sj
            // 
            this.FanF_Sj.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FanF_Sj.Location = new System.Drawing.Point(14, 94);
            this.FanF_Sj.Margin = new System.Windows.Forms.Padding(2);
            this.FanF_Sj.Name = "FanF_Sj";
            this.FanF_Sj.Size = new System.Drawing.Size(112, 32);
            this.FanF_Sj.TabIndex = 2;
            this.FanF_Sj.Text = "延时时间";
            this.FanF_Sj.UseVisualStyleBackColor = true;
            this.FanF_Sj.Click += new System.EventHandler(this.FanF_Sj_Click);
            // 
            // FanF_Sd
            // 
            this.FanF_Sd.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FanF_Sd.Location = new System.Drawing.Point(14, 51);
            this.FanF_Sd.Margin = new System.Windows.Forms.Padding(2);
            this.FanF_Sd.Name = "FanF_Sd";
            this.FanF_Sd.Size = new System.Drawing.Size(112, 32);
            this.FanF_Sd.TabIndex = 1;
            this.FanF_Sd.Text = "速度";
            this.FanF_Sd.UseVisualStyleBackColor = true;
            this.FanF_Sd.Click += new System.EventHandler(this.FanF_Sd_Click);
            // 
            // FanF_Cs
            // 
            this.FanF_Cs.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FanF_Cs.Location = new System.Drawing.Point(14, 9);
            this.FanF_Cs.Margin = new System.Windows.Forms.Padding(2);
            this.FanF_Cs.Name = "FanF_Cs";
            this.FanF_Cs.Size = new System.Drawing.Size(112, 32);
            this.FanF_Cs.TabIndex = 0;
            this.FanF_Cs.Text = "反复次数";
            this.FanF_Cs.UseVisualStyleBackColor = true;
            this.FanF_Cs.Click += new System.EventHandler(this.FanF_Cs_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.button49);
            this.panel2.Controls.Add(this.button48);
            this.panel2.Controls.Add(this.button47);
            this.panel2.Controls.Add(this.button46);
            this.panel2.Controls.Add(this.button45);
            this.panel2.Controls.Add(this.button44);
            this.panel2.Controls.Add(this.button43);
            this.panel2.Controls.Add(this.button42);
            this.panel2.Controls.Add(this.button41);
            this.panel2.Controls.Add(this.button40);
            this.panel2.Controls.Add(this.button39);
            this.panel2.Controls.Add(this.button36);
            this.panel2.Controls.Add(this.button35);
            this.panel2.Controls.Add(this.button34);
            this.panel2.Controls.Add(this.button32);
            this.panel2.Controls.Add(this.button33);
            this.panel2.Controls.Add(this.button31);
            this.panel2.Location = new System.Drawing.Point(490, 250);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(203, 186);
            this.panel2.TabIndex = 28;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(57, 93);
            this.button39.Margin = new System.Windows.Forms.Padding(2);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(38, 40);
            this.button39.TabIndex = 7;
            this.button39.Text = "8";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(57, 48);
            this.button36.Margin = new System.Windows.Forms.Padding(2);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(38, 40);
            this.button36.TabIndex = 6;
            this.button36.Text = "5";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(57, 3);
            this.button35.Margin = new System.Windows.Forms.Padding(2);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(38, 40);
            this.button35.TabIndex = 5;
            this.button35.Text = "2";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(2, 93);
            this.button34.Margin = new System.Windows.Forms.Padding(2);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(38, 40);
            this.button34.TabIndex = 4;
            this.button34.Text = "7";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(2, 48);
            this.button32.Margin = new System.Windows.Forms.Padding(2);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(38, 40);
            this.button32.TabIndex = 3;
            this.button32.Text = "4";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(62, 0);
            this.button33.Margin = new System.Windows.Forms.Padding(2);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(0, 0);
            this.button33.TabIndex = 2;
            this.button33.Text = "button33";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(2, 3);
            this.button31.Margin = new System.Windows.Forms.Padding(2);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(38, 40);
            this.button31.TabIndex = 0;
            this.button31.Text = "1";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button3.Enabled = false;
            this.button3.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(313, 138);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(150, 50);
            this.button3.TabIndex = 32;
            this.button3.Text = "选中设备";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // FFXZSB
            // 
            this.FFXZSB.Font = new System.Drawing.Font("宋体", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FFXZSB.FormattingEnabled = true;
            this.FFXZSB.ItemHeight = 14;
            this.FFXZSB.Location = new System.Drawing.Point(313, 186);
            this.FFXZSB.Name = "FFXZSB";
            this.FFXZSB.ScrollAlwaysVisible = true;
            this.FFXZSB.Size = new System.Drawing.Size(150, 410);
            this.FFXZSB.TabIndex = 30;
            // 
            // FFCue_List
            // 
            this.FFCue_List.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FFCue_List.FormattingEnabled = true;
            this.FFCue_List.ItemHeight = 16;
            this.FFCue_List.Location = new System.Drawing.Point(122, 138);
            this.FFCue_List.Name = "FFCue_List";
            this.FFCue_List.ScrollAlwaysVisible = true;
            this.FFCue_List.Size = new System.Drawing.Size(193, 452);
            this.FFCue_List.TabIndex = 28;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Enabled = false;
            this.button2.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(122, 85);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(192, 55);
            this.button2.TabIndex = 26;
            this.button2.Text = "江姐";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(593, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 27);
            this.label1.TabIndex = 24;
            this.label1.Text = "场次设置";
            // 
            // FFLabel
            // 
            this.FFLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FFLabel.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FFLabel.Location = new System.Drawing.Point(313, 85);
            this.FFLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.FFLabel.Name = "FFLabel";
            this.FFLabel.Size = new System.Drawing.Size(988, 53);
            this.FFLabel.TabIndex = 63;
            this.FFLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _2changcifanfu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1443, 844);
            this.Controls.Add(this.FFLabel);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.FFXZSB);
            this.Controls.Add(this.FFCue_List);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "_2changcifanfu";
            this.Text = "_2changcifanfu";
            this.Load += new System.EventHandler(this._2changcifanfu_Load);
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button CCFF_Qx;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button CCFF_DuoD;
        private System.Windows.Forms.Button CCFF_DanD;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button FanF_QR;
        private System.Windows.Forms.Button FanF_DelData;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ListBox FFXZSB;
        private System.Windows.Forms.ListBox FFCue_List;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button FanF_Wz2;
        private System.Windows.Forms.Button FanF_Wz1;
        private System.Windows.Forms.Button FanF_Sj;
        private System.Windows.Forms.Button FanF_Sd;
        private System.Windows.Forms.Button FanF_Cs;
        private System.Windows.Forms.Label FFLabel;
        private System.Windows.Forms.Label La_FWZ2;
        private System.Windows.Forms.Label La_FWZ1;
        private System.Windows.Forms.Label La_FT;
        private System.Windows.Forms.Label La_FV;
        private System.Windows.Forms.Label La_FCS;
    }
}