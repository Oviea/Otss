﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class shuzhishezhi : Form
    {
        private bool[,] validate1;
        private int[,] input1;
        private bool[,] validate2;
        private int[,] input2;
        private bool[,] validate3;
        private int[,] input3;
        private int[,] totalinput;
        private int thirtyzheng = 0;
        private int thirtyyu = 0;
        private int tenzheng = 0;
        private int tenyu = 0;
        private string[] shebeiinfo;
        private int ThirtyZ;
        private int beginindex1, beginindex2;
        DBB1 dbb1;
        public shuzhishezhi(DBB1 d)
        {
            this.dbb1 = d;
            InitializeComponent();
        }

        private void button32_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button29_Click(object sender, EventArgs e)
        {
            var frm = new main();
            frm.Show();
            this.Close();
        }

        private void shuzhishezhi_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            if (dataGridView1.Rows.Count == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns.Add(new DataGridViewTextBoxColumn());
                }
                for (int i = 0; i < 3; i++)
                {
                    dataGridView1.Rows.Add(new DataGridViewRow());
                }
            }
            this.dataGridView1.Rows[0].HeaderCell.Value = "软上限";
            this.dataGridView1.Rows[1].HeaderCell.Value = "当前位置";
            this.dataGridView1.Rows[2].HeaderCell.Value = "软下限";
            this.dataGridView1.Rows[3].HeaderCell.Value = "带景下限";
            this.dataGridView1.TopLeftHeaderCell.Value = "数值|设备";

            if (dataGridView2.Rows.Count == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView2.Columns.Add(new DataGridViewTextBoxColumn());
                }
                for (int i = 0; i < 3; i++)
                {
                    dataGridView2.Rows.Add(new DataGridViewRow());
                }
            }
            this.dataGridView2.Rows[0].HeaderCell.Value = "软上限";
            this.dataGridView2.Rows[1].HeaderCell.Value = "当前位置";
            this.dataGridView2.Rows[2].HeaderCell.Value = "软下限";
            this.dataGridView2.Rows[3].HeaderCell.Value = "带景下限";
            this.dataGridView2.TopLeftHeaderCell.Value = "数值|设备";

            if (dataGridView3.Rows.Count == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView3.Columns.Add(new DataGridViewTextBoxColumn());
                }
                for (int i = 0; i < 3; i++)
                {
                    dataGridView3.Rows.Add(new DataGridViewRow());
                }
            }
            this.dataGridView3.Rows[0].HeaderCell.Value = "软上限";
            this.dataGridView3.Rows[1].HeaderCell.Value = "当前位置";
            this.dataGridView3.Rows[2].HeaderCell.Value = "软下限";
            this.dataGridView3.Rows[3].HeaderCell.Value = "带景下限";
            this.dataGridView3.TopLeftHeaderCell.Value = "数值|设备";

            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            int total = 0;
            //    total = int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString())+ int.Parse(sbsd[2].ToString())+ int.Parse(sbsd[3].ToString());
            total = int.Parse(sbsd[0].ToString());
            shebeiinfo = new string[total];
            totalinput = new int[4, total];
            Bt_N.BackColor = Color.Red;
            int j = 1;
            for(int i=0;i< int.Parse(sbsd[0].ToString()); i++)
            {
                shebeiinfo[i] = "调速设备" + j;
                j++;
            }
            j = 1;
         /*   for(int i= int.Parse(sbsd[0].ToString());i< int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString()); i++)
            {
                shebeiinfo[i] = "调速互锁类设备" + j;
                j++;
            }
            j = 1;
            for(int i= int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString());i< int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString())+ int.Parse(sbsd[2].ToString()); i++)
            {
                shebeiinfo[i] = "定速定位设备" + j;
                j++;
            }
            j = 1;
            for(int i= int.Parse(sbsd[0].ToString()) + int.Parse(sbsd[1].ToString()) + int.Parse(sbsd[2].ToString()); i < total; i++)
            {
                shebeiinfo[i] = "定速设备" + j;
                j++;
            }
            for(int i = 0; i < total; i++)
            {
                Console.WriteLine(shebeiinfo[i]);
            }*/
            tenzheng = total / 10;
            tenyu = total % 10;
            thirtyzheng = total / 30;
            thirtyyu = total % 30;
            ThirtyZ = thirtyzheng;
            beginindex2 = total;
            if (thirtyzheng == 0)
            {
                switch (tenzheng)
                {
                    case 0:
                        validate1 = new bool[4, tenyu];
                        input1 = new int[4, tenyu];
                        for(int i = 0; i < tenyu; i++)
                        {
                          
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];
                        }
                        for(int i = tenyu; i < 10; i++)
                        {
                            dataGridView1.Columns[i].ReadOnly = true;
                        }
                        dataGridView2.ReadOnly = true;
                        dataGridView3.ReadOnly = true;

                        break;
                    case 1:
                        validate1 = new bool[4, 10];
                        input1 = new int[4, 10];
                        validate2 = new bool[4, tenyu];
                        input2 = new int[4, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                             dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 10+tenyu; i++)
                        {
                            dataGridView2.Columns[i-10].HeaderCell.Value = shebeiinfo[i]; 
                        } 
                        for(int i = 10 + tenyu; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].ReadOnly = true;
                        }
                        dataGridView3.ReadOnly = true;
                        break;
                    case 2:
                        validate1 = new bool[4, 10];
                        input1 = new int[4, 10];
                        validate2 = new bool[4, 10];
                        input2 = new int[4, 10];
                        validate3 = new bool[4, tenyu];
                        input3 = new int[4, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20; i < 20+tenyu; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                        }
                        for(int i = 20 + tenyu; i < 30; i++)
                        {
                            dataGridView3.Columns[i].ReadOnly = true;
                        }
                        break;
                }
            }
            else
            {
                validate1 = new bool[4, 10];
                input1 = new int[4, 10];
                validate2 = new bool[4, 10];
                input2 = new int[4, 10];
                validate3 = new bool[4, 10];
                input3 = new int[4, 10];
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                }
            }   
        }

       

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int x = e.RowIndex;
            int y = e.ColumnIndex;
            Console.WriteLine("X:" + x + "Y:" + y);
            validate1[x, y] = true;
          //  Console.WriteLine(dataGridView1.Rows[x].Cells[y].Value.ToString());
            input1[x, y] = int.Parse(dataGridView1.Rows[x].Cells[y].Value.ToString());
        }

       

        private void AllowEdit_Button_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("确定允许编辑吗?", "设备数值编辑", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                dataGridView1.ReadOnly = false;
                dataGridView2.ReadOnly = false;
                dataGridView3.ReadOnly = false;
                // this.AllowEdit_Button.BackColor
                this.AllowEdit_Button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));

            }
        }

        private void ToRight_SZ_Click(object sender, EventArgs e)
        {   
            thirtyzheng = thirtyzheng - 1;
            beginindex1 = beginindex1 + 30;
           for(int i = 0; i < 4; i++)
            {
                for(int j = 0; j < 10; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value ="";
                    dataGridView2.Rows[i].Cells[j].Value = "";
                    dataGridView3.Rows[i].Cells[j].Value = "";
                }
            }
            if (thirtyzheng > 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[beginindex1+i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                }
                validate1 = new bool[4, 10];
                input1 = new int[4, 10];
                validate2 = new bool[4, 10];
                input2 = new int[4, 10];
                validate3 = new bool[4, 10];
                input3 = new int[4, 10];
            }
            else if(thirtyzheng==0)
            {
                int tenzheng = thirtyyu / 10;
                int thenyu = thirtyyu % 10;
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = "";

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = "";
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = "";
                }
                switch (tenzheng)
                {
                    case 0:
                        validate1 = new bool[4, tenyu];
                        input1 = new int[4, tenyu];
                        validate2 = new bool[4, 0];
                        input2 = new int[4, 0];
                        validate3 = new bool[4, 0];
                        input3 = new int[4, 0];
                        for (int i = 0; i < tenyu; i++)
                        {

                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                        }
                        break;
                    case 1:
                        validate1 = new bool[4, 10];
                        input1 = new int[4, 10];
                        validate2 = new bool[4, tenyu];
                        input2 = new int[4, tenyu];
                        validate3 = new bool[4, 0];
                        input3 = new int[4, 0];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[beginindex1 + i];

                        }
                        for (int i = 10; i < 10 + tenyu; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                        }
                        break;
                    case 2:
                        validate1 = new bool[4, 10];
                        input1 = new int[4, 10];
                        validate2 = new bool[4, 10];
                        input2 = new int[4, 10];
                        validate3 = new bool[4, tenyu];
                        input3 = new int[4, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[beginindex1 + i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                        }
                        for (int i = 20; i < 20 + tenyu; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                        }
                        break;
                }
              //  Console.WriteLine("%%%%%#%#@%"+thirtyzheng);
            }
            else
            {
                MessageBox.Show("没有更多设备信息!!!");
              //  ToRight_SZ.Enabled = false;
                thirtyzheng = thirtyzheng + 1;
                beginindex1 = beginindex1 - 30;
            }
            ToLeft_SZ.Enabled = true;
            Console.WriteLine("%%%%%#%#@%right" + thirtyzheng);
        }

        private void ToLeft_SZ_Click(object sender, EventArgs e)
        {
            thirtyzheng = thirtyzheng + 1;
            beginindex1 = beginindex1 - 30;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = "";
                    dataGridView2.Rows[i].Cells[j].Value = "";
                    dataGridView3.Rows[i].Cells[j].Value = "";
                }
            }
            if (thirtyzheng>0&&thirtyzheng<=ThirtyZ)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[beginindex1 + i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                }
                validate1 = new bool[4, 10];
                input1 = new int[4, 10];
                validate2 = new bool[4, 10];
                input2 = new int[4, 10];
                validate3 = new bool[4, 10];
                input3 = new int[4, 10];
            }
            else if (thirtyzheng > ThirtyZ)
            {
                MessageBox.Show("没有更多数据!");
             //   ToLeft_SZ.Enabled = false;
                thirtyzheng = thirtyzheng - 1;
                beginindex1=beginindex1+30;
            }
            ToRight_SZ.Enabled = true;
            Console.WriteLine("%%%%%#%#Left" + thirtyzheng);

        }

        private void Bt_M_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 4; i++)
            {
                for (int k = 0; k < 10; k++)
                {
                    dataGridView1.Rows[i].Cells[k].Value = " ";
                    dataGridView2.Rows[i].Cells[k].Value = " ";
                    dataGridView3.Rows[i].Cells[k].Value = " ";
                }
            }
            for (int i = 0; i < 10; i++)
            {
                dataGridView1.Columns[i].HeaderCell.Value = " ";
                dataGridView2.Columns[i].HeaderCell.Value = " ";
                dataGridView3.Columns[i].HeaderCell.Value = " ";
            }
            if (Bt_N.BackColor == Color.Red)
            {
                Bt_N.BackColor = Color.White;
            }
            if (Bt_K.BackColor == Color.Red)
            {
                Bt_K.BackColor = Color.White;
            }
            if (Bt_P.BackColor == Color.Red)
            {
                Bt_P.BackColor = Color.White;
            }
            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            int total = 0;
            //    total = int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString())+ int.Parse(sbsd[2].ToString())+ int.Parse(sbsd[3].ToString());
            total = int.Parse(sbsd[1].ToString());
            shebeiinfo = new string[total];
            totalinput = new int[4, total];
            Bt_M.BackColor = Color.Red;
            int j = 1;
               for(int i = 0; i < int.Parse(sbsd[1].ToString()); i++)
               {
                   shebeiinfo[i] = "调速互锁类设备" + j;
                   j++;
               }
             
            tenzheng = total / 10;
            tenyu = total % 10;
            thirtyzheng = total / 30;
            thirtyyu = total % 30;
            ThirtyZ = thirtyzheng;
            beginindex2 = total;
            if (thirtyzheng == 0)
            {
                switch (tenzheng)
                {
                    case 0:
                        validate1 = new bool[4, tenyu];
                        input1 = new int[4, tenyu];
                        for (int i = 0; i < tenyu; i++)
                        {

                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = tenyu; i < 10; i++)
                        {
                            dataGridView1.Columns[i].ReadOnly = true;
                        }
                        dataGridView2.ReadOnly = true;
                        dataGridView3.ReadOnly = true;

                        break;
                    case 1:
                        validate1 = new bool[4, 10];
                        input1 = new int[4, 10];
                        validate2 = new bool[4, tenyu];
                        input2 = new int[4, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 10 + tenyu; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 10 + tenyu; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].ReadOnly = true;
                        }
                        dataGridView3.ReadOnly = true;
                        break;
                    case 2:
                        validate1 = new bool[4, 10];
                        input1 = new int[4, 10];
                        validate2 = new bool[4, 10];
                        input2 = new int[4, 10];
                        validate3 = new bool[4, tenyu];
                        input3 = new int[4, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20; i < 20 + tenyu; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20 + tenyu; i < 30; i++)
                        {
                            dataGridView3.Columns[i].ReadOnly = true;
                        }
                        break;
                }
            }
            else
            {
                validate1 = new bool[4, 10];
                input1 = new int[4, 10];
                validate2 = new bool[4, 10];
                input2 = new int[4, 10];
                validate3 = new bool[4, 10];
                input3 = new int[4, 10];
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                }
            }
        }

        private void Bt_N_Click(object sender, EventArgs e)
        {

            if (Bt_M.BackColor == Color.Red)
            {
                Bt_M.BackColor = Color.White;
            }
            if (Bt_K.BackColor == Color.Red)
            {
                Bt_K.BackColor = Color.White;
            }
            if (Bt_P.BackColor == Color.Red)
            {
                Bt_P.BackColor = Color.White;
            }
            for (int i = 0; i < 4; i++)
            {
                for (int k = 0; k < 10; k++)
                {
                    dataGridView1.Rows[i].Cells[k].Value = " ";
                    dataGridView2.Rows[i].Cells[k].Value = " ";
                    dataGridView3.Rows[i].Cells[k].Value = " ";
                }
            }
            for(int i = 0; i < 10; i++)
            {
                dataGridView1.Columns[i].HeaderCell.Value = " ";
                dataGridView2.Columns[i].HeaderCell.Value = " ";
                dataGridView3.Columns[i].HeaderCell.Value = " ";
            }
            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            int total = 0;
            //    total = int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString())+ int.Parse(sbsd[2].ToString())+ int.Parse(sbsd[3].ToString());
            total = int.Parse(sbsd[0].ToString());
            shebeiinfo = new string[total];
            totalinput = new int[4, total];
            Bt_N.BackColor = Color.Red;
            int j = 1;
            for (int i = 0; i < int.Parse(sbsd[0].ToString()); i++)
            {
                shebeiinfo[i] = "调速设备" + j;
                j++;
            }
            j = 1;
            tenzheng = total / 10;
            tenyu = total % 10;
            thirtyzheng = total / 30;
            thirtyyu = total % 30;
            ThirtyZ = thirtyzheng;
            beginindex2 = total;
            if (thirtyzheng == 0)
            {
                switch (tenzheng)
                {
                    case 0:
                        validate1 = new bool[4, tenyu];
                        input1 = new int[4, tenyu];
                        for (int i = 0; i < tenyu; i++)
                        {

                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = tenyu; i < 10; i++)
                        {
                            dataGridView1.Columns[i].ReadOnly = true;
                        }
                        dataGridView2.ReadOnly = true;
                        dataGridView3.ReadOnly = true;

                        break;
                    case 1:
                        validate1 = new bool[4, 10];
                        input1 = new int[4, 10];
                        validate2 = new bool[4, tenyu];
                        input2 = new int[4, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 10 + tenyu; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 10 + tenyu; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].ReadOnly = true;
                        }
                        dataGridView3.ReadOnly = true;
                        break;
                    case 2:
                        validate1 = new bool[4, 10];
                        input1 = new int[4, 10];
                        validate2 = new bool[4, 10];
                        input2 = new int[4, 10];
                        validate3 = new bool[4, tenyu];
                        input3 = new int[4, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20; i < 20 + tenyu; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20 + tenyu; i < 30; i++)
                        {
                            dataGridView3.Columns[i].ReadOnly = true;
                        }
                        break;
                }
            }
            else
            {
                validate1 = new bool[4, 10];
                input1 = new int[4, 10];
                validate2 = new bool[4, 10];
                input2 = new int[4, 10];
                validate3 = new bool[4, 10];
                input3 = new int[4, 10];
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                }
            }
        }

        private void Bt_K_Click(object sender, EventArgs e)
        {
            if (Bt_N.BackColor == Color.Red)
            {
                Bt_N.BackColor = Color.White;
            }
            if (Bt_M.BackColor == Color.Red)
            {
                Bt_M.BackColor = Color.White;
            }
            if (Bt_P.BackColor == Color.Red)
            {
                Bt_P.BackColor = Color.White;
            }
            for (int i = 0; i < 4; i++)
            {
                for (int k = 0; k < 10; k++)
                {
                    dataGridView1.Rows[i].Cells[k].Value = " ";
                    dataGridView2.Rows[i].Cells[k].Value = " ";
                    dataGridView3.Rows[i].Cells[k].Value = " ";
                }
            }
            for (int i = 0; i < 10; i++)
            {
                dataGridView1.Columns[i].HeaderCell.Value = " ";
                dataGridView2.Columns[i].HeaderCell.Value = " ";
                dataGridView3.Columns[i].HeaderCell.Value = " ";
            }
            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            int total = 0;
            //    total = int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString())+ int.Parse(sbsd[2].ToString())+ int.Parse(sbsd[3].ToString());
            total = int.Parse(sbsd[2].ToString());
            shebeiinfo = new string[total];
            totalinput = new int[4, total];
            
            Bt_K.BackColor = Color.Red;
            int j = 1;
          

               for(int i = 0; i < int.Parse(sbsd[2].ToString()); i++)
               {
                   shebeiinfo[i] = "定速定位设备" + j;
                   j++;
               }
               for(int i = 0; i < total; i++)
               {
                   Console.WriteLine(shebeiinfo[i]);
               }
            tenzheng = total / 10;
            tenyu = total % 10;
            thirtyzheng = total / 30;
            thirtyyu = total % 30;
            ThirtyZ = thirtyzheng;
            beginindex2 = total;
            if (thirtyzheng == 0)
            {
                switch (tenzheng)
                {
                    case 0:
                        validate1 = new bool[4, tenyu];
                        input1 = new int[4, tenyu];
                        for (int i = 0; i < tenyu; i++)
                        {

                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = tenyu; i < 10; i++)
                        {
                            dataGridView1.Columns[i].ReadOnly = true;
                        }
                        dataGridView2.ReadOnly = true;
                        dataGridView3.ReadOnly = true;

                        break;
                    case 1:
                        validate1 = new bool[4, 10];
                        input1 = new int[4, 10];
                        validate2 = new bool[4, tenyu];
                        input2 = new int[4, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 10 + tenyu; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 10 + tenyu; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].ReadOnly = true;
                        }
                        dataGridView3.ReadOnly = true;
                        break;
                    case 2:
                        validate1 = new bool[4, 10];
                        input1 = new int[4, 10];
                        validate2 = new bool[4, 10];
                        input2 = new int[4, 10];
                        validate3 = new bool[4, tenyu];
                        input3 = new int[4, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20; i < 20 + tenyu; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20 + tenyu; i < 30; i++)
                        {
                            dataGridView3.Columns[i].ReadOnly = true;
                        }
                        break;
                }
            }
            else
            {
                validate1 = new bool[4, 10];
                input1 = new int[4, 10];
                validate2 = new bool[4, 10];
                input2 = new int[4, 10];
                validate3 = new bool[4, 10];
                input3 = new int[4, 10];
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                }
            }
        }

        private void Bt_P_Click(object sender, EventArgs e)
        {
            if (Bt_N.BackColor == Color.Red)
            {
                Bt_N.BackColor = Color.White;
            }
            if (Bt_M.BackColor == Color.Red)
            {
                Bt_M.BackColor = Color.White;
            }
            if (Bt_K.BackColor == Color.Red)
            {
                Bt_K.BackColor = Color.White;
            }
            for (int i = 0; i < 4; i++)
            {
                for (int k = 0; k < 10; k++)
                { 
                    dataGridView1.Rows[i].Cells[k].Value = " ";
                    dataGridView2.Rows[i].Cells[k].Value = " ";
                    dataGridView3.Rows[i].Cells[k].Value = " ";
                }
            }
            for (int i = 0; i < 10; i++)
            {
                dataGridView1.Columns[i].HeaderCell.Value = " ";
                dataGridView2.Columns[i].HeaderCell.Value = " ";
                dataGridView3.Columns[i].HeaderCell.Value = " ";
            }
            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            int total = 0;
            //    total = int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString())+ int.Parse(sbsd[2].ToString())+ int.Parse(sbsd[3].ToString());
            total = int.Parse(sbsd[3].ToString());
            shebeiinfo = new string[total];
            totalinput = new int[4, total];
           
            Bt_P.BackColor = Color.Red;
            int j = 1;
         
               for(int i = 0; i < int.Parse(sbsd[3].ToString()); i++)
               {
                   shebeiinfo[i] = "定速设备" + j;
                   j++;
               }
               for(int i = 0; i < total; i++)
               {
                   Console.WriteLine(shebeiinfo[i]);
               }
            tenzheng = total / 10;
            tenyu = total % 10;
            thirtyzheng = total / 30;
            thirtyyu = total % 30;
            ThirtyZ = thirtyzheng;
            beginindex2 = total;
            if (thirtyzheng == 0)
            {
                switch (tenzheng)
                {
                    case 0:
                        validate1 = new bool[4, tenyu];
                        input1 = new int[4, tenyu];
                        for (int i = 0; i < tenyu; i++)
                        {

                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = tenyu; i < 10; i++)
                        {
                            dataGridView1.Columns[i].ReadOnly = true;
                        }
                        dataGridView2.ReadOnly = true;
                        dataGridView3.ReadOnly = true;

                        break;
                    case 1:
                        validate1 = new bool[4, 10];
                        input1 = new int[4, 10];
                        validate2 = new bool[4, tenyu];
                        input2 = new int[4, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 10 + tenyu; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 10 + tenyu; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].ReadOnly = true;
                        }
                        dataGridView3.ReadOnly = true;
                        break;
                    case 2:
                        validate1 = new bool[4, 10];
                        input1 = new int[4, 10];
                        validate2 = new bool[4, 10];
                        input2 = new int[4, 10];
                        validate3 = new bool[4, tenyu];
                        input3 = new int[4, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20; i < 20 + tenyu; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20 + tenyu; i < 30; i++)
                        {
                            dataGridView3.Columns[i].ReadOnly = true;
                        }
                        break;
                }
            }
            else
            {
                validate1 = new bool[4, 10];
                input1 = new int[4, 10];
                validate2 = new bool[4, 10];
                input2 = new int[4, 10];
                validate3 = new bool[4, 10];
                input3 = new int[4, 10];
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                }
            }
        }

        private void SHQR_Click(object sender, EventArgs e)
        {
            this.AllowEdit_Button.BackColor = System.Drawing.Color.LightGray;
            bool b = true;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j<validate1.GetLength(1); j++)
                {
                    if (validate1[i, j] == false)
                    {
                        b = false;
                    }
                }
                for(int j = 0; j < validate2.GetLength(1); j++)
                {
                    if (validate2[i, j] == false)
                    {
                        b = false;
                    }
                }
                for (int j = 0; j < validate3.GetLength(1); j++)
                {
                    if (validate3[i, j] == false)
                    {
                        b = false;
                    }
                }

            }
              if (b == true)
              { int[] rsx = new int[input1.GetLength(1)+ input2.GetLength(1)+ input3.GetLength(1)];
                int[] rxx = new int[input1.GetLength(1) + input2.GetLength(1) + input3.GetLength(1)];
                int[] djrxx = new int[input1.GetLength(1) + input2.GetLength(1) + input3.GetLength(1)];
                for (int i = 0; i < 4; i++)
                  {
                      for (int j = 0; j < input1.GetLength(1); j++)
                      {
                        totalinput[i, j] = input1[i, j];
                      }
                    
                  }
  

                for (int i = 0; i < 4; i++)
                {
                    for (int j = input1.GetLength(1); j < input1.GetLength(1)+ input2.GetLength(1); j++)
                    {
                        totalinput[i, j] = input2[i, j- input1.GetLength(1)];
                    }

                }

                for (int i = 0; i < 4; i++)
                {
                    for (int j = input1.GetLength(1)+ input2.GetLength(1); j < input1.GetLength(1) + input2.GetLength(1)+ input3.GetLength(1); j++)
                    {
                        totalinput[i, j] = input2[i, j - input1.GetLength(1)- input3.GetLength(1)];
                    }

                }
                for (int j = 0; j < input1.GetLength(1); j++)
                {
                    rsx[j] = input1[0, j];
                    rxx[j] = input1[2, j];
                    djrxx[j] = input1[3, j];
                }
                for (int j = input1.GetLength(1); j < input1.GetLength(1) + input2.GetLength(1); j++)
                {
                    rsx[j] = input1[0, j - input1.GetLength(1)];
                    rxx[j] = input1[2, j - input1.GetLength(1)];
                    djrxx[j] = input1[3, j - input1.GetLength(1)];
                }
                for (int j = input1.GetLength(1) + input2.GetLength(1); j < input1.GetLength(1) + input2.GetLength(1) + input3.GetLength(1); j++)
                {

                    rsx[j] = input1[0, j - input1.GetLength(1) - input3.GetLength(1)];
                    rxx[j] = input1[2, j - input1.GetLength(1) - input3.GetLength(1)];
                    djrxx[j] = input1[3, j - input1.GetLength(1) - input3.GetLength(1)];
                }
                if (Bt_N.BackColor == Color.Red)
                {
                    dbb1.tsshuzhi(rsx, rxx, djrxx);
                }
                else if (Bt_K.BackColor == Color.Red)
                {
                    dbb1.tsdhssz(rsx, rxx, djrxx);
                }
                else if (Bt_M.BackColor == Color.Red)
                {
                    dbb1.dsdwsz(rsx, rxx);
                }
                else
                {

                }


            }
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < totalinput.GetLength(1); j++)
                {
                    Console.WriteLine(totalinput[i, j]);
                }
                Console.WriteLine(" ");
            }
            //   Console.WriteLine(b);
        }
    }
}
