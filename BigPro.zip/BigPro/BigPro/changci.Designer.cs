﻿namespace BigPro
{
    partial class _2changci
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.ShowCueName = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Cue_List = new System.Windows.Forms.ListBox();
            this.LBDX = new System.Windows.Forms.ListBox();
            this.XZSB = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button49 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.CC_DangQ = new System.Windows.Forms.Button();
            this.CC_QuX = new System.Windows.Forms.Button();
            this.CC_FanF = new System.Windows.Forms.Button();
            this.CC_DuoD = new System.Windows.Forms.Button();
            this.CC_DanD = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.ChangCi_QR = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.Back_2_JuMu = new System.Windows.Forms.Button();
            this.Back_2_Sy = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(595, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "场次设置";
            // 
            // ShowCueName
            // 
            this.ShowCueName.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ShowCueName.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ShowCueName.Location = new System.Drawing.Point(315, 80);
            this.ShowCueName.Margin = new System.Windows.Forms.Padding(2);
            this.ShowCueName.Name = "ShowCueName";
            this.ShowCueName.Size = new System.Drawing.Size(986, 55);
            this.ShowCueName.TabIndex = 13;
            this.ShowCueName.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Enabled = false;
            this.button2.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(124, 80);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(192, 55);
            this.button2.TabIndex = 9;
            this.button2.Text = "江姐";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // Cue_List
            // 
            this.Cue_List.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Cue_List.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Cue_List.FormattingEnabled = true;
            this.Cue_List.ItemHeight = 20;
            this.Cue_List.Location = new System.Drawing.Point(124, 135);
            this.Cue_List.Name = "Cue_List";
            this.Cue_List.ScrollAlwaysVisible = true;
            this.Cue_List.Size = new System.Drawing.Size(193, 444);
            this.Cue_List.TabIndex = 14;
            this.Cue_List.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.Cue_List_DrawItem);
            this.Cue_List.SelectedIndexChanged += new System.EventHandler(this.Cue_List_SelectedIndexChanged);
            // 
            // LBDX
            // 
            this.LBDX.Font = new System.Drawing.Font("宋体", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LBDX.FormattingEnabled = true;
            this.LBDX.ItemHeight = 14;
            this.LBDX.Location = new System.Drawing.Point(315, 181);
            this.LBDX.Name = "LBDX";
            this.LBDX.ScrollAlwaysVisible = true;
            this.LBDX.Size = new System.Drawing.Size(137, 410);
            this.LBDX.TabIndex = 15;
            this.LBDX.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // XZSB
            // 
            this.XZSB.Font = new System.Drawing.Font("宋体", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.XZSB.FormattingEnabled = true;
            this.XZSB.ItemHeight = 14;
            this.XZSB.Location = new System.Drawing.Point(449, 181);
            this.XZSB.Name = "XZSB";
            this.XZSB.ScrollAlwaysVisible = true;
            this.XZSB.Size = new System.Drawing.Size(138, 410);
            this.XZSB.TabIndex = 16;
            this.XZSB.SelectedIndexChanged += new System.EventHandler(this.XZSB_SelectedIndexChanged);
            this.XZSB.MouseUp += new System.Windows.Forms.MouseEventHandler(this.XZSB_MouseUp);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Enabled = false;
            this.button1.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(315, 135);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 47);
            this.button1.TabIndex = 17;
            this.button1.Text = "待选设备";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button3.Enabled = false;
            this.button3.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(449, 135);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(138, 47);
            this.button3.TabIndex = 18;
            this.button3.Text = "选中设备";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.CC_DangQ);
            this.panel1.Controls.Add(this.CC_QuX);
            this.panel1.Controls.Add(this.CC_FanF);
            this.panel1.Controls.Add(this.CC_DuoD);
            this.panel1.Controls.Add(this.CC_DanD);
            this.panel1.Location = new System.Drawing.Point(584, 135);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(717, 460);
            this.panel1.TabIndex = 19;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.button49);
            this.panel2.Controls.Add(this.button48);
            this.panel2.Controls.Add(this.button47);
            this.panel2.Controls.Add(this.button46);
            this.panel2.Controls.Add(this.button45);
            this.panel2.Controls.Add(this.button44);
            this.panel2.Controls.Add(this.button43);
            this.panel2.Controls.Add(this.button42);
            this.panel2.Controls.Add(this.button41);
            this.panel2.Controls.Add(this.button40);
            this.panel2.Controls.Add(this.button39);
            this.panel2.Controls.Add(this.button36);
            this.panel2.Controls.Add(this.button35);
            this.panel2.Controls.Add(this.button34);
            this.panel2.Controls.Add(this.button32);
            this.panel2.Controls.Add(this.button33);
            this.panel2.Controls.Add(this.button31);
            this.panel2.Location = new System.Drawing.Point(490, 250);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(204, 186);
            this.panel2.TabIndex = 28;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(161, 138);
            this.button49.Margin = new System.Windows.Forms.Padding(2);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(38, 40);
            this.button49.TabIndex = 17;
            this.button49.Text = "b";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(108, 138);
            this.button48.Margin = new System.Windows.Forms.Padding(2);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(38, 40);
            this.button48.TabIndex = 16;
            this.button48.Text = "*";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(57, 138);
            this.button47.Margin = new System.Windows.Forms.Padding(2);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(38, 40);
            this.button47.TabIndex = 15;
            this.button47.Text = ".";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(2, 138);
            this.button46.Margin = new System.Windows.Forms.Padding(2);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(38, 40);
            this.button46.TabIndex = 14;
            this.button46.Text = "0";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(161, 93);
            this.button45.Margin = new System.Windows.Forms.Padding(2);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(38, 40);
            this.button45.TabIndex = 13;
            this.button45.Text = "b";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(161, 48);
            this.button44.Margin = new System.Windows.Forms.Padding(2);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(38, 40);
            this.button44.TabIndex = 12;
            this.button44.Text = "b";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(161, 3);
            this.button43.Margin = new System.Windows.Forms.Padding(2);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(38, 40);
            this.button43.TabIndex = 11;
            this.button43.Text = "b";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(108, 93);
            this.button42.Margin = new System.Windows.Forms.Padding(2);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(38, 40);
            this.button42.TabIndex = 10;
            this.button42.Text = "9";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(108, 48);
            this.button41.Margin = new System.Windows.Forms.Padding(2);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(38, 40);
            this.button41.TabIndex = 9;
            this.button41.Text = "6";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(108, 3);
            this.button40.Margin = new System.Windows.Forms.Padding(2);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(38, 40);
            this.button40.TabIndex = 8;
            this.button40.Text = "3";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(57, 93);
            this.button39.Margin = new System.Windows.Forms.Padding(2);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(38, 40);
            this.button39.TabIndex = 7;
            this.button39.Text = "8";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(57, 48);
            this.button36.Margin = new System.Windows.Forms.Padding(2);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(38, 40);
            this.button36.TabIndex = 6;
            this.button36.Text = "5";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(57, 3);
            this.button35.Margin = new System.Windows.Forms.Padding(2);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(38, 40);
            this.button35.TabIndex = 5;
            this.button35.Text = "2";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(2, 93);
            this.button34.Margin = new System.Windows.Forms.Padding(2);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(38, 40);
            this.button34.TabIndex = 4;
            this.button34.Text = "7";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(2, 48);
            this.button32.Margin = new System.Windows.Forms.Padding(2);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(38, 40);
            this.button32.TabIndex = 3;
            this.button32.Text = "4";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(62, 0);
            this.button33.Margin = new System.Windows.Forms.Padding(2);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(0, 0);
            this.button33.TabIndex = 2;
            this.button33.Text = "button33";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(2, 3);
            this.button31.Margin = new System.Windows.Forms.Padding(2);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(38, 40);
            this.button31.TabIndex = 0;
            this.button31.Text = "1";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // CC_DangQ
            // 
            this.CC_DangQ.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC_DangQ.Location = new System.Drawing.Point(274, 142);
            this.CC_DangQ.Margin = new System.Windows.Forms.Padding(2);
            this.CC_DangQ.Name = "CC_DangQ";
            this.CC_DangQ.Size = new System.Drawing.Size(150, 56);
            this.CC_DangQ.TabIndex = 4;
            this.CC_DangQ.Text = "当前位置";
            this.CC_DangQ.UseVisualStyleBackColor = true;
            this.CC_DangQ.Visible = false;
            // 
            // CC_QuX
            // 
            this.CC_QuX.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC_QuX.Location = new System.Drawing.Point(45, 142);
            this.CC_QuX.Margin = new System.Windows.Forms.Padding(2);
            this.CC_QuX.Name = "CC_QuX";
            this.CC_QuX.Size = new System.Drawing.Size(150, 56);
            this.CC_QuX.TabIndex = 3;
            this.CC_QuX.Text = "曲线";
            this.CC_QuX.UseVisualStyleBackColor = true;
            this.CC_QuX.Visible = false;
            this.CC_QuX.Click += new System.EventHandler(this.button8_Click);
            // 
            // CC_FanF
            // 
            this.CC_FanF.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC_FanF.Location = new System.Drawing.Point(502, 30);
            this.CC_FanF.Margin = new System.Windows.Forms.Padding(2);
            this.CC_FanF.Name = "CC_FanF";
            this.CC_FanF.Size = new System.Drawing.Size(150, 56);
            this.CC_FanF.TabIndex = 2;
            this.CC_FanF.Text = "反复";
            this.CC_FanF.UseVisualStyleBackColor = true;
            this.CC_FanF.Visible = false;
            this.CC_FanF.Click += new System.EventHandler(this.button7_Click);
            // 
            // CC_DuoD
            // 
            this.CC_DuoD.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC_DuoD.Location = new System.Drawing.Point(274, 30);
            this.CC_DuoD.Margin = new System.Windows.Forms.Padding(2);
            this.CC_DuoD.Name = "CC_DuoD";
            this.CC_DuoD.Size = new System.Drawing.Size(150, 56);
            this.CC_DuoD.TabIndex = 1;
            this.CC_DuoD.Text = "多段";
            this.CC_DuoD.UseVisualStyleBackColor = true;
            this.CC_DuoD.Visible = false;
            this.CC_DuoD.Click += new System.EventHandler(this.button5_Click);
            // 
            // CC_DanD
            // 
            this.CC_DanD.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC_DanD.Location = new System.Drawing.Point(45, 30);
            this.CC_DanD.Margin = new System.Windows.Forms.Padding(2);
            this.CC_DanD.Name = "CC_DanD";
            this.CC_DanD.Size = new System.Drawing.Size(150, 56);
            this.CC_DanD.TabIndex = 0;
            this.CC_DanD.Text = "单段";
            this.CC_DanD.UseVisualStyleBackColor = true;
            this.CC_DanD.Visible = false;
            this.CC_DanD.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.ChangCi_QR);
            this.panel3.Controls.Add(this.button10);
            this.panel3.Location = new System.Drawing.Point(124, 594);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1177, 64);
            this.panel3.TabIndex = 20;
            // 
            // ChangCi_QR
            // 
            this.ChangCi_QR.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ChangCi_QR.Location = new System.Drawing.Point(772, 10);
            this.ChangCi_QR.Margin = new System.Windows.Forms.Padding(2);
            this.ChangCi_QR.Name = "ChangCi_QR";
            this.ChangCi_QR.Size = new System.Drawing.Size(112, 48);
            this.ChangCi_QR.TabIndex = 2;
            this.ChangCi_QR.Text = "确认";
            this.ChangCi_QR.UseVisualStyleBackColor = true;
            this.ChangCi_QR.Click += new System.EventHandler(this.ChangCi_QR_Click);
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button10.Location = new System.Drawing.Point(273, 7);
            this.button10.Margin = new System.Windows.Forms.Padding(2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(112, 48);
            this.button10.TabIndex = 0;
            this.button10.Text = "复制";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button14.Location = new System.Drawing.Point(599, 676);
            this.button14.Margin = new System.Windows.Forms.Padding(2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(112, 48);
            this.button14.TabIndex = 21;
            this.button14.Text = "保存";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button15.Location = new System.Drawing.Point(738, 676);
            this.button15.Margin = new System.Windows.Forms.Padding(2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(112, 48);
            this.button15.TabIndex = 22;
            this.button15.Text = "场景";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // Back_2_JuMu
            // 
            this.Back_2_JuMu.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Back_2_JuMu.Location = new System.Drawing.Point(9, 676);
            this.Back_2_JuMu.Margin = new System.Windows.Forms.Padding(2);
            this.Back_2_JuMu.Name = "Back_2_JuMu";
            this.Back_2_JuMu.Size = new System.Drawing.Size(112, 48);
            this.Back_2_JuMu.TabIndex = 26;
            this.Back_2_JuMu.Text = "返回";
            this.Back_2_JuMu.UseVisualStyleBackColor = true;
            this.Back_2_JuMu.Click += new System.EventHandler(this.Back_2_JuMu_Click);
            // 
            // Back_2_Sy
            // 
            this.Back_2_Sy.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Back_2_Sy.Location = new System.Drawing.Point(1322, 683);
            this.Back_2_Sy.Margin = new System.Windows.Forms.Padding(2);
            this.Back_2_Sy.Name = "Back_2_Sy";
            this.Back_2_Sy.Size = new System.Drawing.Size(112, 48);
            this.Back_2_Sy.TabIndex = 27;
            this.Back_2_Sy.Text = "回首页";
            this.Back_2_Sy.UseVisualStyleBackColor = true;
            this.Back_2_Sy.Click += new System.EventHandler(this.Back_2_Sy_Click);
            // 
            // _2changci
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1443, 844);
            this.Controls.Add(this.Back_2_Sy);
            this.Controls.Add(this.Back_2_JuMu);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.XZSB);
            this.Controls.Add(this.LBDX);
            this.Controls.Add(this.Cue_List);
            this.Controls.Add(this.ShowCueName);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "_2changci";
            this.Text = "_2changci";
            this.Load += new System.EventHandler(this._2changci_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ShowCueName;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListBox Cue_List;
        private System.Windows.Forms.ListBox LBDX;
        private System.Windows.Forms.ListBox XZSB;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button CC_DangQ;
        private System.Windows.Forms.Button CC_QuX;
        private System.Windows.Forms.Button CC_FanF;
        private System.Windows.Forms.Button CC_DuoD;
        private System.Windows.Forms.Button CC_DanD;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button ChangCi_QR;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button Back_2_JuMu;
        private System.Windows.Forms.Button Back_2_Sy;
    }
}