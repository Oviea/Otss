﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class bianpinqi : Form
    {
        private static int allshebei;
        private static string[] shebei;
        private int n, k, m, p;
        private static int clickcountDown;
        private static int clickcountUP;
        private static bool UPorDownFlag;//true:up false:down
        public bianpinqi()
        {
            InitializeComponent();
        }

        private void BPQ_ToL_Click(object sender, EventArgs e)
        {
            if (UPorDownFlag == false)
            {
                clickcountDown--;
                if (ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei >= allshebei - 30)
                {
                    MessageBox.Show("没有更多变频器！");
                    clickcountDown++;
                    //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
                }
                else
                {
                    delpanelall();

                    for (int i = 0; i < 10; i++)
                    {
                        panelset(200 + 150 * i, 110, shebei[(allshebei / 30) * 30 - ((allshebei / 30) - clickcountDown) * 30 + i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(200 + 150 * (i - 10), 325, shebei[(allshebei / 30) * 30 - ((allshebei / 30) - clickcountDown) * 30 + i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(200 + 150 * (i - 20), 540, shebei[(allshebei / 30) * 30 - ((allshebei / 30) - clickcountDown) * 30 + i]);
                    }

                    if (ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei == 0)
                    {
                        if (allshebei % 30 == 0)
                        {
                            ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei = 30;
                        }
                        else
                        {
                            ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei = allshebei % 30;
                        }
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei = ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei + 30;
                    }
                }
            }
            else
            {
                clickcountUP--;
                if (ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei >= allshebei - 30)
                {
                    MessageBox.Show("没有更多变频器！");
                    clickcountUP++;
                    //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
                }
                else
                {
                    delpanelall();

                    for (int i = 0; i < 10; i++)
                    {
                        panelset(200 + 150 * i, 110, shebei[(allshebei / 30) * 30 - ((allshebei / 30) - clickcountUP) * 30 + i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(200 + 150 * (i - 10), 325, shebei[(allshebei / 30) * 30 - ((allshebei / 30) - clickcountUP) * 30 + i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(200 + 150 * (i - 20), 540, shebei[(allshebei / 30) * 30 - ((allshebei / 30) - clickcountUP) * 30 + i]);
                    }

                    if (ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei == 0)
                    {
                        if (allshebei % 30 == 0)
                        {
                            ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei = 30;
                        }
                        else
                        {
                            ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei = allshebei % 30;
                        }
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei = ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei + 30;
                    }
                }
            }
        }

        private void BPQ_TR_Click(object sender, EventArgs e)
        {
            if (UPorDownFlag == false)
            {
                clickcountDown++;
                if (ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei == 0)
                {
                    MessageBox.Show("没有更多变频器！");
                    // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                    clickcountDown--;
                }
                else
                {
                    delpanelall();
                    if (ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei < 30)
                    {

                        if (0 <= ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei && ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei <= 10)
                        {
                            for (int i = 0; i < ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[30 * clickcountDown + i]);
                            }
                        }
                        else if (ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei > 10 && ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[30 * clickcountDown + i]);
                            }
                            for (int i = 10; i < ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei; i++)
                            {
                                panelset(200 + 150 * (i - 10), 325, shebei[30 * clickcountDown + i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[30 * clickcountDown + i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(200 + 150 * (i - 10), 325, shebei[30 * clickcountDown + i]);
                            }
                            for (int i = 20; i < ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei; i++)
                            {
                                panelset(200 + 150 * (i - 20), 540, shebei[30 * clickcountDown + i]);
                            }

                        }
                        ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(200 + 150 * i, 110, shebei[30 * clickcountDown + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(200 + 150 * (i - 10), 325, shebei[30 * clickcountDown + i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(200 + 150 * (i - 20), 540, shebei[30 * clickcountDown + i]);
                        }

                        ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei = ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei - 40;
                    }
                }
            }
            else
            {
                clickcountUP++;
                if (ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei == 0)
                {
                    MessageBox.Show("没有更多变频器！");
                    // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                    clickcountUP--;
                }
                else
                {
                    delpanelall();
                    if (ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei < 30)
                    {

                        if (0 <= ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei && ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei <= 10)
                        {
                            for (int i = 0; i < ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[30 * clickcountUP + i]);
                            }
                        }
                        else if (ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei > 10 && ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[30 * clickcountUP + i]);
                            }
                            for (int i = 10; i < ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei; i++)
                            {
                                panelset(200 + 150 * (i - 10), 325, shebei[30 * clickcountUP + i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[30 * clickcountUP + i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(200 + 150 * (i - 10), 325, shebei[30 * clickcountUP + i]);
                            }
                            for (int i = 20; i < ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei; i++)
                            {
                                panelset(200 + 150 * (i - 20), 540, shebei[30 * clickcountUP + i]);
                            }

                        }
                        ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(200 + 150 * i, 110, shebei[30 * clickcountUP + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(200 + 150 * (i - 10), 325, shebei[30 * clickcountUP + i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(200 + 150 * (i - 20), 540, shebei[30 * clickcountUP + i]);
                        }

                        ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei = ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei - 40;
                    }
                }
            }
        }

        private void BPQ_TXTS_Click(object sender, EventArgs e)
        {
            BPQ_TXTS.Enabled = false ;
            BPQ_TSTS.BackColor = Color.White;
            BPQ_TSTS.Enabled = true;
            BPQ_TXTS.BackColor = Color.AliceBlue;
            BPQ_MiddleL.Text = "台下变频器状态";
            UPorDownFlag = false;
            if (!UPorDownFlag)
            {
                delpanelall();
                if (File.Exists("SBSD.txt"))
                {
                    List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                    n = int.Parse(nkmp[0]);
                    k = int.Parse(nkmp[1]);
                    m = int.Parse(nkmp[2]);
                    p = int.Parse(nkmp[3]);
                    int totalshebei = n + m + k + p;
                    allshebei = totalshebei;
                    nkmp.Clear();
                    for (int i = 0; i < n; i++)
                    {
                        int j = i + 1;
                        nkmp.Add("调速设备" + j);
                    }
                    for (int i = n; i < n + k; i++)
                    {
                        int j = i + 1 - n;
                        nkmp.Add("调速互锁类设备" + j);
                    }
                    for (int i = n + k; i < n + k + m; i++)
                    {
                        int j = i + 1 - n - k;
                        nkmp.Add("定速定位设备" + j);
                    }
                    for (int i = n + k + m; i < n + k + m + p; i++)
                    {
                        int j = i + 1 - n - k - m;
                        nkmp.Add("定速设备" + j);
                    }
                    shebei = nkmp.ToArray();
                    //for(int i = 0; i < shebei.Length; i++)
                    //{
                    //    Console.WriteLine("++++++=+==" + shebei[i]);
                    //}
                    if (totalshebei <= 30)
                    {
                        if (0 <= totalshebei && totalshebei <= 10)
                        {
                            for (int i = 0; i < totalshebei; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[i]);
                            }
                        }
                        else if (totalshebei > 10 && totalshebei <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[i]);
                            }
                            for (int i = 10; i < totalshebei; i++)
                            {
                                panelset(200 + 150 * (i - 10), 325, shebei[i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(200 + 150 * (i - 10), 325, shebei[i]);
                            }
                            for (int i = 20; i < totalshebei; i++)
                            {
                                panelset(200 + 150 * (i - 20), 540, shebei[i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(200 + 150 * i, 110, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(200 + 150 * (i - 10), 325, shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(200 + 150 * (i - 20), 540, shebei[i]);
                        }
                        ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei = totalshebei - 30;
                    }
                }
            }
        }

        private void BPQ_TSTS_Click(object sender, EventArgs e)
        {
            BPQ_TXTS.Enabled = true;
            BPQ_TXTS.BackColor = Color.White;
            BPQ_TSTS.Enabled = false;
            BPQ_TSTS.BackColor = Color.AliceBlue;
            BPQ_MiddleL.Text = "台上变频器状态";

            UPorDownFlag = true;
            if (UPorDownFlag)
            {
                delpanelall();
                if (File.Exists("SBSD.txt"))
                {
                    List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                    n = int.Parse(nkmp[0]);
                    k = int.Parse(nkmp[1]);
                    m = int.Parse(nkmp[2]);
                    p = int.Parse(nkmp[3]);
                    int totalshebei = n + m + k + p;
                    allshebei = totalshebei;
                    nkmp.Clear();
                    for (int i = 0; i < n; i++)
                    {
                        int j = i + 1;
                        nkmp.Add("调速设备" + j);
                    }
                    for (int i = n; i < n + k; i++)
                    {
                        int j = i + 1 - n;
                        nkmp.Add("调速互锁类设备" + j);
                    }
                    for (int i = n + k; i < n + k + m; i++)
                    {
                        int j = i + 1 - n - k;
                        nkmp.Add("定速定位设备" + j);
                    }
                    for (int i = n + k + m; i < n + k + m + p; i++)
                    {
                        int j = i + 1 - n - k - m;
                        nkmp.Add("定速设备" + j);
                    }
                    shebei = nkmp.ToArray();
                    //for(int i = 0; i < shebei.Length; i++)
                    //{
                    //    Console.WriteLine("++++++=+==" + shebei[i]);
                    //}
                    if (totalshebei <= 30)
                    {
                        if (0 <= totalshebei && totalshebei <= 10)
                        {
                            for (int i = 0; i < totalshebei; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[i]);
                            }
                        }
                        else if (totalshebei > 10 && totalshebei <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[i]);
                            }
                            for (int i = 10; i < totalshebei; i++)
                            {
                                panelset(200 + 150 * (i - 10), 325, shebei[i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(200 + 150 * (i - 10), 325, shebei[i]);
                            }
                            for (int i = 20; i < totalshebei; i++)
                            {
                                panelset(200 + 150 * (i - 20), 540, shebei[i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(200 + 150 * i, 110, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(200 + 150 * (i - 10), 325, shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(200 + 150 * (i - 20), 540, shebei[i]);
                        }
                        ChangCiSheZhiGlobalData.TaiShangBianPingQiShengYuSheBei = totalshebei - 30;
                    }
                }
            }
        }

        private void BPQ_Back2Main_Click(object sender, EventArgs e)
        {
            var frm = new main();
            frm.Show();
            this.Close();
        }

        private void BPQ_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bianpinqi_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            UPorDownFlag = false;
            if (!UPorDownFlag)
            {
                BPQ_TXTS.BackColor = Color.AliceBlue;
                BPQ_TXTS.Enabled = false;
                delpanelall();
                if (File.Exists("SBSD.txt"))
                {
                    List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                    n = int.Parse(nkmp[0]);
                    k = int.Parse(nkmp[1]);
                    m = int.Parse(nkmp[2]);
                    p = int.Parse(nkmp[3]);
                    int totalshebei = n + m + k + p;
                    allshebei = totalshebei;
                    nkmp.Clear();
                    for (int i = 0; i < n; i++)
                    {
                        int j = i + 1;
                        nkmp.Add("调速设备" + j);
                    }
                    for (int i = n; i < n + k; i++)
                    {
                        int j = i + 1 - n;
                        nkmp.Add("调速互锁类设备" + j);
                    }
                    for (int i = n + k; i < n + k + m; i++)
                    {
                        int j = i + 1 - n - k;
                        nkmp.Add("定速定位设备" + j);
                    }
                    for (int i = n + k + m; i < n + k + m + p; i++)
                    {
                        int j = i + 1 - n - k - m;
                        nkmp.Add("定速设备" + j);
                    }
                    shebei = nkmp.ToArray();
                    //for(int i = 0; i < shebei.Length; i++)
                    //{
                    //    Console.WriteLine("++++++=+==" + shebei[i]);
                    //}
                    if (totalshebei <= 30)
                    {
                        if (0 <= totalshebei && totalshebei <= 10)
                        {
                            for (int i = 0; i < totalshebei; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[i]);
                            }
                        }
                        else if (totalshebei > 10 && totalshebei <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[i]);
                            }
                            for (int i = 10; i < totalshebei; i++)
                            {
                                panelset(200 + 150 * (i - 10), 325, shebei[i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(200 + 150 * i, 110, shebei[i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(200 + 150 * (i - 10), 325, shebei[i]);
                            }
                            for (int i = 20; i < totalshebei; i++)
                            {
                                panelset(200 + 150 * (i - 20), 540, shebei[i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(200 + 150 * i, 110, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(200 + 150 * (i - 10), 325, shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(200 + 150 * (i - 20), 540, shebei[i]);
                        }
                        ChangCiSheZhiGlobalData.TaiXiaBianPingQiShengYuSheBei = totalshebei - 30;
                    }
                }
            }
        }

        private void delpanelall()
        {
            if (Controls["BPQ_P200110"] != null)
            {
                Controls["BPQ_P200110"].Dispose();
            }
            if (Controls["BPQ_P350110"] != null)
            {
                Controls["BPQ_P350110"].Dispose();
            }
            if (Controls["BPQ_P500110"] != null)
            {
                Controls["BPQ_P500110"].Dispose();
            }
            if (Controls["BPQ_P650110"] != null)
            {
                Controls["BPQ_P650110"].Dispose();
            }
            if (Controls["BPQ_P800110"] != null)
            {
                Controls["BPQ_P800110"].Dispose();
            }
            if (Controls["BPQ_P950110"] != null)
            {
                Controls["BPQ_P950110"].Dispose();
            }
            if (Controls["BPQ_P1100110"] != null)
            {
                Controls["BPQ_P1100110"].Dispose();
            }
            if (Controls["BPQ_P1250110"] != null)
            {
                Controls["BPQ_P1250110"].Dispose();
            }
            if (Controls["BPQ_P1400110"] != null)
            {
                Controls["BPQ_P1400110"].Dispose();
            }
            if (Controls["BPQ_P1550110"] != null)
            {
                Controls["BPQ_P1550110"].Dispose();
            }


            if (Controls["BPQ_P200325"] != null)
            {
                Controls["BPQ_P200325"].Dispose();
            }
            if (Controls["BPQ_P350325"] != null)
            {
                Controls["BPQ_P350325"].Dispose();
            }
            if (Controls["BPQ_P500325"] != null)
            {
                Controls["BPQ_P500325"].Dispose();
            }
            if (Controls["BPQ_P650325"] != null)
            {
                Controls["BPQ_P650325"].Dispose();
            }
            if (Controls["BPQ_P800325"] != null)
            {
                Controls["BPQ_P800325"].Dispose();
            }
            if (Controls["BPQ_P950325"] != null)
            {
                Controls["BPQ_P950325"].Dispose();
            }
            if (Controls["BPQ_P1100325"] != null)
            {
                Controls["BPQ_P1100325"].Dispose();
            }
            if (Controls["BPQ_P1250325"] != null)
            {
                Controls["BPQ_P1250325"].Dispose();
            }
            if (Controls["BPQ_P1400325"] != null)
            {
                Controls["BPQ_P1400325"].Dispose();
            }
            if (Controls["BPQ_P1550325"] != null)
            {
                Controls["BPQ_P1550325"].Dispose();
            }


            if (Controls["BPQ_P200540"] != null)
            {
                Controls["BPQ_P200540"].Dispose();
            }
            if (Controls["BPQ_P350540"] != null)
            {
                Controls["BPQ_P350540"].Dispose();
            }
            if (Controls["BPQ_P500540"] != null)
            {
                Controls["BPQ_P500540"].Dispose();
            }
            if (Controls["BPQ_P650540"] != null)
            {
                Controls["BPQ_P650540"].Dispose();
            }
            if (Controls["BPQ_P800540"] != null)
            {
                Controls["BPQ_P800540"].Dispose();
            }
            if (Controls["BPQ_P950540"] != null)
            {
                Controls["BPQ_P950540"].Dispose();
            }
            if (Controls["BPQ_P1100540"] != null)
            {
                Controls["BPQ_P1100540"].Dispose();
            }
            if (Controls["BPQ_P1250540"] != null)
            {
                Controls["BPQ_P1250540"].Dispose();
            }
            if (Controls["BPQ_P1400540"] != null)
            {
                Controls["BPQ_P1400540"].Dispose();
            }
            if (Controls["BPQ_P1550540"] != null)
            {
                Controls["BPQ_P1550540"].Dispose();
            }
        }

        private void panelset(int x, int y, string shebeiname)
        {
            Label L_SBM = new Label();
            L_SBM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            L_SBM.Font = new System.Drawing.Font("宋体", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            L_SBM.Location = new System.Drawing.Point(0, 90);
            L_SBM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            L_SBM.Name = "L_SBM"+x+y;
            L_SBM.Size = new System.Drawing.Size(70, 20);
            L_SBM.TabIndex = 813;
            L_SBM.Text = shebeiname;
            L_SBM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // L_BPQDZ
            // 
            Label L_BPQDZ = new Label();
            L_BPQDZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            L_BPQDZ.Location = new System.Drawing.Point(0, 110);
            L_BPQDZ.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            L_BPQDZ.Name = "L_BPQDZ" + x + y;
            L_BPQDZ.Size = new System.Drawing.Size(70, 20);
            L_BPQDZ.TabIndex = 814;
            L_BPQDZ.Text = "地址";
            L_BPQDZ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BPQ_P
            // 

            // 
            // L_ZT1
            // 
            Label L_ZT1 = new Label();
            L_ZT1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            L_ZT1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            L_ZT1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            L_ZT1.Location = new System.Drawing.Point(0, 0);
            L_ZT1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            L_ZT1.Name = "L_ZT1" + x + y;
            L_ZT1.Size = new System.Drawing.Size(70, 20);
            L_ZT1.TabIndex = 1045;
            L_ZT1.Text = "状态字1";
            L_ZT1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // L_ZT2
            // 
            Label L_ZT2 = new Label();
            L_ZT2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            L_ZT2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            L_ZT2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            L_ZT2.Location = new System.Drawing.Point(0, 20);
            L_ZT2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            L_ZT2.Name = "L_ZT2" + x + y;
            L_ZT2.Size = new System.Drawing.Size(70, 20);
            L_ZT2.TabIndex = 1046;
            L_ZT2.Text = "状态字2";
            L_ZT2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // 
            // BPQIcon
            // 
            PictureBox BPQIcon = new PictureBox();
            BPQIcon.Image = ((System.Drawing.Image)(global::BigPro.Properties.Resources.变频器));
            BPQIcon.Location = new System.Drawing.Point(0, 40);
            BPQIcon.Margin = new System.Windows.Forms.Padding(0);
            BPQIcon.Name = "BPQIcon" + x + y;
            BPQIcon.Size = new System.Drawing.Size(70, 50);
            BPQIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            BPQIcon.TabIndex = 812;
            BPQIcon.TabStop = false;


            Panel BPQ_P = new Panel();
            BPQ_P.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            BPQ_P.Controls.Add(L_ZT1);
            BPQ_P.Controls.Add(L_SBM);
            BPQ_P.Controls.Add(L_BPQDZ);
            BPQ_P.Controls.Add(BPQIcon);
            BPQ_P.Controls.Add(L_ZT2);
            BPQ_P.Location = new System.Drawing.Point(x, y);
            BPQ_P.Name = "BPQ_P" + x + y;
            BPQ_P.Size = new System.Drawing.Size(70, 130);
            BPQ_P.TabIndex = 1434;
            this.Controls.Add(BPQ_P);
        }
    }
}
