﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class weizhizhuangtai : Form
    {
        private static int allshebei;
        private static string[] shebei;
        private static int clickcountTSTS;
        private static int clickcountTXTS;
        private static int clickcountDSDW;
        private static int clickcountDS;
        private int n, k, m, p;
        private static int ZTFour;//0:TSTS 1:TXTS 2:DSDW 3:DS
        public weizhizhuangtai()
        {
            InitializeComponent();
        }

        private void WZZT_TL_Click(object sender, EventArgs e)
        {
            if (ZTFour == 0)
            {
                clickcountTSTS--;
                if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS >= allshebei - 40)
                {
                    MessageBox.Show("没有更多台上调速设备！");
                    clickcountTSTS++;
                    //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
                }
                else
                {
                    delpanelall();

                    for (int i = 0; i < 10; i++)
                    {
                        panelset(100, 150 + 50 * i, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountTSTS) * 40 + i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(550, 150 + 50 * (i - 10), shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountTSTS) * 40 + i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(1000, 150 + 50 * (i - 20), shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountTSTS) * 40 + i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(1450, 150 + 50 * (i - 30), shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountTSTS) * 40 + i]);
                    }
                    if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS == 0)
                    {
                        if (allshebei % 40 == 0)
                        {
                            ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS = 40;
                        }
                        else
                        {
                            ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS = allshebei % 40;
                        }
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS = ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS + 40;
                    }
                }
            }
            else if (ZTFour == 1)
            {
                clickcountTXTS--;
                if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS >= allshebei - 40)
                {
                    MessageBox.Show("没有更多台下调速设备！");
                    clickcountTXTS++;
                    //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
                }
                else
                {
                    delpanelall();

                    for (int i = 0; i < 10; i++)
                    {
                        panelset(100, 150 + 50 * i, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountTXTS) * 40 + i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(550, 150 + 50 * (i - 10), shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountTXTS) * 40 + i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(1000, 150 + 50 * (i - 20), shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountTXTS) * 40 + i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(1450, 150 + 50 * (i - 30), shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountTXTS) * 40 + i]);
                    }
                    if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS == 0)
                    {
                        if (allshebei % 40 == 0)
                        {
                            ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS = 40;
                        }
                        else
                        {
                            ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS = allshebei % 40;
                        }
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS = ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS + 40;
                    }
                }
            }else if (ZTFour == 2)
            {
                clickcountDSDW--;
                if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW >= allshebei - 40)
                {
                    MessageBox.Show("没有更多定速定位设备！");
                    clickcountDSDW++;
                    //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
                }
                else
                {
                    delpanelall();

                    for (int i = 0; i < 10; i++)
                    {
                        panelset(100, 150 + 50 * i, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountDSDW) * 40 + i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(550, 150 + 50 * (i - 10), shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountDSDW) * 40 + i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(1000, 150 + 50 * (i - 20), shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountDSDW) * 40 + i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(1450, 150 + 50 * (i - 30), shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountDSDW) * 40 + i]);
                    }
                    if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW == 0)
                    {
                        if (allshebei % 40 == 0)
                        {
                            ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW = 40;
                        }
                        else
                        {
                            ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW = allshebei % 40;
                        }
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW = ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW + 40;
                    }
                }
            }
            else if (ZTFour == 3)
            {
                clickcountDS--;
                if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS >= allshebei - 40)
                {
                    MessageBox.Show("没有更多定速定位设备！");
                    clickcountDS++;
                    //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
                }
                else
                {
                    delpanelall();

                    for (int i = 0; i < 10; i++)
                    {
                        panelset(100, 150 + 50 * i, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountDS) * 40 + i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(550, 150 + 50 * (i - 10), shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountDS) * 40 + i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(1000, 150 + 50 * (i - 20), shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountDS) * 40 + i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(1450, 150 + 50 * (i - 30), shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcountDS) * 40 + i]);
                    }
                    if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS == 0)
                    {
                        if (allshebei % 40 == 0)
                        {
                            ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS = 40;
                        }
                        else
                        {
                            ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS = allshebei % 40;
                        }
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS = ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS + 40;
                    }
                }
            }
        }

        private void WZZT_TR_Click(object sender, EventArgs e)
        {
            if (ZTFour == 0)
            {
                clickcountTSTS++;
                if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS == 0)
                {
                    MessageBox.Show("没有更多台上调速设备");
                    // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                    clickcountTSTS--;
                }
                else
                {
                    delpanelall();
                    if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS < 40)
                    {

                        if (0 <= ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS && ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS <= 10)
                        {
                            for (int i = 0; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountTSTS + i]);
                            }
                        }
                        else if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS > 10 && ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountTSTS + i]);
                            }
                            for (int i = 10; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS; i++)
                            {
                                panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountTSTS + i]);
                            }
                        }
                        else if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS > 20 && ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS <= 30)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountTSTS + i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountTSTS + i]);
                            }
                            for (int i = 20; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS; i++)
                            {
                                panelset(1000, 150 + 50 * (i - 20), shebei[40 * clickcountTSTS + i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountTSTS + i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountTSTS + i]);
                            }
                            for (int i = 20; i < 30; i++)
                            {
                                panelset(1000, 150 + 50 * (i - 20), shebei[40 * clickcountTSTS + i]);
                            }
                            for (int i = 30; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS; i++)
                            {
                                panelset(1450, 150 + 50 * (i - 30), shebei[40 * clickcountTSTS + i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[40 * clickcountTSTS + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountTSTS + i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[40 * clickcountTSTS + i]);
                        }
                        for (int i = 30; i < 40; i++)
                        {
                            panelset(1450, 150 + 50 * (i - 30), shebei[40 * clickcountTSTS + i]);
                        }
                        ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS = ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS - 40;
                    }
                }
            }else if (ZTFour == 1)
            {
                clickcountTXTS++;
                if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS == 0)
                {
                    MessageBox.Show("没有更多台下调速设备");
                    // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                    clickcountTXTS--;
                }
                else
                {
                    delpanelall();
                    if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS < 40)
                    {

                        if (0 <= ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS && ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS <= 10)
                        {
                            for (int i = 0; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountTXTS + i]);
                            }
                        }
                        else if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS > 10 && ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountTXTS + i]);
                            }
                            for (int i = 10; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS; i++)
                            {
                                panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountTXTS + i]);
                            }
                        }
                        else if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS > 20 && ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS <= 30)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountTXTS + i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountTXTS + i]);
                            }
                            for (int i = 20; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS; i++)
                            {
                                panelset(1000, 150 + 50 * (i - 20), shebei[40 * clickcountTXTS + i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountTXTS + i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountTXTS + i]);
                            }
                            for (int i = 20; i < 30; i++)
                            {
                                panelset(1000, 150 + 50 * (i - 20), shebei[40 * clickcountTXTS + i]);
                            }
                            for (int i = 30; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS; i++)
                            {
                                panelset(1450, 150 + 50 * (i - 30), shebei[40 * clickcountTXTS + i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[40 * clickcountTXTS + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountTXTS + i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[40 * clickcountTXTS + i]);
                        }
                        for (int i = 30; i < 40; i++)
                        {
                            panelset(1450, 150 + 50 * (i - 30), shebei[40 * clickcountTXTS + i]);
                        }
                        ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS = ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS - 40;
                    }
                }
            }
            else if (ZTFour == 2)
            {
                clickcountDSDW++;
                if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW == 0)
                {
                    MessageBox.Show("没有更多台下调速设备");
                    // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                    clickcountDSDW--;
                }
                else
                {
                    delpanelall();
                    if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW < 40)
                    {

                        if (0 <= ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW && ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW <= 10)
                        {
                            for (int i = 0; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountDSDW + i]);
                            }
                        }
                        else if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW > 10 && ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountDSDW + i]);
                            }
                            for (int i = 10; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW; i++)
                            {
                                panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountDSDW + i]);
                            }
                        }
                        else if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW > 20 && ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW <= 30)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountDSDW + i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountDSDW + i]);
                            }
                            for (int i = 20; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW; i++)
                            {
                                panelset(1000, 150 + 50 * (i - 20), shebei[40 * clickcountDSDW + i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountDSDW + i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountDSDW + i]);
                            }
                            for (int i = 20; i < 30; i++)
                            {
                                panelset(1000, 150 + 50 * (i - 20), shebei[40 * clickcountDSDW + i]);
                            }
                            for (int i = 30; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW; i++)
                            {
                                panelset(1450, 150 + 50 * (i - 30), shebei[40 * clickcountDSDW + i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[40 * clickcountDSDW + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountDSDW + i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[40 * clickcountDSDW + i]);
                        }
                        for (int i = 30; i < 40; i++)
                        {
                            panelset(1450, 150 + 50 * (i - 30), shebei[40 * clickcountDSDW + i]);
                        }
                        ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW = ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW - 40;
                    }
                }
            }
            else if (ZTFour == 3)
            {
                clickcountDS++;
                if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS == 0)
                {
                    MessageBox.Show("没有更多台下调速设备");
                    // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                    clickcountDS--;
                }
                else
                {
                    delpanelall();
                    if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS < 40)
                    {

                        if (0 <= ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS && ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS <= 10)
                        {
                            for (int i = 0; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountDS + i]);
                            }
                        }
                        else if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS > 10 && ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountDS + i]);
                            }
                            for (int i = 10; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS; i++)
                            {
                                panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountDS + i]);
                            }
                        }
                        else if (ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS > 20 && ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS <= 30)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountDS + i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountDS + i]);
                            }
                            for (int i = 20; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS; i++)
                            {
                                panelset(1000, 150 + 50 * (i - 20), shebei[40 * clickcountDS + i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(100, 150 + 50 * i, shebei[40 * clickcountDS + i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountDS + i]);
                            }
                            for (int i = 20; i < 30; i++)
                            {
                                panelset(1000, 150 + 50 * (i - 20), shebei[40 * clickcountDS + i]);
                            }
                            for (int i = 30; i < ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS; i++)
                            {
                                panelset(1450, 150 + 50 * (i - 30), shebei[40 * clickcountDS + i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[40 * clickcountDS + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[40 * clickcountDS + i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[40 * clickcountDS + i]);
                        }
                        for (int i = 30; i < 40; i++)
                        {
                            panelset(1450, 150 + 50 * (i - 30), shebei[40 * clickcountDS + i]);
                        }
                        ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS = ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS - 40;
                    }
                }
            }
        }

        private void WZZT_TSTS_Click(object sender, EventArgs e)
        {
            WZZT_TSTS.Enabled = false;
            WZZT_TSTS.BackColor = Color.AliceBlue;
            WZZT_TXTS.Enabled = true;
            WZZT_TXTS.BackColor = Color.White;
            WZZT_DSDW.Enabled = true;
            WZZT_DSDW.BackColor = Color.White;
            WZZT_DS.Enabled = true;
            WZZT_DS.BackColor = Color.White;
            WZZT_ML.Text = "台上调速";
            ZTFour = 0;
            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                if (totalshebei <= 40)
                {
                    if (0 <= totalshebei && totalshebei <= 10)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                    }
                    else if (totalshebei > 10 && totalshebei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < totalshebei; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                    }
                    else if (totalshebei > 20 && totalshebei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                        for (int i = 20; i < totalshebei; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                        }
                        for (int i = 30; i < totalshebei; i++)
                        {
                            panelset(1450, 150 + 50 * (i - 30), shebei[i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(100, 150 + 50 * i, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(550, 150 + 50 * (i - 10), shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(1450, 150 + 50 * (i - 30), shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS = totalshebei - 40;
                }
            }
        }

        private void WZZT_TXTS_Click(object sender, EventArgs e)
        {
            WZZT_TXTS.Enabled = false;
            WZZT_TXTS.BackColor = Color.AliceBlue;
            WZZT_TSTS.Enabled = true;
            WZZT_TSTS.BackColor = Color.White;
            WZZT_DSDW.Enabled = true;
            WZZT_DSDW.BackColor = Color.White;
            WZZT_DS.Enabled = true;
            WZZT_DS.BackColor = Color.White;
            WZZT_ML.Text = "台下调速";
            ZTFour = 1;
            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                if (totalshebei <= 40)
                {
                    if (0 <= totalshebei && totalshebei <= 10)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                    }
                    else if (totalshebei > 10 && totalshebei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < totalshebei; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                    }
                    else if (totalshebei > 20 && totalshebei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                        for (int i = 20; i < totalshebei; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                        }
                        for (int i = 30; i < totalshebei; i++)
                        {
                            panelset(1450, 150 + 50 * (i - 30), shebei[i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(100, 150 + 50 * i, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(550, 150 + 50 * (i - 10), shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(1450, 150 + 50 * (i - 30), shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTXTS = totalshebei - 40;
                }
            }
        }

        private void WZZT_DSDW_Click(object sender, EventArgs e)
        {
            WZZT_DSDW.Enabled = false;
            WZZT_DSDW.BackColor = Color.AliceBlue;
            WZZT_TSTS.Enabled = true;
            WZZT_TSTS.BackColor = Color.White;
            WZZT_TXTS.Enabled = true;
            WZZT_TXTS.BackColor = Color.White;
            WZZT_DS.Enabled = true;
            WZZT_DS.BackColor = Color.White;
            WZZT_ML.Text = "定速定位";
            ZTFour = 2;
            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                if (totalshebei <= 40)
                {
                    if (0 <= totalshebei && totalshebei <= 10)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                    }
                    else if (totalshebei > 10 && totalshebei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < totalshebei; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                    }
                    else if (totalshebei > 20 && totalshebei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                        for (int i = 20; i < totalshebei; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                        }
                        for (int i = 30; i < totalshebei; i++)
                        {
                            panelset(1450, 150 + 50 * (i - 30), shebei[i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(100, 150 + 50 * i, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(550, 150 + 50 * (i - 10), shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(1450, 150 + 50 * (i - 30), shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDSDW = totalshebei - 40;
                }
            }
        }

        private void WZZT_DS_Click(object sender, EventArgs e)
        {
            WZZT_DS.Enabled = false;
            WZZT_DS.BackColor = Color.AliceBlue;
            WZZT_TSTS.Enabled = true;
            WZZT_TSTS.BackColor = Color.White;
            WZZT_TXTS.Enabled = true;
            WZZT_TXTS.BackColor = Color.White;
            WZZT_DSDW.Enabled = true;
            WZZT_DSDW.BackColor = Color.White;
            WZZT_ML.Text = "定速";
            ZTFour = 3;
            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                if (totalshebei <= 40)
                {
                    if (0 <= totalshebei && totalshebei <= 10)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                    }
                    else if (totalshebei > 10 && totalshebei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < totalshebei; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                    }
                    else if (totalshebei > 20 && totalshebei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                        for (int i = 20; i < totalshebei; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                        }
                        for (int i = 30; i < totalshebei; i++)
                        {
                            panelset(1450, 150 + 50 * (i - 30), shebei[i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(100, 150 + 50 * i, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(550, 150 + 50 * (i - 10), shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(1450, 150 + 50 * (i - 30), shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiDS = totalshebei - 40;
                }
            }
        }

        private void WZZT_2Main_Click(object sender, EventArgs e)
        {
            var frm = new main();
            frm.Show();
            this.Close();
        }

        private void WZZT_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void weizhizhuangtai_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            delpanelall();
            WZZT_TSTS.BackColor = Color.AliceBlue;
            WZZT_TSTS.Enabled = false;
            WZZT_ML.Text = "台上调速";
            ZTFour = 0;
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                if (totalshebei <= 40)
                {
                    if (0 <= totalshebei && totalshebei <= 10)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(100, 150+50*i, shebei[i]);
                        }
                    }
                    else if (totalshebei > 10 && totalshebei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < totalshebei; i++)
                        {
                            panelset(550, 150 + 50 * (i-10), shebei[i]);
                        }
                    }
                    else if (totalshebei > 20 && totalshebei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                        for (int i = 20; i < totalshebei; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(100, 150 + 50 * i, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(550, 150 + 50 * (i - 10), shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                        }
                        for (int i = 30; i < totalshebei; i++)
                        {
                            panelset(1450, 150 + 50 * (i - 30), shebei[i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(100, 150 + 50 * i, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(550, 150 + 50 * (i - 10), shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(1000, 150 + 50 * (i - 20), shebei[i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(1450, 150 + 50 * (i - 30), shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.WeiZhiZhuangTaiShengYuSheBeiTSTS = totalshebei - 40;
                }
            }
        }

        private void panelset(int x, int y, string shebeiname)
        {
            // 
            // SBM_WZZT
            // 
            Label SBM_WZZT = new Label();
            SBM_WZZT.BackColor = System.Drawing.SystemColors.Control;
            SBM_WZZT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SBM_WZZT.Font = new System.Drawing.Font("宋体", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            SBM_WZZT.ForeColor = System.Drawing.SystemColors.ControlText;
            SBM_WZZT.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            SBM_WZZT.Location = new System.Drawing.Point(-1, -1);
            SBM_WZZT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            SBM_WZZT.Name = "SBM_WZZT"+x+y;
            SBM_WZZT.Size = new System.Drawing.Size(90, 35);
            SBM_WZZT.TabIndex = 423;
            SBM_WZZT.Text = shebeiname;
            SBM_WZZT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // WZ_WZZT
            // 
            Label WZ_WZZT = new Label();
            WZ_WZZT.BackColor = System.Drawing.SystemColors.Control;
            WZ_WZZT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            WZ_WZZT.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            WZ_WZZT.ForeColor = System.Drawing.SystemColors.ControlText;
            WZ_WZZT.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            WZ_WZZT.Location = new System.Drawing.Point(88, -1);
            WZ_WZZT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            WZ_WZZT.Name = "WZ_WZZT" + x + y;
            WZ_WZZT.Size = new System.Drawing.Size(70, 35);
            WZ_WZZT.TabIndex = 424;
            WZ_WZZT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ZT_WZZT
            // 
            Label ZT_WZZT = new Label();
            ZT_WZZT.BackColor = System.Drawing.SystemColors.Control;
            ZT_WZZT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            ZT_WZZT.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            ZT_WZZT.ForeColor = System.Drawing.SystemColors.ControlText;
            ZT_WZZT.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            ZT_WZZT.Location = new System.Drawing.Point(157, -1);
            ZT_WZZT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            ZT_WZZT.Name = "ZT_WZZT" + x + y;
            ZT_WZZT.Size = new System.Drawing.Size(70, 35);
            ZT_WZZT.TabIndex = 425;
            ZT_WZZT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // XW_WZZT
            // 
            Label XW_WZZT = new Label();
            XW_WZZT.BackColor = System.Drawing.SystemColors.Control;
            XW_WZZT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            XW_WZZT.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            XW_WZZT.ForeColor = System.Drawing.SystemColors.ControlText;
            XW_WZZT.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            XW_WZZT.Location = new System.Drawing.Point(226, -1);
            XW_WZZT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            XW_WZZT.Name = "XW_WZZT" + x + y;
            XW_WZZT.Size = new System.Drawing.Size(70, 35);
            XW_WZZT.TabIndex = 614;
            XW_WZZT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PC_WZZT
            //
            Label PC_WZZT = new Label();
            PC_WZZT.BackColor = System.Drawing.SystemColors.Control;
            PC_WZZT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            PC_WZZT.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            PC_WZZT.ForeColor = System.Drawing.SystemColors.ControlText;
            PC_WZZT.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            PC_WZZT.Location = new System.Drawing.Point(295, -1);
            PC_WZZT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            PC_WZZT.Name = "PC_WZZT" + x + y;
            PC_WZZT.Size = new System.Drawing.Size(70, 35);
            PC_WZZT.TabIndex = 615;
            PC_WZZT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // 
            // P_WZZT
            // 
            Panel P_WZZT = new Panel();
            P_WZZT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            P_WZZT.Controls.Add(SBM_WZZT);
            P_WZZT.Controls.Add(WZ_WZZT);
            P_WZZT.Controls.Add(ZT_WZZT);
            P_WZZT.Controls.Add(XW_WZZT);
            P_WZZT.Controls.Add(PC_WZZT);
            P_WZZT.Location = new System.Drawing.Point(x, y);
            P_WZZT.Name = "P_WZZT" + x + y;
            P_WZZT.Size = new System.Drawing.Size(365, 35);
            P_WZZT.TabIndex = 860;
            this.Controls.Add(P_WZZT);
        }

        private void delpanelall()
        {
            if (Controls["P_WZZT100150"] != null)
            {
                Controls["P_WZZT100150"].Dispose();
            }
            if (Controls["P_WZZT100200"] != null)
            {
                Controls["P_WZZT100200"].Dispose();
            }
            if (Controls["P_WZZT100250"] != null)
            {
                Controls["P_WZZT100250"].Dispose();
            }
            if (Controls["P_WZZT100300"] != null)
            {
                Controls["P_WZZT100300"].Dispose();
            }
            if (Controls["P_WZZT100350"] != null)
            {
                Controls["P_WZZT100350"].Dispose();
            }
            if (Controls["P_WZZT100400"] != null)
            {
                Controls["P_WZZT100400"].Dispose();
            }
            if (Controls["P_WZZT100450"] != null)
            {
                Controls["P_WZZT100450"].Dispose();
            }
            if (Controls["P_WZZT100500"] != null)
            {
                Controls["P_WZZT100500"].Dispose();
            }
            if (Controls["P_WZZT100550"] != null)
            {
                Controls["P_WZZT100550"].Dispose();
            }
            if (Controls["P_WZZT100600"] != null)
            {
                Controls["P_WZZT100600"].Dispose();
            }



            if (Controls["P_WZZT550150"] != null)
            {
                Controls["P_WZZT550150"].Dispose();
            }
            if (Controls["P_WZZT550200"] != null)
            {
                Controls["P_WZZT550200"].Dispose();
            }
            if (Controls["P_WZZT550250"] != null)
            {
                Controls["P_WZZT550250"].Dispose();
            }
            if (Controls["P_WZZT550300"] != null)
            {
                Controls["P_WZZT550300"].Dispose();
            }
            if (Controls["P_WZZT550350"] != null)
            {
                Controls["P_WZZT550350"].Dispose();
            }
            if (Controls["P_WZZT550400"] != null)
            {
                Controls["P_WZZT550400"].Dispose();
            }
            if (Controls["P_WZZT550450"] != null)
            {
                Controls["P_WZZT550450"].Dispose();
            }
            if (Controls["P_WZZT550500"] != null)
            {
                Controls["P_WZZT550500"].Dispose();
            }
            if (Controls["P_WZZT550550"] != null)
            {
                Controls["P_WZZT550550"].Dispose();
            }
            if (Controls["P_WZZT550600"] != null)
            {
                Controls["P_WZZT550600"].Dispose();
            }


            if (Controls["P_WZZT1000150"] != null)
            {
                Controls["P_WZZT1000150"].Dispose();
            }
            if (Controls["P_WZZT1000200"] != null)
            {
                Controls["P_WZZT1000200"].Dispose();
            }
            if (Controls["P_WZZT1000250"] != null)
            {
                Controls["P_WZZT1000250"].Dispose();
            }
            if (Controls["P_WZZT1000300"] != null)
            {
                Controls["P_WZZT1000300"].Dispose();
            }
            if (Controls["P_WZZT1000350"] != null)
            {
                Controls["P_WZZT1000350"].Dispose();
            }
            if (Controls["P_WZZT1000400"] != null)
            {
                Controls["P_WZZT1000400"].Dispose();
            }
            if (Controls["P_WZZT1000450"] != null)
            {
                Controls["P_WZZT1000450"].Dispose();
            }
            if (Controls["P_WZZT1000500"] != null)
            {
                Controls["P_WZZT1000500"].Dispose();
            }
            if (Controls["P_WZZT1000550"] != null)
            {
                Controls["P_WZZT1000550"].Dispose();
            }
            if (Controls["P_WZZT1000600"] != null)
            {
                Controls["P_WZZT1000600"].Dispose();
            }


            if (Controls["P_WZZT1450150"] != null)
            {
                Controls["P_WZZT1450150"].Dispose();
            }
            if (Controls["P_WZZT1450200"] != null)
            {
                Controls["P_WZZT1450200"].Dispose();
            }
            if (Controls["P_WZZT1450250"] != null)
            {
                Controls["P_WZZT1450250"].Dispose();
            }
            if (Controls["P_WZZT1450300"] != null)
            {
                Controls["P_WZZT1450300"].Dispose();
            }
            if (Controls["P_WZZT1450350"] != null)
            {
                Controls["P_WZZT1450350"].Dispose();
            }
            if (Controls["P_WZZT1450400"] != null)
            {
                Controls["P_WZZT1450400"].Dispose();
            }
            if (Controls["P_WZZT1450450"] != null)
            {
                Controls["P_WZZT1450450"].Dispose();
            }
            if (Controls["P_WZZT1450500"] != null)
            {
                Controls["P_WZZT1450500"].Dispose();
            }
            if (Controls["P_WZZT1450550"] != null)
            {
                Controls["P_WZZT1450550"].Dispose();
            }
            if (Controls["P_WZZT1450600"] != null)
            {
                Controls["P_WZZT1450600"].Dispose();
            }
        }
    }
}
