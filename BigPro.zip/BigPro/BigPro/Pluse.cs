﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class Pluse : Form
    {
        private bool[,] validate1;
        private int[,] input1;
        private bool[,] validate2;
        private int[,] input2;
        private bool[,] validate3;
        private int[,] input3;
        private int[,] totalinput;
        private int thirtyzheng = 0;
        private int thirtyyu = 0;
        private int tenzheng = 0;
        private int tenyu = 0;
        private string[] shebeiinfo;
        private int ThirtyZ;
        private int beginindex1, beginindex2;
        public Pluse()
        {
            InitializeComponent();
        }
    

        private void MC_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MC_2Main_Click(object sender, EventArgs e)
        {
            var admin = new main();
            this.Close();
            admin.Show();
        }

        private void MC_TL_Click(object sender, EventArgs e)
        {
            thirtyzheng = thirtyzheng + 1;
            beginindex1 = beginindex1 - 30;
            for (int i = 0; i < 1; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = "";
                    dataGridView2.Rows[i].Cells[j].Value = "";
                    dataGridView3.Rows[i].Cells[j].Value = "";
                }
            }
            if (thirtyzheng > 0 && thirtyzheng <= ThirtyZ)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[beginindex1 + i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                }
                validate1 = new bool[2, 10];
                input1 = new int[2, 10];
                validate2 = new bool[2, 10];
                input2 = new int[2, 10];
                validate3 = new bool[2, 10];
                input3 = new int[2, 10];
            }
            else if (thirtyzheng > ThirtyZ)
            {
                MessageBox.Show("没有更多数据!");
                //   ToLeft_SZ.Enabled = false;
                thirtyzheng = thirtyzheng - 1;
                beginindex1 = beginindex1 + 30;
            }
            MC_TR.Enabled = true;
            Console.WriteLine("%%%%%#%#Left" + thirtyzheng);
        }

        private void MC_TR_Click(object sender, EventArgs e)
        {
            thirtyzheng = thirtyzheng - 1;
            beginindex1 = beginindex1 + 30;
            for (int i = 0; i < 1; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = "";
                    dataGridView2.Rows[i].Cells[j].Value = "";
                    dataGridView3.Rows[i].Cells[j].Value = "";
                }
            }
            if (thirtyzheng > 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[beginindex1 + i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                }
                validate1 = new bool[2, 10];
                input1 = new int[2, 10];
                validate2 = new bool[2, 10];
                input2 = new int[2, 10];
                validate3 = new bool[2, 10];
                input3 = new int[2, 10];
            }
            else if (thirtyzheng == 0)
            {
                int tenzheng = thirtyyu / 10;
                int thenyu = thirtyyu % 10;
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = "";

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = "";
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = "";
                }
                switch (tenzheng)
                {
                    case 0:
                        validate1 = new bool[2, tenyu];
                        input1 = new int[2, tenyu];
                        validate2 = new bool[2, 0];
                        input2 = new int[2, 0];
                        validate3 = new bool[2, 0];
                        input3 = new int[2, 0];
                        for (int i = 0; i < tenyu; i++)
                        {

                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                        }
                        break;
                    case 1:
                        validate1 = new bool[2, 10];
                        input1 = new int[2, 10];
                        validate2 = new bool[2, tenyu];
                        input2 = new int[2, tenyu];
                        validate3 = new bool[2, 0];
                        input3 = new int[2, 0];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[beginindex1 + i];

                        }
                        for (int i = 10; i < 10 + tenyu; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                        }
                        break;
                    case 2:
                        validate1 = new bool[2, 10];
                        input1 = new int[2, 10];
                        validate2 = new bool[2, 10];
                        input2 = new int[2, 10];
                        validate3 = new bool[2, tenyu];
                        input3 = new int[2, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[beginindex1 + i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                        }
                        for (int i = 20; i < 20 + tenyu; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[beginindex1 + i];
                        }
                        break;
                }
                //  Console.WriteLine("%%%%%#%#@%"+thirtyzheng);
            }
            else
            {
                MessageBox.Show("没有更多设备信息!!!");
                //  ToRight_SZ.Enabled = false;
                thirtyzheng = thirtyzheng + 1;
                beginindex1 = beginindex1 - 30;
            }
            MC_TL.Enabled = true;
        //    Console.WriteLine("%%%%%#%#@%right" + thirtyzheng);
        }

        private void MC_TXTS_Click(object sender, EventArgs e)
        {
            if (MC_TSTS.BackColor == Color.AliceBlue)
            {
                MC_TSTS.BackColor = Color.White;
            }
            if (MC_DSDW.BackColor == Color.AliceBlue)
            {
                MC_DSDW.BackColor = Color.White;
            }
            for (int i = 0; i < 1; i++)
            {
                for (int k = 0; k < 10; k++)
                {
                    dataGridView1.Rows[i].Cells[k].Value = " ";
                    dataGridView2.Rows[i].Cells[k].Value = " ";
                    dataGridView3.Rows[i].Cells[k].Value = " ";
                }
            }
            for (int i = 0; i < 10; i++)
            {
                dataGridView1.Columns[i].HeaderCell.Value = " ";
                dataGridView2.Columns[i].HeaderCell.Value = " ";
                dataGridView3.Columns[i].HeaderCell.Value = " ";
            }
            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            int total = 0;
            //    total = int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString())+ int.Parse(sbsd[2].ToString())+ int.Parse(sbsd[3].ToString());
            total = int.Parse(sbsd[1].ToString());
            shebeiinfo = new string[total];
            totalinput = new int[2, total];

            MC_TXTS.BackColor = Color.AliceBlue;
            int j = 1;


            for (int i = 0; i < int.Parse(sbsd[1].ToString()); i++)
            {
                shebeiinfo[i] = "调速互锁类设备" + j;
                j++;
            }
            //for (int i = 0; i < total; i++)
            //{
            //    Console.WriteLine(shebeiinfo[i]);
            //}
            tenzheng = total / 10;
            tenyu = total % 10;
            thirtyzheng = total / 30;
            thirtyyu = total % 30;
            ThirtyZ = thirtyzheng;
            beginindex2 = total;
            if (thirtyzheng == 0)
            {
                switch (tenzheng)
                {
                    case 0:
                        validate1 = new bool[2, tenyu];
                        input1 = new int[2, tenyu];
                        for (int i = 0; i < tenyu; i++)
                        {

                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = tenyu; i < 10; i++)
                        {
                            dataGridView1.Columns[i].ReadOnly = true;
                        }
                        dataGridView2.ReadOnly = true;
                        dataGridView3.ReadOnly = true;

                        break;
                    case 1:
                        validate1 = new bool[2, 10];
                        input1 = new int[2, 10];
                        validate2 = new bool[2, tenyu];
                        input2 = new int[2, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 10 + tenyu; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 10 + tenyu; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].ReadOnly = true;
                        }
                        dataGridView3.ReadOnly = true;
                        break;
                    case 2:
                        validate1 = new bool[2, 10];
                        input1 = new int[2, 10];
                        validate2 = new bool[2, 10];
                        input2 = new int[2, 10];
                        validate3 = new bool[2, tenyu];
                        input3 = new int[2, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20; i < 20 + tenyu; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20 + tenyu; i < 30; i++)
                        {
                            dataGridView3.Columns[i].ReadOnly = true;
                        }
                        break;
                }
            }
            else
            {
                validate1 = new bool[2, 10];
                input1 = new int[2, 10];
                validate2 = new bool[2, 10];
                input2 = new int[2, 10];
                validate3 = new bool[2, 10];
                input3 = new int[2, 10];
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                }
            }
        }

        private void MC_DSDW_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 1; i++)
            {
                for (int k = 0; k < 10; k++)
                {
                    dataGridView1.Rows[i].Cells[k].Value = " ";
                    dataGridView2.Rows[i].Cells[k].Value = " ";
                    dataGridView3.Rows[i].Cells[k].Value = " ";
                }
            }
            for (int i = 0; i < 10; i++)
            {
                dataGridView1.Columns[i].HeaderCell.Value = " ";
                dataGridView2.Columns[i].HeaderCell.Value = " ";
                dataGridView3.Columns[i].HeaderCell.Value = " ";
            }
            if (MC_TSTS.BackColor == Color.AliceBlue)
            {
                MC_TSTS.BackColor = Color.White;
            }
            if (MC_TXTS.BackColor == Color.AliceBlue)
            {
                MC_TXTS.BackColor = Color.White;
            }

            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            int total = 0;
            //    total = int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString())+ int.Parse(sbsd[2].ToString())+ int.Parse(sbsd[3].ToString());
            total = int.Parse(sbsd[2].ToString());
            shebeiinfo = new string[total];
            totalinput = new int[2, total];
            MC_DSDW.BackColor = Color.AliceBlue;
            int j = 1;
            for (int i = 0; i < int.Parse(sbsd[2].ToString()); i++)
            {
                shebeiinfo[i] = "定速定位设备" + j;
                j++;
            }

            tenzheng = total / 10;
            tenyu = total % 10;
            thirtyzheng = total / 30;
            thirtyyu = total % 30;
            ThirtyZ = thirtyzheng;
            beginindex2 = total;
            if (thirtyzheng == 0)
            {
                switch (tenzheng)
                {
                    case 0:
                        validate1 = new bool[2, tenyu];
                        input1 = new int[2, tenyu];
                        for (int i = 0; i < tenyu; i++)
                        {

                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = tenyu; i < 10; i++)
                        {
                            dataGridView1.Columns[i].ReadOnly = true;
                        }
                        dataGridView2.ReadOnly = true;
                        dataGridView3.ReadOnly = true;

                        break;
                    case 1:
                        validate1 = new bool[2, 10];
                        input1 = new int[2, 10];
                        validate2 = new bool[2, tenyu];
                        input2 = new int[2, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 10 + tenyu; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 10 + tenyu; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].ReadOnly = true;
                        }
                        dataGridView3.ReadOnly = true;
                        break;
                    case 2:
                        validate1 = new bool[2, 10];
                        input1 = new int[2, 10];
                        validate2 = new bool[2, 10];
                        input2 = new int[2, 10];
                        validate3 = new bool[2, tenyu];
                        input3 = new int[2, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20; i < 20 + tenyu; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20 + tenyu; i < 30; i++)
                        {
                            dataGridView3.Columns[i].ReadOnly = true;
                        }
                        break;
                }
            }
            else
            {
                validate1 = new bool[2, 10];
                input1 = new int[2, 10];
                validate2 = new bool[2, 10];
                input2 = new int[2, 10];
                validate3 = new bool[2, 10];
                input3 = new int[2, 10];
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                }
            }
        }

        private void MC_TSTS_Click(object sender, EventArgs e)
        {
            if (MC_TXTS.BackColor == Color.AliceBlue)
            {
                MC_TXTS.BackColor = Color.White;
            }
            if (MC_DSDW.BackColor == Color.AliceBlue)
            {
                MC_DSDW.BackColor = Color.White;
            }
            for (int i = 0; i < 1; i++)
            {
                for (int k = 0; k < 10; k++)
                {
                    dataGridView1.Rows[i].Cells[k].Value = " ";
                    dataGridView2.Rows[i].Cells[k].Value = " ";
                    dataGridView3.Rows[i].Cells[k].Value = " ";
                }
            }
            for (int i = 0; i < 10; i++)
            {
                dataGridView1.Columns[i].HeaderCell.Value = " ";
                dataGridView2.Columns[i].HeaderCell.Value = " ";
                dataGridView3.Columns[i].HeaderCell.Value = " ";
            }
            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            int total = 0;
            //    total = int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString())+ int.Parse(sbsd[2].ToString())+ int.Parse(sbsd[3].ToString());
            total = int.Parse(sbsd[0].ToString());
            shebeiinfo = new string[total];
            totalinput = new int[2, total];
            MC_TSTS.BackColor = Color.AliceBlue;
            int j = 1;
            for (int i = 0; i < int.Parse(sbsd[0].ToString()); i++)
            {
                shebeiinfo[i] = "调速设备" + j;
                j++;
            }
            j = 1;
            tenzheng = total / 10;
            tenyu = total % 10;
            thirtyzheng = total / 30;
            thirtyyu = total % 30;
            ThirtyZ = thirtyzheng;
            beginindex2 = total;
            if (thirtyzheng == 0)
            {
                switch (tenzheng)
                {
                    case 0:
                        validate1 = new bool[2, tenyu];
                        input1 = new int[2, tenyu];
                        for (int i = 0; i < tenyu; i++)
                        {

                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = tenyu; i < 10; i++)
                        {
                            dataGridView1.Columns[i].ReadOnly = true;
                        }
                        dataGridView2.ReadOnly = true;
                        dataGridView3.ReadOnly = true;

                        break;
                    case 1:
                        validate1 = new bool[2, 10];
                        input1 = new int[2, 10];
                        validate2 = new bool[2, tenyu];
                        input2 = new int[2, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 10 + tenyu; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 10 + tenyu; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].ReadOnly = true;
                        }
                        dataGridView3.ReadOnly = true;
                        break;
                    case 2:
                        validate1 = new bool[2, 10];
                        input1 = new int[2, 10];
                        validate2 = new bool[2, 10];
                        input2 = new int[2, 10];
                        validate3 = new bool[2, tenyu];
                        input3 = new int[2, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20; i < 20 + tenyu; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20 + tenyu; i < 30; i++)
                        {
                            dataGridView3.Columns[i].ReadOnly = true;
                        }
                        break;
                }
            }
            else
            {
                validate1 = new bool[2, 10];
                input1 = new int[2, 10];
                validate2 = new bool[2, 10];
                input2 = new int[2, 10];
                validate3 = new bool[2, 10];
                input3 = new int[2, 10];
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                }
            }
        }

        private void MC_Allow_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("确定允许编辑吗?", "设备数值编辑", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                dataGridView1.ReadOnly = false;
                dataGridView2.ReadOnly = false;
                dataGridView3.ReadOnly = false;
                // this.AllowEdit_Button.BackColor
                this.MC_Allow.BackColor = Color.AliceBlue;
            }
        }

        private void Pluse_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.MC_Allow.BackColor = Color.White;
            if (dataGridView1.Rows.Count == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns.Add(new DataGridViewTextBoxColumn());
                }
                for (int i = 0; i < 1; i++)
                {
                    dataGridView1.Rows.Add(new DataGridViewRow());
                }
            }
            this.dataGridView1.Rows[0].HeaderCell.Value = "系数n";
            this.dataGridView1.Rows[1].HeaderCell.Value = "系数m";
            this.dataGridView1.TopLeftHeaderCell.Value = "系数|设备";

            if (dataGridView2.Rows.Count == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView2.Columns.Add(new DataGridViewTextBoxColumn());
                }
                for (int i = 0; i < 1; i++)
                {
                    dataGridView2.Rows.Add(new DataGridViewRow());
                }
            }
            this.dataGridView2.Rows[0].HeaderCell.Value = "系数n";
            this.dataGridView2.Rows[1].HeaderCell.Value = "系数m";
            this.dataGridView2.TopLeftHeaderCell.Value = "系数|设备";

            if (dataGridView3.Rows.Count == 0)
            {
                for (int i = 0; i < 10; i++)
                {
                    dataGridView3.Columns.Add(new DataGridViewTextBoxColumn());
                }
                for (int i = 0; i < 1; i++)
                {
                    dataGridView3.Rows.Add(new DataGridViewRow());
                }
            }
            this.dataGridView3.Rows[0].HeaderCell.Value = "系数n";
            this.dataGridView3.Rows[1].HeaderCell.Value = "系数m";
            this.dataGridView3.TopLeftHeaderCell.Value = "系数|设备";

            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            int total = 0;
            //    total = int.Parse(sbsd[0].ToString())+ int.Parse(sbsd[1].ToString())+ int.Parse(sbsd[2].ToString())+ int.Parse(sbsd[3].ToString());
            total = int.Parse(sbsd[0].ToString());
            shebeiinfo = new string[total];
            totalinput = new int[2, total];
            MC_TSTS.BackColor = Color.AliceBlue;
            //MC_TSTS.Enabled = false;
            int j = 1;
            for (int i = 0; i < int.Parse(sbsd[0].ToString()); i++)
            {
                shebeiinfo[i] = "调速设备" + j;
                j++;
            }
            j = 1;
            tenzheng = total / 10;
            tenyu = total % 10;
            thirtyzheng = total / 30;
            thirtyyu = total % 30;
            ThirtyZ = thirtyzheng;
            beginindex2 = total;
            if (thirtyzheng == 0)
            {
                switch (tenzheng)
                {
                    case 0:
                        validate1 = new bool[2, tenyu];
                        input1 = new int[2, tenyu];
                        for (int i = 0; i < tenyu; i++)
                        {

                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = tenyu; i < 10; i++)
                        {
                            dataGridView1.Columns[i].ReadOnly = true;
                        }
                        dataGridView2.ReadOnly = true;
                        dataGridView3.ReadOnly = true;

                        break;
                    case 1:
                        validate1 = new bool[2, 10];
                        input1 = new int[2, 10];
                        validate2 = new bool[2, tenyu];
                        input2 = new int[2, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 10 + tenyu; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 10 + tenyu; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].ReadOnly = true;
                        }
                        dataGridView3.ReadOnly = true;
                        break;
                    case 2:
                        validate1 = new bool[2, 10];
                        input1 = new int[2, 10];
                        validate2 = new bool[2, 10];
                        input2 = new int[2, 10];
                        validate3 = new bool[2, tenyu];
                        input3 = new int[2, tenyu];
                        for (int i = 0; i < 10; i++)
                        {
                            dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                        }
                        for (int i = 10; i < 20; i++)
                        {
                            dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20; i < 20 + tenyu; i++)
                        {
                            dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                        }
                        for (int i = 20 + tenyu; i < 30; i++)
                        {
                            dataGridView3.Columns[i].ReadOnly = true;
                        }
                        break;
                }
            }
            else
            {
                validate1 = new bool[2, 10];
                input1 = new int[2, 10];
                validate2 = new bool[2, 10];
                input2 = new int[2, 10];
                validate3 = new bool[2, 10];
                input3 = new int[2, 10];
                for (int i = 0; i < 10; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = shebeiinfo[i];

                }
                for (int i = 10; i < 20; i++)
                {
                    dataGridView2.Columns[i - 10].HeaderCell.Value = shebeiinfo[i];
                }
                for (int i = 20; i < 30; i++)
                {
                    dataGridView3.Columns[i - 20].HeaderCell.Value = shebeiinfo[i];
                }
            }
        }
    }
}
