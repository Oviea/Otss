﻿namespace BigPro
{
    partial class panglusheding
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DKXZ_ToLeft = new System.Windows.Forms.Button();
            this.DKXZ_ToRight = new System.Windows.Forms.Button();
            this.PL_MainPage = new System.Windows.Forms.Button();
            this.PL_Back = new System.Windows.Forms.Button();
            this.PL_QXPL = new System.Windows.Forms.Button();
            this.PL_TJSB = new System.Windows.Forms.Button();
            this.PLAll_Cancel = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.PL_ML = new System.Windows.Forms.Label();
            this.PL_QR = new System.Windows.Forms.Button();
            this.PL_YX = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // DKXZ_ToLeft
            // 
            this.DKXZ_ToLeft.ForeColor = System.Drawing.Color.Black;
            this.DKXZ_ToLeft.Image = global::BigPro.Properties.Resources.Toleft;
            this.DKXZ_ToLeft.Location = new System.Drawing.Point(11, 11);
            this.DKXZ_ToLeft.Margin = new System.Windows.Forms.Padding(2);
            this.DKXZ_ToLeft.Name = "DKXZ_ToLeft";
            this.DKXZ_ToLeft.Size = new System.Drawing.Size(50, 50);
            this.DKXZ_ToLeft.TabIndex = 462;
            this.DKXZ_ToLeft.UseVisualStyleBackColor = true;
            this.DKXZ_ToLeft.Click += new System.EventHandler(this.DKXZ_ToLeft_Click);
            // 
            // DKXZ_ToRight
            // 
            this.DKXZ_ToRight.ForeColor = System.Drawing.Color.Black;
            this.DKXZ_ToRight.Image = global::BigPro.Properties.Resources.ToRight;
            this.DKXZ_ToRight.Location = new System.Drawing.Point(1856, 15);
            this.DKXZ_ToRight.Margin = new System.Windows.Forms.Padding(2);
            this.DKXZ_ToRight.Name = "DKXZ_ToRight";
            this.DKXZ_ToRight.Size = new System.Drawing.Size(50, 50);
            this.DKXZ_ToRight.TabIndex = 459;
            this.DKXZ_ToRight.UseVisualStyleBackColor = true;
            this.DKXZ_ToRight.Click += new System.EventHandler(this.DKXZ_ToRight_Click);
            // 
            // PL_MainPage
            // 
            this.PL_MainPage.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PL_MainPage.Location = new System.Drawing.Point(1773, 932);
            this.PL_MainPage.Margin = new System.Windows.Forms.Padding(2);
            this.PL_MainPage.Name = "PL_MainPage";
            this.PL_MainPage.Size = new System.Drawing.Size(112, 40);
            this.PL_MainPage.TabIndex = 458;
            this.PL_MainPage.Text = "回首页";
            this.PL_MainPage.UseVisualStyleBackColor = true;
            this.PL_MainPage.Click += new System.EventHandler(this.PL_MainPage_Click);
            // 
            // PL_Back
            // 
            this.PL_Back.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PL_Back.Location = new System.Drawing.Point(49, 932);
            this.PL_Back.Margin = new System.Windows.Forms.Padding(2);
            this.PL_Back.Name = "PL_Back";
            this.PL_Back.Size = new System.Drawing.Size(112, 40);
            this.PL_Back.TabIndex = 457;
            this.PL_Back.Text = "返回";
            this.PL_Back.UseVisualStyleBackColor = true;
            this.PL_Back.Click += new System.EventHandler(this.PL_Back_Click);
            // 
            // PL_QXPL
            // 
            this.PL_QXPL.Font = new System.Drawing.Font("宋体", 14.2F);
            this.PL_QXPL.Location = new System.Drawing.Point(683, 838);
            this.PL_QXPL.Margin = new System.Windows.Forms.Padding(2);
            this.PL_QXPL.Name = "PL_QXPL";
            this.PL_QXPL.Size = new System.Drawing.Size(112, 40);
            this.PL_QXPL.TabIndex = 456;
            this.PL_QXPL.Text = "已旁路";
            this.PL_QXPL.UseVisualStyleBackColor = true;
            this.PL_QXPL.Click += new System.EventHandler(this.PL_QXPL_Click);
            // 
            // PL_TJSB
            // 
            this.PL_TJSB.Font = new System.Drawing.Font("宋体", 14.2F);
            this.PL_TJSB.Location = new System.Drawing.Point(975, 838);
            this.PL_TJSB.Margin = new System.Windows.Forms.Padding(2);
            this.PL_TJSB.Name = "PL_TJSB";
            this.PL_TJSB.Size = new System.Drawing.Size(112, 40);
            this.PL_TJSB.TabIndex = 454;
            this.PL_TJSB.Text = "添加设备";
            this.PL_TJSB.UseVisualStyleBackColor = true;
            this.PL_TJSB.Click += new System.EventHandler(this.PL_TJSB_Click);
            // 
            // PLAll_Cancel
            // 
            this.PLAll_Cancel.Font = new System.Drawing.Font("宋体", 14.2F);
            this.PLAll_Cancel.Location = new System.Drawing.Point(1267, 838);
            this.PLAll_Cancel.Margin = new System.Windows.Forms.Padding(2);
            this.PLAll_Cancel.Name = "PLAll_Cancel";
            this.PLAll_Cancel.Size = new System.Drawing.Size(112, 40);
            this.PLAll_Cancel.TabIndex = 453;
            this.PLAll_Cancel.Text = "全部取消";
            this.PLAll_Cancel.UseVisualStyleBackColor = true;
            this.PLAll_Cancel.Click += new System.EventHandler(this.PLAll_Cancel_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("宋体", 14.2F);
            this.label2.Location = new System.Drawing.Point(-5, 133);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1940, 3);
            this.label2.TabIndex = 451;
            // 
            // PL_ML
            // 
            this.PL_ML.AutoSize = true;
            this.PL_ML.Font = new System.Drawing.Font("宋体", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PL_ML.Location = new System.Drawing.Point(883, 25);
            this.PL_ML.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PL_ML.Name = "PL_ML";
            this.PL_ML.Size = new System.Drawing.Size(120, 27);
            this.PL_ML.TabIndex = 450;
            this.PL_ML.Text = "旁路设置";
            // 
            // PL_QR
            // 
            this.PL_QR.Font = new System.Drawing.Font("宋体", 14.2F);
            this.PL_QR.Location = new System.Drawing.Point(1081, 21);
            this.PL_QR.Margin = new System.Windows.Forms.Padding(2);
            this.PL_QR.Name = "PL_QR";
            this.PL_QR.Size = new System.Drawing.Size(75, 40);
            this.PL_QR.TabIndex = 449;
            this.PL_QR.Text = "确认";
            this.PL_QR.UseVisualStyleBackColor = true;
            this.PL_QR.Click += new System.EventHandler(this.PL_QR_Click);
            // 
            // PL_YX
            // 
            this.PL_YX.Font = new System.Drawing.Font("宋体", 14.2F);
            this.PL_YX.Location = new System.Drawing.Point(730, 21);
            this.PL_YX.Margin = new System.Windows.Forms.Padding(2);
            this.PL_YX.Name = "PL_YX";
            this.PL_YX.Size = new System.Drawing.Size(75, 40);
            this.PL_YX.TabIndex = 448;
            this.PL_YX.Text = "允许";
            this.PL_YX.UseVisualStyleBackColor = true;
            this.PL_YX.Click += new System.EventHandler(this.PL_YX_Click);
            // 
            // panglusheding
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.DKXZ_ToLeft);
            this.Controls.Add(this.DKXZ_ToRight);
            this.Controls.Add(this.PL_MainPage);
            this.Controls.Add(this.PL_Back);
            this.Controls.Add(this.PL_QXPL);
            this.Controls.Add(this.PL_TJSB);
            this.Controls.Add(this.PLAll_Cancel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PL_ML);
            this.Controls.Add(this.PL_QR);
            this.Controls.Add(this.PL_YX);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "panglusheding";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "panglushezhi";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.panglushezhi_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button DKXZ_ToLeft;
        private System.Windows.Forms.Button DKXZ_ToRight;
        private System.Windows.Forms.Button PL_MainPage;
        private System.Windows.Forms.Button PL_Back;
        private System.Windows.Forms.Button PL_QXPL;
        private System.Windows.Forms.Button PL_TJSB;
        private System.Windows.Forms.Button PLAll_Cancel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label PL_ML;
        private System.Windows.Forms.Button PL_QR;
        private System.Windows.Forms.Button PL_YX;
    }
}