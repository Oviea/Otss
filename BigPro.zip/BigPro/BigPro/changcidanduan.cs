﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class _2changcidanduan : Form
    {
        private static string JuTiJuMu;
        private static string JuTiChangCi;
        private static string JuTiSheBei;
        public DBB1 dBB1;
        public _2changcidanduan(DBB1 dBB1)
        {
            this.dBB1 = dBB1;
            InitializeComponent();
        }
        static void WriteWS(string filePath, string writestr)
        {
            FileStream fs = new FileStream(filePath, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            try
            {
                sw.WriteLine(writestr);
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine("Writing has been completed");
            }
            catch (IOException e)
            {
                sw.Flush();
                sw.Close();
                fs.Close();
                Console.WriteLine(e.ToString());
            }
        }
        private void _2changcidanduan_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            JuTiJuMu = ChangCiSheZhiGlobalData.NageJuMu;
            JuTiChangCi = ChangCiSheZhiGlobalData.JuTiChangCi;
            JuTiSheBei = ChangCiSheZhiGlobalData.JuTiSheBei;
            Console.WriteLine("^^^^^^^" + JuTiSheBei);
            if (!Directory.Exists("" + JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei))
            {
                Directory.CreateDirectory("" + JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei);
            }
            if (File.Exists("" + JuTiJuMu + "\\" + JuTiJuMu + ".txt"))
            {
                //List<string> lines = new List<string>(File.ReadAllLines("" + JuTiJuMu + "\\" + JuTiJuMu + ".txt"));
                //foreach (string s in lines)
                //{
                //    DDCue_List.Items.Add(s);
                //}
                DDCue_List.Items.Add("场次:" + JuTiChangCi.Substring(2));
                DDXZSB.Items.Add(JuTiSheBei);
                DDLabel.Text = ChangCiSheZhiGlobalData.YingSheQianChangCi +  "/" + JuTiSheBei;
            }
            List<string> sbsd = new List<string>(File.ReadAllLines("SBSD.txt"));
            // Console.WriteLine("%%%%"+sbsd[0].ToString());
            int j = 1;
            //for (int i = 0; i < int.Parse(sbsd[0].ToString()); i++)
            //{
            //    DanD_Dx.Items.Add("调速设备" + j);
            //    j++;
            //}
            //j = 1;
            //for (int i = 0; i < int.Parse(sbsd[1].ToString()); i++)
            //{
            //    DanD_Dx.Items.Add("调速互锁类设备" + j);
            //    j++;
            //}
            //j = 1;
            //for (int i = 0; i < int.Parse(sbsd[2].ToString()); i++)
            //{
            //    DanD_Dx.Items.Add("定速定位设备" + j);
            //    j++;
            //}
            //j = 1;
            //for (int i = 0; i < int.Parse(sbsd[3].ToString()); i++)
            //{
            //    DanD_Dx.Items.Add("定速设备" + j);
            //    j++;
            //}
        }

        private void button15_Click(object sender, EventArgs e)
        {
            new _2changci(dBB1).Show();
            this.Close();


        }

        private void button16_Click(object sender, EventArgs e)
        {
            new main().Show();
            this.Close();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            new changjing().Show();
        }



        private void DD_V_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入设定速度", "设定速度", "速度", -1, -1);
            if (str != "")
            {
                if (str != "速度")
                {

                    WriteWS("" + JuTiJuMu + "\\" + JuTiChangCi + "\\" + JuTiSheBei + "\\" + JuTiSheBei + "DanV" + ".txt", str);
                    La_V.Text = str;
                    MessageBox.Show("设置成功！");

                }
                else
                {
                    MessageBox.Show("请输入速度！");
                }
            }
        }

        private void DD_L_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入设定位置", "设定位置", "位置", -1, -1);
            if (str != "")
            {
                if (str != "位置")
                {
                    WriteWS("" + JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "DanL" + ".txt", str);
                    La_L.Text = str;
                    MessageBox.Show("设置成功！");
                }
                else
                {
                    MessageBox.Show("请输入位置！");
                }
            }
        }

        private void DD_T_Click(object sender, EventArgs e)
        {
            string str = Interaction.InputBox("请输入延时时间", "设置延时时间", "延时时间", -1, -1);
            if (str != "")
            {
                if (str != "延时时间")
                {
                    WriteWS("" + JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "DanT" + ".txt", str);
                    La_T.Text = str;
                    MessageBox.Show("设置成功！");
                }
                else
                {
                    MessageBox.Show("请输入延时时间！");
                }
            }
        }

        private void DD_VLTdel_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                DialogResult result = MessageBox.Show("确定删除吗？", "单段设定删除", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    File.Delete("" + JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "DanV" + ".txt");
                    File.Delete("" + JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "DanL" + ".txt");
                    File.Delete("" + JuTiJuMu + "\\" + JuTiChangCi + "\\"  + JuTiSheBei + "\\" + JuTiSheBei + "DanT" + ".txt");

                }
            }
        }

        private void CCDDl_Click(object sender, EventArgs e)
        {
            if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
            {
                ChangCiSheZhiGlobalData.TSDuoDuanflag[ChangCiSheZhiGlobalData.TSSheBeiIndex] = true;

            }
            else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
            {
                ChangCiSheZhiGlobalData.TSHSDuoDuanflag[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = true;
            }
            else
            {
                MessageBox.Show("请选择设备！");
            }
            var frm = new _2changciduoduan(dBB1);
            frm.Show();
            this.Close();
        }

        private void CCDanD_FF_Click(object sender, EventArgs e)
        {
            if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
            {
                ChangCiSheZhiGlobalData.TSFanFuflag[ChangCiSheZhiGlobalData.TSSheBeiIndex] = true;

            }
            else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
            {
                ChangCiSheZhiGlobalData.TSHSFanFuflag[ChangCiSheZhiGlobalData.TSHSSheBeiIndex] = true;
            }
            else
            {
                MessageBox.Show("请选择设备！");
            }
            var frm = new _2changcifanfu(dBB1);
            frm.Show();
            this.Close();
        }

        private void CCDanD_QX_Click(object sender, EventArgs e)
        {
            var frm = new _2changciquxian(dBB1);
            frm.Show();
            this.Close();
        }

        private void DDXZSB_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

            if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速设备"))
            {
                dBB1.Tsdanduan(ChangCiSheZhiGlobalData.TSDanDuanflag, ChangCiSheZhiGlobalData.TSDanDuanSDWZ, ChangCiSheZhiGlobalData.TSDanDuanSDSD, ChangCiSheZhiGlobalData.TSDuoDuanYSSJ);

            }
            else if (ChangCiSheZhiGlobalData.XuanZhongSheBei_Name.Equals("调速互锁类设备"))
            {
                dBB1.Tshsdanduan(ChangCiSheZhiGlobalData.TSHSDanDuanflag, ChangCiSheZhiGlobalData.TSHSDanDuanSDWZ, ChangCiSheZhiGlobalData.TSHSDanDuanSDSD, ChangCiSheZhiGlobalData.TSHSDuoDuanYSSJ);
            }
        }

        private void DanD_Dx_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button19_Click(object sender, EventArgs e)
        {

        }
    }
}
