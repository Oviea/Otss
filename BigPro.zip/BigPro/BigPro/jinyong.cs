﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigPro
{
    public partial class jinyong : Form
    {
        private static int allshebei;
        private static string[] shebei;
        private static int clickcount;
        private int n, k, m, p;
        private bool Ifjinyong;
        public jinyong()
        {
            InitializeComponent();
        }

        private void jinyong_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            delpanelall();
            if (File.Exists("SBSD.txt"))
            {
                List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                n = int.Parse(nkmp[0]);
                k = int.Parse(nkmp[1]);
                m = int.Parse(nkmp[2]);
                p = int.Parse(nkmp[3]);
                int totalshebei = n + m + k + p;
                int t = totalshebei + 2;
                ChangCiSheZhiGlobalData.IF_JinYong = new bool[t];
                //for (int i = 0; i < t; i++) {
                //    ChangCiSheZhiGlobalData.IF_JinYng[i] = false;
                //}
                allshebei = totalshebei;
                nkmp.Clear();
                for (int i = 0; i < n; i++)
                {
                    int j = i + 1;
                    nkmp.Add("调速设备" + j);
                }
                for (int i = n; i < n + k; i++)
                {
                    int j = i + 1 - n;
                    nkmp.Add("调速互锁类设备" + j);
                }
                for (int i = n + k; i < n + k + m; i++)
                {
                    int j = i + 1 - n - k;
                    nkmp.Add("定速定位设备" + j);
                }
                for (int i = n + k + m; i < n + k + m + p; i++)
                {
                    int j = i + 1 - n - k - m;
                    nkmp.Add("定速设备" + j);
                }
                shebei = nkmp.ToArray();
                //for(int i = 0; i < shebei.Length; i++)
                //{
                //    Console.WriteLine("++++++=+==" + shebei[i]);
                //}
                if (totalshebei <= 40)
                {
                    if (0 <= totalshebei && totalshebei <= 10)
                    {
                        for (int i = 0; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                    }
                    else if (totalshebei > 10 && totalshebei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                    }
                    else if (totalshebei > 20 && totalshebei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                        for (int i = 30; i < totalshebei; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.JinYongShengYuSheBei = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(130 + 170 * (i - 30), 550, shebei[i]);
                    }
                    ChangCiSheZhiGlobalData.JinYongShengYuSheBei = totalshebei - 40;
                }
            }
        }

        private void JY_ToLeft_Click(object sender, EventArgs e)
        {
            clickcount--;
            if (ChangCiSheZhiGlobalData.JinYongShengYuSheBei >= allshebei - 40)
            {
                MessageBox.Show("没有更多已编组设备！");
                clickcount++;
                //   ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei-5;
            }
            else
            {
                delpanelall();

                for (int i = 0; i < 10; i++)
                {
                    panelset(130 + 170 * i, 250, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                for (int i = 10; i < 20; i++)
                {
                    panelset(130 + 170 * (i - 10), 350, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                for (int i = 20; i < 30; i++)
                {
                    panelset(130 + 170 * (i - 20), 450, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                for (int i = 30; i < 40; i++)
                {
                    panelset(130 + 170 * (i - 30), 550, shebei[(allshebei / 40) * 40 - ((allshebei / 40) - clickcount) * 40 + i]);
                }
                if (ChangCiSheZhiGlobalData.JinYongShengYuSheBei == 0)
                {
                    if (allshebei % 40 == 0)
                    {
                        ChangCiSheZhiGlobalData.JinYongShengYuSheBei = 40;
                    }
                    else
                    {
                        ChangCiSheZhiGlobalData.JinYongShengYuSheBei = allshebei % 40;
                    }
                }
                else
                {
                    ChangCiSheZhiGlobalData.JinYongShengYuSheBei = ChangCiSheZhiGlobalData.JinYongShengYuSheBei + 40;
                }
            }
        }

        private void JY_TJ_Click(object sender, EventArgs e)
        {
            if (Ifjinyong == false)
            {
                Ifjinyong = true;
                JY_TJ.Enabled = false;
                JY_TJ.BackColor = Color.AliceBlue;
                JY_QX.Enabled = true;
                JY_QX.BackColor = Color.White;
                MessageBox.Show("可以添加禁用设备!");
                delpanelall();
                if (File.Exists("SBSD.txt"))
                {
                    List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                    n = int.Parse(nkmp[0]);
                    k = int.Parse(nkmp[1]);
                    m = int.Parse(nkmp[2]);
                    p = int.Parse(nkmp[3]);
                    int totalshebei = 0;
                    nkmp.Clear();
                    for (int i = 0; i < n; i++)
                    {
                        int j = i + 1;
                        if (ChangCiSheZhiGlobalData.IF_JinYong[i + 1] == false)
                        {
                            nkmp.Add("调速设备" + j);
                            totalshebei++;
                        }
                    }
                    for (int i = n; i < n + k; i++)
                    {
                        int j = i + 1 - n;
                        if (ChangCiSheZhiGlobalData.IF_JinYong[i + 1] == false)
                        {
                            nkmp.Add("调速互锁类设备" + j);
                            totalshebei++;
                        }
                    }
                    for (int i = n + k; i < n + k + m; i++)
                    {
                        int j = i + 1 - n - k;
                        if (ChangCiSheZhiGlobalData.IF_JinYong[i + 1] == false)
                        {
                            nkmp.Add("定速定位设备" + j);
                            totalshebei++;
                        }
                    }
                    for (int i = n + k + m; i < n + k + m + p; i++)
                    {
                        int j = i + 1 - n - k - m;
                        if (ChangCiSheZhiGlobalData.IF_JinYong[i + 1] == false)
                        {
                            nkmp.Add("定速设备" + j);
                            totalshebei++;
                        }
                    }
                    allshebei = totalshebei;
                    shebei = nkmp.ToArray();
                    if (totalshebei <= 40)
                    {
                        if (0 <= totalshebei && totalshebei <= 10)
                        {
                            for (int i = 0; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                        }
                        else if (totalshebei > 10 && totalshebei <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                        }
                        else if (totalshebei > 20 && totalshebei <= 30)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                            for (int i = 20; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 20), 450, shebei[i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                            for (int i = 20; i < 30; i++)
                            {
                                panelset(130 + 170 * (i - 20), 450, shebei[i]);
                            }
                            for (int i = 30; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 30), 550, shebei[i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.JinYongShengYuSheBei = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                        for (int i = 30; i < 40; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[i]);
                        }
                        ChangCiSheZhiGlobalData.JinYongShengYuSheBei = totalshebei - 40;
                    }
                }
            }
            else
            {
                MessageBox.Show("已经可以添加禁用设备!");
            }
           
        }

        private void JY_QX_Click(object sender, EventArgs e)
        {
            if (Ifjinyong == true)
            {
                Ifjinyong = false;
                JY_TJ.Enabled = true;
                JY_TJ.BackColor = Color.White;
                JY_QX.Enabled = false;
                JY_QX.BackColor = Color.AliceBlue;
                MessageBox.Show("可以取消禁用设备!");
                delpanelall();
                if (File.Exists("SBSD.txt"))
                {
                    List<string> nkmp = new List<string>(File.ReadAllLines("SBSD.txt"));
                    n = int.Parse(nkmp[0]);
                    k = int.Parse(nkmp[1]);
                    m = int.Parse(nkmp[2]);
                    p = int.Parse(nkmp[3]);
                    int totalshebei = 0;
                    nkmp.Clear();
                    for (int i = 0; i < n; i++)
                    {
                        int j = i + 1;
                        if (ChangCiSheZhiGlobalData.IF_JinYong[i + 1] == true)
                        {
                            nkmp.Add("调速设备" + j);
                            totalshebei++;
                        }
                    }
                    for (int i = n; i < n + k; i++)
                    {
                        int j = i + 1 - n;
                        if (ChangCiSheZhiGlobalData.IF_JinYong[i + 1] == true)
                        {
                            nkmp.Add("调速互锁类设备" + j);
                            totalshebei++;
                        }
                    }
                    for (int i = n + k; i < n + k + m; i++)
                    {
                        int j = i + 1 - n - k;
                        if (ChangCiSheZhiGlobalData.IF_JinYong[i + 1] == true)
                        {
                            nkmp.Add("定速定位设备" + j);
                            totalshebei++;
                        }
                    }
                    for (int i = n + k + m; i < n + k + m + p; i++)
                    {
                        int j = i + 1 - n - k - m;
                        if (ChangCiSheZhiGlobalData.IF_JinYong[i + 1] == true)
                        {
                            nkmp.Add("定速设备" + j);
                            totalshebei++;
                        }
                    }
                    allshebei = totalshebei;
                    shebei = nkmp.ToArray();
                    if (totalshebei <= 40)
                    {
                        if (0 <= totalshebei && totalshebei <= 10)
                        {
                            for (int i = 0; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                        }
                        else if (totalshebei > 10 && totalshebei <= 20)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                        }
                        else if (totalshebei > 20 && totalshebei <= 30)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                            for (int i = 20; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 20), 450, shebei[i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                panelset(130 + 170 * i, 250, shebei[i]);
                            }
                            for (int i = 10; i < 20; i++)
                            {
                                panelset(130 + 170 * (i - 10), 350, shebei[i]);
                            }
                            for (int i = 20; i < 30; i++)
                            {
                                panelset(130 + 170 * (i - 20), 450, shebei[i]);
                            }
                            for (int i = 30; i < totalshebei; i++)
                            {
                                panelset(130 + 170 * (i - 30), 550, shebei[i]);
                            }
                        }
                        ChangCiSheZhiGlobalData.JinYongShengYuSheBei = 0;
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[i]);
                        }
                        for (int i = 30; i < 40; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[i]);
                        }
                        ChangCiSheZhiGlobalData.JinYongShengYuSheBei = totalshebei - 40;
                    }
                }
            }
            else
            {
                MessageBox.Show("已经取消禁用设备!");
            }
        }

        private void JY_ToRight_Click(object sender, EventArgs e)
        {
            clickcount++;
            if (ChangCiSheZhiGlobalData.JinYongShengYuSheBei == 0)
            {
                MessageBox.Show("没有更多已编组设备！");
                // ChangCiSheZhiGlobalData.ShengYuSheBei = allshebei % 5;
                clickcount--;
            }
            else
            {
                delpanelall();
                if (ChangCiSheZhiGlobalData.JinYongShengYuSheBei < 40)
                {

                    if (0 <= ChangCiSheZhiGlobalData.JinYongShengYuSheBei && ChangCiSheZhiGlobalData.JinYongShengYuSheBei <= 10)
                    {
                        for (int i = 0; i < ChangCiSheZhiGlobalData.JinYongShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                    }
                    else if (ChangCiSheZhiGlobalData.JinYongShengYuSheBei > 10 && ChangCiSheZhiGlobalData.JinYongShengYuSheBei <= 20)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                        for (int i = 10; i < ChangCiSheZhiGlobalData.JinYongShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                        }
                    }
                    else if (ChangCiSheZhiGlobalData.JinYongShengYuSheBei > 20 && ChangCiSheZhiGlobalData.JinYongShengYuSheBei <= 30)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                        }
                        for (int i = 20; i < ChangCiSheZhiGlobalData.JinYongShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[40 * clickcount + i]);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                        }
                        for (int i = 10; i < 20; i++)
                        {
                            panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                        }
                        for (int i = 20; i < 30; i++)
                        {
                            panelset(130 + 170 * (i - 20), 450, shebei[40 * clickcount + i]);
                        }
                        for (int i = 30; i < ChangCiSheZhiGlobalData.JinYongShengYuSheBei; i++)
                        {
                            panelset(130 + 170 * (i - 30), 550, shebei[40 * clickcount + i]);
                        }
                    }
                    ChangCiSheZhiGlobalData.JinYongShengYuSheBei = 0;
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        panelset(130 + 170 * i, 250, shebei[40 * clickcount + i]);
                    }
                    for (int i = 10; i < 20; i++)
                    {
                        panelset(130 + 170 * (i - 10), 350, shebei[40 * clickcount + i]);
                    }
                    for (int i = 20; i < 30; i++)
                    {
                        panelset(130 + 170 * (i - 20), 450, shebei[40 * clickcount + i]);
                    }
                    for (int i = 30; i < 40; i++)
                    {
                        panelset(130 + 170 * (i - 30), 550, shebei[40 * clickcount + i]);
                    }
                    ChangCiSheZhiGlobalData.JinYongShengYuSheBei = ChangCiSheZhiGlobalData.JinYongShengYuSheBei - 40;
                }
            }
        }

        private void delpanelall()
        {
            if (Controls["SheBeiJinYong_Panel130250"] != null)
            {
                Controls["SheBeiJinYong_Panel130250"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel300250"] != null)
            {
                Controls["SheBeiJinYong_Panel300250"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel470250"] != null)
            {
                Controls["SheBeiJinYong_Panel470250"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel640250"] != null)
            {
                Controls["SheBeiJinYong_Panel640250"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel810250"] != null)
            {
                Controls["SheBeiJinYong_Panel810250"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel980250"] != null)
            {
                Controls["SheBeiJinYong_Panel980250"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1150250"] != null)
            {
                Controls["SheBeiJinYong_Panel1150250"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1320250"] != null)
            {
                Controls["SheBeiJinYong_Panel1320250"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1490250"] != null)
            {
                Controls["SheBeiJinYong_Panel1490250"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1660250"] != null)
            {
                Controls["SheBeiJinYong_Panel1660250"].Dispose();
            }


            if (Controls["SheBeiJinYong_Panel130350"] != null)
            {
                Controls["SheBeiJinYong_Panel130350"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel300350"] != null)
            {
                Controls["SheBeiJinYong_Panel300350"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel470350"] != null)
            {
                Controls["SheBeiJinYong_Panel470350"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel640350"] != null)
            {
                Controls["SheBeiJinYong_Panel640350"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel810350"] != null)
            {
                Controls["SheBeiJinYong_Panel810350"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel980350"] != null)
            {
                Controls["SheBeiJinYong_Panel980350"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1150350"] != null)
            {
                Controls["SheBeiJinYong_Panel1150350"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1320350"] != null)
            {
                Controls["SheBeiJinYong_Panel1320350"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1490350"] != null)
            {
                Controls["SheBeiJinYong_Panel1490350"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1660350"] != null)
            {
                Controls["SheBeiJinYong_Panel1660350"].Dispose();
            }


            if (Controls["SheBeiJinYong_Panel130450"] != null)
            {
                Controls["SheBeiJinYong_Panel130450"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel300450"] != null)
            {
                Controls["SheBeiJinYong_Panel300450"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel470450"] != null)
            {
                Controls["SheBeiJinYong_Panel470450"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel640450"] != null)
            {
                Controls["SheBeiJinYong_Panel640450"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel810450"] != null)
            {
                Controls["SheBeiJinYong_Panel810450"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel980450"] != null)
            {
                Controls["SheBeiJinYong_Panel980450"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1150450"] != null)
            {
                Controls["SheBeiJinYong_Panel1150450"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1320450"] != null)
            {
                Controls["SheBeiJinYong_Panel1320450"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1490450"] != null)
            {
                Controls["SheBeiJinYong_Panel1490450"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1660450"] != null)
            {
                Controls["SheBeiJinYong_Panel1660450"].Dispose();
            }

            if (Controls["SheBeiJinYong_Panel130550"] != null)
            {
                Controls["SheBeiJinYong_Panel130550"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel300550"] != null)
            {
                Controls["SheBeiJinYong_Panel300550"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel470550"] != null)
            {
                Controls["SheBeiJinYong_Panel470550"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel640550"] != null)
            {
                Controls["SheBeiJinYong_Panel640550"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel810550"] != null)
            {
                Controls["SheBeiJinYong_Panel810550"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel980550"] != null)
            {
                Controls["SheBeiJinYong_Panel980550"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1150550"] != null)
            {
                Controls["SheBeiJinYong_Panel1150550"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1320550"] != null)
            {
                Controls["SheBeiJinYong_Panel1320550"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1490550"] != null)
            {
                Controls["SheBeiJinYong_Panel1490550"].Dispose();
            }
            if (Controls["SheBeiJinYong_Panel1660550"] != null)
            {
                Controls["SheBeiJinYong_Panel1660550"].Dispose();
            }
        }

        private void JY_QBQX_Click(object sender, EventArgs e)
        {
            for (int i = 1; i < ChangCiSheZhiGlobalData.IF_JinYong.Length; i++)
            {
                ChangCiSheZhiGlobalData.IF_JinYong[i] = false;
            }
            MessageBox.Show("所有禁用已经取消!");
        }

        private void panelset(int x, int y, string shebeiname)
        {
            Button Shebei_JinYong = new Button();
            Shebei_JinYong.Font = new System.Drawing.Font("宋体", 10F);
            // Shebei_JinYong.Location = new System.Drawing.Point(1660, 550);
            Shebei_JinYong.Margin = new System.Windows.Forms.Padding(2);
            Shebei_JinYong.Name = shebeiname + x + y;
            Shebei_JinYong.Size = new System.Drawing.Size(90, 40);
            Shebei_JinYong.Text = shebeiname;
            Shebei_JinYong.UseVisualStyleBackColor = true;
            Shebei_JinYong.Click += (e, a) => this.Shebei_JinYong(shebeiname);
            // 


            Panel SheBeiJinYong_Panel = new Panel();
            SheBeiJinYong_Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            SheBeiJinYong_Panel.Controls.Add(Shebei_JinYong);
            SheBeiJinYong_Panel.Location = new System.Drawing.Point(x, y);
            SheBeiJinYong_Panel.Margin = new System.Windows.Forms.Padding(2);
            SheBeiJinYong_Panel.Name = "SheBeiJinYong_Panel" + x + y;
            SheBeiJinYong_Panel.Size = new System.Drawing.Size(91, 41);
            this.Controls.Add(SheBeiJinYong_Panel);
        }

        private void Shebei_JinYong(string shebeiname)
        {
            if (Ifjinyong == true)
            {
                ChangCiSheZhiGlobalData.IF_JinYong[GetIndex(shebeiname)] = true;
                MessageBox.Show(shebeiname + "已经禁用!");
            }
            else
            {
                ChangCiSheZhiGlobalData.IF_JinYong[GetIndex(shebeiname)] = false;
                MessageBox.Show(shebeiname + "已经取消禁用!");
            }
        }
        public int GetIndex(string shebeiname)
        {
            if (shebeiname.Contains("调速设备"))
            {
                int i = int.Parse(shebeiname.Substring(4));
                return i;
            }
            else if (shebeiname.Contains("调速互锁类设备"))
            {
                int i = int.Parse(shebeiname.Substring(7));
                return i + n;
            }
            else if (shebeiname.Contains("定速定位设备"))
            {
                int i = int.Parse(shebeiname.Substring(6));
                return i + n + k;
            }
            else if (shebeiname.Contains("定速设备"))
            {
                int i = int.Parse(shebeiname.Substring(4));
                return i + n + k + m;
            }
            return 0;
        }
    }
}
