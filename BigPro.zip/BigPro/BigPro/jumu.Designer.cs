﻿using System;

namespace BigPro
{
    partial class jumu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CC1 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.CC40 = new System.Windows.Forms.Button();
            this.CC41 = new System.Windows.Forms.Button();
            this.CC39 = new System.Windows.Forms.Button();
            this.CC38 = new System.Windows.Forms.Button();
            this.CC36 = new System.Windows.Forms.Button();
            this.CC37 = new System.Windows.Forms.Button();
            this.CC35 = new System.Windows.Forms.Button();
            this.CC34 = new System.Windows.Forms.Button();
            this.CC33 = new System.Windows.Forms.Button();
            this.CC31 = new System.Windows.Forms.Button();
            this.CC32 = new System.Windows.Forms.Button();
            this.CC30 = new System.Windows.Forms.Button();
            this.CC29 = new System.Windows.Forms.Button();
            this.CC27 = new System.Windows.Forms.Button();
            this.CC28 = new System.Windows.Forms.Button();
            this.CC26 = new System.Windows.Forms.Button();
            this.CC25 = new System.Windows.Forms.Button();
            this.CC23 = new System.Windows.Forms.Button();
            this.CC24 = new System.Windows.Forms.Button();
            this.CC22 = new System.Windows.Forms.Button();
            this.CC21 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button39 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.CC19 = new System.Windows.Forms.Button();
            this.CC20 = new System.Windows.Forms.Button();
            this.CC18 = new System.Windows.Forms.Button();
            this.CC17 = new System.Windows.Forms.Button();
            this.CC15 = new System.Windows.Forms.Button();
            this.CC16 = new System.Windows.Forms.Button();
            this.CC14 = new System.Windows.Forms.Button();
            this.CC13 = new System.Windows.Forms.Button();
            this.CC11 = new System.Windows.Forms.Button();
            this.CC12 = new System.Windows.Forms.Button();
            this.CC10 = new System.Windows.Forms.Button();
            this.CC9 = new System.Windows.Forms.Button();
            this.CC7 = new System.Windows.Forms.Button();
            this.CC8 = new System.Windows.Forms.Button();
            this.CC6 = new System.Windows.Forms.Button();
            this.CC5 = new System.Windows.Forms.Button();
            this.CC3 = new System.Windows.Forms.Button();
            this.CC4 = new System.Windows.Forms.Button();
            this.CC2 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.JuMuList = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.CC_Insert = new System.Windows.Forms.Button();
            this.CC_Add = new System.Windows.Forms.Button();
            this.CC_Del = new System.Windows.Forms.Button();
            this.CC_Copy = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.JuMuMc = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.LaZCC = new System.Windows.Forms.Label();
            this.LaDQCC = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // CC1
            // 
            this.CC1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC1.Location = new System.Drawing.Point(9, 7);
            this.CC1.Name = "CC1";
            this.CC1.Size = new System.Drawing.Size(50, 50);
            this.CC1.TabIndex = 0;
            this.CC1.Text = "1";
            this.CC1.UseVisualStyleBackColor = true;
            this.CC1.Visible = false;
            this.CC1.Click += new System.EventHandler(this.CC1_Click);
            this.CC1.MouseHover += new System.EventHandler(this.CC1_MouseHover);
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(150, 126);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(30, 30);
            this.button49.TabIndex = 17;
            this.button49.Text = "b";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button13.Location = new System.Drawing.Point(12, 723);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(200, 70);
            this.button13.TabIndex = 25;
            this.button13.Text = "返回";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(105, 126);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(30, 30);
            this.button48.TabIndex = 16;
            this.button48.Text = "*";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(58, 126);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(30, 30);
            this.button47.TabIndex = 15;
            this.button47.Text = ".";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(13, 126);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(30, 30);
            this.button46.TabIndex = 14;
            this.button46.Text = "0";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(150, 86);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(30, 30);
            this.button45.TabIndex = 13;
            this.button45.Text = "b";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(150, 50);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(30, 30);
            this.button44.TabIndex = 12;
            this.button44.Text = "b";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(150, 14);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(30, 30);
            this.button43.TabIndex = 11;
            this.button43.Text = "b";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(105, 86);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(30, 30);
            this.button42.TabIndex = 10;
            this.button42.Text = "9";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(105, 50);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(30, 30);
            this.button41.TabIndex = 9;
            this.button41.Text = "6";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button16.Location = new System.Drawing.Point(1690, 723);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(200, 70);
            this.button16.TabIndex = 37;
            this.button16.Text = "回首页";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(105, 14);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(30, 30);
            this.button40.TabIndex = 8;
            this.button40.Text = "3";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.CC40);
            this.panel1.Controls.Add(this.CC41);
            this.panel1.Controls.Add(this.CC39);
            this.panel1.Controls.Add(this.CC38);
            this.panel1.Controls.Add(this.CC36);
            this.panel1.Controls.Add(this.CC37);
            this.panel1.Controls.Add(this.CC35);
            this.panel1.Controls.Add(this.CC34);
            this.panel1.Controls.Add(this.CC33);
            this.panel1.Controls.Add(this.CC31);
            this.panel1.Controls.Add(this.CC32);
            this.panel1.Controls.Add(this.CC30);
            this.panel1.Controls.Add(this.CC29);
            this.panel1.Controls.Add(this.CC27);
            this.panel1.Controls.Add(this.CC28);
            this.panel1.Controls.Add(this.CC26);
            this.panel1.Controls.Add(this.CC25);
            this.panel1.Controls.Add(this.CC23);
            this.panel1.Controls.Add(this.CC24);
            this.panel1.Controls.Add(this.CC22);
            this.panel1.Controls.Add(this.CC21);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.CC19);
            this.panel1.Controls.Add(this.CC20);
            this.panel1.Controls.Add(this.CC18);
            this.panel1.Controls.Add(this.CC17);
            this.panel1.Controls.Add(this.CC15);
            this.panel1.Controls.Add(this.CC16);
            this.panel1.Controls.Add(this.CC14);
            this.panel1.Controls.Add(this.CC13);
            this.panel1.Controls.Add(this.CC11);
            this.panel1.Controls.Add(this.CC12);
            this.panel1.Controls.Add(this.CC10);
            this.panel1.Controls.Add(this.CC9);
            this.panel1.Controls.Add(this.CC7);
            this.panel1.Controls.Add(this.CC8);
            this.panel1.Controls.Add(this.CC6);
            this.panel1.Controls.Add(this.CC5);
            this.panel1.Controls.Add(this.CC3);
            this.panel1.Controls.Add(this.CC4);
            this.panel1.Controls.Add(this.CC2);
            this.panel1.Controls.Add(this.button67);
            this.panel1.Controls.Add(this.CC1);
            this.panel1.Location = new System.Drawing.Point(475, 183);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1009, 420);
            this.panel1.TabIndex = 33;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // CC40
            // 
            this.CC40.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC40.Location = new System.Drawing.Point(501, 295);
            this.CC40.Name = "CC40";
            this.CC40.Size = new System.Drawing.Size(50, 50);
            this.CC40.TabIndex = 104;
            this.CC40.Text = "1";
            this.CC40.UseVisualStyleBackColor = true;
            this.CC40.Visible = false;
            this.CC40.Click += new System.EventHandler(this.CC40_Click);
            this.CC40.MouseHover += new System.EventHandler(this.CC40_MouseHover);
            // 
            // CC41
            // 
            this.CC41.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC41.Location = new System.Drawing.Point(583, 295);
            this.CC41.Name = "CC41";
            this.CC41.Size = new System.Drawing.Size(50, 50);
            this.CC41.TabIndex = 103;
            this.CC41.Text = "1";
            this.CC41.UseVisualStyleBackColor = true;
            this.CC41.Visible = false;
            this.CC41.Click += new System.EventHandler(this.CC41_Click);
            this.CC41.MouseHover += new System.EventHandler(this.CC41_MouseHover);
            // 
            // CC39
            // 
            this.CC39.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC39.Location = new System.Drawing.Point(419, 295);
            this.CC39.Name = "CC39";
            this.CC39.Size = new System.Drawing.Size(50, 50);
            this.CC39.TabIndex = 102;
            this.CC39.Text = "1";
            this.CC39.UseVisualStyleBackColor = true;
            this.CC39.Visible = false;
            this.CC39.Click += new System.EventHandler(this.CC39_Click);
            this.CC39.MouseHover += new System.EventHandler(this.CC39_MouseHover);
            // 
            // CC38
            // 
            this.CC38.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC38.Location = new System.Drawing.Point(337, 295);
            this.CC38.Name = "CC38";
            this.CC38.Size = new System.Drawing.Size(50, 50);
            this.CC38.TabIndex = 101;
            this.CC38.Text = "1";
            this.CC38.UseVisualStyleBackColor = true;
            this.CC38.Visible = false;
            this.CC38.Click += new System.EventHandler(this.CC38_Click);
            this.CC38.MouseHover += new System.EventHandler(this.CC38_MouseHover);
            // 
            // CC36
            // 
            this.CC36.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC36.Location = new System.Drawing.Point(173, 295);
            this.CC36.Name = "CC36";
            this.CC36.Size = new System.Drawing.Size(50, 50);
            this.CC36.TabIndex = 100;
            this.CC36.Text = "1";
            this.CC36.UseVisualStyleBackColor = true;
            this.CC36.Visible = false;
            this.CC36.Click += new System.EventHandler(this.CC36_Click);
            this.CC36.MouseHover += new System.EventHandler(this.CC36_MouseHover);
            // 
            // CC37
            // 
            this.CC37.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC37.Location = new System.Drawing.Point(255, 295);
            this.CC37.Name = "CC37";
            this.CC37.Size = new System.Drawing.Size(50, 50);
            this.CC37.TabIndex = 99;
            this.CC37.Text = "1";
            this.CC37.UseVisualStyleBackColor = true;
            this.CC37.Visible = false;
            this.CC37.Click += new System.EventHandler(this.CC37_Click);
            this.CC37.MouseHover += new System.EventHandler(this.CC37_MouseHover);
            // 
            // CC35
            // 
            this.CC35.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC35.Location = new System.Drawing.Point(91, 295);
            this.CC35.Name = "CC35";
            this.CC35.Size = new System.Drawing.Size(50, 50);
            this.CC35.TabIndex = 98;
            this.CC35.Text = "1";
            this.CC35.UseVisualStyleBackColor = true;
            this.CC35.Visible = false;
            this.CC35.Click += new System.EventHandler(this.CC35_Click);
            this.CC35.MouseHover += new System.EventHandler(this.CC35_MouseHover);
            // 
            // CC34
            // 
            this.CC34.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC34.Location = new System.Drawing.Point(9, 295);
            this.CC34.Name = "CC34";
            this.CC34.Size = new System.Drawing.Size(50, 50);
            this.CC34.TabIndex = 97;
            this.CC34.Text = "1";
            this.CC34.UseVisualStyleBackColor = true;
            this.CC34.Visible = false;
            this.CC34.Click += new System.EventHandler(this.CC34_Click);
            this.CC34.MouseHover += new System.EventHandler(this.CC34_MouseHover);
            // 
            // CC33
            // 
            this.CC33.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC33.Location = new System.Drawing.Point(665, 199);
            this.CC33.Name = "CC33";
            this.CC33.Size = new System.Drawing.Size(50, 50);
            this.CC33.TabIndex = 96;
            this.CC33.Text = "1";
            this.CC33.UseVisualStyleBackColor = true;
            this.CC33.Visible = false;
            this.CC33.Click += new System.EventHandler(this.CC33_Click);
            this.CC33.MouseHover += new System.EventHandler(this.CC33_MouseHover);
            // 
            // CC31
            // 
            this.CC31.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC31.Location = new System.Drawing.Point(501, 199);
            this.CC31.Name = "CC31";
            this.CC31.Size = new System.Drawing.Size(50, 50);
            this.CC31.TabIndex = 95;
            this.CC31.Text = "1";
            this.CC31.UseVisualStyleBackColor = true;
            this.CC31.Visible = false;
            this.CC31.Click += new System.EventHandler(this.CC31_Click);
            this.CC31.MouseHover += new System.EventHandler(this.CC31_MouseHover);
            // 
            // CC32
            // 
            this.CC32.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC32.Location = new System.Drawing.Point(583, 199);
            this.CC32.Name = "CC32";
            this.CC32.Size = new System.Drawing.Size(50, 50);
            this.CC32.TabIndex = 94;
            this.CC32.Text = "1";
            this.CC32.UseVisualStyleBackColor = true;
            this.CC32.Visible = false;
            this.CC32.Click += new System.EventHandler(this.CC32_Click);
            this.CC32.MouseHover += new System.EventHandler(this.CC32_MouseHover);
            // 
            // CC30
            // 
            this.CC30.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC30.Location = new System.Drawing.Point(419, 199);
            this.CC30.Name = "CC30";
            this.CC30.Size = new System.Drawing.Size(50, 50);
            this.CC30.TabIndex = 93;
            this.CC30.Text = "1";
            this.CC30.UseVisualStyleBackColor = true;
            this.CC30.Visible = false;
            this.CC30.Click += new System.EventHandler(this.CC30_Click);
            this.CC30.MouseHover += new System.EventHandler(this.CC30_MouseHover);
            // 
            // CC29
            // 
            this.CC29.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC29.Location = new System.Drawing.Point(337, 199);
            this.CC29.Name = "CC29";
            this.CC29.Size = new System.Drawing.Size(50, 50);
            this.CC29.TabIndex = 92;
            this.CC29.Text = "1";
            this.CC29.UseVisualStyleBackColor = true;
            this.CC29.Visible = false;
            this.CC29.Click += new System.EventHandler(this.CC29_Click);
            this.CC29.MouseHover += new System.EventHandler(this.CC29_MouseHover);
            // 
            // CC27
            // 
            this.CC27.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC27.Location = new System.Drawing.Point(173, 199);
            this.CC27.Name = "CC27";
            this.CC27.Size = new System.Drawing.Size(50, 50);
            this.CC27.TabIndex = 91;
            this.CC27.Text = "1";
            this.CC27.UseVisualStyleBackColor = true;
            this.CC27.Visible = false;
            this.CC27.Click += new System.EventHandler(this.CC27_Click);
            this.CC27.MouseHover += new System.EventHandler(this.CC27_MouseHover);
            // 
            // CC28
            // 
            this.CC28.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC28.Location = new System.Drawing.Point(255, 199);
            this.CC28.Name = "CC28";
            this.CC28.Size = new System.Drawing.Size(50, 50);
            this.CC28.TabIndex = 90;
            this.CC28.Text = "1";
            this.CC28.UseVisualStyleBackColor = true;
            this.CC28.Visible = false;
            this.CC28.Click += new System.EventHandler(this.CC28_Click);
            this.CC28.MouseHover += new System.EventHandler(this.CC28_MouseHover);
            // 
            // CC26
            // 
            this.CC26.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC26.Location = new System.Drawing.Point(91, 199);
            this.CC26.Name = "CC26";
            this.CC26.Size = new System.Drawing.Size(50, 50);
            this.CC26.TabIndex = 89;
            this.CC26.Text = "1";
            this.CC26.UseVisualStyleBackColor = true;
            this.CC26.Visible = false;
            this.CC26.Click += new System.EventHandler(this.CC26_Click);
            this.CC26.MouseHover += new System.EventHandler(this.CC26_MouseHover);
            // 
            // CC25
            // 
            this.CC25.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC25.Location = new System.Drawing.Point(9, 199);
            this.CC25.Name = "CC25";
            this.CC25.Size = new System.Drawing.Size(50, 50);
            this.CC25.TabIndex = 88;
            this.CC25.Text = "1";
            this.CC25.UseVisualStyleBackColor = true;
            this.CC25.Visible = false;
            this.CC25.Click += new System.EventHandler(this.CC25_Click);
            this.CC25.MouseHover += new System.EventHandler(this.CC25_MouseHover);
            // 
            // CC23
            // 
            this.CC23.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC23.Location = new System.Drawing.Point(829, 103);
            this.CC23.Name = "CC23";
            this.CC23.Size = new System.Drawing.Size(50, 50);
            this.CC23.TabIndex = 87;
            this.CC23.Text = "1";
            this.CC23.UseVisualStyleBackColor = true;
            this.CC23.Visible = false;
            this.CC23.Click += new System.EventHandler(this.CC23_Click);
            this.CC23.MouseHover += new System.EventHandler(this.CC23_MouseHover);
            // 
            // CC24
            // 
            this.CC24.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC24.Location = new System.Drawing.Point(911, 103);
            this.CC24.Name = "CC24";
            this.CC24.Size = new System.Drawing.Size(50, 50);
            this.CC24.TabIndex = 86;
            this.CC24.Text = "1";
            this.CC24.UseVisualStyleBackColor = true;
            this.CC24.Visible = false;
            this.CC24.Click += new System.EventHandler(this.CC24_Click);
            this.CC24.MouseHover += new System.EventHandler(this.CC24_MouseHover);
            // 
            // CC22
            // 
            this.CC22.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC22.Location = new System.Drawing.Point(747, 103);
            this.CC22.Name = "CC22";
            this.CC22.Size = new System.Drawing.Size(50, 50);
            this.CC22.TabIndex = 85;
            this.CC22.Text = "1";
            this.CC22.UseVisualStyleBackColor = true;
            this.CC22.Visible = false;
            this.CC22.Click += new System.EventHandler(this.CC22_Click);
            this.CC22.MouseHover += new System.EventHandler(this.CC22_MouseHover);
            // 
            // CC21
            // 
            this.CC21.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC21.Location = new System.Drawing.Point(665, 103);
            this.CC21.Name = "CC21";
            this.CC21.Size = new System.Drawing.Size(50, 50);
            this.CC21.TabIndex = 84;
            this.CC21.Text = "1";
            this.CC21.UseVisualStyleBackColor = true;
            this.CC21.Visible = false;
            this.CC21.Click += new System.EventHandler(this.CC21_Click);
            this.CC21.MouseHover += new System.EventHandler(this.CC21_MouseHover);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.button49);
            this.panel2.Controls.Add(this.button48);
            this.panel2.Controls.Add(this.button47);
            this.panel2.Controls.Add(this.button46);
            this.panel2.Controls.Add(this.button45);
            this.panel2.Controls.Add(this.button44);
            this.panel2.Controls.Add(this.button43);
            this.panel2.Controls.Add(this.button42);
            this.panel2.Controls.Add(this.button41);
            this.panel2.Controls.Add(this.button40);
            this.panel2.Controls.Add(this.button39);
            this.panel2.Controls.Add(this.button36);
            this.panel2.Controls.Add(this.button35);
            this.panel2.Controls.Add(this.button34);
            this.panel2.Controls.Add(this.button32);
            this.panel2.Controls.Add(this.button33);
            this.panel2.Controls.Add(this.button31);
            this.panel2.Location = new System.Drawing.Point(765, 199);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(195, 176);
            this.panel2.TabIndex = 28;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(58, 86);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(30, 30);
            this.button39.TabIndex = 7;
            this.button39.Text = "8";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(58, 50);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(30, 30);
            this.button36.TabIndex = 6;
            this.button36.Text = "5";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(58, 14);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(30, 30);
            this.button35.TabIndex = 5;
            this.button35.Text = "2";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(13, 86);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(30, 30);
            this.button34.TabIndex = 4;
            this.button34.Text = "7";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(13, 50);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(30, 30);
            this.button32.TabIndex = 3;
            this.button32.Text = "4";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(83, 0);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(0, 0);
            this.button33.TabIndex = 2;
            this.button33.Text = "button33";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(13, 14);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(30, 30);
            this.button31.TabIndex = 0;
            this.button31.Text = "1";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // CC19
            // 
            this.CC19.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC19.Location = new System.Drawing.Point(501, 103);
            this.CC19.Name = "CC19";
            this.CC19.Size = new System.Drawing.Size(50, 50);
            this.CC19.TabIndex = 83;
            this.CC19.Text = "1";
            this.CC19.UseVisualStyleBackColor = true;
            this.CC19.Visible = false;
            this.CC19.Click += new System.EventHandler(this.CC19_Click);
            this.CC19.MouseHover += new System.EventHandler(this.CC19_MouseHover);
            // 
            // CC20
            // 
            this.CC20.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC20.Location = new System.Drawing.Point(583, 103);
            this.CC20.Name = "CC20";
            this.CC20.Size = new System.Drawing.Size(50, 50);
            this.CC20.TabIndex = 82;
            this.CC20.Text = "1";
            this.CC20.UseVisualStyleBackColor = true;
            this.CC20.Visible = false;
            this.CC20.Click += new System.EventHandler(this.CC20_Click);
            this.CC20.MouseHover += new System.EventHandler(this.CC20_MouseHover);
            // 
            // CC18
            // 
            this.CC18.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC18.Location = new System.Drawing.Point(419, 103);
            this.CC18.Name = "CC18";
            this.CC18.Size = new System.Drawing.Size(50, 50);
            this.CC18.TabIndex = 81;
            this.CC18.Text = "1";
            this.CC18.UseVisualStyleBackColor = true;
            this.CC18.Visible = false;
            this.CC18.Click += new System.EventHandler(this.CC18_Click);
            this.CC18.MouseHover += new System.EventHandler(this.CC18_MouseHover);
            // 
            // CC17
            // 
            this.CC17.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC17.Location = new System.Drawing.Point(337, 103);
            this.CC17.Name = "CC17";
            this.CC17.Size = new System.Drawing.Size(50, 50);
            this.CC17.TabIndex = 80;
            this.CC17.Text = "1";
            this.CC17.UseVisualStyleBackColor = true;
            this.CC17.Visible = false;
            this.CC17.Click += new System.EventHandler(this.CC17_Click);
            this.CC17.MouseHover += new System.EventHandler(this.CC17_MouseHover);
            // 
            // CC15
            // 
            this.CC15.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC15.Location = new System.Drawing.Point(173, 103);
            this.CC15.Name = "CC15";
            this.CC15.Size = new System.Drawing.Size(50, 50);
            this.CC15.TabIndex = 79;
            this.CC15.Text = "1";
            this.CC15.UseVisualStyleBackColor = true;
            this.CC15.Visible = false;
            this.CC15.Click += new System.EventHandler(this.CC15_Click);
            this.CC15.MouseHover += new System.EventHandler(this.CC15_MouseHover);
            // 
            // CC16
            // 
            this.CC16.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC16.Location = new System.Drawing.Point(255, 103);
            this.CC16.Name = "CC16";
            this.CC16.Size = new System.Drawing.Size(50, 50);
            this.CC16.TabIndex = 78;
            this.CC16.Text = "1";
            this.CC16.UseVisualStyleBackColor = true;
            this.CC16.Visible = false;
            this.CC16.Click += new System.EventHandler(this.CC16_Click);
            this.CC16.MouseHover += new System.EventHandler(this.CC16_MouseHover);
            // 
            // CC14
            // 
            this.CC14.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC14.Location = new System.Drawing.Point(91, 103);
            this.CC14.Name = "CC14";
            this.CC14.Size = new System.Drawing.Size(50, 50);
            this.CC14.TabIndex = 77;
            this.CC14.Text = "1";
            this.CC14.UseVisualStyleBackColor = true;
            this.CC14.Visible = false;
            this.CC14.Click += new System.EventHandler(this.CC14_Click);
            this.CC14.MouseHover += new System.EventHandler(this.CC14_MouseHover);
            // 
            // CC13
            // 
            this.CC13.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC13.Location = new System.Drawing.Point(9, 103);
            this.CC13.Name = "CC13";
            this.CC13.Size = new System.Drawing.Size(50, 50);
            this.CC13.TabIndex = 76;
            this.CC13.Text = "1";
            this.CC13.UseVisualStyleBackColor = true;
            this.CC13.Visible = false;
            this.CC13.Click += new System.EventHandler(this.CC13_Click);
            this.CC13.MouseHover += new System.EventHandler(this.CC13_MouseHover);
            // 
            // CC11
            // 
            this.CC11.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC11.Location = new System.Drawing.Point(829, 7);
            this.CC11.Name = "CC11";
            this.CC11.Size = new System.Drawing.Size(50, 50);
            this.CC11.TabIndex = 75;
            this.CC11.Text = "1";
            this.CC11.UseVisualStyleBackColor = true;
            this.CC11.Visible = false;
            this.CC11.Click += new System.EventHandler(this.CC11_Click);
            this.CC11.MouseHover += new System.EventHandler(this.CC11_MouseHover);
            // 
            // CC12
            // 
            this.CC12.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC12.Location = new System.Drawing.Point(911, 7);
            this.CC12.Name = "CC12";
            this.CC12.Size = new System.Drawing.Size(50, 50);
            this.CC12.TabIndex = 74;
            this.CC12.Text = "1";
            this.CC12.UseVisualStyleBackColor = true;
            this.CC12.Visible = false;
            this.CC12.Click += new System.EventHandler(this.CC12_Click);
            this.CC12.MouseHover += new System.EventHandler(this.CC12_MouseHover);
            // 
            // CC10
            // 
            this.CC10.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC10.Location = new System.Drawing.Point(747, 7);
            this.CC10.Name = "CC10";
            this.CC10.Size = new System.Drawing.Size(50, 50);
            this.CC10.TabIndex = 73;
            this.CC10.Text = "1";
            this.CC10.UseVisualStyleBackColor = true;
            this.CC10.Visible = false;
            this.CC10.Click += new System.EventHandler(this.CC10_Click);
            this.CC10.MouseHover += new System.EventHandler(this.CC10_MouseHover);
            // 
            // CC9
            // 
            this.CC9.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC9.Location = new System.Drawing.Point(665, 7);
            this.CC9.Name = "CC9";
            this.CC9.Size = new System.Drawing.Size(50, 50);
            this.CC9.TabIndex = 72;
            this.CC9.Text = "1";
            this.CC9.UseVisualStyleBackColor = true;
            this.CC9.Visible = false;
            this.CC9.Click += new System.EventHandler(this.CC9_Click);
            this.CC9.MouseHover += new System.EventHandler(this.CC9_MouseHover);
            // 
            // CC7
            // 
            this.CC7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC7.Location = new System.Drawing.Point(501, 7);
            this.CC7.Name = "CC7";
            this.CC7.Size = new System.Drawing.Size(50, 50);
            this.CC7.TabIndex = 71;
            this.CC7.Text = "1";
            this.CC7.UseVisualStyleBackColor = true;
            this.CC7.Visible = false;
            this.CC7.Click += new System.EventHandler(this.CC7_Click);
            this.CC7.MouseHover += new System.EventHandler(this.CC7_MouseHover);
            // 
            // CC8
            // 
            this.CC8.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC8.Location = new System.Drawing.Point(583, 7);
            this.CC8.Name = "CC8";
            this.CC8.Size = new System.Drawing.Size(50, 50);
            this.CC8.TabIndex = 70;
            this.CC8.Text = "1";
            this.CC8.UseVisualStyleBackColor = true;
            this.CC8.Visible = false;
            this.CC8.Click += new System.EventHandler(this.CC8_Click);
            this.CC8.MouseHover += new System.EventHandler(this.CC8_MouseHover);
            // 
            // CC6
            // 
            this.CC6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC6.Location = new System.Drawing.Point(419, 7);
            this.CC6.Name = "CC6";
            this.CC6.Size = new System.Drawing.Size(50, 50);
            this.CC6.TabIndex = 69;
            this.CC6.Text = "1";
            this.CC6.UseVisualStyleBackColor = true;
            this.CC6.Visible = false;
            this.CC6.Click += new System.EventHandler(this.CC6_Click);
            this.CC6.MouseHover += new System.EventHandler(this.CC6_MouseHover);
            // 
            // CC5
            // 
            this.CC5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC5.Location = new System.Drawing.Point(337, 7);
            this.CC5.Name = "CC5";
            this.CC5.Size = new System.Drawing.Size(50, 50);
            this.CC5.TabIndex = 68;
            this.CC5.Text = "1";
            this.CC5.UseVisualStyleBackColor = true;
            this.CC5.Visible = false;
            this.CC5.Click += new System.EventHandler(this.CC5_Click);
            this.CC5.MouseHover += new System.EventHandler(this.CC5_MouseHover);
            // 
            // CC3
            // 
            this.CC3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC3.Location = new System.Drawing.Point(173, 7);
            this.CC3.Name = "CC3";
            this.CC3.Size = new System.Drawing.Size(50, 50);
            this.CC3.TabIndex = 67;
            this.CC3.Text = "1";
            this.CC3.UseVisualStyleBackColor = true;
            this.CC3.Visible = false;
            this.CC3.Click += new System.EventHandler(this.CC3_Click);
            this.CC3.MouseHover += new System.EventHandler(this.CC3_MouseHover);
            // 
            // CC4
            // 
            this.CC4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC4.Location = new System.Drawing.Point(255, 7);
            this.CC4.Name = "CC4";
            this.CC4.Size = new System.Drawing.Size(50, 50);
            this.CC4.TabIndex = 66;
            this.CC4.Text = "1";
            this.CC4.UseVisualStyleBackColor = true;
            this.CC4.Visible = false;
            this.CC4.Click += new System.EventHandler(this.CC4_Click);
            this.CC4.MouseHover += new System.EventHandler(this.CC4_MouseHover);
            // 
            // CC2
            // 
            this.CC2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC2.Location = new System.Drawing.Point(91, 7);
            this.CC2.Name = "CC2";
            this.CC2.Size = new System.Drawing.Size(50, 50);
            this.CC2.TabIndex = 65;
            this.CC2.Text = "1";
            this.CC2.UseVisualStyleBackColor = true;
            this.CC2.Visible = false;
            this.CC2.Click += new System.EventHandler(this.CC2_Click);
            this.CC2.MouseHover += new System.EventHandler(this.CC2_MouseHover);
            // 
            // button67
            // 
            this.button67.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button67.Location = new System.Drawing.Point(665, 298);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(50, 50);
            this.button67.TabIndex = 64;
            this.button67.Text = "返场";
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // JuMuList
            // 
            this.JuMuList.FormattingEnabled = true;
            this.JuMuList.ItemHeight = 16;
            this.JuMuList.Location = new System.Drawing.Point(294, 185);
            this.JuMuList.Margin = new System.Windows.Forms.Padding(4);
            this.JuMuList.Name = "JuMuList";
            this.JuMuList.ScrollAlwaysVisible = true;
            this.JuMuList.Size = new System.Drawing.Size(184, 324);
            this.JuMuList.TabIndex = 28;
            this.JuMuList.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Enabled = false;
            this.button2.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(294, 132);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(184, 48);
            this.button2.TabIndex = 26;
            this.button2.Text = "剧目";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(683, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 27);
            this.label1.TabIndex = 24;
            this.label1.Text = "剧目设置";
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button17.Enabled = false;
            this.button17.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button17.Location = new System.Drawing.Point(971, 132);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(157, 48);
            this.button17.TabIndex = 38;
            this.button17.Text = "总场次";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button19.Enabled = false;
            this.button19.Font = new System.Drawing.Font("宋体", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button19.Location = new System.Drawing.Point(1223, 132);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(164, 48);
            this.button19.TabIndex = 40;
            this.button19.Text = "当前场次";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.CC_Insert);
            this.panel4.Controls.Add(this.CC_Add);
            this.panel4.Controls.Add(this.CC_Del);
            this.panel4.Controls.Add(this.CC_Copy);
            this.panel4.Location = new System.Drawing.Point(294, 603);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1190, 64);
            this.panel4.TabIndex = 35;
            // 
            // CC_Insert
            // 
            this.CC_Insert.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC_Insert.Location = new System.Drawing.Point(620, 13);
            this.CC_Insert.Name = "CC_Insert";
            this.CC_Insert.Size = new System.Drawing.Size(101, 37);
            this.CC_Insert.TabIndex = 5;
            this.CC_Insert.Text = "插入";
            this.CC_Insert.UseVisualStyleBackColor = true;
            this.CC_Insert.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // CC_Add
            // 
            this.CC_Add.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC_Add.Location = new System.Drawing.Point(482, 13);
            this.CC_Add.Name = "CC_Add";
            this.CC_Add.Size = new System.Drawing.Size(101, 37);
            this.CC_Add.TabIndex = 4;
            this.CC_Add.Text = "添加";
            this.CC_Add.UseVisualStyleBackColor = true;
            this.CC_Add.Click += new System.EventHandler(this.button56_Click);
            // 
            // CC_Del
            // 
            this.CC_Del.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC_Del.Location = new System.Drawing.Point(758, 13);
            this.CC_Del.Name = "CC_Del";
            this.CC_Del.Size = new System.Drawing.Size(101, 37);
            this.CC_Del.TabIndex = 3;
            this.CC_Del.Text = "删除";
            this.CC_Del.UseVisualStyleBackColor = true;
            this.CC_Del.Click += new System.EventHandler(this.button11_Click);
            // 
            // CC_Copy
            // 
            this.CC_Copy.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CC_Copy.Location = new System.Drawing.Point(344, 13);
            this.CC_Copy.Name = "CC_Copy";
            this.CC_Copy.Size = new System.Drawing.Size(101, 37);
            this.CC_Copy.TabIndex = 0;
            this.CC_Copy.Text = "复制";
            this.CC_Copy.UseVisualStyleBackColor = true;
            this.CC_Copy.Click += new System.EventHandler(this.button12_Click);
            // 
            // button55
            // 
            this.button55.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button55.Location = new System.Drawing.Point(485, 740);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(101, 37);
            this.button55.TabIndex = 44;
            this.button55.Text = "场景";
            this.button55.UseVisualStyleBackColor = true;
            this.button55.Click += new System.EventHandler(this.button55_Click);
            // 
            // button57
            // 
            this.button57.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button57.Location = new System.Drawing.Point(844, 740);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(101, 37);
            this.button57.TabIndex = 45;
            this.button57.Text = "导入";
            this.button57.UseVisualStyleBackColor = true;
            // 
            // button69
            // 
            this.button69.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button69.Location = new System.Drawing.Point(971, 740);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(101, 37);
            this.button69.TabIndex = 46;
            this.button69.Text = "导出";
            this.button69.UseVisualStyleBackColor = true;
            // 
            // button70
            // 
            this.button70.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button70.Location = new System.Drawing.Point(1241, 740);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(101, 37);
            this.button70.TabIndex = 47;
            this.button70.Text = "保存";
            this.button70.UseVisualStyleBackColor = true;
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(294, 529);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(184, 36);
            this.button71.TabIndex = 49;
            this.button71.Text = "添加剧目";
            this.button71.UseVisualStyleBackColor = true;
            this.button71.Click += new System.EventHandler(this.button71_Click_1);
            // 
            // JuMuMc
            // 
            this.JuMuMc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.JuMuMc.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.JuMuMc.Location = new System.Drawing.Point(478, 132);
            this.JuMuMc.Name = "JuMuMc";
            this.JuMuMc.Size = new System.Drawing.Size(493, 48);
            this.JuMuMc.TabIndex = 50;
            this.JuMuMc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.JuMuMc.Click += new System.EventHandler(this.JuMuMc_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(294, 565);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(184, 36);
            this.button6.TabIndex = 51;
            this.button6.Text = "删除剧目";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // LaZCC
            // 
            this.LaZCC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LaZCC.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LaZCC.Location = new System.Drawing.Point(1133, 132);
            this.LaZCC.Name = "LaZCC";
            this.LaZCC.Size = new System.Drawing.Size(87, 48);
            this.LaZCC.TabIndex = 52;
            this.LaZCC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LaDQCC
            // 
            this.LaDQCC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LaDQCC.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LaDQCC.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.LaDQCC.Location = new System.Drawing.Point(1392, 132);
            this.LaDQCC.Name = "LaDQCC";
            this.LaDQCC.Size = new System.Drawing.Size(92, 48);
            this.LaDQCC.TabIndex = 53;
            this.LaDQCC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jumu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.LaDQCC);
            this.Controls.Add(this.LaZCC);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.JuMuMc);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.JuMuList);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "jumu";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.jumu_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button CC1;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.ListBox JuMuList;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button CC_Del;
        private System.Windows.Forms.Button CC_Copy;
        private System.Windows.Forms.Button CC33;
        private System.Windows.Forms.Button CC31;
        private System.Windows.Forms.Button CC32;
        private System.Windows.Forms.Button CC30;
        private System.Windows.Forms.Button CC29;
        private System.Windows.Forms.Button CC27;
        private System.Windows.Forms.Button CC28;
        private System.Windows.Forms.Button CC26;
        private System.Windows.Forms.Button CC25;
        private System.Windows.Forms.Button CC23;
        private System.Windows.Forms.Button CC24;
        private System.Windows.Forms.Button CC22;
        private System.Windows.Forms.Button CC21;
        private System.Windows.Forms.Button CC19;
        private System.Windows.Forms.Button CC20;
        private System.Windows.Forms.Button CC18;
        private System.Windows.Forms.Button CC17;
        private System.Windows.Forms.Button CC15;
        private System.Windows.Forms.Button CC16;
        private System.Windows.Forms.Button CC14;
        private System.Windows.Forms.Button CC13;
        private System.Windows.Forms.Button CC11;
        private System.Windows.Forms.Button CC12;
        private System.Windows.Forms.Button CC10;
        private System.Windows.Forms.Button CC9;
        private System.Windows.Forms.Button CC7;
        private System.Windows.Forms.Button CC8;
        private System.Windows.Forms.Button CC6;
        private System.Windows.Forms.Button CC5;
        private System.Windows.Forms.Button CC3;
        private System.Windows.Forms.Button CC4;
        private System.Windows.Forms.Button CC2;
        private System.Windows.Forms.Button CC_Add;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Label JuMuMc;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label LaZCC;
        private System.Windows.Forms.Label LaDQCC;
        private System.Windows.Forms.Button CC40;
        private System.Windows.Forms.Button CC41;
        private System.Windows.Forms.Button CC39;
        private System.Windows.Forms.Button CC38;
        private System.Windows.Forms.Button CC36;
        private System.Windows.Forms.Button CC37;
        private System.Windows.Forms.Button CC35;
        private System.Windows.Forms.Button CC34;
        private System.Windows.Forms.Button CC_Insert;
    }
}